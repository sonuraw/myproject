UPDATE report.LimitArchive RLA 
JOIN rg_limit.rg_category RG ON RLA.CategoryId = RG.id  
SET RLA.CategoryType = RG.label;

UPDATE report.PlayerAppliedLimit PAL 
JOIN rg_limit.rg_category RG ON PAL.CategoryId = RG.id COLLATE utf8_unicode_ci 
SET PAL.CategoryType = RG.label;
