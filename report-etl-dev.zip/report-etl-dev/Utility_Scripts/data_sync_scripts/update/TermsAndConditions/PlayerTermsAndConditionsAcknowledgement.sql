UPDATE report.PlayerTermsAndConditionsAcknowledgement RPTC 
    JOIN profile.user_acknowledgment PUA ON RPTC.CreatedAt = PUA.acknowledgment_date AND RPTC.PlayerId = PUA.user_id 
    JOIN profile.terms_and_conditions PTC ON PUA.data = PTC.id
SET RPTC.Revision = PTC.revision;

UPDATE PlayerTermsAndConditionsAcknowledgementArchive PTCA 
JOIN PlayerTermsAndConditionsAcknowledgement PTC ON PTCA.PlayerId = PTC.PlayerId 
SET PTCA.Revision = PTC.Revision;
