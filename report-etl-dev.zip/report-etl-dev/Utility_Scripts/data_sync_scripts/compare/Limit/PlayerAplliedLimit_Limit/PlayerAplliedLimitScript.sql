SELECT count(*) AS record_count 
FROM report.EtlServiceErrorLog 
WHERE Topic = "limit" AND Type = "limit-applied";
