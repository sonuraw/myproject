#!/bin/sh
cd /home/app && npm start