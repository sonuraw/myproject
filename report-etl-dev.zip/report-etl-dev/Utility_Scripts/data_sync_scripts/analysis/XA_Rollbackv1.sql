DROP PROCEDURE IF EXISTS `XA_Rollback_TranId`;
DELIMITER $$
CREATE PROCEDURE `XA_Rollback_TranId`()
BEGIN 

DECLARE done INT DEFAULT FALSE;
DECLARE fetch_formatID TEXT;
DECLARE fetch_gtrid_length TEXT;
DECLARE fetch_bqual_length TEXT;
DECLARE fetch_data TEXT;
DECLARE retentionInterval INT DEFAULT (SELECT IdentifierValue FROM  XaTranIdSettings WHERE Identifier='TimeInterval' limit 1);
DECLARE XaInitial CURSOR FOR SELECT * FROM InitialPartitionView; 
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

DROP VIEW IF EXISTS InitialPartitionView;
#CREATE VIEW InitialPartitionView as XA RECOVER;
CREATE VIEW InitialPartitionView as SELECT Id,PlayerId,OperatorId,GameId FROM TransactionSummary  LIMIT 1;

OPEN XaInitial;
 
  XaInitialRollback: LOOP
  
    FETCH XaInitial INTO fetch_formatID,fetch_gtrid_length,fetch_bqual_length,fetch_data;
     
   
    IF done THEN
      LEAVE XaInitialRollback;
    END IF;
    
    #select fetch_formatID,fetch_gtrid_length,fetch_bqual_length,fetch_data;
    SET fetch_formatID=1096044365;
    SET fetch_gtrid_length=30;
    SET fetch_bqual_length=17;
    SET fetch_data='10.0.0.41.tm15247601764570889810.0.0.41.tm17656';
    #select fetch_formatID,fetch_gtrid_length,fetch_bqual_length,fetch_data;
    
    #SELECT SUBSTRING('10.0.0.41.tm15247601764570889810.0.0.41.tm17656', 0, -30);
    
    SET @firstPart=NULL;
    SET @secondPart=Null;
    SET @firstPart=(SUBSTRING(fetch_data, 1, fetch_gtrid_length));
    SET @secondPart=(SUBSTRING(fetch_data, 1, fetch_bqual_length));
    #select @firstPart;
    #select @secondPart;
    
    SET @jmsPresent=0;
    SELECT Id INTO @jmsPresent FROM JmsMessageDetails WHERE XATranId=fetch_data AND UpdatedDate>(now() + INTERVAL retentionInterval MINUTE);
    
    IF(@jmsPresent>0)THEN
      #XA ROLLBACK @firstPart,@secondPart,fetch_formatID;
      SET @select_detail_query = NULL; 
      SET @select_detail_query = CONCAT_WS("",@select_detail_query,"XA ROLLBACK '",@firstPart,"','","','",@secondPart,"','",fetch_formatID,"'");
      PREPARE selectQuery FROM @select_detail_query;
	  EXECUTE selectQuery;
	  DEALLOCATE PREPARE selectQuery;
    END IF;
    
    
  END LOOP;

  CLOSE XaInitial;


END$$
DELIMITER ;

call XA_Rollback_TranId();

