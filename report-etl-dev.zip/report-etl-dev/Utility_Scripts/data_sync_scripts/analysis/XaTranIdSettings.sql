DROP TABLE IF EXISTS `XaTranIdSettings`;
CREATE TABLE `XaTranIdSettings` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Identifier` varchar(100) COLLATE utf8_bin NOT NULL,
  `IdentifierValue` varchar(75) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`Id`)
);

INSERT INTO `XaTranIdSettings` (`Identifier`,`IdentifierValue` ) VALUES ('TimeInterval',5);