* If there is any lock acquisition happened in report DB without any queries running in the background
(this can be confirmed by using SHOW FULL PROCESSLIST), 
one of the possibility could be XA lock . 

* To confirm this, please use the following steps (require root access for some of the queries)

    `SELECT * FROM INFORMATION_SCHEMA.INNODB_TRX;`

|trx_id|trx_state|trx_started|trx_requested_lock_id|trx_wait_started|trx_weight|trx_mysql_thread_id|trx_query|trx_operation_state|trx_tables_in_use|trx_tables_locked|trx_lock_structs|trx_lock_memory_bytes|trx_rows_locked|trx_rows_modified|trx_concurrency_tickets|trx_isolation_level|trx_unique_checks|trx_foreign_key_checks|trx_last_foreign_key_error|trx_adaptive_hash_latched|trx_adaptive_hash_timeout|trx_is_read_only|trx_autocommit_non_locking|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|39572728|RUNNING|2018-04-26 16:29:36|\N|\N|2|0|\N|\N|0|0|0|1136|1|2|0|REPEATABLE READ|1|1|\N|0|0|0|0|

* look for trx_mysql_thread_id column in the query and also the trx_started
SELECT trx_mysql_thread_id FROM INFORMATION_SCHEMA.INNODB_TRX;

* If the time-diff b/w trx_started and the current time is longer than usual, then it could be locking thread.

* If trx_mysql_thread_id is having values other than 0 , please use it to kill the running query, using `KILL ${trx_mysql_thread_id}`

* If it is 0, check the output of `XA RECOVER;`

|formatID|	gtrid_length|	bqual_length|	data|
|---|---|---|---|
|1096044365|	30|	17|	10.0.0.41.tm15247601764570889810.0.0.41.tm17656|


* As of now, we don't know how to link these 2 tables, that yet to be identified.
So we needs to be very careful before proceeding to kill the lock thread based on XA RECOVER, otherwise we may end up in killing the running queries.
One option to make sure is, no XA related services is connected to report DB.

* if the count of both `XA RECOVER;` matches with `SELECT * FROM INFORMATION_SCHEMA.INNODB_TRX;` we can go ahead.

* these locked XA transactions needs to be rollbacked to release the lock.
`XA ROLLBACK '10.0.0.156.tm152464877833003128','10.0.0.156.tm6240',1096044365;`

* In the above `XA ROLLBACK`, the first arg is the substring of XA RECOVER result set - data column (SUSTRING(data, 0, grid_length))
Second arg is the remaining value from data col, which it's length equals to bqual_length
Third arg is formatID.
  
