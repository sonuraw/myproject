SELECT count(*) as missing_count
FROM  exclusion.exclusion
WHERE createdAt between :createdFrom and :createdTo
AND exclusionId NOT IN (SELECT ID FROM report.SelfExclusion);