select count(*) as missing_count from game_manager.game_partner where created_at between :createdFrom and :createdTo AND
id collate utf8_unicode_ci
not in (select id from report.GameProviders);