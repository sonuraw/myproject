select count(*) as missing_count
from game_manager.game a
inner join game_manager.game_sub_category b on a.game_sub_category_id = b.id 
inner join game_manager.game_category c on c.id = b.game_category_id 
inner join game_manager.game_partner d on a.game_partner_id = d.id and d.operator = a.operator 
inner join game_manager.game_type e on a.game_type_id = e.id
where a.created_at between :createdFrom and :createdTo AND a.id collate utf8_unicode_ci
not in (select GameId from report.GameDetails);