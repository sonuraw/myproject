select count(*) as missing_count from game_manager.game_category
WHERE game_manager.game_category.created_at between :createdFrom and :createdTo AND id collate utf8_unicode_ci
not in (select id from report.GameCategories);