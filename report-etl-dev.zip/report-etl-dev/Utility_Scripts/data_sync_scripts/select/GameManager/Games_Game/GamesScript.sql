select count(*) as missing_count from game_manager.game a
inner join game_manager.game_sub_category b on a.game_sub_category_id = b.id
where a.created_at between :createdFrom and :createdTo AND a.id collate utf8_unicode_ci
not in (select id from report.Games);