SELECT count(*) as missing_count
FROM teams_and_leagues.team_player ttp 
WHERE ttp.creation_date between :createdFrom and :createdTo
AND ttp.id COLLATE utf8_unicode_ci NOT IN (SELECT Id FROM `report`.`TeamPlayer`);
