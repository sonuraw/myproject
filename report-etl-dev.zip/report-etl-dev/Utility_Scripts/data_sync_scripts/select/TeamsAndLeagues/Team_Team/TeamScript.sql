SELECT count(*) as missing_count
FROM teams_and_leagues.team tt
WHERE tt.creation_date between :createdFrom and :createdTo
AND tt.id COLLATE utf8_unicode_ci NOT IN (SELECT Id FROM `report`.`Team`);
