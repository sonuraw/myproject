SELECT count(*) as missing_count
FROM teams_and_leagues.league tl
WHERE tl.creation_date between :createdFrom and :createdTo
AND tl.id COLLATE utf8_unicode_ci NOT IN (SELECT Id FROM `report`.`League`);
