select (Select count(id) from gvi.wager Where created_at between :createdFrom and :createdTo)
-
(SELECT count(id)
FROM gvi.wager where created_at between :createdFrom and :createdTo
AND id in (SELECT Id FROM report.Wager)) as missing_count;