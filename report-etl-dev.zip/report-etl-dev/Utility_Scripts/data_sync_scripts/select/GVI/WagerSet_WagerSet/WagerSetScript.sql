select (Select count(id) from gvi.wager_set Where created_at between :createdFrom and :createdTo)
-
(SELECT count(id)
FROM gvi.wager_set where created_at between :createdFrom and :createdTo
AND id in (SELECT Id FROM report.WagerSet)) as missing_count;
