select (Select count(id) from gvi.winning Where created_at between :createdFrom and :createdTo)
-
(SELECT count(id)
FROM gvi.winning where created_at between :createdFrom and :createdTo AND
id in (SELECT Id FROM report.Winning)) as missing_count;