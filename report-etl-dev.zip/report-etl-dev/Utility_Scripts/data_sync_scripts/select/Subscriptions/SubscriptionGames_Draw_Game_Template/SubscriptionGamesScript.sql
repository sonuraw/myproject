SELECT count(*) as missing_count
FROM subscriptions.draw_game_template sdgt
WHERE sdgt.draw_game_template_id COLLATE utf8_unicode_ci NOT IN (SELECT DrawGameTemplateId FROM report.SubscriptionGames);
-- todo