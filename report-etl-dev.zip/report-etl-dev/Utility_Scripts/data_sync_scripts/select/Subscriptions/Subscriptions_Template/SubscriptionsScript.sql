SELECT count(*) as missing_count
FROM subscriptions.template st 
WHERE st.created_at between :createdFrom and :createdTo AND
st.id COLLATE utf8_unicode_ci NOT IN (SELECT Id FROM report.Subscriptions);