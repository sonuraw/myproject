select (Select count(uuid) from profile.user Where register_date between :createdFrom and :createdTo)
-
(SELECT count(uuid)
FROM profile.user where register_date between :createdFrom and :createdTo AND uuid collate utf8_unicode_ci in (SELECT Id FROM report.PlayerProfile)) as missing_count;

-- TODO