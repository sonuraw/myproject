select (Select count(id) from profile.user_payment_method Where creation_date between :createdFrom and :createdTo)
-
(SELECT count(id)
FROM profile.user_payment_method where creation_date between :createdFrom and :createdTo AND id in (SELECT Id FROM report.PlayerPaymentMethod)) as missing_count;