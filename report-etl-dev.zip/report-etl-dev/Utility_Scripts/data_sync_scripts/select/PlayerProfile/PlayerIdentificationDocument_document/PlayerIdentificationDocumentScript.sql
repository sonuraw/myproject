select (Select count(id) from profile.user_identification)
-
(SELECT count(id)
FROM profile.user_identification where id in (SELECT Id FROM report.PlayerIdentificationDocument)) as missing_count;
-- TODO