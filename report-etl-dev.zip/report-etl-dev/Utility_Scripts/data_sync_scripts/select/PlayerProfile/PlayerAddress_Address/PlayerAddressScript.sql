select (Select count(id) from profile.user_address)
-
(SELECT count(id)
FROM profile.user_address where id in (SELECT Id FROM report.PlayerAddress)) as missing_count;

-- TODO