select (Select count(user_id) from profile.user_affiliation)
-
(SELECT count(id)
FROM profile.user_affiliation acu        
        LEFT JOIN
    profile.user u ON u.id = acu.user_id where u.uuid COLLATE utf8_unicode_ci in (SELECT PlayerId FROM report.PlayerAffiliate)) as missing_count;

-- TODO