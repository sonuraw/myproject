select (Select count(txID) from transactions.transactions Where created_at between :createdFrom and :createdTo)
-
(SELECT count(txID)
FROM transactions.transactions where created_at between :createdFrom and :createdTo AND txID in (SELECT TranId FROM report.PlayerTransaction)) as missing_count;