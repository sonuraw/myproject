select (Select count(id) from profile.user_card Where creation_date between :createdFrom and :createdTo)
-
(SELECT count(id)
FROM profile.user_card where creation_date between :createdFrom and :createdTo AND id in (SELECT Id FROM report.PlayerCard)) as missing_count;