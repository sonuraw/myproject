select (Select count(id) from profile.user_comment Where creation_date between :createdFrom and :createdTo)
-
(SELECT count(id)
FROM profile.user_comment Where creation_date between :createdFrom and :createdTo AND id in (SELECT Id FROM report.PlayerComment)) as missing_count;