select (Select count(uid) from profile.session)
-
(SELECT count(uid)
FROM profile.session where uid collate utf8_unicode_ci in (SELECT SessionId FROM report.PlayerSession)) as missing_count;

-- TODO