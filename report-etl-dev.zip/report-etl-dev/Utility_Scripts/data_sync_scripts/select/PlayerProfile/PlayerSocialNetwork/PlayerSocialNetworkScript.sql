select (Select count(user_id) from profile.social_network Where creation_date between :createdFrom and :createdTo)
-
(SELECT count(user_id)
FROM profile.social_network 
INNER JOIN profile.user ON profile.social_network.user_id = profile.user.id
INNER JOIN profile.website ON profile.user.website_origin_id= website.id
Where profile.social_network.creation_date between :createdFrom and :createdTo AND CONCAT_WS('_', profile.social_network.user_id,profile.website.code, profile.social_network.network)
COLLATE utf8_unicode_ci IN (SELECT CONCAT_WS('_',PlayerId,OperatorId, network) FROM report.PlayerSocialNetwork )) as missing_count;