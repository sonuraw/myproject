select (Select count(id) from profile.user_phone)
-
(SELECT count(id)
FROM profile.user_phone where id in (SELECT Id FROM report.PlayerPhone)) as missing_count;

-- TODO