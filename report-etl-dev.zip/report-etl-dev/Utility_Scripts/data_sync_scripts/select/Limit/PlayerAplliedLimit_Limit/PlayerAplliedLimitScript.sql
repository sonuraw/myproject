SELECT count(*) as missing_count
FROM rg_limit.rg_limit WHERE rg_limit.rg_limit.createdAt between :createdFrom and :createdTo
AND rg_limit.rg_limit.Id COLLATE utf8_unicode_ci NOT IN
    (SELECT report.PlayerAppliedLimit.LimitId FROM report.PlayerAppliedLimit );