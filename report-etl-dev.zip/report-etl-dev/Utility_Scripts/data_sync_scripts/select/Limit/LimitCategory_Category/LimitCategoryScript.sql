SELECT count(*) as missing_count
FROM rg_limit.rg_category 
WHERE createdAt between :createdFrom and :createdTo AND
Id COLLATE utf8_unicode_ci NOT IN (SELECT CategoryId FROM report.LimitCategory);