SELECT 
    COUNT(*) AS missing_count
FROM
    profile.acl_country_user acu
        LEFT JOIN
    profile.user_admin ON acu.user_id = profile.user_admin.user_id
        LEFT JOIN
    profile.user u ON u.id = acu.user_id
        LEFT JOIN
    profile.country c ON c.iso = acu.country_iso
WHERE
    u.uuid COLLATE utf8_unicode_ci NOT IN (SELECT 
            AgentId COLLATE utf8_unicode_ci
        FROM
            report.AgentCountryList)
        AND c.alpha_iso2 NOT IN (SELECT 
            CountryId COLLATE utf8_unicode_ci
        FROM
            report.AgentCountryList);

-- TODO