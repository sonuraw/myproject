select 
    count(*) as missing_count
from profile.user a 
inner join profile.user_admin on a.id = profile.user_admin.user_id 
where a.register_date between :createdFrom and :createdTo AND uuid collate utf8_unicode_ci not in
    (select id collate utf8_unicode_ci from report.AgentProfile);