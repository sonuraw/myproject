SELECT 
    COUNT(*) AS missing_count
FROM
    profile.acl_credential acu
        LEFT JOIN
    profile.user_admin ON acu.user_id = profile.user_admin.user_id
        LEFT JOIN
    profile.user u ON u.id = acu.user_id        
WHERE
    u.uuid COLLATE utf8_unicode_ci NOT IN (SELECT 
            AgentId COLLATE utf8_unicode_ci
        FROM
            report.AgentPermission)
        AND acu.right_code NOT IN (SELECT 
            CredentialCode COLLATE utf8_unicode_ci
        FROM
            report.AgentPermission);

-- TODO