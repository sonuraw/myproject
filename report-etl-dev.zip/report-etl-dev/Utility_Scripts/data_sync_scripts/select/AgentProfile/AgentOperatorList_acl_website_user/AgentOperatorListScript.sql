SELECT 
    COUNT(*) AS missing_count
FROM
    profile.acl_website_user awu
        LEFT JOIN
    profile.user_admin ON awu.user_id = profile.user_admin.user_id
        LEFT JOIN
    profile.user u ON u.id = awu.user_id
        LEFT JOIN
    profile.website w ON w.id = awu.website_id
WHERE
    u.uuid COLLATE utf8_unicode_ci NOT IN (SELECT 
            AgentId COLLATE utf8_unicode_ci
        FROM
            report.AgentOperatorList)
        AND w.code NOT IN (SELECT 
            OperatorId COLLATE utf8_unicode_ci
        FROM
            report.AgentOperatorList);

-- TODO