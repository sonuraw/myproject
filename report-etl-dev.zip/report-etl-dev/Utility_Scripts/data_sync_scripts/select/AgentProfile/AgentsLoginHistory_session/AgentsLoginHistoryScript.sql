SELECT 
    COUNT(*) AS missing_count
FROM
    profile.session s        
WHERE
    s.uid COLLATE utf8_unicode_ci NOT IN (SELECT 
            SessionId COLLATE utf8_unicode_ci
        FROM
            report.AgentsLoginHistory);

-- todo