-- Subscriptions diff check query between scs and report DB
SELECT 
id, 
player_id, 
operator_id, 
effective_date,
updated_at,
created_at, 
total_cost_per_week, 
template_state, 
bs_agreement_id, 
funding_payment_method_id,
payout_payment_method_id,
comment,
author,
funding_payment_method_type,
updated_at,
add_on,
on_hold_until,
CASE(gap_funding_payment_method_id) WHEN "" THEN 0 ELSE 1 END,
gap_funding_payment_method_id
FROM subscriptions.template st 
WHERE st.id COLLATE utf8_unicode_ci NOT IN (select Id from report.Subscriptions);


-- Wager diff check query between scs and report DB
SELECT 
id,
"wager",
player_id,
wager_set_id,
external_id,
brand,
game,
type,
sub_url,
channel,
state,
updated_at,
created_at,
external_created_time,
amount,
notify_win,
round_id,
expected_end_date,
"real-money",
"DKK",
operator_id
FROM gvi.wager gw 
WHERE gw.id COLLATE utf8_unicode_ci NOT IN (SELECT Id FROM report.Wager);


-- Win diff check query between scs and report DB
SELECT id AS Id,
	NULL AS EventType, -- no relevant column
	player_id AS PlayerId,
	operator_id AS OperatorId,
	wager_id AS WagerId,
	TYPE AS TYPE,  -- IN REPORT, ITS RESERVATION , IN GVI IT'S just win
	NULL AS ExternalURL,
	state AS State,
	CONVERT( (amount/1000), SIGNED) AS VALUE,  -- is this correct?
	updated_at AS UpdatedDate,
	created_at AS CreationDate,
	0 AS PlayerCardPrize,
	0 AS RollbackPrizes,
	external_checked_time AS ExternalCreationDate
FROM gvi.winning WHERE id NOT IN (SELECT Id FROM report.Winning) order by id desc;


-- Player Transaction diff check query between scs and report DB
SELECT * FROM transactions.transactions tt 
where ledger in (
'offline',
'PROMOTION_OPENBET',
'real-money',
'RESTRICTED_BWIN_BONUS',
'RESTRICTED_BWIN_POKER_WINNINGS',
'EXCEPTIONAL_WINS'
)
and tt.created_at > "2018-05-01" 
and tt.id not in (select TranId from report.PlayerTransaction) order by tt.created_at desc;


-- Subscription Transaction diff check query between scs and report DB
SELECT * FROM transactions.transactions tt 
where ledger not in (
'offline',
'PROMOTION_OPENBET',
'real-money',
'RESTRICTED_BWIN_BONUS',
'RESTRICTED_BWIN_POKER_WINNINGS',
'EXCEPTIONAL_WINS'
)
and tt.created_at > "2018-05-01" 
and tt.id not in (select TransactionId from report.SubscriptionTransactions) order by tt.created_at desc;

-- Ledger Type diff check query between scs and report DB
select * from subscriptions.template t left join report.LedgerType l on t.id = l.MoneyType where l.MoneyType is null;

-- Ledger Type Sync Query
INSERT INTO `report`.`LedgerType`
(`MoneyType`,
`DisplayName`,
`PlayerId`,
`Operator`,
`Type`,
`IsStatic`,
`Owner`) 
select t.id, t.id, NULL, "DLO", NULL, 0, "subscription" from subscriptions.template t left join report.LedgerType l on CAST(t.id as CHAR(50)) = l.MoneyType where l.MoneyType is null;

-- Player Transaction to Subscription Transaction Sync Query
INSERT INTO `report`.`SubscriptionTransactions`
(`TransactionId`,
`PlayerId`,
`OperatorId`,
`TransactionDate`,
`TransactionType`,
`SubscriptionId`,
`Amount`,
`BalanceBefore`,
`BalanceAfter`,
`PaymentMethodId`,
`Status`,
`AuthorId`,
`AuthorIp`,
`AuthorSessionId`,
`AuthorType`,
`Comment`,
`WagerSetId`,
`PurchaseId`,
`GameId`,
`Numbers`,
`WinId`,
`ExternalId`,
`ExternalWagerId`,
`LinkedTransactionId`,
`BankName`,
`CardNumberLastFour`,
`CardType`,
`AccountType`,
`AccountNumber`,
`Channel`,
`Currency`,
`ExternalCreatedDate`,
`SubType`,
`ExternalUrl`,
`ApprovedDate`,
`ApprovedBy`,
`UpdatedDate`,
`WithdrawalProcessedDate`,
`IsNationalAccount`,
`IsReprocessed`,
`ReprocessedDate`,
`WalletUpdatedDate`,
`GviPreviousState`,
`GviState`,
`GviStateUpdatedAt`,
`EventId`,
`EventCreatedAt`,
`GameCycleId`,
`Fee`,
`PlayerCardType`,
`PurchaseStatus`,
`PurchaseOrderId`,
`EventType`)
select 
TranId,
PlayerId,
OperatorId,
EventCreatedAt,
TransactionType,
MoneyType,
Amount,
BalanceBefore,
BalanceAfter,
MethodId,
TransactionStatus,
AuthorAgentId,
IpAddress,
SessionId,
"Agent",
NULL,
WagerSetId,
WagerId,
GameId,
NULL,
WinId,
ExternalId,
ExternalId,
LinkedTransactionId,
BankName,
CardNumberLastFour,
CardType,
AccountNumber,
AccountType,
Channel,
Currency,
ExternalCreatedDate,
SubType,
ExternalUrl,
ApprovedDate,
ApprovedBy,
UpdatedDate,
WithdrawalProcessedDate,
IsNationalAccount,
IsReprocessed,
ReprocessedDate,
WalletUpdatedDate,
GviPreviousState,
GviState,
GviStateUpdatedAt,
EventId,
EventCreatedAt, 
GameCycleId,
Fee,
PlayerCardType,
"Success",
"",
"transaction-created"
from report.PlayerTransaction where Channel = "SUBSCRIPTION";

-- Player Transaction amount diff check query between scs and report DB
Select A.ReportTranType as TranType, sum(A.ReportAmount), sum(B.SCSAmount), sum(B.SCSAmount - A.ReportAmount) as AmountDiff from
(SELECT abs(sum(Amount)) as ReportAmount,  TransactionType ReportTranType 
FROM report.PlayerTransaction where CreationDate >= '2018-05-01' and TransactionStatus != "completed" and TransactionStatus != "processed" 
group by TransactionType) A
inner join
(SELECT sum(Amount) as SCSAmount, type as SCSTranType FROM transactions.transactions tt 
where ledger in (
'offline',
'PROMOTION_OPENBET',
'real-money',
'RESTRICTED_BWIN_BONUS',
'RESTRICTED_BWIN_POKER_WINNINGS',
'EXCEPTIONAL_WINS'
)
and tt.created_at >= '2018-05-01'
and (captured is null or captured = true) and tt.id >=1 group by type) B
on A.ReportTranType = B.SCSTranType
group by TranType with rollup;

-- Player transaction diff by transaction type, operator id and player id
Select A.ReportTranType as TranType, sum(A.ReportAmount), sum(B.SCSAmount), sum(B.SCSAmount - A.ReportAmount) as AmountDiff, A.OperatorId, A.PlayerId from
(SELECT abs(sum(Amount)) as ReportAmount,  TransactionType ReportTranType, OperatorId, PlayerId
FROM report.PlayerTransaction where CreationDate >= '2018-05-15' and TransactionStatus != "completed" 
group by TransactionType, OperatorId, PlayerId) A
inner join
(SELECT sum(Amount) as SCSAmount, type as SCSTranType, wallet_player_id, wallet_operator FROM transactions.transactions tt 
where ledger in (
'offline',
'PROMOTION_OPENBET',
'real-money',
'RESTRICTED_BWIN_BONUS',
'RESTRICTED_BWIN_POKER_WINNINGS',
'EXCEPTIONAL_WINS'
)
and tt.created_at >= '2018-05-15'
and (captured is null or captured = true) and tt.id >=1 group by type, wallet_operator, wallet_player_id) B
on A.ReportTranType = B.SCSTranType and A.OperatorId = B.wallet_operator and A.PlayerId = B.wallet_player_id 
group by TranType, OperatorId, PlayerId having AmountDiff != 0;

-- Player transaction amount check
select sum(abs(Amount)) from
(SELECT any_value(amount)  as Amount
FROM report.PlayerTransaction where CreationDate >= '2018-05-15' and TransactionType = 'withdrawal' group by TranId) A;

-- Country Sync query 
update report.PlayerProfile pp left join profile.user u on pp.Id = u.id left join profile.user_address ua on u.id = ua.user_id left join profile.country c on ua.country_iso = c.iso set pp.Country = c.alpha_iso2 where pp.Country is null;

-- Purchase Status Sync Query
update report.SubscriptionTransactions st left join subscriptions.purchase_fact pf on pf.purchase_order_id = st.PurchaseOrderId set st.PurchaseStatus = pf.purchase_state where st.PurchaseStatus is null;

-- Purchase fact vs Subscription Transactions diff query 
select * from subscriptions.purchase_fact pf left join report.SubscriptionTransactions st on pf.purchase_order_id = st.PurchaseOrderId where pf.purchase_order_id is not null and st.PurchaseOrderId is null order by pf.purchase_date desc;

-- Purchase fact vs Subscription Transactions Games diff query
select * from subscriptions.purchase_fact pf left join report.SubscriptionTransactionGames stg on pf.purchase_order_id = stg.PurchaseOrderId where pf.purchase_order_id is not null and stg.PurchaseOrderId is null order by pf.purchase_date desc;

-- Purchase fact vs Subscription Funding Failure diff query
select * from subscriptions.purchase_fact pf left join report.SubscriptionFundingFailure sff on pf.purchase_order_id = sff.CorrelationId where pf.purchase_order_id is not null and sff.CorrelationId is null and pf.purchase_state = "Failure" order by pf.purchase_date desc;

-- Player Payment Method Update
update report.PlayerPaymentMethodArchive 
LEFT JOIN report.PlayerPaymentMethod on PlayerPaymentMethod.Id = PlayerPaymentMethodArchive.Id 
LEFT JOIN profile.user_payment_method ON PlayerPaymentMethod.Id = user_payment_method.id
LEFT JOIN profile.payment_method ON payment_method.id = user_payment_method.payment_method_id 
LEFT JOIN profile.payment_method_type ON payment_method_type.id = payment_method.type_payment_id 
set PlayerPaymentMethodArchive.PaymentMethodType = CASE payment_method_type.type_payment WHEN 'bnk' THEN 'bankAccount' ELSE 'creditCard' END;

update report.Subscriptions rs
left join subscriptions.template  st on rs.Id = st.id
set rs.PurchasedWith = st.funding_payment_method_id;

update report.SubscriptionsArchive rs
left join subscriptions.template  st on rs.Id = st.id
set rs.PurchasedWith = st.funding_payment_method_id;

update report.Subscriptions rs
left join subscriptions.template  st on rs.Id = st.id
set rs.WinningsSentTo = st.payout_payment_method_id;

update report.SubscriptionsArchive rs
left join subscriptions.template  st on rs.Id = st.id
set rs.WinningsSentTo = st.payout_payment_method_id;









