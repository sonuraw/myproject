insert into report.AgentProfile (id, username, firstname, lastname, email, locale, jobtitle, createdAt, status, validfrom, validtill, authorId)
select 
    uuid, user_name, to_base64(first_name), to_base64(last_name), to_base64(email), locale, occupation, register_date, 
    case state when 1 then 'active' when 2 then 'pending' when 3 then 'locked' when 4 then 'closed' end as status, 
    valid_from, valid_till, 
    (select uuid from profile.user where id = a.grant_user_id) as authorId 
from profile.user a 
inner join profile.user_admin on a.id = profile.user_admin.user_id 
where uuid collate utf8_unicode_ci not in
    (select id collate utf8_unicode_ci from report.AgentProfile)
