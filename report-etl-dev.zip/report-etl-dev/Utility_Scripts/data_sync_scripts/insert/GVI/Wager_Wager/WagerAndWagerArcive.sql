DROP PROCEDURE IF EXISTS `CorrectMissingWager`;
DELIMITER $$
CREATE PROCEDURE `CorrectMissingWager`()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE a INT;
    DECLARE cur1 CURSOR FOR SELECT a.id FROM gvi.wager a WHERE (a.operator_id = "DLO" OR a.operator_id = "DLI") AND id NOT IN (
SELECT ID FROM report.Wager b WHERE b.CreationDate >= "2018-01-01 00:00:00" AND (b.OperatorId = "DLO" OR b.OperatorId = "DLI"))
AND a.created_at >= "2018-01-01 00:00:00";
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    OPEN cur1;
    read_loop: LOOP
      FETCH cur1 INTO a;
        IF done THEN
          LEAVE read_loop;
        END IF;
               SET @wagerId = a;
      INSERT INTO report.Wager(`Id`, `EventType`,`PlayerId`,`WagerSetId`,`ExternalWagerId`,`Brand`,`GameId`,`ExternalURL`,`Channel`,`State`,`UpdatedDate`,`CreationDate`,`ExternalCreationDate`,`Value`,`NotifyWin`,`RoundId`,`ExpectedEndDate`,
`Currency`,`OperatorId`,`IpAddress`,`SubscriptionId`,`SessionId`,`PreviousStatus`)
select W.id, "Wager-Created", T.wallet_player_id, W.wager_set_id, W.external_id, W.brand, W.game, W.sub_url, W.channel, W.state, W.created_at, W.updated_at, W.external_created_time, -(W.amount), W.notify_win, W.round_id, W.expected_end_date, T.currency, W.operator_id, T.ip, CASE WHEN W.channel = "SUBSCRIPTION" THEN CAST(T.ledger AS SIGNED) ELSE NULL END, T.session_id, W.state from transactions.transactions T LEFT JOIN gvi.wager W ON W.id = @wagerId where T.payload like CONCAT('%', @wagerId, '%') limit 0, 1;

		INSERT INTO report.`WagerArchive`(`RevisionDate`, `RevisionState`, `Id`, `EventType`, `PlayerId`, `WagerSetId`, `ExternalWagerId`, `Brand`, `GameId`, `ExternalURL`, `Channel`, `State`, `UpdatedDate`, `CreationDate`, `ExternalCreationDate`, `Value`, `NotifyWin`, `RoundId`, `ExpectedEndDate`, `Currency`, `OperatorId`, `IpAddress`, `SubscriptionId`, `SessionId`, `PreviousStatus`, `IsReprocessed`, `ReprocessedDate`, `IsReConciled`, `WagerType`) 
		SELECT NOW(), "wager-Created", id, "wager-Created", PlayerId, WagerSetId, ExternalWagerId, Brand, GameId, ExternalURL, Channel, State, UpdatedDate, CreationDate, ExternalCreationDate, Value, NotifyWin, RoundId, ExpectedEndDate, Currency, OperatorId, IpAddress, SubscriptionId, SessionId, PreviousStatus, IsReprocessed, ReprocessedDate, IsReConciled, WagerType FROM report.Wager WHERE Id = @wagerId;

    END LOOP;
    CLOSE cur1;
END
call CorrectMissingWager();
DROP PROCEDURE IF EXISTS `CorrectMissingWager`;

DROP PROCEDURE IF EXISTS `CorrectWagerValue`;
DELIMITER $$
CREATE PROCEDURE `CorrectWagerValue`()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE a INT;
	DECLARE wagerAmt bigint;
    DECLARE cur1 CURSOR FOR SELECT GWS.id, (GWS.amount * 1000) as amt FROM gvi.wager GW LEFT JOIN report.Wager RW ON RW.Id = GW.id where RW.Value != abs(GW.amount * 1000);
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    OPEN cur1;
    read_loop: LOOP
      FETCH cur1 INTO a, wagerAmt;
        IF done THEN
			LEAVE read_loop;
        END IF;
        SET @wagerId = a;
		SET @amount = wagerAmt;
        UPDATE report.Wager SET Value = -(@amount) WHERE Id = @wagerId;

		INSERT INTO report.`WagerArchive`(`RevisionDate`, `RevisionState`, `Id`, `EventType`, `PlayerId`, `WagerSetId`, `ExternalWagerId`, `Brand`, `GameId`, `ExternalURL`, `Channel`, `State`, `UpdatedDate`, `CreationDate`, `ExternalCreationDate`, `Value`, `NotifyWin`, `RoundId`, `ExpectedEndDate`, `Currency`, `OperatorId`, `IpAddress`, `SubscriptionId`, `SessionId`, `PreviousStatus`, `IsReprocessed`, `ReprocessedDate`, `IsReConciled`, `WagerType`) 
		SELECT NOW(), "wager-updated", id, "wager-updated", PlayerId, WagerSetId, ExternalWagerId, Brand, GameId, ExternalURL, Channel, State, UpdatedDate, CreationDate, ExternalCreationDate, Value, NotifyWin, RoundId, ExpectedEndDate, Currency, OperatorId, IpAddress, SubscriptionId, SessionId, PreviousStatus, IsReprocessed, ReprocessedDate, IsReConciled, WagerType FROM report.Wager WHERE Id = @wagerId;
    END LOOP;
    CLOSE cur1;
END
call CorrectWagerValue();
DROP PROCEDURE IF EXISTS `CorrectWagerValue`;