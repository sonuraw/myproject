DROP PROCEDURE IF EXISTS `CorrectMissingWagerSet`;
DELIMITER $$
CREATE PROCEDURE `CorrectMissingWagerSet`()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE a INT;
    DECLARE cur1 CURSOR FOR SELECT a.id FROM gvi.wager_set a WHERE (a.operator_id = "DLO" OR a.operator_id = "DLI") AND id NOT IN ( SELECT ID FROM report.WagerSet b WHERE b.CreationDate >= "2018-01-01 00:00:00" AND (b.OperatorId = "DLO" OR b.OperatorId = "DLI")) AND a.created_at >= "2018-01-01 00:00:00";
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    OPEN cur1;
    read_loop: LOOP
      FETCH cur1 INTO a;
        IF done THEN
          LEAVE read_loop;
        END IF;
        SET @wagerSetId = a;
		INSERT INTO report.WagerSet(`Id`, `EventType`, `PlayerId`, `OperatorId`, `ExternalWagerId`, `Brand`, `GameId`, `Type`, `ExternalURL`, `SessionId`, `Currency`, `Channel`, `Value`, `NotifyWin`, `NumberOfTransactions`, `State`, `CreationDate`, `UpdatedDate`, `ExternalCreationDate`, `ExpectedEndDate`, `WagerType`) SELECT WS.id, "wager-set-created" AS event_type, WS.player_id, WS.operator_id, WS.external_id, WS.brand, WS.game, "wager Set" AS TYPE, sub_url, T.session_id, T.currency, WS.channel, WS.amount, WS.notify_win,  CASE WHEN (SUBSTRING(payload, LOCATE('"numberOfWagers":"',payload) + 18, ((LOCATE('","setID"',payload) - (LOCATE('"numberOfWagers":"',payload) + 18))))) IS NOT NULL  THEN SUBSTRING(payload, LOCATE('"numberOfWagers":"',payload) + 18, ((LOCATE('","setID"',payload) - (LOCATE('"numberOfWagers":"',payload) + 18)))) ELSE 1 END AS NumberOfWagers, WS.state, WS.created_at, WS.updated_at, WS.external_created_time, WS.expected_end_date, SUBSTRING(payload, LOCATE('"wagerSetType":"',payload) + 16, ((LOCATE('","wagerSetExternalId',payload) - (LOCATE('"wagerSetType":"',payload) + 16)))) AS wagerType FROM transactions.transactions T RIGHT JOIN  gvi.wager_set WS ON WS.id = @wagerSetId WHERE T.payload LIKE CONCAT('%"setID":"', @wagerSetId, '%') OR WS.id IS NOT NULL AND T.id >= 1 LIMIT 0, 1;

		INSERT INTO report.`WagerSetArchive`(`RevisionDate`, `RevisionState`, `Id`, `EventType`, `PlayerId`, `OperatorId`, `ExternalWagerId`, `Source`, `Brand`, `GameId`, `Type`, `ExternalURL`, `SessionId`, `Currency`, `Channel`, `Value`, `NotifyWin`, `NumberOfTransactions`, `State`, `CreationDate`, `UpdatedDate`, `ExternalCreationDate`, `ExpectedEndDate`, `WagerType`) 
		SELECT now(), "wager-set-updated", Id, "wager-set-updated", PlayerId, OperatorId, ExternalWagerId, Source, Brand, GameId, Type, ExternalURL, SessionId, Currency, Channel, Value, NotifyWin, NumberOfTransactions, State, CreationDate, UpdatedDate, ExternalCreationDate, ExpectedEndDate, WagerType FROM report.WagerSet WHERE Id = @wagerSetId;
    END LOOP;
    CLOSE cur1;
END

call CorrectMissingWagerSet();
DROP PROCEDURE IF EXISTS `CorrectMissingWagerSet`;




DROP PROCEDURE IF EXISTS `CorrectWagerSetValue`;
DELIMITER $$
CREATE PROCEDURE `CorrectWagerSetValue`()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE a INT;
	DECLARE wagerSetAmt bigint;
	DECLARE createdAt DATETIME(6);
	DECLARE updatedAt DATETIME(6);
	DECLARE externalCreatedTime DATETIME(6);
	DECLARE expectedEndDate DATETIME(6);
    DECLARE cur1 CURSOR FOR SELECT GWS.id, (GWS.amount * 1000) as amt, GWS.created_at, GWS.updated_at, GWS.external_created_time, GWS.expected_end_date FROM gvi.wager_set GWS LEFT JOIN report.WagerSet RWS ON RWS.Id = GWS.id where RWS.Value != abs(GWS.amount * 1000);
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    OPEN cur1;
    read_loop: LOOP
      FETCH cur1 INTO a, wagerSetAmt, createdAt, updatedAt, externalCreatedTime, expectedEndDate;
        IF done THEN
			LEAVE read_loop;
        END IF;
        SET @wagerSetId = a;
		SET @amount = wagerSetAmt;
        UPDATE report.WagerSet SET Value = -(@amount), CreationDate = createdAt, UpdatedDate = updatedAt, ExternalCreationDate = externalCreatedTime, ExpectedEndDate = expectedEndDate WHERE Id = @wagerSetId;

		INSERT INTO report.`WagerSetArchive`(`RevisionDate`, `RevisionState`, `Id`, `EventType`, `PlayerId`, `OperatorId`, `ExternalWagerId`, `Source`, `Brand`, `GameId`, `Type`, `ExternalURL`, `SessionId`, `Currency`, `Channel`, `Value`, `NotifyWin`, `NumberOfTransactions`, `State`, `CreationDate`, `UpdatedDate`, `ExternalCreationDate`, `ExpectedEndDate`, `WagerType`) 
		SELECT NOW(), "wager-set-updated", Id, "wager-set-updated", PlayerId, OperatorId, ExternalWagerId, Source, Brand, GameId, Type, ExternalURL, SessionId, Currency, Channel, Value, NotifyWin, NumberOfTransactions, State, CreationDate, UpdatedDate, ExternalCreationDate, ExpectedEndDate, WagerType FROM report.WagerSet WHERE Id = @wagerSetId;
    END LOOP;
    CLOSE cur1;
END

call CorrectWagerSetValue();
DROP PROCEDURE IF EXISTS `CorrectWagerSetValue`;