DROP PROCEDURE IF EXISTS `CorrectMissingWin`;
DELIMITER $$
CREATE PROCEDURE `CorrectMissingWin`()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE a INT;
    DECLARE cur1 CURSOR FOR SELECT a.id FROM gvi.winning a WHERE (a.operator_id = "DLO" OR a.operator_id = "DLI") AND id NOT IN (SELECT ID FROM report.Winning b WHERE (b.OperatorId = "DLO" OR b.OperatorId = "DLI")) AND a.id >=0;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    OPEN cur1;
    read_loop: LOOP
      FETCH cur1 INTO a;
        IF done THEN
          LEAVE read_loop;
        END IF;
        SET @winId = a;
		INSERT INTO `report`.`Winning`
		(`Id`,`EventType`,`PlayerId`,`OperatorId`,`WagerId`,`Type`,`ExternalURL`,`State`,`Value`,`UpdatedDate`,`CreationDate`,`PlayerCardPrize`,`RollbackPrizes`,`ExternalCreationDate`,`PreviousStatus`,`IsReprocessed`,`ReprocessedDate`,`IsReConciled`)
		select Win.id, "Win-Created", Win.player_id, Win.operator_id, Win.wager_id, Win.type, Wager.sub_url, CONVERT( (amount/1000), SIGNED), Win.updated_at, Win.created_at, 0, 0, Win.external_checked_time, Win.state, 0, NULL, NULL from gvi.winning Win LEFT JOIN gvi.wager Wager ON Wager.id = Win.wager_id where Win.id = @winId limit 0, 1;

		INSERT INTO `report`.`WinningArchive`
		(`RevisionDate`,`RevisionState`,`Id`,`EventType`,`PlayerId`,`OperatorId`,`WagerId`,`Type`,`ExternalURL`,`State`,`Value`,`UpdatedDate`,`CreationDate`,`PlayerCardPrize`,`RollbackPrizes`,`ExternalCreationDate`,`PreviousStatus`,`IsReprocessed`,`ReprocessedDate`,`IsReConciled`)
		SELECT NOW(), "Win-Created", id, "Win-Created", PlayerId, OperatorId, WagerId, Brand, Type, ExternalURL, State, Value, UpdatedDate, CreationDate, PlayerCardPrize, RollbackPrizes, ExternalCreationDate, PreviousStatus, IsReprocessed, ReprocessedDate, IsReConciled FROM `report`.`Winning` WHERE Id = @winId;

    END LOOP;
    CLOSE cur1;
END
call CorrectMissingWin();
DROP PROCEDURE IF EXISTS `CorrectMissingWin`;



DROP PROCEDURE IF EXISTS `CorrectWinValue`;
DELIMITER $$
CREATE PROCEDURE `CorrectWinValue`()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE a INT;
	DECLARE wagerSetAmt bigint;
	DECLARE createdAt DATETIME(6);
	DECLARE updatedAt DATETIME(6);
	DECLARE externalCreatedTime DATETIME(6);
	DECLARE expectedEndDate DATETIME(6);
    DECLARE cur1 CURSOR FOR SELECT GW.id, CONVERT( (GW.amount*1000), SIGNED) AS amt, GW.created_at, GW.updated_at, GW.external_checked_time FROM gvi.winning GW LEFT JOIN report.Winning RW ON RW.Id = GW.id WHERE CONVERT( (RW.Value/1000), SIGNED) != CONVERT(GW.amount, SIGNED);
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    OPEN cur1;
    read_loop: LOOP
      FETCH cur1 INTO a, winAmt, createdAt, updatedAt, externalCreatedTime;
        IF done THEN
			LEAVE read_loop;
        END IF;
        SET @winId = a;
		SET @amount = winAmt;
        UPDATE report.Winning SET Value = @amount, CreationDate = createdAt, UpdatedDate = updatedAt, ExternalCreationDate = externalCreatedTime, ExpectedEndDate = expectedEndDate WHERE Id = @winId;

		INSERT INTO `report`.`WinningArchive`
		(`RevisionDate`,`RevisionState`,`Id`,`EventType`,`PlayerId`,`OperatorId`,`WagerId`,`Type`,`ExternalURL`,`State`,`Value`,`UpdatedDate`,`CreationDate`,`PlayerCardPrize`,`RollbackPrizes`,`ExternalCreationDate`,`PreviousStatus`,`IsReprocessed`,`ReprocessedDate`,`IsReConciled`)
		SELECT NOW(), "Win-Created", id, "Win-Created", PlayerId, OperatorId, WagerId, Brand, Type, ExternalURL, State, Value, UpdatedDate, CreationDate, PlayerCardPrize, RollbackPrizes, ExternalCreationDate, PreviousStatus, IsReprocessed, ReprocessedDate, IsReConciled FROM `report`.`Winning` WHERE Id = @winId;
    END LOOP;
    CLOSE cur1;
END

call CorrectWinValue();
DROP PROCEDURE IF EXISTS `CorrectWinValue`;
