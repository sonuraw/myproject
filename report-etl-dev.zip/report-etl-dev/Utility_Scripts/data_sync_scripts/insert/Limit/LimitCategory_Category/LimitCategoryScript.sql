INSERT INTO report.LimitCategory
(   CategoryId, 
	CategoryName, 
	CategoryType, 
	CategoryLabel, 
	Operator, 
	CreatedDate, 
	DelayDown, 
	DelayUp, 
	UpdatedDate
)
SELECT id AS CategoryId, 
    label AS CategoryName, 
    TYPE AS CategoryType, 
    label AS CategoryLabel, 
    operatorId AS Operator, 
    createdAt AS CreatedDate, 
    deferDelayDown AS DelayDown, 
    deferDelayDown AS DelayDown, 
    updatedAt AS UpdatedDate
FROM rg_limit.rg_category 
WHERE Id COLLATE utf8_unicode_ci NOT IN (SELECT CategoryId FROM report.LimitCategory);