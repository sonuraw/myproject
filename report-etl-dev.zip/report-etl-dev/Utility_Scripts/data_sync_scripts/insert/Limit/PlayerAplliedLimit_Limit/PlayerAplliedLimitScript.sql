INSERT INTO report.PlayerAppliedLimit  	
(LimitId, 
	LimitType, 
	ScopeType, 
	OperatorId, 
	PlayerId, 
	CategoryId, 
	Extent, 
	VALUE, 
	CreationDate, 
	Author, 
	AuthorType, 
	AppliedFrom, 
	AppliedTill, 
	PlannedDate, 
	LimitStatus, 
	EventType, 
	ModifiedAt, 
	CategoryType
)
SELECT 	id AS LimitId, 
	CASE WHEN rg_limit.rg_limit.status IS NULL THEN NULL ELSE CONCAT('limit-',rg_limit.rg_limit.status) END AS LimitType, -- ??
	NULL AS ScopeType, -- ??
	scope_operatorId AS OperatorId,
	scope_playerId AS PlayerId,
	category_id AS CategoryId,
	Period AS Extent,
	VALUE AS VALUE,
	createdAt AS CreationDate,
	NULL AS Author,
	NULL AS AuthorType,
	appliedFrom AS AppliedFrom,
	appliedUntil AS AppliedTill,
	plannedAt AS PlannedDate,
	STATUS AS LimitStatus,
	TYPE AS EventType, -- ??
	updatedAt AS ModifiedAte,
	NULL AS CategoryType -- ??
FROM rg_limit.rg_limit WHERE rg_limit.rg_limit.Id COLLATE utf8_unicode_ci NOT IN 
    (SELECT report.PlayerAppliedLimit.LimitId FROM report.PlayerAppliedLimit );