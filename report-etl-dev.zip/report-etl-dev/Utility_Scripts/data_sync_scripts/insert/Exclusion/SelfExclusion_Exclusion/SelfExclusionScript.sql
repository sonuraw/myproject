INSERT INTO report.selfexclusion (
Id,
	EventType,
	PlayerId,
	OperatorId,
	AppliedFrom,
	AppliedUntil,
	Period,
	ExclusionType,
	Reason,
	AuthorPlayerId,
	AuthorAgentId,
	AuthorIp,
	AuthorSessionId,
	CreatedAt,
	ModifiedAt
)
SELECT exclusionId AS Id,
	exclusionType AS EventType,
	playerId AS PlayerId,
	OperatorId AS OperatorId,
	CONVERT(CAST(appliedFrom AS DATETIME(6)), CHAR(50)) AS AppliedFrom,
	CONVERT(CAST(appliedUntil AS DATETIME(6)), CHAR(50)) AS AppliedUntil,
	period AS Period,
	TYPE AS ExclusionType,
	reason AS Reason,
	author_id AS AuthorPlayerId,
	NULL AS AuthorAgentId,
	author_ip AS AuthorIp,
	author_sessionId AS AuthorSessionId,
	createdAt AS CreatedAt,
	createdAt AS ModifiedAt
FROM  exclusion.exclusion
WHERE exclusionId NOT IN (SELECT ID FROM report.selfexclusion);


-- not working
