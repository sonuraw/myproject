INSERT INTO report.PlayerIdentificationDocument (
	Id,
	PlayerId,
	OperatorId,
	TYPE,
	Number,
	ISSUER,
	ExpirationDate,
	AuthorPlayerId,
	AuthorAgentId,
	AuthorIp,
	AuthorSessionId,
	CreatedAt,
	IsValidated,
	isDeleted,
	ModifiedAt
)
SELECT profile.user_identification.id AS Id,
user_id AS PlayerId,
website.code AS OperatorId,
	CASE profile.user_identification.type WHEN 1 THEN 'passport' WHEN 2 THEN 'ssn' WHEN 3 THEN 'cpr' END AS TYPE,
	number AS Number,
	alpha_iso2 AS ISSUER,
	user_identification.expiration_date AS ExpirationDate,
	NULL AS AuthorPlayerId,
	NULL AS AuthorAgentId,
	NULL AS AuthorIp,
	NULL AS AuthorSessionId,
	user_identification.modification_date AS CreatedAt,
	is_validated AS IsValidated,
	0 AS isDeleted,
	user_identification.modification_date AS ModifiedAt
FROM profile.user_identification
INNER JOIN profile.user ON user_identification.user_id = user.id
INNER JOIN profile.website ON user.website_origin_id= website.id
INNER JOIN profile.document_type_i18n ON profile.document_type_i18n.document_type_id  = profile.user_identification.type
INNER JOIN profile.country ON profile.country.iso = profile.user_identification.issuer_country
WHERE profile.user_identification.id  COLLATE utf8_unicode_ci NOT IN (SELECT Id FROM report.PlayerIdentificationDocument);