INSERT INTO report.PlayerPaymentMethodArchive(
	RevisionState,
    Id, 
	PlayerId, 
	OperatorId, 
	PaymentMethodType, 
	Holder, 
	BankName, 
	AccountNumber, 
	RoutingNumber, 
	CardNumberLastFour, 
	ExpirationDate, 
	Token, 
	IsValid, 
	AuthorPlayerId, 
	AuthorAgentId, 
	AuthorIp, 
	AuthorSessionId, 
	CreatedAt, 
	CardType
)

 SELECT 
 	"payment-method-created",
 	user_payment_method.id AS Id, 
	user_id AS PlayerId, 
	website.code AS OperatorId, 
	CASE payment_method_type.type_payment WHEN 'bnk' THEN 'bankAccount' ELSE 'creditCard' END AS PaymentMethodType,
	holder_name AS Holder, 
	CASE WHEN financial_institution IS NULL THEN NULL ELSE financial_institution END AS BankName, 
	CASE WHEN bank_iban IS NULL THEN NULL ELSE bank_iban END AS AccountNumber, 
	CASE WHEN bank_swift IS NULL THEN NULL ELSE bank_swift END AS RoutingNumber, 
	display_hint AS CardNumberLastFour, 
	card_validity_date AS ExpirationDate, 
	token AS Token, 
	is_validated AS IsValid, 
	NULL AS AuthorPlayerId, 
	NULL AS AuthorAgentId, 
	NULL AS AuthorIp, 
	NULL AS AuthorSessionId, 
	creation_date AS CreatedAt, 
	card_type AS CardType 
FROM profile.user_payment_method 
LEFT JOIN profile.user ON user_payment_method.user_id = user.id
LEFT JOIN profile.website ON user.website_origin_id= website.id 
LEFT JOIN profile.payment_method ON payment_method.id = user_payment_method.payment_method_id 
LEFT JOIN profile.payment_method_type ON payment_method_type.id = payment_method.type_payment_id 
WHERE user_payment_method.id COLLATE utf8_unicode_ci NOT IN  (SELECT Id FROM report.PlayerPaymentMethod);
