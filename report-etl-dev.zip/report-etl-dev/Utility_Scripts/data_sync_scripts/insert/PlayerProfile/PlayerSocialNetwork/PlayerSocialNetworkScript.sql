INSERT ignore INTO report.PlayerSocialNetwork (
    Id, 
	PlayerId, 
	OperatorId, 
	Network, 
	SocialNetworkId, 
	AuthorPlayerId, 
	AuthorAgentId, 
	AuthorIp, 
	AuthorSessionId, 
	CreatedAt, 
	isDeleted, 
	ModifiedAt
)

SELECT social_network.id AS Id, 
	user_id AS PlayerId, 
	website.code AS OperatorId, 
	network AS Network, 
	social_network.id AS SocialNetworkId, 
	NULL AS AuthorPlayerId, 
	NULL AS AuthorAgentId, 
	NULL AS AuthorIp, 
	NULL AS AuthorSessionId, 
	social_network.creation_date AS CreatedAt, 
	NULL AS isDeleted, 
	social_network.modification_date AS ModifiedAt 
FROM social_network
INNER JOIN profile.user ON social_network.user_id = user.id
INNER JOIN profile.website ON user.website_origin_id= website.id
WHERE CONCAT_WS('_', user_id,website.code, network) COLLATE utf8_unicode_ci NOT IN (SELECT CONCAT_WS('_',PlayerId,OperatorId, network) FROM report.PlayerSocialNetwork );
