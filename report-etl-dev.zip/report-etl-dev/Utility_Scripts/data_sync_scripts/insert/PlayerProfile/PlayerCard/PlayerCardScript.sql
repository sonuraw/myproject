INSERT INTO report.PlayerCard (
    Id, 
	PlayerId, 
	OperatorId, 
	CardNumber, 
	Reason, 
	AuthorPlayerId, 
	AuthorAgentId, 
	AuthorIp, 
	AuthorSessionId, 
	PrintedDate, 
	ExpirationDate, 
	CancelDate, 
	CreatedAt, 
	isDeleted, 
	ModifiedAt, 
	TYPE
)
SELECT profile.user_card.id AS Id,
	user_id AS PlayerId, 
	website.code AS OperatorId, 
	number AS CardNumber, 
	NULL AS Reason, 
	NULL AS AuthorPlayerId, 
	NULL AS AuthorAgentId, 
	NULL AS AuthorIp, 
	NULL AS AuthorSessionId, 
	printed_date AS PrintedDate, 
	expiration_date AS ExpirationDate, 
	cancel_date AS CancelDate, 
	creation_date AS CreatedAt, 
	CASE profile.user_card.status WHEN 4 then 1 ELSE 0 END AS isDeleted,
	NULL AS ModifiedAt, 
	CASE profile.user_card.card_type WHEN 1 THEN 'physical' WHEN 2 THEN 'digital' END AS TYPE
FROM profile.user_card
INNER JOIN profile.user ON user_card.user_id = user.id
INNER JOIN profile.website ON user.website_origin_id= website.id
WHERE profile.user_card.id  COLLATE utf8_unicode_ci NOT IN (SELECT Id FROM report.PlayerCard);