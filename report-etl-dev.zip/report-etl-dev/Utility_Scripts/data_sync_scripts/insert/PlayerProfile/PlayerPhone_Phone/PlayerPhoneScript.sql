INSERT INTO report.PlayerProfile (Id, OperatorId, STATUS, statusReasonId, username, alias, email, firstname,
lastname, gender, SecurityQuestion, LoginEnabled, SubscriptionEnabled, SecurityAnswer, ExchCode, Locale, BirthDate,
Occupation, VipLevel, IsTestingAccount, IsPoliticallyExposed, RegistrationType, Country, CreatedAt, ModifiedAt)

SELECT UUID, website.code AS operatorId,
    CASE a.state WHEN 1 THEN 'active' WHEN 2 THEN 'pending' WHEN 3 THEN 'locked' WHEN 4 THEN 'closed' END AS STATUS,
    CASE closed_reason WHEN 1 THEN 'card-fraud' WHEN 2 THEN 'casino-fraud' WHEN 3 THEN 'double'
    WHEN 4 THEN 'fake' WHEN 5 THEN 'fraud-suspicion' WHEN 6 THEN 'self-exclusion'
    WHEN 7 THEN 'invalid-identification-document' WHEN 8 THEN 'no-identification-documents-after-limit'
    WHEN 11 THEN 'player-registered-from-a-banned-country' WHEN 12 THEN 'chargeback'
    WHEN 14 THEN 'suspect-banking-operations-detected-on-account' WHEN 21 THEN 'blacklisted-by-operator'
    WHEN 22 THEN 'deceased' WHEN 23 THEN 'blacklisted-by-validation-partner'
    WHEN 24 THEN 'requested-by-patron'
    WHEN 25 THEN 'deleted' END AS closed_reason,
    user_name, alias, TO_BASE64(email) email, TO_BASE64(first_name) first_name,
    TO_BASE64(last_name) last_name,   CASE sex WHEN 0 THEN 'male' WHEN 1 THEN 'female' END AS gender,
    CASE secret_question_id WHEN 1 THEN 'favoriteHobby' WHEN 2 THEN 'mothersName' WHEN 3 THEN 'firstCar' WHEN 5 THEN 'petsName'
    WHEN 6 THEN 'nickname' WHEN 7 THEN 'favoriteBookName' WHEN 8 THEN 'bestFriendsName'
    WHEN 9 THEN 'childhoodHero' WHEN 10 THEN 'favoriteSportsTeam' WHEN 11 THEN 'bornCity' WHEN 12 THEN 'school' END AS secret_question,
    CASE 1 & has_setting_enabled WHEN 1 THEN 1 ELSE 0 END AS login_enabled,
    CASE 16 & has_setting_enabled WHEN 16 THEN 1 ELSE 0 END AS subscription_enabled,
    TO_BASE64(secret_response), a.currency, locale,birth_date,
    CASE is_politically_exposed WHEN 1 THEN TO_BASE64(occupation) ELSE occupation END AS occupation, vip_level,
    is_a_testing_account, is_politically_exposed, b.type AS registrationType, d.alpha_iso2, register_date, a.modification_date
FROM profile.user a
INNER JOIN profile.website ON a.website_origin_id= website.id
INNER JOIN profile.user_registration b ON a.id = b.user_id
INNER JOIN profile.user_address c ON a.id = c.user_id AND c.type = 1
INNER JOIN country d ON c.country_iso = d.iso
WHERE UUID COLLATE utf8_unicode_ci NOT IN
    (SELECT id FROM report.AgentProfile UNION SELECT id FROM report.PlayerProfile);
