INSERT INTO report.PlayerAddress(
    Id, 
	PlayerId, 
	OperatorId, 
	AddressType, 
	CoName, 
	HouseNumber, 
	LEVEL, 
	Door, 
	Street, 
	PostalCode, 
	City, 
	State, 
	Country, 
	Detail, 
	IsValidated, 
	AuthorPlayerId, 
	AuthorAgentId, 
	AuthorIp, 
	AuthorSessionId, 
	CreatedAt, 
	isDeleted, 
	-- isVerified,
	ModifiedAt
)
SELECT profile.user_address.Id AS Id,
	user_id AS PlayerId, 
	website.code AS OperatorId,
	CASE user_address.type WHEN 1 THEN 'home' WHEN 2 THEN 'office' END AS AddressType,
	co_name AS CoName,
	house_number AS HouseNumber, 
	user_address.level AS LEVEL, 
	door AS Door, 
	street AS Street, 
	zip AS PostalCode, 
	user_address.city AS City, 
	user_address.state AS State, 
	alpha_iso2 AS Country, 
	detail AS Detail, 
	is_validated AS IsValidated, -- grant_user_id
	NULL AS AuthorPlayerId, 
	NULL AS AuthorAgentId, 
	NULL AS AuthorIp, 
	NULL AS AuthorSessionId, 
	user_address.modification_date AS CreatedAt, 
	NULL AS isDeleted, 
	-- is_validated AS isVerified,
	user_address.modification_date AS ModifiedAt 
FROM profile.user_address
INNER JOIN profile.user ON profile.user_address.user_id = profile.user.id
INNER JOIN profile.website ON user.website_origin_id= profile.website.id
INNER JOIN profile.country ON profile.country.iso = profile.user_address.country_iso
WHERE profile.user_address.id  COLLATE utf8_unicode_ci NOT IN (SELECT Id FROM report.PlayerAddress);
