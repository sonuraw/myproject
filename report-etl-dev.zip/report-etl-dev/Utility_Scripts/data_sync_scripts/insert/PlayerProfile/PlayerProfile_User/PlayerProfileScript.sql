insert into report.PlayerProfile (Id, OperatorId, status, statusReasonId, username, alias, email, firstname, 
lastname, gender, SecurityQuestion, LoginEnabled, SubscriptionEnabled, SecurityAnswer, ExchCode, Locale, BirthDate,
Occupation, VipLevel, IsTestingAccount, IsPoliticallyExposed, RegistrationType, Country, CreatedAt, ModifiedAt)

select uuid, case website_origin_id when 67 then 'DLI' when 68 then 'DLO' end as operatorId, 
    case a.state when 1 then 'active' when 2 then 'pending' when 3 then 'locked' when 4 then 'closed' end as status,
    case closed_reason when 1 then 'card-fraud' when 2 then 'casino-fraud' when 3 then 'double' 
    when 4 then 'fake' when 5 then 'fraud-suspicion' when 6 then 'self-exclusion' 
    when 7 then 'invalid-identification-document' when 8 then 'no-identification-documents-after-limit' 
    when 11 then 'player-registered-from-a-banned-country' when 12 then 'chargeback' 
    when 14 then 'suspect-banking-operations-detected-on-account' when 21 then 'blacklisted-by-operator' 
    when 22 then 'deceased' when 23 then 'blacklisted-by-validation-partner' 
    when 24 then 'requested-by-patron' 
    when 25 then 'deleted' end as closed_reason, 
    user_name, alias, email, first_name, 
    last_name,   case sex when 0 then 'male' when 1 then 'female' end as gender,
    case secret_question_id when 1 then 'favoriteHobby' when 2 then 'mothersName' when 3 then 'firstCar' when 5 then 'petsName'
    when 6 then 'nickname' when 7 then 'favoriteBookName' when 8 then 'bestFriendsName' 
    when 9 then 'childhoodHero' when 10 then 'favoriteSportsTeam' when 11 then 'bornCity' when 12 then 'school' end as secret_question, 
    case 1 & has_setting_enabled when 1 then 1 else 0 end as login_enabled, 
    case 16 & has_setting_enabled when 16 then 1 else 0 end as subscription_enabled,
    secret_response, a.currency, locale,birth_date, 
    occupation, vip_level,
    is_a_testing_account, is_politically_exposed, b.type as registrationType, d.alpha_iso2, register_date, a.modification_date
from profile.user a 
inner join profile.user_registration b on a.id = b.user_id 
inner join profile.user_address c on a.id = c.user_id and c.type = 1 
inner join profile.country d on c.country_iso = d.iso 
where uuid collate utf8_unicode_ci in 
    (3534380,3534399,3534428,3534429,3534430,3534468,3534471,3534474,3534479,3534494,3534496,3534497,3534531,3534533,3534534,3534618,3534704,3534733,3534734,3534735,3534773,3534792,3534794,3534795,3534822,3534832,3534834,3534836,3534837,3534922,3535006,3535035,3535036,3535037,3535083,3535090,3535097,3535099,3535100,3535135,3535137,3535138,3535157,3535159,3535163,3535166,3535169,3535171,3546262,3546317,3546318,3546345,3546346,3546347,3546385,3546388,3546391,3546393,3546411,3546413,3546414,3546449,3546451,3546452,3546471,3546474,3546477,3546479,3546481,3546482,3546547,3546601,3546602,3546629,3546630,3546631,3546681,3546687,3546689,3546690,3546698,3546727,3546729,3546730,3546749,3546752,3547014,3547070,3547071,3547098,3547099,3547100,3547154,3547156,3547157,3547192,3547194,3547195,3547208,3547217,3547220,3547222);
