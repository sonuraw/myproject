INSERT INTO `report`.`Subscriptions` 
(`Id`,
`PlayerId`,
`OperatorId`,
`StartDate`,
`EndDate`,
`CreatedDate`,
`TotalCost`,
`Status`,
`PbsAgreementNumber`,
`PurchasedWith`,
`WinningsSentTo`,
`Comment`,
`AuthorType`,
`PurchasedWithAccountType`,
`ModifiedAt`,
`IsAddon`,
`OnHoldUntil`,
`IsGapPurchase`,
`GapFundingPaymentMethodId`
)
SELECT 
id, 
player_id, 
operator_id, 
effective_date,
updated_at,
created_at, 
total_cost_per_week, 
template_state, 
bs_agreement_id, 
funding_payment_method_id,
payout_payment_method_id,
comment,
author,
funding_payment_method_type,
updated_at,
add_on,
on_hold_until,
CASE(gap_funding_payment_method_id) WHEN "" THEN 0 ELSE 1 END,
gap_funding_payment_method_id
FROM subscriptions.template st 
WHERE st.id COLLATE utf8_unicode_ci NOT IN (select id from report.Subscriptions);

