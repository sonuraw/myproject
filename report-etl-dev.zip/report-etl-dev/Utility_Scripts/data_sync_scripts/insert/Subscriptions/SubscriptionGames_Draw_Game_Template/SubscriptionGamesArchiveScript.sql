INSERT INTO `report`.`SubscriptionGamesArchive`
(
`RevisionState`,
`DrawGameTemplateId`,
`SubscriptionId`,
`GameId`,
`GameName`,
`PlayMethod`,
`CostPerDraw`,
`PartnerId`,
`AddOnTriggerValue`,
`ParentDrawGameTemplateId`
)
SELECT 
'subscription-games-created',
draw_game_template_id,
template_id,
game_type,
sgi.game,
play_method,
cost_per_draw,
partner_id,
add_on_trigger_value,
parent_draw_game_template_id
FROM subscriptions.draw_game_template sdgt 
LEFT JOIN subscriptions.game_info sgi ON sdgt.game_type = sgi.game_num 
WHERE sdgt.template_id COLLATE utf8_unicode_ci IN (1447868,1447869,1447870,1447871,1447875,1447876,1447877,1447879,1447880,1447881,1447882,1447883,1447884,1447885,1447886,1447964,1447965);
