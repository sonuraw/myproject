insert into  report.GameCategories (Id, operatorId, name, AuthorId, CreatedAt)
select id, operator, name, case created_by When 'system' THEN 2 ELSE created_by END AS created_by, created_at from game_manager.game_category where id collate utf8_unicode_ci not in (select id from report.GameCategories);
