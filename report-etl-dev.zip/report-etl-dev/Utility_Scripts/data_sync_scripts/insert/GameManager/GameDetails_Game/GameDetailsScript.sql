insert into  report.GameDetails (GameId, operatorId, Game, ExternalGameId, SubCategoryId, GameProviderId, GameTypeId,
TheoreticalPayoutPercentage, TaxPercentage, channel, Status,  SubscriptionAvailable, SubCategory, CategoryId, Category, GameType, GameProvider)
select a.id, b.operator, a.name, external_game_id, game_sub_category_id, game_partner_id, game_type_id,
theoretical_payout_percentage, tax_percentage, channel, enabled, subscription_available,  b.name, c.id, c.name, e.name, d.name 
from game_manager.game a
inner join game_manager.game_sub_category b on a.game_sub_category_id = b.id 
inner join game_manager.game_category c on c.id = b.game_category_id 
inner join game_manager.game_partner d on a.game_partner_id = d.id and d.operator = a.operator 
inner join game_manager.game_type e on a.game_type_id = e.id
where  a.id collate utf8_unicode_ci not in (select GameId from report.GameDetails);