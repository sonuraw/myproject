insert into  report.GameProviders (Id, operatorId, name, AuthorId, CreatedAt)
select id, operator, name, created_by, case created_by When 'system' THEN 2 ELSE created_by END AS created_by from game_manager.game_partner where id collate utf8_unicode_ci not in (select id from report.GameProviders);
