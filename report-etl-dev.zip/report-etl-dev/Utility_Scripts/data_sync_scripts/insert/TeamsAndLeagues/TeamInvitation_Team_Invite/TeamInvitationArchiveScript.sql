INSERT INTO `report`.`TeamInvitationArchive`
(`RevisionDate`,
`RevisionState`,
`Id`,
`OperatorId`,
`PlayerId`,
`Email`,
`AcceptHash`,
`DeclineHash`,
`TeamId`,
`Status`,
`AuthorId`,
`CreatedAt`)
SELECT 
tti.creation_date,
"create_invite",
tti.id,
"DKS",
tti.player_id,
tti.email,
tti.accept_hash,
tti.decline_hash,
tti.team_id,
tti.status,
tt.creator_id,
tti.creation_date
FROM teams_and_leagues.team_invite tti
LEFT JOIN teams_and_leagues.team tt ON tt.id = tti.team_id 
WHERE tti.id COLLATE utf8_unicode_ci NOT IN (SELECT Id FROM `report`.`TeamInvitationArchive`);
