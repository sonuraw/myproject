INSERT INTO `report`.`LeaguePlayer`
(`Id`,
`PlayerId`,
`LeagueId`,
`OperatorId`,
`Status`,
`AuthorId`,
`UpdatedAt`,
`CreatedAt`)
SELECT 
tlp.id,
tlp.player_id,
tlp.league_id,
"DKS",
tlp.status,
tl.creator_id,
tlp.update_date,
tlp.creation_date
FROM teams_and_leagues.league_player tlp
LEFT JOIN teams_and_leagues.league tl ON tl.id = tlp.league_id 
WHERE tlp.id COLLATE utf8_unicode_ci NOT IN (SELECT Id FROM `report`.`LeaguePlayer`);
