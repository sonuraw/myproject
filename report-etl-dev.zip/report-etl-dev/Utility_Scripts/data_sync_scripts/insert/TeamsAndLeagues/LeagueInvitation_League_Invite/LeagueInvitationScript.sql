INSERT INTO `report`.`LeagueInvitation`
(`Id`,
`OperatorId`,
`PlayerId`,
`Email`,
`LeagueId`,
`Status`,
`AcceptHash`,
`DeclineHash`,
`AuthorSessionId`,
`UpdatedAt`,
`CreatedAt`)
SELECT 
tli.id,
"DKS",
tli.player_id,
tli.email,
tli.league_id,
tli.status,
tli.accept_hash,
tli.decline_hash,
tl.creator_id,
tli.update_date,
tli.creation_date
FROM teams_and_leagues.league_invite tli 
LEFT JOIN teams_and_leagues.league tl ON tl.id = tli.league_id 
WHERE tli.id COLLATE utf8_unicode_ci NOT IN (SELECT Id FROM `report`.`LeagueInvitation`);
