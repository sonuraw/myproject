INSERT INTO `report`.`TeamPlayer`
(`Id`,
`PlayerId`,
`TeamId`,
`OperatorId`,
`Status`,
`AuthorId`,
`UpdatedAt`,
`CreatedAt`
)
SELECT 
ttp.id,
ttp.player_id,
ttp.team_id,
"DKS",
ttp.status,
tt.creator_id,
ttp.update_date,
ttp.creation_date
FROM teams_and_leagues.team_player ttp
LEFT JOIN teams_and_leagues.team tt ON tt.id = ttp.team_id 
WHERE ttp.id COLLATE utf8_unicode_ci NOT IN (SELECT Id FROM `report`.`TeamPlayer`);
