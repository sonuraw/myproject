DROP PROCEDURE IF EXISTS `CorrectMissingTeams`;
DELIMITER $$
CREATE PROCEDURE `CorrectMissingTeams`()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE ids INT;
    DECLARE cur1 CURSOR FOR SELECT TLT.id FROM `teams-leagues`.team TLT LEFT JOIN `report`.Team RT ON RT.Id = TLT.id WHERE RT.id IS NULL;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    OPEN cur1;
    read_loop: LOOP
      FETCH cur1 INTO ids;
        IF done THEN
          LEAVE read_loop;
        END IF;
		SET @teamId = ids;
		INSERT IGNORE INTO `report`.`Team`
		(`OperatorId`,`Id`,`Name`,`ChairmanId`,`CreatorId`,`MaxNumberOfParticipants`,`MinNumberOfParticipants`,`Status`,`CompetitionId`,`CompetitionName`,`CompetitionStartDatetime`,
		`CloseDate`,`MultipleTeams`,`AuthorId`,`AuthorIp`,`AuthorSessionId`,`UpdatedAt`,`CreatedAt`)
		SELECT DISTINCT TP.operator_id, any_value(T.id)
		 , any_value(T.name), any_value(T.chairman_id), any_value(T.creator_id), any_value(T.max_number_of_participant)
		 , any_value(T.min_number_of_participant), any_value(T.status), any_value(T.competition_id), any_value(T.competition_name), any_value(T.competition_start_datetime)
		 , any_value(T.close_date), any_value(T.multiple_teams), any_value(T.creator_id), "127.0.0.1", NULL, any_value(T.update_date), any_value(T.creation_date) 
		FROM `teams-leagues`.team T LEFT JOIN `teams-leagues`.team_player TP ON(TP.team_id = T.id)WHERE T.id = @teamId;

		INSERT INTO `report`.`TeamArchive`(`RevisionDate`,`RevisionState`,`Id`,`OperatorId`,`Name`,`ChairmanId`,`CreatorId`,`MaxNumberOfParticipants`,`MinNumberOfParticipants`,`Status`,`CompetitionId`,`CompetitionName`,`CompetitionStartDatetime`,`CloseDate`,`MultipleTeams`,`AuthorId`,`AuthorIp`,`AuthorSessionId`,`CreatedAt`)
		SELECT NOW(), "team-created",  `Id`,`OperatorId`,`Name`,`ChairmanId`,`CreatorId`,`MaxNumberOfParticipants`,`MinNumberOfParticipants`,`Status`,`CompetitionId`,`CompetitionName`,`CompetitionStartDatetime`,`CloseDate`,`MultipleTeams`,`AuthorId`,`AuthorIp`,`AuthorSessionId`,`CreatedAt`
		FROM `report`.Team where Id = @teamId;
    END LOOP;
    CLOSE cur1;
END


call CorrectMissingTeams();
DROP PROCEDURE IF EXISTS `CorrectMissingTeams`;








DROP PROCEDURE IF EXISTS `CorrectMissingTeamInvite`;
DELIMITER $$
CREATE PROCEDURE `CorrectMissingTeamInvite`()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE ids INT;
    DECLARE cur1 CURSOR FOR SELECT TLTI.id FROM `teams-leagues`.team_invite TLTI LEFT JOIN `report`.TeamInvitation RTI ON RTI.Id = TLTI.id WHERE RTI.id IS NULL;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    OPEN cur1;
    read_loop: LOOP
      FETCH cur1 INTO ids;
        IF done THEN
          LEAVE read_loop;
        END IF;
		SET @inviteId = ids;
		INSERT IGNORE INTO`report`.`TeamInvitation`(`OperatorId`,`Id`,`PlayerId`,`Email`,`AcceptHash`,`DeclineHash`,`TeamId`,`Status`,`AuthorId`,`AuthorIp`,`AuthorSessionId`,`UpdatedAt`,`CreatedAt`)
		SELECT DISTINCT TP.operator_id, any_value(TI.id), any_value(TI.player_id), any_value(TI.email), any_value(TI.accept_hash), any_value(TI.decline_hash), any_value(TI.team_id), any_value(TI.status), any_value(T.creator_id), "127.0.0.1", NULL, any_value(TI.update_date), any_value(TI.creation_date) FROM `teams-leagues`.team_invite TI LEFT JOIN `teams-leagues`.team T ON (TI.team_id = T.id) LEFT JOIN `teams-leagues`.team_player TP ON (TP.team_id = TI.team_id) WHERE TI.id = @inviteId;



		INSERT INTO `report`.`TeamInvitationArchive`(`RevisionDate`,`RevisionState`,`Id`,`OperatorId`,`PlayerId`,`Email`,`AcceptHash`,`DeclineHash`,`TeamId`,`Status`,`AuthorId`,`AuthorIp`,`AuthorSessionId`,`CreatedAt`)
		SELECT NOW(), "team-invitation-created", `Id`,`OperatorId`,`PlayerId`,`Email`,`AcceptHash`,`DeclineHash`,`TeamId`,`Status`,`AuthorId`,`AuthorIp`,`AuthorSessionId`,`CreatedAt`
		FROM `report`.`TeamInvitation` TI WHERE TI.Id = @inviteId;
    END LOOP;
    CLOSE cur1;
END


call CorrectMissingTeamInvite();
DROP PROCEDURE IF EXISTS `CorrectMissingTeamInvite`;









DROP PROCEDURE IF EXISTS `CorrectMissingTeamPlayer`;
DELIMITER $$
CREATE PROCEDURE `CorrectMissingTeamPlayer`()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE ids INT;
    DECLARE cur1 CURSOR FOR SELECT TLTP.player_id FROM `teams-leagues`.team_player TLTP LEFT JOIN `report`.TeamPlayer RTP ON RTP.PlayerId = TLTP.player_id WHERE RTP.PlayerId IS NULL;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    OPEN cur1;
    read_loop: LOOP
      FETCH cur1 INTO ids;
        IF done THEN
          LEAVE read_loop;
        END IF;
		SET @playerId = ids;
		INSERT INTO `report`.`TeamPlayer`(`PlayerId`,`TeamId`,`OperatorId`,`Status`,`AuthorId`,`AuthorIp`,`AuthorSessionId`,`UpdatedAt`,`CreatedAt`)
		SELECT TP.player_id, TP.team_id, TP.operator_id, TP.status, T.creator_id, "127.0.0.1", NULL, TP.update_date, TP.creation_date 
		FROM `teams-leagues`.team_player TP
		LEFT JOIN `teams-leagues`.team T ON (T.id = TP.team_id)
		WHERE TP.player_id = @playerId;


		INSERT INTO `report`.`TeamPlayerArchive`
		(`RevisionDate`,`RevisionState`,`PlayerId`,`TeamId`,`OperatorId`,`Status`,`AuthorId`,`AuthorIp`,`AuthorSessionId`,`CreatedAt`)
		SELECT NOW(), "team-player-created", `PlayerId`,`TeamId`,`OperatorId`,`Status`,`AuthorId`,`AuthorIp`,`AuthorSessionId`,`CreatedAt` 
		FROM `report`.`TeamPlayer` TP WHERE TP.PlayerId = @playerId;
    END LOOP;
    CLOSE cur1;
END


call CorrectMissingTeamPlayer();
DROP PROCEDURE IF EXISTS `CorrectMissingTeamPlayer`;