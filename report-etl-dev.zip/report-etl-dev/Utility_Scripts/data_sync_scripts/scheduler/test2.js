var Client = require('ssh2').Client;
var connSettings = {
    host: "beta.sg-platform-vpc.wms.com",
    port: '22',
    username: 'ubuntu',
    password: 'quo1AiMu'
};

var conn = new Client();
conn.on('ready', function () {
    conn.sftp(function (err, sftp) {
        if (err) throw err;

        console.log(err)

        /* var fs = require("fs"); // Use node filesystem
        var readStream = fs.createReadStream("./ZipFolder0e041543-ae65-46b1-82ce-7567de43ff79/content_2017-11-16.zip");
        var writeStream = sftp.createWriteStream("/home/ubuntu/sftp_folders/content2.zip");

        writeStream.on('close', function () {
            console.log("- file transferred succesfully");
        });

        writeStream.on('end', function () {
            console.log("sftp connection closed");
            conn.close();
        });

        // initiate transfer of file
        readStream.pipe(writeStream);
 */

        sftp.readdir('/home/ubuntu/sftp_folders/data_sync_scripts', function (err, list) {
            if (err) {
                console.log(err.code)
                if (err.message == 'No such file') {
                    sftp.mkdir('/home/ubuntu/sftp_folders/data_sync_scripts', (err) => {
                        console.log(err)
                    })

                }
            }
            console.dir(list);
            /* sftp.fastPut('./ZipFolder0e041543-ae65-46b1-82ce-7567de43ff79/content_2017-11-16.zip', '/home/ubuntu/sftp_folders/data_sync/content3.zip', (err, res) => {
                console.log(err)
                conn.end()
            }) */
        })


    });
}).connect(connSettings);