logger = require('./lib/log')

const scheduler = require('./lib/scheduler')

scheduler.init()