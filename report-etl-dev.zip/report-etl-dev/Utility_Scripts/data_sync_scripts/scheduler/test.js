let Client = require('ssh2-sftp-client');
let sftp = new Client();
sftp.connect({
    host: "beta.sg-platform-vpc.wms.com",
    port: '22',
    username: 'ubuntu',
    password: 'quo1AiMu'
}).then(() => {
    // return sftp.list('/home/ubuntu/testFolder');

    return sftp.put('./ZipFolder0e041543-ae65-46b1-82ce-7567de43ff79/content_2017-11-16.zip', '/home/ubuntu/sftp_folders/content.zip')
}).then((data) => {
    console.log(data, 'the data info');
    sftp.end()
}).catch((err) => {
    console.log(err, 'catch error');
    sftp.end()
});