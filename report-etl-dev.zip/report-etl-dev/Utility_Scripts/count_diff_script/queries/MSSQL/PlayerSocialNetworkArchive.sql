SELECT '[player].[SocialNetwork]' AS 'Table', count(*) AS Count from [player].[SocialNetwork]
