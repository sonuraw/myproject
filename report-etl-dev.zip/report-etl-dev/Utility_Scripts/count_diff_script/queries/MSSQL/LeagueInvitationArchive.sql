SELECT '[tnl].[LeagueInvitation]' AS 'Table', count(*) AS Count from [tnl].[LeagueInvitation]
