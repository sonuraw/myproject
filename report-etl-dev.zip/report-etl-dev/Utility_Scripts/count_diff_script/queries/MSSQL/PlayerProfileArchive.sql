SELECT '[player].[Profile]' AS 'Table', count(*) AS Count from [player].[Profile]
