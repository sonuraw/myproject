SELECT '[subscription].[SubscriptionBetPanels]' AS 'Table', count(*) AS Count from [subscription].[SubscriptionBetPanels]
