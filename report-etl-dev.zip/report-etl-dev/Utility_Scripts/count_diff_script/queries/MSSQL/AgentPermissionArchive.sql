SELECT '[agent].[Permission]' AS 'Table', count(*) AS Count from [agent].[Permission]
