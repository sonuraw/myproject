SELECT '[player].[PaymentMethod]' AS 'Table', count(*) AS Count from [player].[PaymentMethod]
