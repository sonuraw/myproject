SELECT '[account].[Transaction]' AS 'Table', count(*) AS Count from [account].[Transaction]
