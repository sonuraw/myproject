SELECT '[ga].[WagerSet]' AS 'Table', count(*) AS Count from [ga].[WagerSet]
