SELECT '[player].[ExcludedPlayerRegistrationAttempt]' AS 'Table', count(*) AS Count from [player].[ExcludedPlayerRegistrationAttempt]
