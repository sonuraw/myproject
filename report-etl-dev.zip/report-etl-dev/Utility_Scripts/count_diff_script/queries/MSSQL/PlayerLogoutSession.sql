SELECT '[player].[LogoutSession]' AS 'Table', count(*) AS Count from [player].[LogoutSession]
