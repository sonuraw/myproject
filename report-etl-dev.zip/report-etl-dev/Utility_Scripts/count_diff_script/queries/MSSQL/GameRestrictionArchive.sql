SELECT '[rg].[Restriction]' AS 'Table', count(*) AS Count from [rg].[Restriction]
