SELECT '[player].[Reactivation]' AS 'Table', count(*) AS Count from [player].[Reactivation]
