SELECT '[game].[Type]' AS 'Table', count(*) AS Count from [game].[Type]
