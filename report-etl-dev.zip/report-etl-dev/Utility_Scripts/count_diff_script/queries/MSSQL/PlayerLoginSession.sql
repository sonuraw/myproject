SELECT '[player].[LoginSession]' AS 'Table', count(*) AS Count from [player].[LoginSession]
