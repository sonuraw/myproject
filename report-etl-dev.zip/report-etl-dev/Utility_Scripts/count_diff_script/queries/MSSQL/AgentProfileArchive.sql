SELECT '[agent].[Profile]' AS 'Table', count(*) AS Count from [agent].[Profile]
