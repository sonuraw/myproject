SELECT '[game].[Provider]' AS 'Table', count(*) AS Count from [game].[Provider]
