SELECT '[player].[Comments]' AS 'Table', count(*) AS Count from [player].[Comments]
