SELECT '[rg].[Limit]' AS 'Table', count(*) AS Count from [rg].[Limit]
