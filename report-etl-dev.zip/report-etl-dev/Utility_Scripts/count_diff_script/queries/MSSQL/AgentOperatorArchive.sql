SELECT '[agent].[Operator]' AS 'Table', count(*) AS Count from [agent].[Operator]
