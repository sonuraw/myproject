SELECT '[tnl].[LeaguePlayer]' AS 'Table', count(*) AS Count from [tnl].[LeaguePlayer]
