SELECT '[subscription].[SubscriptionGames]' AS 'Table', count(*) AS Count from [subscription].[SubscriptionGames]
