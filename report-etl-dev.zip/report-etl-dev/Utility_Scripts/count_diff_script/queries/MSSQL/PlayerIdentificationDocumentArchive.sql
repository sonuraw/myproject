SELECT '[player].[Identification]' AS 'Table', count(*) AS Count from [player].[Identification]
