SELECT '[player].[TermsAndConditionsAcknowledgement]' AS 'Table', count(*) AS Count from [player].[TermsAndConditionsAcknowledgement]
