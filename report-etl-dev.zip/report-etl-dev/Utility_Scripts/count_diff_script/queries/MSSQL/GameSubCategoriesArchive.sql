SELECT '[game].[Subcategory]' AS 'Table', count(*) AS Count from [game].[Subcategory]
