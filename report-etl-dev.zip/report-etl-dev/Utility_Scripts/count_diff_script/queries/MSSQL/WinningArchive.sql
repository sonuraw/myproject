SELECT '[ga].[Winning]' AS 'Table', count(*) AS Count from [ga].[Winning]
