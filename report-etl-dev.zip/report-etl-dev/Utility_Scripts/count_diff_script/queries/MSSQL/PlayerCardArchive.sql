SELECT '[player].[Card]' AS 'Table', count(*) AS Count from [player].[Card]
