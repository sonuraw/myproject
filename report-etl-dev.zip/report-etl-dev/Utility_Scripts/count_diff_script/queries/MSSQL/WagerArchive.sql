SELECT '[ga].[Wager]' AS 'Table', count(*) AS Count from [ga].[Wager]
