SELECT '[player].[Phone]' AS 'Table', count(*) AS Count from [player].[Phone]
