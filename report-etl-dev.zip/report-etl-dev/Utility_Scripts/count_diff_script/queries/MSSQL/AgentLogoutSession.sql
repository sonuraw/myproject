SELECT '[agent].[LogoutSession]' AS 'Table', count(*) AS Count from [agent].[LogoutSession]
