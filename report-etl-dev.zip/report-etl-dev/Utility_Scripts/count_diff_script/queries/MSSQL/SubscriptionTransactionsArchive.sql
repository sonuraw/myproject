SELECT '[subscription].[SubscriptionItem]' AS 'Table', count(*) AS Count from [subscription].[SubscriptionItem]
