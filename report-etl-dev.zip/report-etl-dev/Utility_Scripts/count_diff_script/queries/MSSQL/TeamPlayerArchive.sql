SELECT '[tnl].[TeamPlayer]' AS 'Table', count(*) AS Count from [tnl].[TeamPlayer]
