SELECT '[player].[Affiliation]' AS 'Table', count(*) AS Count from [player].[Affiliation]
