SELECT '[tnl].[Team]' AS 'Table', count(*) AS Count from [tnl].[Team]
