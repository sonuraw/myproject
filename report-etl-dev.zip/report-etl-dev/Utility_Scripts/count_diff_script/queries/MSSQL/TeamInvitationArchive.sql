SELECT '[tnl].[TeamInvitation]' AS 'Table', count(*) AS Count from [tnl].[TeamInvitation]
