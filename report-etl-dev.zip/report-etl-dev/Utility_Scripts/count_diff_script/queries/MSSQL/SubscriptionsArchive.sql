SELECT '[subscription].[Subscription]' AS 'Table', count(*) AS Count from [subscription].[Subscription]
