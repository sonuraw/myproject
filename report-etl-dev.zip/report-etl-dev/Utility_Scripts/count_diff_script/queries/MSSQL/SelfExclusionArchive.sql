SELECT '[rg].[SelfExclusion]' AS 'Table', count(*) AS Count from [rg].[SelfExclusion]
