SELECT '[player].[Address]' AS 'Table', count(*) AS Count from [player].[Address]
