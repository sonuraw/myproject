SELECT '[game].[Category]' AS 'Table', count(*) AS Count from [game].[Category]
