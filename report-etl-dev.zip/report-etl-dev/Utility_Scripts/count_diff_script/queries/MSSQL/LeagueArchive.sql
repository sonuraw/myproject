SELECT '[tnl].[League]' AS 'Table', count(*) AS Count from [tnl].[League]
