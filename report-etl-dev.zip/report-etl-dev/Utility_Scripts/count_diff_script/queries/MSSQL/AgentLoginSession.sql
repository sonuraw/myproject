SELECT '[agent].[LoginSession]' AS 'Table', count(*) AS Count from [agent].[LoginSession]
