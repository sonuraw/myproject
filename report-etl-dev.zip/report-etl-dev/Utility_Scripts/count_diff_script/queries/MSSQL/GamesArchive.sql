SELECT '[game].[Game]' AS 'Table', count(*) AS Count from [game].[Game]
