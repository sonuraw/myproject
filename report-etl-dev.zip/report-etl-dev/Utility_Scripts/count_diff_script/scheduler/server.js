logger = require('./lib/log')

const scheduler = require('./lib/scheduler')

scheduler.init()

process.on('uncaughtException', (err => {
    console.error((new Date()).toUTCString() + ' uncaughtException:', (err.message || err))
    console.error(err.stack)
    process.exit(1)
}))

process.on('unhandledRejection', ((reason, p) => {
    console.error(`Possibly Unhandled Rejection at: Promise , ${p}, reason: , ${reason}`)    
    process.exit(1)
}))