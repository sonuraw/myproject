package com.sciplay.report.etl.Entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.DynamicUpdate;

/** The Class WagerSetArchiveEntity. */
@Entity
@Table(name = "WagerSetArchive")
@DynamicUpdate
public class WagerSetArchiveEntity {

  /** The revision number. */
  @Column(name = "RevisionNumber")
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long revisionNumber;

  /** The revision date. */
  private Date revisionDate;

  /** The revision state. */
  private String revisionState;

  /** The id. */
  @Column(name = "Id")
  private long id;

  /** The event type. */
  private String eventType;

  /** The player id. */
  private Integer playerId;

  /** The operator id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The external wager id. */
  private String externalWagerId;

  /** The source. */
  private String source;

  /** The brand. */
  private String brand;

  /** The game id. */
  private Integer gameId;

  /** The type. */
  private String type;

  /** The external url. */
  private String externalUrl;

  /** The channel. */
  private String channel;

  /** The value. */
  private Long value;

  /** The notify win. */
  private boolean notifyWin;

  /** The number of transactions. */
  private int numberOfTransactions;

  /** The state. */
  private String state;

  /** The creation date. */
  private Date creationDate;

  /** The updated date. */
  @Column(name = "UpdatedDate")
  private Date updatedDate;

  /** The external creation date. */
  private Date externalCreationDate;

  /** The expected end date. */
  private Date expectedEndDate;

  /** The currency. */
  private String currency;

  /** The session id. */
  private String sessionId;

  /** The wager type. */
  private String wagerType;

  /** Instantiates a new wager set archive entity. */
  public WagerSetArchiveEntity() {}

  /**
   * Instantiates a new wager set archive entity.
   *
   * @param id the id
   * @param eventType the event type
   * @param playerId the player id
   * @param externalWagerId the external wager id
   * @param brand the brand
   * @param gameId the game id
   * @param channel the channel
   * @param notifyWin the notify win
   * @param numberOfTransactions the number of transactions
   * @param creationDate the creation date
   * @param updatedDate the updated date
   * @param externalCreationDate the external creation date
   */
  public WagerSetArchiveEntity(
      long id,
      String eventType,
      Integer playerId,
      String externalWagerId,
      String brand,
      Integer gameId,
      String channel,
      boolean notifyWin,
      int numberOfTransactions,
      Date creationDate,
      Date updatedDate,
      Date externalCreationDate) {
    this.id = id;
    this.eventType = eventType;
    this.playerId = playerId;
    this.externalWagerId = externalWagerId;
    this.brand = brand;
    this.gameId = gameId;
    this.channel = channel;
    this.notifyWin = notifyWin;
    this.numberOfTransactions = numberOfTransactions;
    this.creationDate = creationDate;
    this.updatedDate = updatedDate;
    this.externalCreationDate = externalCreationDate;
  }

  /**
   * Instantiates a new wager set archive entity.
   *
   * @param id the id
   * @param eventType the event type
   * @param playerId the player id
   * @param externalWagerId the external wager id
   * @param source the source
   * @param brand the brand
   * @param gameId the game id
   * @param type the type
   * @param externalUrl the external url
   * @param channel the channel
   * @param value the value
   * @param notifyWin the notify win
   * @param numberOfTransactions the number of transactions
   * @param state the state
   * @param creationDate the creation date
   * @param updatedDate the updated date
   * @param externalCreationDate the external creation date
   * @param expectedEndDate the expected end date
   */
  public WagerSetArchiveEntity(
      long id,
      String eventType,
      Integer playerId,
      String externalWagerId,
      String source,
      String brand,
      Integer gameId,
      String type,
      String externalUrl,
      String channel,
      Long value,
      boolean notifyWin,
      int numberOfTransactions,
      String state,
      Date creationDate,
      Date updatedDate,
      Date externalCreationDate,
      Date expectedEndDate) {
    this.id = id;
    this.eventType = eventType;
    this.playerId = playerId;
    this.externalWagerId = externalWagerId;
    this.source = source;
    this.brand = brand;
    this.gameId = gameId;
    this.type = type;
    this.externalUrl = externalUrl;
    this.channel = channel;
    this.value = value;
    this.notifyWin = notifyWin;
    this.numberOfTransactions = numberOfTransactions;
    this.state = state;
    this.creationDate = creationDate;
    this.updatedDate = updatedDate;
    this.externalCreationDate = externalCreationDate;
    this.expectedEndDate = expectedEndDate;
  }

  /**
   * Gets the wager type.
   *
   * @return the wager type
   */
  public String getWagerType() {
    return wagerType;
  }

  /**
   * Sets the wager type.
   *
   * @param wagerType the new wager type
   */
  public void setWagerType(String wagerType) {
    this.wagerType = wagerType;
  }

  /**
   * Gets the revision number.
   *
   * @return the revision number
   */
  public long getRevisionNumber() {
    return revisionNumber;
  }

  /**
   * Sets the revision number.
   *
   * @param revisionNumber the new revision number
   */
  public void setRevisionNumber(long revisionNumber) {
    this.revisionNumber = revisionNumber;
  }

  /**
   * Gets the revision date.
   *
   * @return the revision date
   */
  public Date getRevisionDate() {
    return revisionDate;
  }

  /**
   * Sets the revision date.
   *
   * @param revisionDate the new revision date
   */
  public void setRevisionDate(Date revisionDate) {
    this.revisionDate = revisionDate;
  }

  /**
   * Gets the revision state.
   *
   * @return the revision state
   */
  public String getRevisionState() {
    return revisionState;
  }

  /**
   * Sets the revision state.
   *
   * @param revisionState the new revision state
   */
  public void setRevisionState(String revisionState) {
    this.revisionState = revisionState;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public long getId() {
    return this.id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(long id) {
    this.id = id;
  }

  /**
   * Gets the event type.
   *
   * @return the event type
   */
  public String getEventType() {
    return this.eventType;
  }

  /**
   * Sets the event type.
   *
   * @param eventType the new event type
   */
  public void setEventType(String eventType) {
    this.eventType = eventType;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return this.playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the operator id.
   *
   * @return the operatorId
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the operatorId to set
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the external wager id.
   *
   * @return the external wager id
   */
  public String getExternalWagerId() {
    return this.externalWagerId;
  }

  /**
   * Sets the external wager id.
   *
   * @param externalWagerId the new external wager id
   */
  public void setExternalWagerId(String externalWagerId) {
    this.externalWagerId = externalWagerId;
  }

  /**
   * Gets the source.
   *
   * @return the source
   */
  public String getSource() {
    return this.source;
  }

  /**
   * Sets the source.
   *
   * @param source the new source
   */
  public void setSource(String source) {
    this.source = source;
  }

  /**
   * Gets the brand.
   *
   * @return the brand
   */
  public String getBrand() {
    return this.brand;
  }

  /**
   * Sets the brand.
   *
   * @param brand the new brand
   */
  public void setBrand(String brand) {
    this.brand = brand;
  }

  /**
   * Gets the game id.
   *
   * @return the game id
   */
  public Integer getGameId() {
    return this.gameId;
  }

  /**
   * Sets the game id.
   *
   * @param gameId the new game id
   */
  public void setGameId(Integer gameId) {
    this.gameId = gameId;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return this.type;
  }

  /**
   * Sets the type.
   *
   * @param type the new type
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the external url.
   *
   * @return the external url
   */
  public String getExternalUrl() {
    return this.externalUrl;
  }

  /**
   * Sets the external url.
   *
   * @param externalUrl the new external url
   */
  public void setExternalUrl(String externalUrl) {
    this.externalUrl = externalUrl;
  }

  /**
   * Gets the channel.
   *
   * @return the channel
   */
  public String getChannel() {
    return this.channel;
  }

  /**
   * Sets the channel.
   *
   * @param channel the new channel
   */
  public void setChannel(String channel) {
    this.channel = channel;
  }

  /**
   * Gets the value.
   *
   * @return the value
   */
  public Long getValue() {
    return this.value;
  }

  /**
   * Sets the value.
   *
   * @param value the new value
   */
  public void setValue(Long value) {
    this.value = value;
  }

  /**
   * Checks if is notify win.
   *
   * @return true, if is notify win
   */
  public boolean isNotifyWin() {
    return this.notifyWin;
  }

  /**
   * Sets the notify win.
   *
   * @param notifyWin the new notify win
   */
  public void setNotifyWin(boolean notifyWin) {
    this.notifyWin = notifyWin;
  }

  /**
   * Gets the number of transactions.
   *
   * @return the number of transactions
   */
  public int getNumberOfTransactions() {
    return this.numberOfTransactions;
  }

  /**
   * Sets the number of transactions.
   *
   * @param numberOfTransactions the new number of transactions
   */
  public void setNumberOfTransactions(int numberOfTransactions) {
    this.numberOfTransactions = numberOfTransactions;
  }

  /**
   * Gets the state.
   *
   * @return the state
   */
  public String getState() {
    return this.state;
  }

  /**
   * Sets the state.
   *
   * @param state the new state
   */
  public void setState(String state) {
    this.state = state;
  }

  /**
   * Gets the creation date.
   *
   * @return the creation date
   */
  public Date getCreationDate() {
    return this.creationDate;
  }

  /**
   * Sets the creation date.
   *
   * @param creationDate the new creation date
   */
  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  /**
   * Gets the updated date.
   *
   * @return the updated date
   */
  public Date getUpdatedDate() {
    return this.updatedDate;
  }

  /**
   * Sets the updated date.
   *
   * @param updatedDate the new updated date
   */
  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  /**
   * Gets the external creation date.
   *
   * @return the external creation date
   */
  public Date getExternalCreationDate() {
    return this.externalCreationDate;
  }

  /**
   * Sets the external creation date.
   *
   * @param externalCreationDate the new external creation date
   */
  public void setExternalCreationDate(Date externalCreationDate) {
    this.externalCreationDate = externalCreationDate;
  }

  /**
   * Gets the expected end date.
   *
   * @return the expected end date
   */
  public Date getExpectedEndDate() {
    return this.expectedEndDate;
  }

  /**
   * Sets the expected end date.
   *
   * @param expectedEndDate the new expected end date
   */
  public void setExpectedEndDate(Date expectedEndDate) {
    this.expectedEndDate = expectedEndDate;
  }

  /**
   * Gets the currency.
   *
   * @return the currency
   */
  public String getCurrency() {
    return currency;
  }

  /**
   * Sets the currency.
   *
   * @param currency the new currency
   */
  public void setCurrency(String currency) {
    this.currency = currency;
  }

  /**
   * Gets the session id.
   *
   * @return the session id
   */
  public String getSessionId() {
    return sessionId;
  }

  /**
   * Sets the session id.
   *
   * @param sessionId the new session id
   */
  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }
}
