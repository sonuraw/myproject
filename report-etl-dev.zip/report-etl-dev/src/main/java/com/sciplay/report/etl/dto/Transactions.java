package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Transactions {

  /** The transactionId. */
  private long transactionId;

  /** The amount. */
  private String amount;

  /** The currency. */
  private String currency;

  /** The ledger. */
  private String ledger;

  /** The creationTime. */
  private String creationTime;

  /** The status. */
  private String status;

  /** @return the transactionId */
  public long getTransactionId() {
    return transactionId;
  }

  /** @param transactionId the transactionId to set */
  public void setTransactionId(long transactionId) {
    this.transactionId = transactionId;
  }

  /** @return the amount */
  public String getAmount() {
    return amount;
  }

  /** @param amount the amount to set */
  public void setAmount(String amount) {
    this.amount = amount;
  }

  /** @return the currency */
  public String getCurrency() {
    return currency;
  }

  /** @param currency the currency to set */
  public void setCurrency(String currency) {
    this.currency = currency;
  }

  /** @return the ledger */
  public String getLedger() {
    return ledger;
  }

  /** @param ledger the ledger to set */
  public void setLedger(String ledger) {
    this.ledger = ledger;
  }

  /** @return the creationTime */
  public String getCreationTime() {
    return creationTime;
  }

  /** @param creationTime the creationTime to set */
  public void setCreationTime(String creationTime) {
    this.creationTime = creationTime;
  }

  /** @return the status */
  public String getStatus() {
    return status;
  }

  /** @param status the status to set */
  public void setStatus(String status) {
    this.status = status;
  }
}
