package com.sciplay.report.etl;

import java.util.HashMap;
import java.util.Map;

public final class WalletConst {

  public static final Map<String, Integer> DEPOSIT_STATUS_FLOW = new HashMap<>();

  // BALANCE COMPARE
  public static final String OLD_BALANCE = "oldBalance";
  public static final String NEW_BALANCE = "newBalance";

  // DATE COMPARE
  public static final String DATE_BEFORE = "Before";
  public static final String DATE_AFTER = "After";
  public static final String DATE_EQUALS = "Equals";

  // EVENT TYPES
  public static final String TRANSACTION_CREATED_EVENT = "transaction-created";
  public static final String TRANSACTION_UPDATED_EVENT = "transaction-updated";
  public static final String TRANSACTION_WIN_UPDATED = "win-updated";
  public static final String TRANSACTION_WINNING_UPDATED = "winning-updated";
  public static final String TRANSACTION_WAGER_UPDATED = "wager-updated";

  public static final String EVENT_CREATED = "created";
  public static final String EVENT_DELETED = "deleted";
  public static final String EVENT_UPDATED = "updated";

  //    TRANSACTION STATUS
  public static final String STATUS_ACCEPTED = "accepted";
  public static final String STATUS_PENDING = "pending";
  public static final String STATUS_ABANDONED = "abandoned";
  public static final String STATUS_PROCESSED = "processed";
  public static final String STATUS_CANCELLED = "cancelled";
  public static final String STATUS_COMPLETED = "completed";
  public static final String STATUS_PROCESSING = "processing";
  public static final String STATUS_REJECTED = "rejected";

  //    TRANSACTION TYPES
  public static final String TRAN_WITHDRAWAL = "withdrawal";
  public static final String TRAN_WAGER = "wager";
  public static final String TRAN_CREDIT = "credit";
  public static final String TRAN_DEBIT = "debit";
  public static final String TRAN_ADJUSTMENT = "adjustment";
  public static final String TRAN_DEPOSIT = "deposit";
  public static final String TRAN_WAGER_SET = "wagerSet";
  public static final String TRAN_WIN = "win";

  // SUB TRAN TYPE
  public static final String SUB_TRAN_WRITE_OFF = "writeoff";
  public static final String SUB_TRAN_WIN_ADJUSTMENT = "win-adjustment";
  public static final String SUB_TRAN_REFUND = "refund";

  // NEGATIVE BALANCE
  public static final String IS_WRITE_OFF = "Yes";
  public static final String RECONCILED_MANUALLY = "Reconciled_Manually";

  // PAYMENT METHODS
  public static final String PAYMENT_CREDIT_CARD = "creditcard";
  public static final String PAYMENT_BANK_ACCOUNT = "bankAccount";

  // deposit flow
  static {
    DEPOSIT_STATUS_FLOW.put("pending-pending", 1);
    DEPOSIT_STATUS_FLOW.put("pending-accepted", 2);
    DEPOSIT_STATUS_FLOW.put("pending-rejected", 3);
    DEPOSIT_STATUS_FLOW.put("pending-abandoned", 3);
    DEPOSIT_STATUS_FLOW.put("accepted-cancelled", 4);
    DEPOSIT_STATUS_FLOW.put("abandoned-accepted", 5);

    // report-etl case limit 1, completed also can come in instead of accepted in
    // our select limit 1 order by UpdatedDate DESC
    DEPOSIT_STATUS_FLOW.put("completed-cancelled", 4);
  }

  public static Map<String, Integer> getDepositStatusFlow() {
    return DEPOSIT_STATUS_FLOW;
  }
}
