package com.sciplay.report.etl.dto.limits;

public class LimitMeta {

  private final String copyright;

  private final int count;

  private final int limit;

  private final String createdAt;

  private final String updatedAt;

  public LimitMeta(String copyright, int count, int limit, String createdAt, String updatedAt) {
    this.copyright = copyright;
    this.count = count;
    this.limit = limit;
    this.createdAt = createdAt;
    this.updatedAt = updatedAt;
  }

  public LimitMeta() {

    this.copyright = null;
    this.count = 0;
    this.limit = 0;
    this.createdAt = null;
    this.updatedAt = null;
  }

  public String getCopyright() {
    return copyright;
  }

  public int getCount() {
    return count;
  }

  public int getLimit() {
    return limit;
  }

  public String getCreatedAt() {
    return createdAt;
  }

  public String getUpdatedAt() {
    return updatedAt;
  }
}
