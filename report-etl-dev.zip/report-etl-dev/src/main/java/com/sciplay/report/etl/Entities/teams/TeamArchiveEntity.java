package com.sciplay.report.etl.Entities.teams;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

/** @author salman */
@Entity
@Table(name = "TeamArchive")
public class TeamArchiveEntity {

  @javax.persistence.Id
  @Column(name = "RevisionNumber")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long revisionNumber;

  @Column(name = "RevisionDate")
  private Date revisionDate;

  @Column(name = "RevisionState")
  private String revisionState;

  @Column(name = "Id")
  private String id;

  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  @Column(name = "Name")
  private String name;

  @Column(name = "ChairmanId")
  private String chairmanId;

  @Column(name = "creatorId")
  private String creatorId;

  @Column(name = "MaxNumberOfParticipants")
  private Integer maxNumberOfParticipants;

  @Column(name = "MinNumberOfParticipants")
  private Integer minNumberOfParticipants;

  @Column(name = "Status", columnDefinition = "enum('OPEN','CLOSED','LOCKED','O','C','L')")
  private String status;

  @Column(name = "Purpose", columnDefinition = "enum('COMPETITION', 'GROUP_PLAY')")
  private String purpose;

  @Column(name = "AltGroupRef")
  private String altGroupRef;

  @Column(name = "CompetitionId")
  private String competitionId;

  @Column(name = "CompetitionName")
  private String competitionName;

  @Column(name = "CompetitionStartDatetime")
  private Date competitionStartDatetime;

  @Column(name = "CloseDate")
  private Date closeDate;

  @Column(name = "MultipleTeams")
  private boolean multipleTeams;

  @Column(name = "AuthorId")
  private Integer authorId;

  @Column(name = "AuthorIp")
  private String authorIp;

  @Column(name = "AuthorSessionId")
  private String authorSessionId;

  @Column(name = "CreatedAt")
  private Date createdAt;

  public TeamArchiveEntity() {}

  public TeamArchiveEntity(TeamEntity teamEntity, String revisionState) {
    this.id = teamEntity.getId();
    this.operatorId = teamEntity.getOperatorId();
    this.name = teamEntity.getName();
    this.chairmanId = teamEntity.getChairmanId();
    this.creatorId = teamEntity.getCreatorId();
    this.maxNumberOfParticipants = teamEntity.getMaxNumberOfParticipants();
    this.minNumberOfParticipants = teamEntity.getMinNumberOfParticipants();
    this.status = teamEntity.getStatus();
    if (teamEntity.getPurpose() != null) {
      this.purpose = teamEntity.getPurpose();
    } else {
      this.purpose = "COMPETITION";
    }
    this.altGroupRef = teamEntity.getAltGroupRef();
    this.competitionId = teamEntity.getCompetitionId();
    this.competitionName = teamEntity.getCompetitionName();
    this.competitionStartDatetime = teamEntity.getCompetitionStartDatetime();
    this.closeDate = teamEntity.getCloseDate();
    this.multipleTeams = teamEntity.isMultipleTeams();
    this.authorId = teamEntity.getAuthorId();
    this.authorIp = teamEntity.getAuthorIp();
    this.authorSessionId = teamEntity.getAuthorSessionId();
    this.createdAt = teamEntity.getCreatedAt();
    this.revisionDate = teamEntity.getUpdatedAt();
    this.revisionState = revisionState;
  }

  public long getRevisionNumber() {
    return revisionNumber;
  }

  public void setRevisionNumber(long revisionNumber) {
    this.revisionNumber = revisionNumber;
  }

  public Date getRevisionDate() {
    return revisionDate;
  }

  public void setRevisionDate(Date revisionDate) {
    this.revisionDate = revisionDate;
  }

  public String getRevisionState() {
    return revisionState;
  }

  public void setRevisionState(String revisionState) {
    this.revisionState = revisionState;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getOperatorId() {
    return operatorId;
  }

  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getChairmanId() {
    return chairmanId;
  }

  public void setChairmanId(String chairmanId) {
    this.chairmanId = chairmanId;
  }

  public String getCreatorId() {
    return creatorId;
  }

  public void setCreatorId(String creatorId) {
    this.creatorId = creatorId;
  }

  public Integer getMaxNumberOfParticipants() {
    return maxNumberOfParticipants;
  }

  public void setMaxNumberOfParticipants(Integer maxNumberOfParticipant) {
    this.maxNumberOfParticipants = maxNumberOfParticipant;
  }

  public Integer getMinNumberOfParticipants() {
    return minNumberOfParticipants;
  }

  public void setMinNumberOfParticipants(Integer minNumberOfParticipant) {
    this.minNumberOfParticipants = minNumberOfParticipant;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getPurpose() {
    return purpose;
  }

  public void setPurpose(String purpose) {
    this.purpose = purpose;
  }

  public String getAltGroupRef() {
    return altGroupRef;
  }

  public void setAltGroupRef(String altGroupRef) {
    this.altGroupRef = altGroupRef;
  }

  public String getCompetitionId() {
    return competitionId;
  }

  public void setCompetitionId(String competitionId) {
    this.competitionId = competitionId;
  }

  public String getCompetitionName() {
    return competitionName;
  }

  public void setCompetitionName(String competitionName) {
    this.competitionName = competitionName;
  }

  public Date getCompetitionStartDatetime() {
    return competitionStartDatetime;
  }

  public void setCompetitionStartDatetime(Date competitionStartDatetime) {
    this.competitionStartDatetime = competitionStartDatetime;
  }

  public Date getCloseDate() {
    return closeDate;
  }

  public void setCloseDate(Date closeDate) {
    this.closeDate = closeDate;
  }

  public boolean isMultipleTeams() {
    return multipleTeams;
  }

  public void setMultipleTeams(boolean multipleTeams) {
    this.multipleTeams = multipleTeams;
  }

  public Integer getAuthorId() {
    return authorId;
  }

  public void setAuthorId(Integer authorId) {
    this.authorId = authorId;
  }

  public String getAuthorIp() {
    return authorIp;
  }

  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  public String getAuthorSessionId() {
    return authorSessionId;
  }

  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  public Date getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }
}
