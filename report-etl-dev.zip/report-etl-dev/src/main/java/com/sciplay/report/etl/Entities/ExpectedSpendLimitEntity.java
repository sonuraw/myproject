package com.sciplay.report.etl.Entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/** The Class ExpectedSpendLimitEntity. */
@Entity
@Table(name = "ExpectedSpendLimit")
public class ExpectedSpendLimitEntity implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The limit id. */
  @Id
  @Column(name = "LimitId")
  private String limitId;

  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The date limit exceeded. */
  @Id
  @Column(name = "DateLimitExceeded")
  @Temporal(TemporalType.DATE)
  private Date dateLimitExceeded;

  @Column(name = "NumberOfTimesExceeded")
  private Integer numberOfTimesExceeded;

  /**
   * Gets the limit id.
   *
   * @return the limit id
   */
  public String getLimitId() {
    return limitId;
  }

  /**
   * Sets the limit id.
   *
   * @param limitId the new limit id
   */
  public void setLimitId(String limitId) {
    this.limitId = limitId;
  }

  /**
   * Gets the date limit exceeded.
   *
   * @return the date limit exceeded
   */
  public Date getDateLimitExceeded() {
    return dateLimitExceeded;
  }

  /**
   * Sets the date limit exceeded.
   *
   * @param dateLimitExceeded the new date limit exceeded
   */
  public void setDateLimitExceeded(Date dateLimitExceeded) {
    this.dateLimitExceeded = dateLimitExceeded;
  }

  /** @return the operatorId */
  public String getOperatorId() {
    return operatorId;
  }

  /** @param operatorId the operatorId to set */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  public Integer getNumberOfTimesExceeded() {
    return numberOfTimesExceeded == null ? 0 : numberOfTimesExceeded;
  }

  public void setNumberOfTimesExceeded(Integer numberOfTimesExceeded) {
    this.numberOfTimesExceeded = numberOfTimesExceeded;
  }
}
