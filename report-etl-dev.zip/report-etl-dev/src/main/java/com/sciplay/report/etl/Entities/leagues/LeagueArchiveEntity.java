package com.sciplay.report.etl.Entities.leagues;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

/** @author salman */
@Entity
@Table(name = "LeagueArchive")
public class LeagueArchiveEntity {

  @javax.persistence.Id
  @Column(name = "RevisionNumber")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long revisionNumber;

  @Column(name = "RevisionDate")
  private Date revisionDate;

  @Column(name = "RevisionState")
  private String revisionState;

  @Column(name = "Id")
  private String id;

  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  @Column(name = "Name")
  private String name;

  @Column(name = "ChairmanId")
  private String chairmanId;

  @Column(name = "creatorId")
  private String creatorId;

  @Column(name = "MaxNumberOfParticipant")
  private Integer maxNumberOfParticipant;

  @Column(name = "MinNumberOfParticipant")
  private Integer minNumberOfParticipant;

  @Column(name = "Status", columnDefinition = "enum('OPEN','CLOSED','LOCKED','O','C','L')")
  private String status;

  @Column(name = "CompetitionId")
  private String competitionId;

  @Column(name = "CompetitionName")
  private String competitionName;

  @Column(name = "CompetitionStartDatetime")
  private Date competitionStartDatetime;

  @Column(name = "CloseDate")
  private Date closeDate;

  @Column(name = "AuthorId")
  private Integer authorId;

  @Column(name = "AuthorIp")
  private String authorIp;

  @Column(name = "AuthorSessionId")
  private String authorSessionId;

  @Column(name = "CreatedAt")
  private Date createdAt;

  public LeagueArchiveEntity() {}

  public LeagueArchiveEntity(LeagueEntity leagueEntity, String revisionState) {
    this.id = leagueEntity.getId();
    this.operatorId = leagueEntity.getOperatorId();
    this.name = leagueEntity.getName();
    this.chairmanId = leagueEntity.getChairmanId();
    this.creatorId = leagueEntity.getCreatorId();
    this.maxNumberOfParticipant = leagueEntity.getMaxNumberOfParticipant();
    this.minNumberOfParticipant = leagueEntity.getMinNumberOfParticipant();
    this.status = leagueEntity.getStatus();
    this.competitionId = leagueEntity.getCompetitionId();
    this.competitionName = leagueEntity.getCompetitionName();
    this.competitionStartDatetime = leagueEntity.getCompetitionStartDatetime();
    this.closeDate = leagueEntity.getCloseDate();
    this.authorId = leagueEntity.getAuthorId();
    this.authorIp = leagueEntity.getAuthorIp();
    this.authorSessionId = leagueEntity.getAuthorSessionId();
    this.createdAt = leagueEntity.getCreatedAt();
    this.revisionDate = leagueEntity.getUpdatedAt();
    this.revisionState = revisionState;
  }

  public long getRevisionNumber() {
    return revisionNumber;
  }

  public void setRevisionNumber(long revisionNumber) {
    this.revisionNumber = revisionNumber;
  }

  public Date getRevisionDate() {
    return revisionDate;
  }

  public void setRevisionDate(Date revisionDate) {
    this.revisionDate = revisionDate;
  }

  public String getRevisionState() {
    return revisionState;
  }

  public void setRevisionState(String revisionState) {
    this.revisionState = revisionState;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getOperatorId() {
    return operatorId;
  }

  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getChairmanId() {
    return chairmanId;
  }

  public void setChairmanId(String chairmanId) {
    this.chairmanId = chairmanId;
  }

  public String getCreatorId() {
    return creatorId;
  }

  public void setCreatorId(String creatorId) {
    this.creatorId = creatorId;
  }

  public Integer getMaxNumberOfParticipant() {
    return maxNumberOfParticipant;
  }

  public void setMaxNumberOfParticipant(Integer maxNumberOfParticipant) {
    this.maxNumberOfParticipant = maxNumberOfParticipant;
  }

  public Integer getMinNumberOfParticipant() {
    return minNumberOfParticipant;
  }

  public void setMinNumberOfParticipant(Integer minNumberOfParticipant) {
    this.minNumberOfParticipant = minNumberOfParticipant;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getCompetitionId() {
    return competitionId;
  }

  public void setCompetitionId(String competitionId) {
    this.competitionId = competitionId;
  }

  public String getCompetitionName() {
    return competitionName;
  }

  public void setCompetitionName(String competitionName) {
    this.competitionName = competitionName;
  }

  public Date getCompetitionStartDatetime() {
    return competitionStartDatetime;
  }

  public void setCompetitionStartDatetime(Date competitionStartDatetime) {
    this.competitionStartDatetime = competitionStartDatetime;
  }

  public Date getCloseDate() {
    return closeDate;
  }

  public void setCloseDate(Date closeDate) {
    this.closeDate = closeDate;
  }

  public Integer getAuthorId() {
    return authorId;
  }

  public void setAuthorId(Integer authorId) {
    this.authorId = authorId;
  }

  public String getAuthorIp() {
    return authorIp;
  }

  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  public String getAuthorSessionId() {
    return authorSessionId;
  }

  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  public Date getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }
}
