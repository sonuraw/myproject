package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public final class HealthCheckResponse {

  private final boolean healthy;
  private final HealthCheckResponseData dependencies;

  public HealthCheckResponse(boolean healthy, HealthCheckResponseData dependencies) {
    boolean healthy1;
    healthy1 = healthy;
    this.dependencies = dependencies;
    if (dependencies.getEtlServiceErrorLogHealth() != null
        && !dependencies.getEtlServiceErrorLogHealth().isHealthy()) {
      healthy1 = false;
    }

    if (dependencies.getEventDispatcherMissingStoreHealth() != null
        && !dependencies.getEventDispatcherMissingStoreHealth().isHealthy()) {
      healthy1 = false;
    }
    if (dependencies.getJmsTopicIndexHealth() != null
        && !dependencies.getJmsTopicIndexHealth().isHealthy()) {
      healthy1 = false;
    }
    this.healthy = healthy1;
  }

  @JsonProperty
  public boolean getHealthy() {

    return healthy;
  }

  @JsonProperty
  public HealthCheckResponseData getDependencies() {
    return dependencies;
  }
}
