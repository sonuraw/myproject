package com.sciplay.report.etl.Entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class SubscriptionSchedulePayloadEntity. */
@Entity
@Table(name = "SubscriptionSchedulePayload")
public class SubscriptionSchedulePayloadEntity implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The Id. */
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int id;

  /** The Year. */
  @Column(name = "Year")
  private Integer year;

  /** The Operator id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The Trigger time. */
  @Column(name = "TriggerTime")
  private Date triggerTime;

  /** The Actions. */
  @Column(name = "Actions")
  private String actions;

  /** The Schedule id. */
  @Column(name = "ScheduleId")
  private Integer scheduleId;

  /**
   * Gets the id.
   *
   * @return the id
   */
  public int getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(int id) {
    this.id = id;
  }

  /**
   * Gets the year.
   *
   * @return the year
   */
  public Integer getYear() {
    return year;
  }

  /**
   * Sets the year.
   *
   * @param year the new year
   */
  public void setYear(Integer year) {
    if (year == null) {
      year = 0;
    }
    this.year = year;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the trigger time.
   *
   * @return the trigger time
   */
  public Date getTriggerTime() {
    return triggerTime;
  }

  /**
   * Sets the trigger time.
   *
   * @param triggerTime the new trigger time
   */
  public void setTriggerTime(Date triggerTime) {
    this.triggerTime = triggerTime;
  }

  /**
   * Gets the actions.
   *
   * @return the actions
   */
  public String getActions() {
    return actions;
  }

  /**
   * Sets the actions.
   *
   * @param actions the new actions
   */
  public void setActions(String actions) {
    this.actions = actions;
  }

  /**
   * Gets the schedule id.
   *
   * @return the schedule id
   */
  public Integer getScheduleId() {
    return scheduleId;
  }

  /**
   * Sets the schedule id.
   *
   * @param scheduleId the new schedule id
   */
  public void setScheduleId(Integer scheduleId) {
    if (scheduleId == null) {
      scheduleId = 0;
    }
    this.scheduleId = scheduleId;
  }
}
