package com.sciplay.report.etl.Entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class SubscriptionsEntity. */
@Entity
@Table(name = "Subscriptions")
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubscriptionsEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The id. */
  @Id
  @Column(name = "Id")
  private Long id;

  /** The player id. */
  private Integer playerId;

  /** The operator id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The subscription name. */
  private String subscriptionName;

  /** The start date. */
  private Date startDate;

  /** The end date. */
  private Date endDate;

  /** The created date. */
  private Date createdDate;

  /** The total cost. */
  private long totalCost;

  /** The status. */
  private String status;

  /** The pbsagreemant number. */
  private String pbsAgreementNumber;

  /** The purchased with. */
  private String purchasedWith;

  /** The winnings sent to. */
  private String winningsSentTo;

  /** The comment. */
  @Column(name = "Comment", length = 65535, columnDefinition = "TEXT")
  private String comment;

  /** The author id. */
  private Integer authorId;

  /** The author ip. */
  private String authorIp;

  /** The author session id. */
  private String authorSessionId;

  /** The author type. */
  private String authorType;

  /** The purchased with account type. */
  private String purchasedWithAccountType;

  /** The Modified at. */
  private Date modifiedAt;

  /** The Is addon. */
  private Boolean isAddOn;

  /** The Cancelled agent id. */
  private Integer cancelledAgentId;

  /** The Cancelled date time. */
  private Date cancelledDateTime;

  /** The On hold until. */
  private Date onHoldUntil;

  /** The Is gap purchase. */
  private Boolean isGapPurchase;

  /** The Gap funding payment method id. */
  private String gapFundingPaymentMethodId;

  /** The Modified by author id. */
  private Integer modifiedByAuthorId;

  /** The Modified by author type. */
  private String modifiedByAuthorType;

  /** The Projected Start Date */
  private Date projectedStartDate;

  /** Instantiates a new subscriptions entity. */
  public SubscriptionsEntity() {}

  /**
   * Instantiates a new subscriptions entity.
   *
   * @param id the id
   * @param playerId the player id
   * @param operatorId the operator id
   * @param subscriptionName the subscription name
   * @param startDate the start date
   * @param endDate the end date
   * @param createdDate the created date
   * @param totalCost the total cost
   * @param status the status
   * @param pbsAgreementNumber the pbsagreemant number
   * @param purchasedWith the purchased with
   * @param winningsSentTo the winnings sent to
   * @param comment the comment
   * @param authorId the author id
   * @param authorIp the author ip
   * @param authorSessionId the author session id
   * @param authorType the author type
   * @param modifiedAt the modified at
   * @param isAddOn the is addon
   */
  public SubscriptionsEntity(
      Long id,
      Integer playerId,
      String operatorId,
      String subscriptionName,
      Date startDate,
      Date endDate,
      Date createdDate,
      Long totalCost,
      String status,
      String pbsAgreementNumber,
      String purchasedWith,
      String winningsSentTo,
      String comment,
      Integer authorId,
      String authorIp,
      String authorSessionId,
      String authorType,
      Date modifiedAt,
      Boolean isAddOn) {
    this.id = id;
    this.playerId = playerId;
    this.operatorId = operatorId;
    this.subscriptionName = subscriptionName;
    this.startDate = startDate;
    this.endDate = endDate;
    this.createdDate = createdDate;
    this.totalCost = Objects.isNull(totalCost) ? 0L : totalCost;
    this.status = status;
    this.pbsAgreementNumber = pbsAgreementNumber;
    this.purchasedWith = purchasedWith;
    this.winningsSentTo = winningsSentTo;
    this.comment = comment;
    this.authorId = Objects.isNull(authorId) ? 0 : authorId;
    this.authorIp = authorIp;
    this.authorSessionId = authorSessionId;
    this.authorType = authorType;
    this.modifiedAt = modifiedAt;
    this.isAddOn = Objects.isNull(isAddOn) ? false : isAddOn;
  }

  /**
   * Gets the modified by author id.
   *
   * @return the modified by author id
   */
  public Integer getModifiedByAuthorId() {
    return modifiedByAuthorId;
  }

  /**
   * Sets the modified by author id.
   *
   * @param modifiedByAuthorId the new modified by author id
   */
  public void setModifiedByAuthorId(Integer modifiedByAuthorId) {
    this.modifiedByAuthorId = Objects.isNull(modifiedByAuthorId) ? 0 : modifiedByAuthorId;
  }

  /**
   * Gets the modified by author type.
   *
   * @return the modified by author type
   */
  public String getModifiedByAuthorType() {
    return modifiedByAuthorType;
  }

  /**
   * Sets the modified by author type.
   *
   * @param modifiedByAuthorType the new modified by author type
   */
  public void setModifiedByAuthorType(String modifiedByAuthorType) {
    this.modifiedByAuthorType = modifiedByAuthorType;
  }

  /**
   * Checks if is gap purchase.
   *
   * @return true, if is gap purchase
   */
  public Boolean isGapPurchase() {
    return isGapPurchase;
  }

  /**
   * Sets the gap purchase.
   *
   * @param isGapPurchase the new gap purchase
   */
  public void setGapPurchase(Boolean isGapPurchase) {
    this.isGapPurchase = Objects.isNull(isGapPurchase) ? false : isGapPurchase;
  }

  /**
   * Checks if is adds the on.
   *
   * @return true, if is adds the on
   */
  public Boolean isAddOn() {
    return isAddOn;
  }

  /**
   * Sets the adds the on.
   *
   * @param isAddOn the new adds the on
   */
  public void setAddOn(Boolean isAddOn) {
    this.isAddOn = isAddOn;
  }

  /**
   * Gets the gap funding payment method id.
   *
   * @return the gap funding payment method id
   */
  public String getGapFundingPaymentMethodId() {
    return gapFundingPaymentMethodId;
  }

  /**
   * Sets the gap funding payment method id.
   *
   * @param gapFundingPaymentMethodId the new gap funding payment method id
   */
  public void setGapFundingPaymentMethodId(String gapFundingPaymentMethodId) {
    this.gapFundingPaymentMethodId = gapFundingPaymentMethodId;
  }

  /**
   * Gets the on hold until.
   *
   * @return the on hold until
   */
  public Date getOnHoldUntil() {
    return onHoldUntil;
  }

  /**
   * Sets the on hold until.
   *
   * @param onHoldUntil the new on hold until
   */
  public void setOnHoldUntil(Date onHoldUntil) {
    this.onHoldUntil = onHoldUntil;
  }

  /**
   * Gets the cancelled agent id.
   *
   * @return the cancelled agent id
   */
  public Integer getCancelledAgentId() {
    return cancelledAgentId;
  }

  /**
   * Sets the cancelled agent id.
   *
   * @param cancelledAgentId the new cancelled agent id
   */
  public void setCancelledAgentId(Integer cancelledAgentId) {
    this.cancelledAgentId = Objects.isNull(cancelledAgentId) ? 0 : cancelledAgentId;
  }

  /**
   * Gets the cancelled date time.
   *
   * @return the cancelled date time
   */
  public Date getCancelledDateTime() {
    return cancelledDateTime;
  }

  /**
   * Sets the cancelled date time.
   *
   * @param cancelledDateTime the new cancelled date time
   */
  public void setCancelledDateTime(Date cancelledDateTime) {
    this.cancelledDateTime = cancelledDateTime;
  }

  /**
   * Checks if is checks if is addon.
   *
   * @return true, if is checks if is addon
   */
  public Boolean isIsAddon() {
    return isAddOn;
  }

  /**
   * Sets the checks if is addon.
   *
   * @param isAddon the new checks if is addon
   */
  public void setIsAddon(Boolean isAddOn) {
    if (isAddOn == null) {
      this.isAddOn = false;
    } else {
      this.isAddOn = isAddOn;
    }
  }

  /**
   * Gets the modified at.
   *
   * @return the modified at
   */
  public Date getModifiedAt() {
    return modifiedAt;
  }

  /**
   * Sets the modified at.
   *
   * @param modifiedAt the new modified at
   */
  public void setModifiedAt(Date modifiedAt) {
    this.modifiedAt = modifiedAt;
  }

  /**
   * Gets the purchased with account type.
   *
   * @return the purchased with account type
   */
  public String getPurchasedWithAccountType() {
    return purchasedWithAccountType;
  }

  /**
   * Sets the purchased with account type.
   *
   * @param purchasedWithAccountType the new purchased with account type
   */
  public void setPurchasedWithAccountType(String purchasedWithAccountType) {
    this.purchasedWithAccountType = purchasedWithAccountType;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public Long getId() {
    return this.id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(Long id) {
    this.id = id;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return this.playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return this.operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the subscription name.
   *
   * @return the subscription name
   */
  public String getSubscriptionName() {
    return this.subscriptionName;
  }

  /**
   * Sets the subscription name.
   *
   * @param subscriptionName the new subscription name
   */
  public void setSubscriptionName(String subscriptionName) {
    this.subscriptionName = subscriptionName;
  }

  /**
   * Gets the start date.
   *
   * @return the start date
   */
  public Date getStartDate() {
    return this.startDate;
  }

  /**
   * Sets the start date.
   *
   * @param startDate the new start date
   */
  public void setStartDate(Date startDate) {
    this.startDate = startDate;
  }

  /**
   * Gets the end date.
   *
   * @return the end date
   */
  public Date getEndDate() {
    return this.endDate;
  }

  /**
   * Sets the end date.
   *
   * @param endDate the new end date
   */
  public void setEndDate(Date endDate) {
    this.endDate = endDate;
  }

  /**
   * Gets the created date.
   *
   * @return the created date
   */
  public Date getCreatedDate() {
    return this.createdDate;
  }

  /**
   * Sets the created date.
   *
   * @param createdDate the new created date
   */
  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  /**
   * Gets the total cost.
   *
   * @return the total cost
   */
  public long getTotalCost() {
    return this.totalCost;
  }

  /**
   * Sets the total cost.
   *
   * @param totalCost the new total cost
   */
  public void setTotalCost(Long totalCost) {
    this.totalCost = Objects.isNull(totalCost) ? 0L : totalCost;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public String getStatus() {
    return this.status;
  }

  /**
   * Sets the status.
   *
   * @param status the new status
   */
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * Gets the pbsagreemant number.
   *
   * @return the pbsagreemant number
   */
  public String getPbsAgreementNumber() {
    return this.pbsAgreementNumber;
  }

  /**
   * Sets the pbsagreemant number.
   *
   * @param pbsAgreementNumber the new pbsagreemant number
   */
  public void setPbsAgreementNumber(String pbsAgreementNumber) {
    this.pbsAgreementNumber = pbsAgreementNumber;
  }

  /**
   * Gets the purchased with.
   *
   * @return the purchased with
   */
  public String getPurchasedWith() {
    return this.purchasedWith;
  }

  /**
   * Sets the purchased with.
   *
   * @param purchasedWith the new purchased with
   */
  public void setPurchasedWith(String purchasedWith) {
    this.purchasedWith = purchasedWith;
  }

  /**
   * Gets the winnings sent to.
   *
   * @return the winnings sent to
   */
  public String getWinningsSentTo() {
    return this.winningsSentTo;
  }

  /**
   * Sets the winnings sent to.
   *
   * @param winningsSentTo the new winnings sent to
   */
  public void setWinningsSentTo(String winningsSentTo) {
    this.winningsSentTo = winningsSentTo;
  }

  /**
   * Gets the comment.
   *
   * @return the comment
   */
  public String getComment() {
    return this.comment;
  }

  /**
   * Sets the comment.
   *
   * @param comment the new comment
   */
  public void setComment(String comment) {
    this.comment = comment;
  }

  /**
   * Gets the author id.
   *
   * @return the author id
   */
  public Integer getAuthorId() {
    return this.authorId;
  }

  /**
   * Sets the author id.
   *
   * @param authorId the new author id
   */
  public void setAuthorId(Integer authorId) {
    this.authorId = Objects.isNull(authorId) ? 0 : authorId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return this.authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return this.authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the author type.
   *
   * @return the author type
   */
  public String getAuthorType() {
    return this.authorType;
  }

  /**
   * Sets the author type.
   *
   * @param authorType the new author type
   */
  public void setAuthorType(String authorType) {
    this.authorType = authorType;
  }

  /** @return the projectedStartDate */
  public Date getProjectedStartDate() {
    return projectedStartDate;
  }

  /** @param featureStartDate the featureStartDate to set */
  public void setProjectedStartDate(Date projectedStartDate) {
    this.projectedStartDate = projectedStartDate;
  }
}
