package com.sciplay.report.etl.Entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.hibernate.annotations.Type;

/** The Class PlayerInfoEntity. */
@Entity
@Table(name = "PlayerProfile")
public class PlayerProfileEntity implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** Player ID. */
  @Id
  @Column(name = "Id")
  private Integer id;

  /** Player Operator. */
  @Id
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The Status. */
  @Column(name = "Status")
  private String status;

  /** The status reason id. */
  @Column(name = "StatusReasonId")
  private String statusReasonId;

  /** The status reason. */
  @Column(name = "StatusReason")
  private String statusReason;

  /** The user name. */
  @Column(name = "UserName")
  private String userName;

  /** The alias. */
  @Column(name = "Alias")
  private String alias;

  /** The password. */
  @Column(name = "Password")
  private String password;

  /** The first name. */
  @Column(name = "FirstName")
  private String firstName;

  /** The last name. */
  @Column(name = "LastName")
  private String lastName;

  /** The gender. */
  @Column(name = "Gender")
  private String gender;

  /** The email. */
  @Column(name = "Email")
  private String email;

  /** The birth date. */
  @Column(name = "BirthDate")
  private Date birthDate;

  /** The exch code. */
  @Column(name = "ExchCode")
  private String exchCode;

  /** The locale. */
  @Column(name = "Locale")
  private String locale;

  /** The operator player id. */
  @Column(name = "OperatorPlayerId")
  private Integer operatorPlayerId;

  /** The operator payload. */
  @Column(name = "OperatorPayload")
  private String operatorPayload;

  /** The security question. */
  @Column(name = "SecurityQuestion")
  private String securityQuestion;

  /** The security answer. */
  @Column(name = "SecurityAnswer")
  private String securityAnswer;

  /** The registration type. */
  @Column(name = "RegistrationType")
  private String registrationType;

  /** The registration user agent. */
  @Column(name = "RegistrationUserAgent")
  @Type(type = "text")
  private String registrationUserAgent;

  /** The registration promotional code. */
  @Column(name = "RegistrationPromotionalCode")
  private String registrationPromotionalCode;

  /** The is testing account. */
  @Column(name = "IsTestingAccount")
  private Boolean isTestingAccount;

  /** The is politically exposed. */
  @Column(name = "IsPoliticallyExposed")
  private Boolean isPoliticallyExposed;

  /** The occupation. */
  @Column(name = "Occupation")
  private String occupation;

  /** The is email valid. */
  @Column(name = "IsEmailValid")
  private Boolean isEmailValid;

  /** The is name valid. */
  @Column(name = "IsNameValid")
  private Boolean isNameValid;

  /** The is birth date valid. */
  @Column(name = "IsBirthDateValid")
  private Boolean isBirthDateValid;

  /** The vip level. */
  @Column(name = "VipLevel")
  private Integer vipLevel;

  /** The author player id. */
  @Column(name = "AuthorPlayerId")
  private Integer authorPlayerId;

  /** The author agent id. */
  @Column(name = "AuthorAgentId")
  private Integer authorAgentId;

  /** The author ip. */
  @Column(name = "AuthorIp")
  private String authorIp;

  /** The author session id. */
  @Column(name = "AuthorSessionId")
  private String authorSessionId;

  /** The created at. */
  @Column(name = "CreatedAt")
  private Date createdAt;

  /** The country. */
  @Column(name = "Country")
  private String country;

  /** The affiliate partner. */
  @Column(name = "AffiliatePartner")
  private String affiliatePartner;

  /** The affiliate campaign. */
  @Column(name = "AffiliateCampaign")
  private String affiliateCampaign;

  /** The affiliate payload. */
  @Column(name = "AffiliatePayload")
  private String affiliatePayload;

  /** The first subscription amount. */
  @Column(name = "FirstSubscriptionAmount")
  private Long firstSubscriptionAmount;

  /** The first subscription date. */
  @Column(name = "FirstSubscriptionDate")
  private Date firstSubscriptionDate;

  /** The re activated date. */
  @Column(name = "ReActivatedDate")
  private Date reActivatedDate;

  /** The modified at. */
  @Column(name = "ModifiedAt")
  private Date modifiedAt;

  /** The locked closed at. */
  @Column(name = "LockedClosedAt")
  private Date lockedClosedAt;

  /** The Subscription enabled. */
  private Boolean subscriptionEnabled;

  /** The Subscription enabled disabled date. */
  private Date subscriptionEnabledDisabledDate;

  /** The Login enabled. */
  private Boolean loginEnabled;

  /** The Login enabled disabled date. */
  private Date loginEnabledDisabledDate;

  /** The Default account. */
  @Column(name = "DefaultWinningsAccount")
  private String defaultWinningsAccount;

  /** The Default preferred game. */
  @Column(name = "PreferredGame")
  private String preferredGame;

  /** The Locked closed author id. */
  @Column(name = "AuthorName")
  private String authorName;

  /** The Locked closed author id. */
  private Integer lockedClosedAuthorId;

  /** The Subscription enabled disabled author id. */
  private Integer subscriptionEnabledDisabledAuthorId;
  /** The is reactivated. */
  @Column(columnDefinition = "enum('true','false')")
  private String isReactivated;
  /** The player address entity. */
  // joinColumns={@JoinColumn(name="Id", referencedColumnName="PlayerId")})
  @OneToMany(fetch = FetchType.EAGER)
  @JoinColumns({@JoinColumn(name = "PlayerId"), @JoinColumn(name = "OperatorId")})
  private List<PlayerAddressEntity> playerAddressEntity;

  /** The login notification enabled. */
  private Boolean loginNotificationEnabled;

  /** The affiliate modification date. */
  private Date affiliateModificationDate;

  /** The last login date. */
  private Date lastLoginDate;

  @Column(name = "IsPlayerSecured")
  private Boolean isPlayerSecured = false;

  /** Instantiates a new player info entity. */
  public PlayerProfileEntity() {}

  /**
   * Gets the last login date.
   *
   * @return the last login date
   */
  public Date getLastLoginDate() {
    return lastLoginDate;
  }

  /**
   * Sets the last login date.
   *
   * @param lastLoginDate the new last login date
   */
  public void setLastLoginDate(Date lastLoginDate) {
    this.lastLoginDate = lastLoginDate;
  }

  /**
   * Gets the affiliate modification date.
   *
   * @return the affiliate modification date
   */
  public Date getAffiliateModificationDate() {
    return affiliateModificationDate;
  }

  /**
   * Sets the affiliate modification date.
   *
   * @param affiliateModificationDate the new affiliate modification date
   */
  public void setAffiliateModificationDate(Date affiliateModificationDate) {
    this.affiliateModificationDate = affiliateModificationDate;
  }

  /**
   * Gets the login notification enabled.
   *
   * @return the login notification enabled
   */
  public Boolean getLoginNotificationEnabled() {
    return loginNotificationEnabled;
  }

  /**
   * Sets the login notification enabled.
   *
   * @param loginNotificationEnabled the new login notification enabled
   */
  public void setLoginNotificationEnabled(Boolean loginNotificationEnabled) {
    this.loginNotificationEnabled =
        (Objects.isNull(loginNotificationEnabled)) ? false : loginNotificationEnabled;
  }

  /**
   * Gets the subscription enabled disabled author id.
   *
   * @return the subscription enabled disabled author id
   */
  public Integer getSubscriptionEnabledDisabledAuthorId() {
    return subscriptionEnabledDisabledAuthorId;
  }

  /**
   * Sets the subscription enabled disabled author id.
   *
   * @param subscriptionEnabledDisabledAuthorId the new subscription enabled disabled author id
   */
  public void setSubscriptionEnabledDisabledAuthorId(Integer subscriptionEnabledDisabledAuthorId) {
    this.subscriptionEnabledDisabledAuthorId =
        (Objects.isNull(subscriptionEnabledDisabledAuthorId))
            ? 0
            : subscriptionEnabledDisabledAuthorId;
  }

  /**
   * Gets the locked closed author id.
   *
   * @return the locked closed author id
   */
  public Integer getLockedClosedAuthorId() {
    return lockedClosedAuthorId;
  }

  /**
   * Sets the locked closed author id.
   *
   * @param lockedClosedAuthorId the new locked closed author id
   */
  public void setLockedClosedAuthorId(Integer lockedClosedAuthorId) {
    this.lockedClosedAuthorId = (Objects.isNull(lockedClosedAuthorId)) ? 0 : lockedClosedAuthorId;
  }

  /**
   * Gets the login enabled.
   *
   * @return the login enabled
   */
  public Boolean getLoginEnabled() {
    return loginEnabled;
  }

  /**
   * Sets the login enabled.
   *
   * @param loginEnabled the new login enabled
   */
  public void setLoginEnabled(Boolean loginEnabled) {
    this.loginEnabled = (Objects.isNull(loginEnabled)) ? false : loginEnabled;
  }

  /**
   * Gets the login enabled disabled date.
   *
   * @return the login enabled disabled date
   */
  public Date getLoginEnabledDisabledDate() {
    return loginEnabledDisabledDate;
  }

  /**
   * Sets the login enabled disabled date.
   *
   * @param loginEnabledDisabledDate the new login enabled disabled date
   */
  public void setLoginEnabledDisabledDate(Date loginEnabledDisabledDate) {
    this.loginEnabledDisabledDate = loginEnabledDisabledDate;
  }

  /**
   * Gets the subscription enabled.
   *
   * @return the subscription enabled
   */
  public Boolean getSubscriptionEnabled() {
    return subscriptionEnabled;
  }

  /**
   * Sets the subscription enabled.
   *
   * @param subscriptionEnabled the new subscription enabled
   */
  public void setSubscriptionEnabled(Boolean subscriptionEnabled) {
    this.subscriptionEnabled = (Objects.isNull(subscriptionEnabled)) ? false : subscriptionEnabled;
  }

  /**
   * Gets the subscription enabled disabled date.
   *
   * @return the subscription enabled disabled date
   */
  public Date getSubscriptionEnabledDisabledDate() {
    return subscriptionEnabledDisabledDate;
  }

  /**
   * Sets the subscription enabled disabled date.
   *
   * @param subscriptionEnabledDisabledDate the new subscription enabled disabled date
   */
  public void setSubscriptionEnabledDisabledDate(Date subscriptionEnabledDisabledDate) {
    this.subscriptionEnabledDisabledDate = subscriptionEnabledDisabledDate;
  }

  // @OneToOne(cascade=CascadeType.ALL)
  // @JoinTable(name="PlayerAddress",

  /**
   * Sets the testing account.
   *
   * @param isTestingAccount the new testing account
   */
  public void setTestingAccount(Boolean isTestingAccount) {
    this.isTestingAccount = isTestingAccount;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public Integer getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id the id to set
   */
  public void setId(Integer id) {
    this.id = id;
  }

  /**
   * Gets the operator id.
   *
   * @return the operatorId
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the operatorId to set
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public String getStatus() {
    return this.status;
  }

  /**
   * Sets the status.
   *
   * @param status the new status
   */
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * Gets the status reason.
   *
   * @return the status reason
   */
  public String getStatusReason() {
    return this.statusReason;
  }

  /**
   * Sets the status reason.
   *
   * @param statusReason the new status reason
   */
  public void setStatusReason(String statusReason) {
    this.statusReason = statusReason;
  }

  /**
   * Gets the status reason id.
   *
   * @return the status reason id
   */
  public String getStatusReasonId() {
    return this.statusReasonId;
  }

  /**
   * Sets the status reason id.
   *
   * @param statusReasonId the new status reason id
   */
  public void setStatusReasonId(String statusReasonId) {
    this.statusReasonId = statusReasonId;
  }

  /**
   * Gets the user name.
   *
   * @return the user name
   */
  public String getUserName() {
    return this.userName;
  }

  /**
   * Sets the user name.
   *
   * @param userName the new user name
   */
  public void setUserName(String userName) {
    this.userName = userName;
  }

  /**
   * Gets the alias.
   *
   * @return the alias
   */
  public String getAlias() {
    return this.alias;
  }

  /**
   * Sets the alias.
   *
   * @param alias the new alias
   */
  public void setAlias(String alias) {
    this.alias = alias;
  }

  /**
   * Gets the password.
   *
   * @return the password
   */
  public String getPassword() {
    return this.password;
  }

  /**
   * Sets the password.
   *
   * @param password the new password
   */
  public void setPassword(String password) {
    this.password = password;
  }

  /**
   * Gets the first name.
   *
   * @return the first name
   */
  public String getFirstName() {
    return this.firstName;
  }

  /**
   * Sets the first name.
   *
   * @param firstName the new first name
   */
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  /**
   * Gets the last name.
   *
   * @return the last name
   */
  public String getLastName() {
    return this.lastName;
  }

  /**
   * Sets the last name.
   *
   * @param lastName the new last name
   */
  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  /**
   * Gets the gender.
   *
   * @return the gender
   */
  public String getGender() {
    return this.gender;
  }

  /**
   * Sets the gender.
   *
   * @param gender the new gender
   */
  public void setGender(String gender) {
    this.gender = gender;
  }

  /**
   * Gets the email.
   *
   * @return the email
   */
  public String getEmail() {
    return this.email;
  }

  /**
   * Sets the email.
   *
   * @param email the new email
   */
  public void setEmail(String email) {
    this.email = email;
  }

  /**
   * Gets the exch code.
   *
   * @return the exch code
   */
  public String getExchCode() {
    return this.exchCode;
  }

  /**
   * Sets the exch code.
   *
   * @param exchCode the new exch code
   */
  public void setExchCode(String exchCode) {
    this.exchCode = exchCode;
  }

  /**
   * Gets the locale.
   *
   * @return the locale
   */
  public String getLocale() {
    return this.locale;
  }

  /**
   * Sets the locale.
   *
   * @param locale the new locale
   */
  public void setLocale(String locale) {
    this.locale = locale;
  }

  /**
   * Gets the operator player id.
   *
   * @return the operator player id
   */
  public Integer getOperatorPlayerId() {
    return this.operatorPlayerId;
  }

  /**
   * Sets the operator player id.
   *
   * @param operatorPlayerId the new operator player id
   */
  public void setOperatorPlayerId(Integer operatorPlayerId) {
    this.operatorPlayerId = (Objects.isNull(operatorPlayerId)) ? 0 : operatorPlayerId;
  }

  /**
   * Gets the operator payload.
   *
   * @return the operator payload
   */
  public String getOperatorPayload() {
    return this.operatorPayload;
  }

  /**
   * Sets the operator payload.
   *
   * @param operatorPayload the new operator payload
   */
  public void setOperatorPayload(String operatorPayload) {
    this.operatorPayload = operatorPayload;
  }

  /**
   * Gets the security question.
   *
   * @return the security question
   */
  public String getSecurityQuestion() {
    return this.securityQuestion;
  }

  /**
   * Sets the security question.
   *
   * @param securityQuestion the new security question
   */
  public void setSecurityQuestion(String securityQuestion) {
    this.securityQuestion = securityQuestion;
  }

  /**
   * Gets the security answer.
   *
   * @return the security answer
   */
  public String getSecurityAnswer() {
    return this.securityAnswer;
  }

  /**
   * Sets the security answer.
   *
   * @param securityAnswer the new security answer
   */
  public void setSecurityAnswer(String securityAnswer) {
    this.securityAnswer = securityAnswer;
  }

  /**
   * Gets the registration type.
   *
   * @return the registration type
   */
  public String getRegistrationType() {
    return this.registrationType;
  }

  /**
   * Sets the registration type.
   *
   * @param registrationType the new registration type
   */
  public void setRegistrationType(String registrationType) {
    this.registrationType = registrationType;
  }

  /**
   * Gets the registration user agent.
   *
   * @return the registration user agent
   */
  public String getRegistrationUserAgent() {
    return this.registrationUserAgent;
  }

  /**
   * Sets the registration user agent.
   *
   * @param registrationUserAgent the new registration user agent
   */
  public void setRegistrationUserAgent(String registrationUserAgent) {
    this.registrationUserAgent = registrationUserAgent;
  }

  /**
   * Gets the registration promotional code.
   *
   * @return the registration promotional code
   */
  public String getRegistrationPromotionalCode() {
    return this.registrationPromotionalCode;
  }

  /**
   * Sets the registration promotional code.
   *
   * @param registrationPromotionalCode the new registration promotional code
   */
  public void setRegistrationPromotionalCode(String registrationPromotionalCode) {
    this.registrationPromotionalCode = registrationPromotionalCode;
  }

  /**
   * Gets the checks if is testing account.
   *
   * @return the checks if is testing account
   */
  public Boolean getIsTestingAccount() {
    return this.isTestingAccount;
  }

  /**
   * Sets the checks if is testing account.
   *
   * @param isTestingAccount the new checks if is testing account
   */
  public void setIsTestingAccount(boolean isTestingAccount) {
    this.isTestingAccount = isTestingAccount;
  }

  /**
   * Gets the checks if is politically exposed.
   *
   * @return the checks if is politically exposed
   */
  public Boolean getIsPoliticallyExposed() {
    return this.isPoliticallyExposed;
  }

  /**
   * Sets the checks if is politically exposed.
   *
   * @param isPoliticallyExposed the new checks if is politically exposed
   */
  public void setIsPoliticallyExposed(Boolean isPoliticallyExposed) {
    this.isPoliticallyExposed = isPoliticallyExposed;
  }

  /**
   * Gets the occupation.
   *
   * @return the occupation
   */
  public String getOccupation() {
    return this.occupation;
  }

  /**
   * Sets the occupation.
   *
   * @param occupation the new occupation
   */
  public void setOccupation(String occupation) {
    this.occupation = occupation;
  }

  /**
   * Gets the checks if is email valid.
   *
   * @return the checks if is email valid
   */
  public Boolean getIsEmailValid() {
    return this.isEmailValid;
  }

  /**
   * Sets the checks if is email valid.
   *
   * @param isEmailValid the new checks if is email valid
   */
  public void setIsEmailValid(Boolean isEmailValid) {
    this.isEmailValid = isEmailValid;
  }

  /**
   * Gets the checks if is name valid.
   *
   * @return the checks if is name valid
   */
  public Boolean getIsNameValid() {
    return this.isNameValid;
  }

  /**
   * Sets the checks if is name valid.
   *
   * @param isNameValid the new checks if is name valid
   */
  public void setIsNameValid(Boolean isNameValid) {
    this.isNameValid = isNameValid;
  }

  /**
   * Gets the checks if is birth date valid.
   *
   * @return the checks if is birth date valid
   */
  public Boolean getIsBirthDateValid() {
    return this.isBirthDateValid;
  }

  /**
   * Sets the checks if is birth date valid.
   *
   * @param isBirthDateValid the new checks if is birth date valid
   */
  public void setIsBirthDateValid(Boolean isBirthDateValid) {
    this.isBirthDateValid = isBirthDateValid;
  }

  /**
   * Gets the vip level.
   *
   * @return the vip level
   */
  public int getVipLevel() {
    return this.vipLevel;
  }

  /**
   * Sets the vip level.
   *
   * @param vipLevel the new vip level
   */
  public void setVipLevel(Integer vipLevel) {
    this.vipLevel = vipLevel;
  }

  /**
   * Sets the vip level.
   *
   * @param vipLevel the new vip level
   */
  public void setVipLevel(int vipLevel) {
    this.vipLevel = vipLevel;
  }

  /**
   * Gets the author player id.
   *
   * @return the author player id
   */
  public Integer getAuthorPlayerId() {
    return this.authorPlayerId;
  }

  /**
   * Sets the author player id.
   *
   * @param authorPlayerId the new author player id
   */
  public void setAuthorPlayerId(Integer authorPlayerId) {
    this.authorPlayerId = (Objects.isNull(authorPlayerId)) ? 0 : authorPlayerId;
  }

  /**
   * Gets the author agent id.
   *
   * @return the author agent id
   */
  public Integer getAuthorAgentId() {
    return this.authorAgentId;
  }

  /**
   * Sets the author agent id.
   *
   * @param authorAgentId the new author agent id
   */
  public void setAuthorAgentId(Integer authorAgentId) {
    this.authorAgentId = (Objects.isNull(authorAgentId)) ? 0 : authorAgentId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return this.authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return this.authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the country.
   *
   * @return the country
   */
  public String getCountry() {
    return this.country;
  }

  /**
   * Sets the country.
   *
   * @param country the new country
   */
  public void setCountry(String country) {
    this.country = country;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return this.createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  /**
   * Gets the affiliate partner.
   *
   * @return the affiliate partner
   */
  public String getAffiliatePartner() {
    return this.affiliatePartner;
  }

  /**
   * Sets the affiliate partner.
   *
   * @param affiliatePartner the new affiliate partner
   */
  public void setAffiliatePartner(String affiliatePartner) {
    this.affiliatePartner = affiliatePartner;
  }

  /**
   * Gets the affiliate campaign.
   *
   * @return the affiliate campaign
   */
  public String getAffiliateCampaign() {
    return this.affiliateCampaign;
  }

  /**
   * Sets the affiliate campaign.
   *
   * @param affiliateCampaign the new affiliate campaign
   */
  public void setAffiliateCampaign(String affiliateCampaign) {
    this.affiliateCampaign = affiliateCampaign;
  }

  /**
   * Gets the affiliate payload.
   *
   * @return the affiliate payload
   */
  public String getAffiliatePayload() {
    return this.affiliatePayload;
  }

  /**
   * Sets the affiliate payload.
   *
   * @param affiliatePayload the new affiliate payload
   */
  public void setAffiliatePayload(String affiliatePayload) {
    this.affiliatePayload = affiliatePayload;
  }

  /**
   * Gets the first subscription amount.
   *
   * @return the first subscription amount
   */
  public Long getFirstSubscriptionAmount() {
    return this.firstSubscriptionAmount;
  }

  /**
   * Sets the first subscription amount.
   *
   * @param firstSubscriptionAmount the new first subscription amount
   */
  public void setFirstSubscriptionAmount(Long firstSubscriptionAmount) {
    this.firstSubscriptionAmount =
        (Objects.isNull(firstSubscriptionAmount)) ? 0L : firstSubscriptionAmount;
  }

  /**
   * Gets the checks if is reactivated.
   *
   * @return the checks if is reactivated
   */
  public String getIsReactivated() {
    return this.isReactivated;
  }

  /**
   * Sets the checks if is reactivated.
   *
   * @param isReactivated the new checks if is reactivated
   */
  public void setIsReactivated(String isReactivated) {
    this.isReactivated = isReactivated;
  }

  /**
   * Gets the birth date.
   *
   * @return the birth date
   */
  public Date getBirthDate() {
    return this.birthDate;
  }

  /**
   * Sets the birth date.
   *
   * @param birthDate the new birth date
   */
  public void setBirthDate(Date birthDate) {
    this.birthDate = birthDate;
  }

  /**
   * Gets the first subscription date.
   *
   * @return the first subscription date
   */
  public Date getFirstSubscriptionDate() {
    return this.firstSubscriptionDate;
  }

  /**
   * Sets the first subscription date.
   *
   * @param firstSubscriptionDate the new first subscription date
   */
  public void setFirstSubscriptionDate(Date firstSubscriptionDate) {
    this.firstSubscriptionDate = firstSubscriptionDate;
  }

  /**
   * Gets the re activated date.
   *
   * @return the re activated date
   */
  public Date getReActivatedDate() {
    return this.reActivatedDate;
  }

  /**
   * Sets the re activated date.
   *
   * @param reActivatedDate the new re activated date
   */
  public void setReActivatedDate(Date reActivatedDate) {
    this.reActivatedDate = reActivatedDate;
  }

  /**
   * Gets the modified at.
   *
   * @return the modified at
   */
  public Date getModifiedAt() {
    return this.modifiedAt;
  }

  /**
   * Sets the modified at.
   *
   * @param modifiedAt the new modified at
   */
  public void setModifiedAt(Date modifiedAt) {
    this.modifiedAt = modifiedAt;
  }

  /**
   * Gets the locked closed at.
   *
   * @return the locked closed at
   */
  public Date getLockedClosedAt() {
    return this.lockedClosedAt;
  }

  /**
   * Sets the locked closed at.
   *
   * @param lockedClosedAt the new locked closed at
   */
  public void setLockedClosedAt(Date lockedClosedAt) {
    this.lockedClosedAt = lockedClosedAt;
  }

  /**
   * Gets the player address entity.
   *
   * @return the player address entity
   */
  public List<PlayerAddressEntity> getPlayerAddressEntity() {
    return playerAddressEntity;
  }

  /**
   * Sets the player address entity.
   *
   * @param playerAddressEntity the new player address entity
   */
  public void setPlayerAddressEntity(List<PlayerAddressEntity> playerAddressEntity) {
    this.playerAddressEntity = playerAddressEntity;
  }

  /**
   * Gets the default winnings account.
   *
   * @return the default winnings account
   */
  public String getDefaultWinningsAccount() {
    return defaultWinningsAccount;
  }

  /**
   * Sets the default winnings account.
   *
   * @param defaultWinningsAccount the new default winnings account
   */
  public void setDefaultWinningsAccount(String defaultWinningsAccount) {
    this.defaultWinningsAccount = defaultWinningsAccount;
  }

  /**
   * Gets the preferred game.
   *
   * @return the preferred game
   */
  public String getPreferredGame() {
    return preferredGame;
  }

  /**
   * Sets the preferred game.
   *
   * @param preferredGame the new preferred game
   */
  public void setPreferredGame(String preferredGame) {
    this.preferredGame = preferredGame;
  }

  /**
   * Gets the author name.
   *
   * @return the authorName
   */
  public String getAuthorName() {
    return authorName;
  }

  /**
   * Sets the author name.
   *
   * @param authorName the authorName to set
   */
  public void setAuthorName(String authorName) {
    this.authorName = authorName;
  }

  public Boolean getPlayerSecured() {
    return isPlayerSecured;
  }

  public void setPlayerSecured(Boolean playerSecured) {
    this.isPlayerSecured = playerSecured;
  }
}
