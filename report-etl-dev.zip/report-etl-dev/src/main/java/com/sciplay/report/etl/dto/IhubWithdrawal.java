package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.ArrayList;

/** The Class PlayerActivation. */
@JsonIgnoreProperties(ignoreUnknown = true)
class IhubWithdrawal {

  /** The transactions. */
  private ArrayList<Transactions> transactions = new ArrayList<>();
}
