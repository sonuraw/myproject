package com.sciplay.report.etl.Entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EventDispatcherMissingStore")
public class EventDispatcherMissingStoreEntity implements Serializable {

  /** The id. */
  @Id
  @Column(name = "ServiceName")
  private String serviceName;

  /** The Topic. */
  @Id
  @Column(name = "EventId")
  private Long eventId;

  public Long getEventId() {
    return eventId;
  }

  public void setEventId(Long eventId) {
    this.eventId = eventId;
  }

  public String getServiceName() {
    return serviceName;
  }

  public void setServiceName(String serviceName) {
    this.serviceName = serviceName;
  }
}
