package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BaseResponseContainer<T> {

  private final MetaResponse meta;
  private final DataResponse<T> data;
  private final Links links;

  public BaseResponseContainer(MetaResponse metaObj, Links linksObj, DataResponse<T> dataObj) {
    this.meta = metaObj;
    this.links = linksObj;
    this.data = dataObj;
  }

  @JsonProperty
  public Links getLinks() {
    return links;
  }

  @JsonProperty
  public MetaResponse getMeta() {
    return meta;
  }

  /** @return the data */
  @JsonProperty
  public DataResponse<T> getData() {
    return data;
  }
}
