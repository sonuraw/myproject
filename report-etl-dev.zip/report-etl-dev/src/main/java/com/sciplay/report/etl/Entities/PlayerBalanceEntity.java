package com.sciplay.report.etl.Entities;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class PlayerBalanceEntity.
 *
 * @author salman
 */
@Entity
@Table(name = "PlayerBalance")
public class PlayerBalanceEntity implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The player id. */
  @Id
  @Column(name = "PlayerId")
  private Integer playerId;

  /** The operator id. */
  @Id
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The money type. */
  @Id
  @Column(name = "MoneyType")
  private String moneyType;

  /** The amount. */
  @Column(name = "Amount")
  private long amount;

  /** The updated date. */
  private Date updatedDate;

  /** The last wager date. */
  private Date lastWagerDate;

  /** The last activity date. */
  private Date lastActivityDate;

  /**
   * Instantiates a new player balance entity.
   *
   * @param playerId the player id
   * @param operatorId the operator id
   * @param moneyType the money type
   * @param amount the amount
   * @param updatedDate the updated date
   */
  public PlayerBalanceEntity(
      Integer playerId, String operatorId, String moneyType, long amount, Date updatedDate) {
    this.playerId = playerId;
    this.operatorId = operatorId;
    this.moneyType = moneyType;
    this.amount = Objects.isNull(amount) ? 0L : amount;
    this.updatedDate = updatedDate;
  }

  /** Instantiates a new player balance entity. */
  public PlayerBalanceEntity() {}

  /**
   * Gets the last wager date.
   *
   * @return the last wager date
   */
  public Date getLastWagerDate() {
    return lastWagerDate;
  }

  /**
   * Sets the last wager date.
   *
   * @param lastWagerDate the new last wager date
   */
  public void setLastWagerDate(Date lastWagerDate) {
    this.lastWagerDate = lastWagerDate;
  }

  /**
   * Gets the last activity date.
   *
   * @return the last activity date
   */
  public Date getLastActivityDate() {
    return lastActivityDate;
  }

  /**
   * Sets the last activity date.
   *
   * @param lastActivityDate the new last activity date
   */
  public void setLastActivityDate(Date lastActivityDate) {
    this.lastActivityDate = lastActivityDate;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the money type.
   *
   * @return the money type
   */
  public String getMoneyType() {
    return moneyType;
  }

  /**
   * Sets the money type.
   *
   * @param moneyType the new money type
   */
  public void setMoneyType(String moneyType) {
    this.moneyType = moneyType;
  }

  /**
   * Gets the amount.
   *
   * @return the amount
   */
  public long getAmount() {
    return amount;
  }

  /**
   * Sets the amount.
   *
   * @param amount the new amount
   */
  public void setAmount(long amount) {
    this.amount = Objects.isNull(amount) ? 0L : amount;
  }

  /**
   * Gets the updated date.
   *
   * @return the updated date
   */
  public Date getUpdatedDate() {
    return updatedDate;
  }

  /**
   * Sets the updated date.
   *
   * @param updatedDate the new updated date
   */
  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }
}
