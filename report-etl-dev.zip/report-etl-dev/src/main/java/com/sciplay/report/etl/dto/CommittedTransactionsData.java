package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** Created by 105450 on 8/8/2017. */

/** The Class CommittedTransactionsData. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class CommittedTransactionsData {
  /** The wallet id. */
  private Integer walletId;

  /** The operator. */
  private String operator;

  /** The transactionId. */
  private String transactionId;

  /** The eventId. */
  private String eventId;

  /** The external id. */
  private String externalId;

  /** The created at. */
  private String createdAt;

  /** The created at. */
  private String eventCreatedAt;

  /** The ledger. */
  private String ledger;

  /** The type. */
  private String type;

  /** The amount. */
  private long amount;

  /** The currency. */
  private String currency;

  /** The channel. */
  private String channel;

  /** The vertical. */
  private String vertical;

  /** The game. */
  private Integer game;

  /** The payload. */
  private WalletPayload payload;

  /** The ip. */
  private String ip;

  /** The session id. */
  private String sessionId;

  /** The previous balance. */
  private long previousBalance;

  /** The post balance. */
  private long postBalance;

  /** The agent. */
  private Integer agent;

  /** The bonus. */
  private String bonus;

  /** The status. */
  private String status;

  /** The fee. */
  private long fee;

  /** The payment method id. */
  private String paymentMethodType;

  private int paymentMethodId;

  /** the previous status. */
  private String previousStatus;

  /** the Player Card Type. */
  private String playerCardType;

  /** the Linked Transaction Id. */
  private Long linkedTransactionId;

  /** the captured. */
  private boolean captured;

  /** the captured. */
  private boolean approved;

  /** subscription - it can be undefined too */
  private Boolean subscription = null;

  /**
   * Gets the post balance.
   *
   * @return the post balance
   */
  public long getPostBalance() {
    return postBalance;
  }

  /**
   * Sets the post balance.
   *
   * @param postBalance the new post balance
   */
  public void setPostBalance(long postBalance) {
    this.postBalance = postBalance;
  }

  /**
   * Gets the operator.
   *
   * @return the operator
   */
  public String getOperator() {
    return operator;
  }

  /**
   * Sets the operator.
   *
   * @param operator the operator to set
   */
  public void setOperator(String operator) {
    this.operator = operator;
  }

  /**
   * Gets the tx ID.
   *
   * @return the txID
   */
  public long getTxID() {
    return Long.valueOf(transactionId);
  }

  /**
   * Gets the created at.
   *
   * @return the createdAt
   */
  public String getCreatedAt() {
    return createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the createdAt to set
   */
  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }

  /**
   * Gets the ledger.
   *
   * @return the ledger
   */
  public String getLedger() {
    return ledger;
  }

  /**
   * Sets the ledger.
   *
   * @param ledger the ledger to set
   */
  public void setLedger(String ledger) {
    this.ledger = ledger;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Sets the type.
   *
   * @param type the type to set
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the amount.
   *
   * @return the amount
   */
  public long getAmount() {
    return amount;
  }

  /**
   * Sets the amount.
   *
   * @param amount the amount to set
   */
  public void setAmount(long amount) {
    this.amount = amount;
  }

  /**
   * Gets the currency.
   *
   * @return the currency
   */
  public String getCurrency() {
    return currency;
  }

  /**
   * Sets the currency.
   *
   * @param currency the currency to set
   */
  public void setCurrency(String currency) {
    this.currency = currency;
  }

  /**
   * Gets the channel ID.
   *
   * @return the channelID
   */
  public String getChannelID() {
    return channel;
  }

  /**
   * Gets the player IP.
   *
   * @return the playerIP
   */
  public String getPlayerIP() {
    return ip;
  }

  /**
   * Gets the session ID.
   *
   * @return the sessionID
   */
  public String getSessionID() {
    return sessionId;
  }

  /**
   * Gets the previous balance.
   *
   * @return the previousBalance
   */
  public long getPreviousBalance() {
    return previousBalance;
  }

  /**
   * Sets the previous balance.
   *
   * @param previousBalance the previousBalance to set
   */
  public void setPreviousBalance(long previousBalance) {
    this.previousBalance = previousBalance;
  }

  /**
   * Gets the agent ID.
   *
   * @return the agentID
   */
  public Integer getAgentID() {
    return agent;
  }

  /**
   * Gets the bonus ID.
   *
   * @return the bonusID
   */
  public String getBonusID() {
    return bonus;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public String getStatus() {
    return status;
  }

  /**
   * Sets the status.
   *
   * @param status the status to set
   */
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * Gets the fee.
   *
   * @return the fee
   */
  public int getFee() {
    return (int) fee;
  }

  /**
   * Sets the fee.
   *
   * @param fee the fee to set
   */
  public void setFee(long fee) {
    this.fee = fee;
  }

  /**
   * Gets the vertical ID.
   *
   * @return the vertical ID
   */
  public String getVerticalID() {
    return vertical;
  }

  /**
   * Gets the game ID.
   *
   * @return the game ID
   */
  public Integer getGameID() {
    return game;
  }

  /**
   * Gets the wallet ID.
   *
   * @return the wallet ID
   */
  public Integer getWalletID() {
    return walletId;
  }

  /**
   * Gets the gv payload.
   *
   * @return the gv payload
   */
  public WalletPayload getGvPayload() {
    return payload;
  }

  /**
   * Gets the wallet id.
   *
   * @return the walletId
   */
  public Integer getWalletId() {
    return walletId;
  }

  /**
   * Sets the wallet id.
   *
   * @param walletId the walletId to set
   */
  public void setWalletId(Integer walletId) {
    this.walletId = walletId;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public String getId() {
    return transactionId;
  }

  /**
   * Sets the id.
   *
   * @param transactionId the new id
   */
  public void setId(String transactionId) {
    this.transactionId = transactionId;
  }

  /**
   * Gets the external id.
   *
   * @return the externalId
   */
  public String getExternalId() {
    return externalId;
  }

  /**
   * Sets the external id.
   *
   * @param externalId the externalId to set
   */
  public void setExternalId(String externalId) {
    this.externalId = externalId;
  }

  /**
   * Gets the channel.
   *
   * @return the channel
   */
  public String getChannel() {
    return channel;
  }

  /**
   * Sets the channel.
   *
   * @param channel the channel to set
   */
  public void setChannel(String channel) {
    this.channel = channel;
  }

  /**
   * Gets the vertical.
   *
   * @return the vertical
   */
  public String getVertical() {
    return vertical;
  }

  /**
   * Sets the vertical.
   *
   * @param vertical the vertical to set
   */
  public void setVertical(String vertical) {
    this.vertical = vertical;
  }

  /**
   * Gets the game.
   *
   * @return the game
   */
  public Integer getGame() {
    return game;
  }

  /**
   * Sets the game.
   *
   * @param game the game to set
   */
  public void setGame(Integer game) {
    this.game = game;
  }

  /**
   * Gets the payload.
   *
   * @return the payload
   */
  public WalletPayload getPayload() {
    return payload;
  }

  /**
   * Sets the payload.
   *
   * @param payload the payload to set
   */
  public void setPayload(WalletPayload payload) {
    this.payload = payload;
  }

  /**
   * Gets the ip.
   *
   * @return the ip
   */
  public String getIp() {
    return ip;
  }

  /**
   * Sets the ip.
   *
   * @param ip the ip to set
   */
  public void setIp(String ip) {
    this.ip = ip;
  }

  /**
   * Gets the session id.
   *
   * @return the sessionId
   */
  public String getSessionId() {
    return sessionId;
  }

  /**
   * Sets the session id.
   *
   * @param sessionId the sessionId to set
   */
  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  /**
   * Gets the agent.
   *
   * @return the agent
   */
  public Integer getAgent() {
    return agent;
  }

  /**
   * Sets the agent.
   *
   * @param agent the agent to set
   */
  public void setAgent(Integer agent) {
    this.agent = agent;
  }

  /**
   * Gets the bonus.
   *
   * @return the bonus
   */
  public String getBonus() {
    return bonus;
  }

  /**
   * Sets the bonus.
   *
   * @param bonus the bonus to set
   */
  public void setBonus(String bonus) {
    this.bonus = bonus;
  }

  /**
   * Gets the payment method id.
   *
   * @return the paymentMethodId
   */
  public int getPaymentMethodId() {
    if (paymentMethodId == 0) {
      return 0;
    } else {
      return paymentMethodId;
    }
  }

  /**
   * Sets the payment method id.
   *
   * @param paymentMethodId the paymentMethodId to set
   */
  public void setPaymentMethodId(int paymentMethodId) {
    this.paymentMethodId = paymentMethodId;
  }

  /**
   * Gets the event created at.
   *
   * @return the eventCreatedAt
   */
  public String getEventCreatedAt() {
    return eventCreatedAt;
  }

  /**
   * Sets the event created at.
   *
   * @param eventCreatedAt the eventCreatedAt to set
   */
  public void setEventCreatedAt(String eventCreatedAt) {
    this.eventCreatedAt = eventCreatedAt;
  }

  /**
   * Gets the previous status.
   *
   * @return the previousStatus
   */
  public String getPreviousStatus() {
    return previousStatus;
  }

  /**
   * Sets the previous status.
   *
   * @param previousStatus the previousStatus to set
   */
  public void setPreviousStatus(String previousStatus) {
    this.previousStatus = previousStatus;
  }

  /**
   * Gets the event id.
   *
   * @return the eventId
   */
  public long getEventId() {
    if (eventId != null) {
      return Long.valueOf(eventId);
    } else {
      return 0;
    }
  }

  /**
   * Sets the event id.
   *
   * @param eventId the eventId to set
   */
  public void setEventId(String eventId) {
    this.eventId = eventId;
  }

  /**
   * Gets the transaction id.
   *
   * @return the transactionId
   */
  public String getTransactionId() {
    return transactionId;
  }

  /**
   * Sets the transaction id.
   *
   * @param transactionId the transactionId to set
   */
  public void setTransactionId(String transactionId) {
    this.transactionId = transactionId;
  }

  /** @return the playerCardType */
  public String getPlayerCardType() {
    return playerCardType;
  }

  /** @param playerCardType the playerCardType to set */
  public void setPlayerCardType(String playerCardType) {
    this.playerCardType = playerCardType;
  }

  public String getPaymentMethodType() {
    if (paymentMethodType != null && paymentMethodType.equals("external")) {
      return "bankAccount";
    }
    return paymentMethodType;
  }

  public void setPaymentMethodType(String paymentMethodType) {
    this.paymentMethodType = paymentMethodType;
  }

  /** @return the linkedTransactionId */
  public Long getLinkedTransactionId() {
    return linkedTransactionId;
  }

  /** @param linkedTransactionId the linkedTransactionId to set */
  public void setLinkedTransactionId(Long linkedTransactionId) {
    this.linkedTransactionId = linkedTransactionId;
  }

  /** @return the captured */
  public boolean isCaptured() {
    return captured;
  }

  /** @param captured the captured to set */
  public void setCaptured(boolean captured) {
    this.captured = captured;
  }

  /** @return the approved */
  public boolean isApproved() {
    return approved;
  }

  /** @param approved the approved to set */
  public void setApproved(boolean approved) {
    this.approved = approved;
  }

  public Boolean getSubscription() {
    return subscription;
  }

  public void setSubscription(Boolean subscription) {
    this.subscription = subscription;
  }
}
