package com.sciplay.report.etl.dto;

public class PlayerAddressMessage extends DynamicMessage<PlayerAddress> {}
