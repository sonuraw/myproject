package com.sciplay.report.etl.Entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class SubscriptionGamesEntity. */
@Entity
@Table(name = "SubscriptionGames")
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubscriptionGamesEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The Draw game template id. */
  @Id
  @Column(name = "DrawGameTemplateId")
  private String drawGameTemplateId;

  /** The Subscription id. */
  private Long subscriptionId;

  /** The Game id. */
  private Integer gameId;

  /** The Game name. */
  private String gameName;

  /** The No of tickets. */
  private Integer noOfTickets;

  /** The Is random. */
  private String playMethod;

  /** The Cost per draw. */
  private Integer costPerDraw;

  /** The Partner id. */
  private String partnerId;

  /** The Add on trigger value. */
  private Long addOnTriggerValue;

  /** The Parent draw game template id. */
  private String parentDrawGameTemplateId;

  /** The next draw start date. */
  private Date nextDrawStartDate;

  /** The next draw end date. */
  private Date nextDrawEndDate;

  /** Instantiates a new subscription games entity. */
  public SubscriptionGamesEntity() {}

  /**
   * Instantiates a new subscription games entity.
   *
   * @param drawGameTemplateId the draw game template id
   * @param subscriptionId the subscription id
   * @param gameId the game id
   * @param gameName the game name
   * @param noOfTickets the no of tickets
   * @param playMethod the play method
   * @param costPerDraw the cost per draw
   */
  public SubscriptionGamesEntity(
      String drawGameTemplateId,
      Long subscriptionId,
      Integer gameId,
      String gameName,
      Integer noOfTickets,
      String playMethod,
      Integer costPerDraw) {
    this.drawGameTemplateId = drawGameTemplateId;
    this.subscriptionId = subscriptionId;
    this.gameId = gameId;
    this.gameName = gameName;
    this.noOfTickets = noOfTickets;
    this.playMethod = playMethod;
    this.costPerDraw = costPerDraw;
  }

  /**
   * Gets the serialversionuid.
   *
   * @return the serialversionuid
   */
  public static long getSerialversionuid() {
    return serialVersionUID;
  }

  /**
   * Gets the next draw start date.
   *
   * @return the next draw start date
   */
  public Date getNextDrawStartDate() {
    return nextDrawStartDate;
  }

  /**
   * Sets the next draw start date.
   *
   * @param nextDrawStartDate the new next draw start date
   */
  public void setNextDrawStartDate(Date nextDrawStartDate) {
    this.nextDrawStartDate = nextDrawStartDate;
  }

  /**
   * Gets the next draw end date.
   *
   * @return the next draw end date
   */
  public Date getNextDrawEndDate() {
    return nextDrawEndDate;
  }

  /**
   * Sets the next draw end date.
   *
   * @param nextDrawEndDate the new next draw end date
   */
  public void setNextDrawEndDate(Date nextDrawEndDate) {
    this.nextDrawEndDate = nextDrawEndDate;
  }

  /**
   * Gets the parent draw game template id.
   *
   * @return the parent draw game template id
   */
  public String getParentDrawGameTemplateId() {
    return parentDrawGameTemplateId;
  }

  /**
   * Sets the parent draw game template id.
   *
   * @param parentDrawGameTemplateId the new parent draw game template id
   */
  public void setParentDrawGameTemplateId(String parentDrawGameTemplateId) {
    this.parentDrawGameTemplateId = parentDrawGameTemplateId;
  }

  /**
   * Gets the partner id.
   *
   * @return the partner id
   */
  public String getPartnerId() {
    return partnerId;
  }

  /**
   * Sets the partner id.
   *
   * @param partnerId the new partner id
   */
  public void setPartnerId(String partnerId) {
    this.partnerId = partnerId;
  }

  /**
   * Gets the adds the on trigger value.
   *
   * @return the adds the on trigger value
   */
  public Long getAddOnTriggerValue() {
    return addOnTriggerValue;
  }

  /**
   * Sets the adds the on trigger value.
   *
   * @param addOnTriggerValue the new adds the on trigger value
   */
  public void setAddOnTriggerValue(Long addOnTriggerValue) {
    if (addOnTriggerValue == null) {
      addOnTriggerValue = 0L;
    }
    this.addOnTriggerValue = addOnTriggerValue;
  }

  /**
   * Gets the draw game template id.
   *
   * @return the draw game template id
   */
  public String getDrawGameTemplateId() {
    return drawGameTemplateId;
  }

  /**
   * Sets the draw game template id.
   *
   * @param drawGameTemplateId the new draw game template id
   */
  public void setDrawGameTemplateId(String drawGameTemplateId) {
    this.drawGameTemplateId = drawGameTemplateId;
  }

  /**
   * Gets the subscription id.
   *
   * @return the subscription id
   */
  public Long getSubscriptionId() {
    return subscriptionId;
  }

  /**
   * Sets the subscription id.
   *
   * @param subscriptionId the new subscription id
   */
  public void setSubscriptionId(Long subscriptionId) {
    if (subscriptionId == null) {
      subscriptionId = 0L;
    }
    this.subscriptionId = subscriptionId;
  }

  /**
   * Gets the game id.
   *
   * @return the game id
   */
  public Integer getGameId() {
    return gameId;
  }

  /**
   * Sets the game id.
   *
   * @param gameId the new game id
   */
  public void setGameId(Integer gameId) {
    if (gameId == null) {
      gameId = 0;
    }
    this.gameId = gameId;
  }

  /**
   * Gets the game name.
   *
   * @return the game name
   */
  public String getGameName() {
    return gameName;
  }

  /**
   * Sets the game name.
   *
   * @param gameName the new game name
   */
  public void setGameName(String gameName) {
    this.gameName = gameName;
  }

  /**
   * Gets the no of tickets.
   *
   * @return the no of tickets
   */
  public Integer getNoOfTickets() {
    return noOfTickets;
  }

  /**
   * Sets the no of tickets.
   *
   * @param noOfTickets the new no of tickets
   */
  public void setNoOfTickets(Integer noOfTickets) {
    if (noOfTickets == null) {
      noOfTickets = 0;
    }
    this.noOfTickets = noOfTickets;
  }

  /**
   * Gets the checks if is random.
   *
   * @return the checks if is random
   */
  public String getPlayMethod() {
    return playMethod;
  }

  /**
   * Sets the checks if is random.
   *
   * @param isRandom the new checks if is random
   */
  public void setPlayMethod(String isRandom) {
    playMethod = isRandom;
  }

  /**
   * Gets the cost per draw.
   *
   * @return the cost per draw
   */
  public Integer getCostPerDraw() {
    return costPerDraw;
  }

  /**
   * Sets the cost per draw.
   *
   * @param costPerDraw the new cost per draw
   */
  public void setCostPerDraw(Integer costPerDraw) {
    if (costPerDraw == null) {
      costPerDraw = 0;
    }
    this.costPerDraw = costPerDraw;
  }
}
