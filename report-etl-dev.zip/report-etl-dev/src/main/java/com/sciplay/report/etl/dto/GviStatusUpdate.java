package com.sciplay.report.etl.dto;

/** Created by 105450 on 8/8/2017. */
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** The Class CommittedTransactionsData. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GviStatusUpdate {

  /** The meta. */
  private Meta meta;

  /** The status update data */
  private StatusUpdateData data;

  /** @return the meta */
  public Meta getMeta() {
    return meta;
  }

  /** @param meta the meta to set */
  public void setMeta(Meta meta) {
    this.meta = meta;
  }

  /** @return the data */
  public StatusUpdateData getData() {
    return data;
  }

  /** @param data the data to set */
  public void setData(StatusUpdateData data) {
    this.data = data;
  }
}
