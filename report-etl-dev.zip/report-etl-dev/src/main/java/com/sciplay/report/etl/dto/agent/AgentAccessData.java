package com.sciplay.report.etl.dto.agent;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** @author salman */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentAccessData {

  private String type;

  private String id;

  private AgentAccessAttributes attributes;

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public AgentAccessAttributes getAttributes() {
    return attributes;
  }

  public void setAttributes(AgentAccessAttributes attributes) {
    this.attributes = attributes;
  }
}
