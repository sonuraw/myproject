package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/** The type Query parameter. */
public class PostParameter {
  /** The Query operation. */
  @JsonProperty("params")
  private String params;
}
