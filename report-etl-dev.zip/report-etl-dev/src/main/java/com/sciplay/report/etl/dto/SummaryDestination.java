package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

@Produces("application/json")
@Consumes("application/json")
@JsonIgnoreProperties(ignoreUnknown = true)
public final class SummaryDestination {

  /** The destination. */
  private String destination;
  /** The count. */
  private long count;
  /** @return the destinations */
  public String getDestination() {
    return destination;
  }
  /** @param destinations the destinations to set */
  public void setDestination(String destination) {
    this.destination = destination;
  }
  /** @return the count */
  public long getCount() {
    return count;
  }
  /** @param count the count to set */
  public void setCount(long count) {
    this.count = count;
  }
}
