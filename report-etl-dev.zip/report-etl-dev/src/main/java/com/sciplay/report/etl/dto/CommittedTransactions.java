package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CommittedTransactions {

  private CommittedTransactionsData data;
  private Meta meta;

  public Meta getMeta() {
    return meta;
  }

  public void setMeta(Meta meta) {
    this.meta = meta;
  }

  public CommittedTransactionsData getData() {
    return data;
  }

  public void setData(CommittedTransactionsData data) {
    this.data = data;
  }
}
