package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** The Class PlayerSession. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PlayerSession {

  /** The player id. */
  private Integer playerId;

  /** The is secured login. */
  private String isSecuredLogin;

  /** The ip. */
  private String ip;

  /** The username. */
  private String username;

  /** The reason. */
  private String reason;

  /** The end reason. */
  private String endReason;

  /** The secure id. */
  private String secureId;

  /** The channel. */
  private String channel;

  /**
   * Gets the secure id.
   *
   * @return the secure id
   */
  public String getSecureId() {
    return secureId;
  }

  /**
   * Sets the secure id.
   *
   * @param secureId the new secure id
   */
  public void setSecureId(String secureId) {
    this.secureId = secureId;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the checks if is secured login.
   *
   * @return the checks if is secured login
   */
  public String getIsSecuredLogin() {
    return isSecuredLogin;
  }

  /**
   * Sets the checks if is secured login.
   *
   * @param isSecuredLogin the new checks if is secured login
   */
  public void setIsSecuredLogin(String isSecuredLogin) {
    this.isSecuredLogin = isSecuredLogin;
  }

  /**
   * Gets the ip.
   *
   * @return the ip
   */
  public String getIp() {
    return ip;
  }

  /**
   * Sets the ip.
   *
   * @param ip the new ip
   */
  public void setIp(String ip) {
    this.ip = ip;
  }

  /**
   * Gets the username.
   *
   * @return the username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Sets the username.
   *
   * @param username the new username
   */
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   * Gets the reason.
   *
   * @return the reason
   */
  public String getReason() {
    return reason;
  }

  /**
   * Sets the reason.
   *
   * @param reason the new reason
   */
  public void setReason(String reason) {
    this.reason = reason;
  }

  /**
   * Gets the end reason.
   *
   * @return the end reason
   */
  public String getEndReason() {
    return endReason;
  }

  /**
   * Sets the end reason.
   *
   * @param endReason the new end reason
   */
  public void setEndReason(String endReason) {
    this.endReason = endReason;
  }

  public String getChannel() {
    return channel;
  }

  public void setChannel(String channel) {
    this.channel = channel;
  }
}
