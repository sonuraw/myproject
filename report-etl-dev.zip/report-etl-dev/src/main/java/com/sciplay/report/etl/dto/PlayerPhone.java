package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** The Class PlayerPhone. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PlayerPhone {

  /** The id. */
  private String id;

  /** The type. */
  private String type;

  /** The player id. */
  private Integer playerId;

  /** The number. */
  private String number;

  /** The is validated. */
  private Boolean isValidated;

  /** The is verified. */
  private Boolean isVerified;

  /**
   * Gets the checks if is verified.
   *
   * @return the checks if is verified
   */
  public Boolean getIsVerified() {
    return isVerified;
  }

  /**
   * Sets the checks if is verified.
   *
   * @param isVerified the new checks if is verified
   */
  public void setIsVerified(Boolean isVerified) {
    this.isVerified = isVerified;
  }

  /**
   * Gets the checks if is validated.
   *
   * @return the checks if is validated
   */
  public Boolean getIsValidated() {
    return isValidated;
  }

  /**
   * Sets the checks if is validated.
   *
   * @param isValidated the new checks if is validated
   */
  public void setIsValidated(Boolean isValidated) {
    this.isValidated = isValidated;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Sets the type.
   *
   * @param type the new type
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the number.
   *
   * @return the number
   */
  public String getNumber() {
    return number;
  }

  /**
   * Sets the number.
   *
   * @param number the new number
   */
  public void setNumber(String number) {
    this.number = number;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }
}
