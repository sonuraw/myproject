package com.sciplay.report.etl.dto;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

@Produces("application/json")
@Consumes("application/json")
public final class DataSyncTopicMaxEventIdResponse {

  private long maxEventId;
  private String serviceName;

  public DataSyncTopicMaxEventIdResponse() {
    super();
  }

  public long getMaxEventId() {
    return maxEventId;
  }

  public void setMaxEventId(long maxEventId) {
    this.maxEventId = maxEventId;
  }

  public String getServiceName() {
    return serviceName;
  }

  public void setServiceName(String serviceName) {
    this.serviceName = serviceName;
  }
}
