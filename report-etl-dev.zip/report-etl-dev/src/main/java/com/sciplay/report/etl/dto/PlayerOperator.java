package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** The Class Author. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PlayerOperator {

  /** The playerId. */
  private Integer playerId;

  /** The agent id. */
  private String payload;

  /**
   * Gets the playerId.
   *
   * @return the playerId
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /** Sets the playerId. */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the payload.
   *
   * @return the payload
   */
  public String getpayload() {
    return payload;
  }

  /** Sets the payload. */
  public void setpayload(String payload) {
    this.payload = payload;
  }
}
