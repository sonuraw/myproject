package com.sciplay.report.etl.dto.BatchLog;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BatchLog {

  @JsonProperty("meta")
  private BatchLogMeta meta;

  @JsonProperty("data")
  private BatchLogData data;

  @JsonProperty("meta")
  public BatchLogMeta getMeta() {
    return meta;
  }

  @JsonProperty("meta")
  public void setMeta(BatchLogMeta meta) {
    this.meta = meta;
  }

  @JsonProperty("data")
  public BatchLogData getData() {
    return data;
  }

  @JsonProperty("data")
  public void setData(BatchLogData data) {
    this.data = data;
  }
}
