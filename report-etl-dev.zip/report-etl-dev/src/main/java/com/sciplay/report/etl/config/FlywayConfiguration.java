package com.sciplay.report.etl.config;

public class FlywayConfiguration {

  private Boolean baselineOnMigrate;
  private String table;
  private String baselineVersion;
  private boolean ignoreMissingMigrations;
  private boolean ignoreIgnoredMigrations;

  public Boolean getBaselineOnMigrate() {
    return baselineOnMigrate;
  }

  public void setBaselineOnMigrate(Boolean baselineOnMigrate) {
    this.baselineOnMigrate = baselineOnMigrate;
  }

  public String getTable() {
    return table;
  }

  public void setTable(String table) {
    this.table = table;
  }

  public String getBaselineVersion() {
    return baselineVersion;
  }

  public void setBaselineVersion(String baselineVersion) {
    this.baselineVersion = baselineVersion;
  }

  public boolean isIgnoreMissingMigrations() {
    return ignoreMissingMigrations;
  }

  public void setIgnoreMissingMigrations(boolean ignoreMissingMigrations) {
    this.ignoreMissingMigrations = ignoreMissingMigrations;
  }

  public boolean isIgnoreIgnoredMigrations() {
    return ignoreIgnoredMigrations;
  }

  public void setIgnoreIgnoredMigrations(boolean ignoreIgnoredMigrations) {
    this.ignoreIgnoredMigrations = ignoreIgnoredMigrations;
  }
}
