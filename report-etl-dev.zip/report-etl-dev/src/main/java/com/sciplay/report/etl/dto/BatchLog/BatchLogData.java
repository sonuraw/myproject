package com.sciplay.report.etl.dto.BatchLog;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BatchLogData {

  @JsonProperty("type")
  private String type;

  @JsonProperty("attributes")
  private BatchLogAttributes attributes;

  @JsonProperty("type")
  public String getType() {
    return type;
  }

  @JsonProperty("type")
  public void setType(String type) {
    this.type = type;
  }

  @JsonProperty("attributes")
  public BatchLogAttributes getAttributes() {
    return attributes;
  }

  @JsonProperty("attributes")
  public void setAttributes(BatchLogAttributes attributes) {
    this.attributes = attributes;
  }
}
