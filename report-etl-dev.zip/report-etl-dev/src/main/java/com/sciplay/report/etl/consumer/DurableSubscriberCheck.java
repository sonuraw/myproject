package com.sciplay.report.etl.consumer;

import com.sciplay.report.etl.ReportEtlConsts;
import com.sciplay.report.etl.ReportEtlContext;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.Topic;
import org.apache.activemq.ActiveMQConnectionFactory;

public class DurableSubscriberCheck {

  private static DurableSubscriberCheck instance = new DurableSubscriberCheck();
  private Connection connection;
  private Session session;
  private MessageConsumer messageConsumer;

  public static DurableSubscriberCheck getInstance() {
    return instance;
  }

  public static void setInstance(DurableSubscriberCheck instance) {
    DurableSubscriberCheck.instance = instance;
  }

  public void createConnection(
      String clientId, String topicName, String subscriptionName, String brokerUrl)
      throws JMSException {

    // create a Connection Factory
    ConnectionFactory connectionFactory =
        new ActiveMQConnectionFactory(
            ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getMqconsumer()
                .get(ReportEtlConsts.ACTIVE_MQ_USERNAME)
                .toString(),
            ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getMqconsumer()
                .get(ReportEtlConsts.ACTIVE_MQ_PASSWORD)
                .toString(),
            brokerUrl);

    //         create a Connection
    connection =
        connectionFactory.createConnection(
            ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getMqconsumer()
                .get(ReportEtlConsts.ACTIVE_MQ_USERNAME)
                .toString(),
            ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getMqconsumer()
                .get(ReportEtlConsts.ACTIVE_MQ_PASSWORD)
                .toString());
    connection.setClientID(clientId);

    // create a Session
    session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

    // create the Topic from which messages will be received
    Topic topic = session.createTopic(topicName);

    // create a MessageConsumer for receiving messages
    messageConsumer = session.createDurableSubscriber(topic, subscriptionName);

    // start the connection in order to receive messages
    connection.start();
  }

  public void closeConnection() throws JMSException {
    if (messageConsumer != null) {
      messageConsumer.close();
    }
    if (session != null) {
      session.close();
    }
    if (connection != null) {
      connection.close();
    }
  }
}
