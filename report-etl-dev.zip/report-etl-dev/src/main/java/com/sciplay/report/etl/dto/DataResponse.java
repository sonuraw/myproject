package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DataResponse<T> {

  private final String id;
  private final String type;
  private final T attributes;

  public DataResponse(String pId, String pType, T pAttributes) {
    this.id = pId;
    this.type = pType;
    this.attributes = pAttributes;
  }

  /** @return the id */
  public String getId() {
    return id;
  }

  /** @return the type */
  public String getType() {
    return type;
  }

  /** @return the attributes */
  public T getAttributes() {
    return attributes;
  }
}
