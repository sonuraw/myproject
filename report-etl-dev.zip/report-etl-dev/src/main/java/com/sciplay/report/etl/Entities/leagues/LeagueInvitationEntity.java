package com.sciplay.report.etl.Entities.leagues;

import com.sciplay.report.etl.dto.teamsleagues.TeamsLeaguesAuthor;
import com.sciplay.report.etl.dto.teamsleagues.TeamsLeaguesMessage;
import com.sciplay.report.etl.utils.ReportEtlUtils;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** @author salman */
@Entity
@Table(name = "LeagueInvitation")
public class LeagueInvitationEntity {

  @Id
  @Column(name = "Id")
  private String id;

  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  @Column(name = "Email")
  private String email;

  @Column(name = "LeagueId")
  private String leagueId;

  @Column(name = "PlayerId")
  private Integer playerId;

  @Column(
      name = "Status",
      columnDefinition = "enum('SENT','ACCEPTED','DECLINED','EXPIRED','INVALID','S','A','D')")
  private String status;

  @Column(name = "AcceptHash", columnDefinition = "longtext")
  private String acceptHash;

  @Column(name = "DeclineHash", columnDefinition = "longtext")
  private String declineHash;

  @Column(name = "AuthorId")
  private Integer authorId;

  @Column(name = "AuthorIp")
  private String authorIp;

  @Column(name = "AuthorSessionId")
  private String authorSessionId;

  @Column(name = "UpdatedAt")
  private Date updatedAt;

  @Column(name = "CreatedAt")
  private Date createdAt;

  public LeagueInvitationEntity() {}

  public LeagueInvitationEntity(TeamsLeaguesMessage teamsLeaguesMessage) {
    TeamsLeaguesAuthor author = teamsLeaguesMessage.getMeta().getAuthor();
    this.id = teamsLeaguesMessage.getData().getId();
    this.operatorId = teamsLeaguesMessage.getMeta().getOperatorId();
    this.email = teamsLeaguesMessage.getData().getAttributes().getEmail();
    this.leagueId = teamsLeaguesMessage.getData().getAttributes().getLeagueId();
    this.playerId = teamsLeaguesMessage.getData().getAttributes().getPlayerId();
    this.playerId = (Objects.isNull(playerId)) ? 0 : playerId;
    this.status = teamsLeaguesMessage.getData().getAttributes().getStatus();
    this.acceptHash = teamsLeaguesMessage.getData().getAttributes().getAcceptHash();
    this.declineHash = teamsLeaguesMessage.getData().getAttributes().getDeclineHash();
    this.authorId = author.getAgentId() == null ? author.getPlayerId() : null;
    this.authorId = (Objects.isNull(authorId)) ? 0 : authorId;
    this.authorIp = author.getIp();
    this.authorSessionId = author.getSessionId();
    this.updatedAt =
        ReportEtlUtils.parseDate(
            teamsLeaguesMessage.getMeta().getUpdatedAt() != null
                ? teamsLeaguesMessage.getMeta().getUpdatedAt()
                : teamsLeaguesMessage.getMeta().getCreatedAt());
    this.createdAt = ReportEtlUtils.parseDate(teamsLeaguesMessage.getMeta().getCreatedAt());
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getOperatorId() {
    return operatorId;
  }

  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getLeagueId() {
    return leagueId;
  }

  public void setLeagueId(String leagueId) {
    this.leagueId = leagueId;
  }

  public Integer getPlayerId() {
    return playerId;
  }

  public void setPlayerId(Integer playerId) {
    this.playerId = Objects.isNull(playerId) ? 0 : playerId;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getAcceptHash() {
    return acceptHash;
  }

  public void setAcceptHash(String acceptHash) {
    this.acceptHash = acceptHash;
  }

  public String getDeclineHash() {
    return declineHash;
  }

  public void setDeclineHash(String declineHash) {
    this.declineHash = declineHash;
  }

  public Integer getAuthorId() {
    return authorId;
  }

  public void setAuthorId(Integer authorId) {
    this.authorId = (Objects.isNull(authorId)) ? 0 : authorId;
  }

  public String getAuthorIp() {
    return authorIp;
  }

  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  public String getAuthorSessionId() {
    return authorSessionId;
  }

  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  public Date getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(Date updatedAt) {
    this.updatedAt = updatedAt;
  }

  public Date getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }
}
