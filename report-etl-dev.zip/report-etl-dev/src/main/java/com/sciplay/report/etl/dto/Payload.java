package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** The Class Payload. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Payload {

  /** The wager state. */
  private String wagerState;

  /** The wager external id. */
  private String wagerExternalId;

  /** The wager external created time. */
  private String wagerExternalCreatedTime;

  /** The wager notify win. */
  private Boolean wagerNotifyWin;

  /** The wager set external id. */
  private String wagerSetExternalId;

  /** The wager set external created time. */
  private String wagerSetExternalCreatedTime;

  /** The wager set notify win. */
  private Boolean wagerSetNotifyWin;

  /** The wager brand. */
  private String wagerBrand;

  /** The number of wagers. */
  private Integer numberOfWagers;

  /** The external created at. */
  private String externalCreatedAt;

  /** The group ID. */
  private Long groupID;

  /** The set ID. */
  private Long setID;

  /** The src URL. */
  private String srcURL;

  /** The player card type. */
  private String playerCardType;

  /** The wager type. */
  private String wagerType;

  /** The wager set type. */
  private String wagerSetType;

  /** The Wager Set State. */
  private String wagerSetState;

  /** The Wager Set Brand. */
  private String wagerSetBrand;

  /** Below new variables got added as part of CR129 */
  private String wagerGameVariant;

  private Byte numberOfWagersInSet;

  private Byte wagerNumberInSet;

  /**
   * Gets the wager type.
   *
   * @return the wager type
   */
  public String getWagerType() {
    return wagerType;
  }

  /**
   * Sets the wager type.
   *
   * @param wagerType the new wager type
   */
  public void setWagerType(String wagerType) {
    this.wagerType = wagerType;
  }

  /**
   * Gets the wager set type.
   *
   * @return the wager set type
   */
  public String getWagerSetType() {
    return wagerSetType;
  }

  /**
   * Sets the wager set type.
   *
   * @param wagerSetType the new wager set type
   */
  public void setWagerSetType(String wagerSetType) {
    this.wagerSetType = wagerSetType;
  }

  /**
   * Gets the wager state.
   *
   * @return the wager state
   */
  public String getWagerState() {
    return wagerState;
  }

  /**
   * Sets the wager state.
   *
   * @param wagerState the new wager state
   */
  public void setWagerState(String wagerState) {
    this.wagerState = wagerState;
  }

  /**
   * Gets the wager external id.
   *
   * @return the wager external id
   */
  public String getWagerExternalId() {
    return wagerExternalId;
  }

  /**
   * Sets the wager external id.
   *
   * @param wagerExternalId the new wager external id
   */
  public void setWagerExternalId(String wagerExternalId) {
    this.wagerExternalId = wagerExternalId;
  }

  /**
   * Gets the wager external created time.
   *
   * @return the wager external created time
   */
  public String getWagerExternalCreatedTime() {
    return wagerExternalCreatedTime;
  }

  /**
   * Sets the wager external created time.
   *
   * @param wagerExternalCreatedTime the new wager external created time
   */
  public void setWagerExternalCreatedTime(String wagerExternalCreatedTime) {
    this.wagerExternalCreatedTime = wagerExternalCreatedTime;
  }

  /**
   * Gets the wager notify win.
   *
   * @return the wager notify win
   */
  public Boolean getWagerNotifyWin() {
    return wagerNotifyWin;
  }

  /**
   * Sets the wager notify win.
   *
   * @param wagerNotifyWin the new wager notify win
   */
  public void setWagerNotifyWin(Boolean wagerNotifyWin) {
    this.wagerNotifyWin = wagerNotifyWin;
  }

  /**
   * Gets the wager set external id.
   *
   * @return the wager set external id
   */
  public String getWagerSetExternalId() {
    return wagerSetExternalId;
  }

  /**
   * Sets the wager set external id.
   *
   * @param wagerSetExternalId the new wager set external id
   */
  public void setWagerSetExternalId(String wagerSetExternalId) {
    this.wagerSetExternalId = wagerSetExternalId;
  }

  /**
   * Gets the wager set external created time.
   *
   * @return the wager set external created time
   */
  public String getWagerSetExternalCreatedTime() {
    return wagerSetExternalCreatedTime;
  }

  /**
   * Sets the wager set external created time.
   *
   * @param wagerSetExternalCreatedTime the new wager set external created time
   */
  public void setWagerSetExternalCreatedTime(String wagerSetExternalCreatedTime) {
    this.wagerSetExternalCreatedTime = wagerSetExternalCreatedTime;
  }

  /**
   * Gets the wager set notify win.
   *
   * @return the wager set notify win
   */
  public Boolean getWagerSetNotifyWin() {
    return wagerSetNotifyWin;
  }

  /**
   * Sets the wager set notify win.
   *
   * @param wagerSetNotifyWin the new wager set notify win
   */
  public void setWagerSetNotifyWin(Boolean wagerSetNotifyWin) {
    this.wagerSetNotifyWin = wagerSetNotifyWin;
  }

  /**
   * Gets the wager brand.
   *
   * @return the wager brand
   */
  public String getWagerBrand() {
    return wagerBrand;
  }

  /**
   * Sets the wager brand.
   *
   * @param wagerBrand the new wager brand
   */
  public void setWagerBrand(String wagerBrand) {
    this.wagerBrand = wagerBrand;
  }

  /**
   * Gets the number of wagers.
   *
   * @return the number of wagers
   */
  public Integer getNumberOfWagers() {
    return numberOfWagers;
  }

  /**
   * Sets the number of wagers.
   *
   * @param numberOfWagers the new number of wagers
   */
  public void setNumberOfWagers(Integer numberOfWagers) {
    this.numberOfWagers = numberOfWagers;
  }

  /**
   * Gets the external created at.
   *
   * @return the external created at
   */
  public String getExternalCreatedAt() {
    return externalCreatedAt;
  }

  /**
   * Sets the external created at.
   *
   * @param externalCreatedAt the new external created at
   */
  public void setExternalCreatedAt(String externalCreatedAt) {
    this.externalCreatedAt = externalCreatedAt;
  }

  /**
   * Gets the group ID.
   *
   * @return the group ID
   */
  public Long getGroupID() {
    return groupID;
  }

  /**
   * Sets the group ID.
   *
   * @param groupID the new group ID
   */
  public void setGroupID(Long groupID) {
    this.groupID = groupID;
  }

  /**
   * Gets the sets the ID.
   *
   * @return the sets the ID
   */
  public Long getSetID() {
    return setID;
  }

  /**
   * Sets the sets the ID.
   *
   * @param setID the new sets the ID
   */
  public void setSetID(Long setID) {
    this.setID = setID;
  }

  /**
   * Gets the src URL.
   *
   * @return the src URL
   */
  public String getSrcURL() {
    return srcURL;
  }

  /**
   * Sets the src URL.
   *
   * @param srcURL the new src URL
   */
  public void setSrcURL(String srcURL) {
    this.srcURL = srcURL;
  }

  /**
   * Gets the player card type.
   *
   * @return the player card type
   */
  public String getPlayerCardType() {
    return playerCardType;
  }

  /**
   * Sets the player card type.
   *
   * @param playerCardType the new player card type
   */
  public void setPlayerCardType(String playerCardType) {
    this.playerCardType = playerCardType;
  }

  /** @return the wagerSetState */
  public String getWagerSetState() {
    return wagerSetState;
  }

  /** @param wagerSetState the wagerSetState to set */
  public void setWagerSetState(String wagerSetState) {
    this.wagerSetState = wagerSetState;
  }

  /** @return the wagerSetBrand */
  public String getWagerSetBrand() {
    return wagerSetBrand;
  }

  /** @param wagerSetBrand the wagerSetBrand to set */
  public void setWagerSetBrand(String wagerSetBrand) {
    this.wagerSetBrand = wagerSetBrand;
  }

  /** @return the wagerGameVariant */
  public String getWagerGameVariant() {
    return wagerGameVariant;
  }

  /** @param wagerGameVariant the wagerGameVariant to set */
  public void setWagerGameVariant(String wagerGameVariant) {
    this.wagerGameVariant = wagerGameVariant;
  }

  /** @return the numberOfWagersInSet */
  public Byte getNumberOfWagersInSet() {
    return numberOfWagersInSet;
  }

  /** @param numberOfWagersInSet the numberOfWagersInSet to set */
  public void setNumberOfWagersInSet(Byte numberOfWagersInSet) {
    this.numberOfWagersInSet = numberOfWagersInSet;
  }

  /** @return the wagerNumberInSet */
  public Byte getWagerNumberInSet() {
    return wagerNumberInSet;
  }

  /** @param wagerNumberInSet the wagerNumberInSet to set */
  public void setWagerNumberInSet(Byte wagerNumberInSet) {
    this.wagerNumberInSet = wagerNumberInSet;
  }
}
