package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sciplay.report.etl.ReportEtlContext;
import java.io.IOException;

/** @author salman */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ThirdPartyErrorMessage {

  private ThirdPartyErrorData data;

  public ThirdPartyErrorData getData() {
    return data;
  }

  public void setData(ThirdPartyErrorData data) {
    this.data = data;
  }

  public String getJsonString() throws IOException {
    return ReportEtlContext.getInstance().getObjectMapper().writeValueAsString(this);
  }
}
