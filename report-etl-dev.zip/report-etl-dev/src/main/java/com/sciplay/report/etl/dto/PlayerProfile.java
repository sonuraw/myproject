package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.ArrayList;
import java.util.Date;

/** The Class PlayerProfile. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PlayerProfile {

  /** The addresses. */
  private ArrayList<PlayerPhone> phones = new ArrayList<>();
  /** The phones. */
  private ArrayList<PlayerAddress> addresses = new ArrayList<>();
  /** The identifications. */
  private ArrayList<Identification> identifications = new ArrayList<>();
  /** The termsAndConditions. */
  private ArrayList<TermsAndConditions> termsAndConditions = new ArrayList<>();
  /** The socialNetworks. */
  private ArrayList<SocialNetwork> socialNetworks = new ArrayList<>();
  /** The player cards. */
  private ArrayList<PlayerCard> playerCards = new ArrayList<>();
  /** The affiliation. */
  private PlayerAffiliate affiliation;
  /** The username. */
  private String username;
  /** The alias. */
  private String alias;
  /** The firstname. */
  private String firstname;
  /** The password. */
  private String password;
  /** The status reason. */
  private String reason;
  /** The lastname. */
  private String lastname;
  /** The gender. */
  private String gender;
  /** The email. */
  private String email;
  /** The birthdate. */
  private Date birthdate;
  /** The exchcode. */
  private String exchcode;
  /** The locale. */
  private String locale;
  /** The vip level. */
  private String vipLevel;
  /** The security question. */
  private String securityQuestion;
  /** The security answer. */
  private String securityAnswer;
  /** The is politically exposed. */
  private String isPoliticallyExposed;
  /** The status. */
  private String status;
  /** The is A testing account. */
  private String isATestingAccount;
  /** The is birthdate valid. */
  private String isBirthdateValid;
  /** The is name valid. */
  private String isNameValid;
  /** The is email valid. */
  private String isEmailValid;
  /** The can subscribe. */
  private Boolean canSubscribe;
  /** The occupation. */
  private String occupation;
  /** The ip. */
  private String ip;
  /** The user agent. */
  private String userAgent;
  /** The operator id. */
  private String operatorId;
  /** The promotion code. */
  private String promotionCode;
  /** The default winnings account. */
  private String defaultWinningsAccount;
  /** The operator. */
  private PlayerOperator operator;
  /** The registration. */
  private PlayerRegistration registration;
  /** The can login. */
  private Boolean canLogin;
  /** Preference of the Player. */
  private PlayerPreference preferences;
  /** Modifying default winning account. */
  private String defaultAccount;
  /** Modifying preferred game. */
  private String preferredGame;

  /** The can login notification. */
  private Boolean canLoginNotification;

  /** The comment. */
  private String comment;

  /**
   * Gets the comment.
   *
   * @return the comment
   */
  public String getComment() {
    return comment;
  }

  /**
   * Sets the comment.
   *
   * @param comment the new comment
   */
  public void setComment(String comment) {
    this.comment = comment;
  }

  /**
   * Gets the can login notification.
   *
   * @return the can login notification
   */
  public Boolean getCanLoginNotification() {
    return canLoginNotification;
  }

  /**
   * Sets the can login notification.
   *
   * @param canLoginNotification the new can login notification
   */
  public void setCanLoginNotification(Boolean canLoginNotification) {
    this.canLoginNotification = canLoginNotification;
  }

  /**
   * Gets the preferences.
   *
   * @return the preferences
   */
  public PlayerPreference getPreferences() {
    return preferences;
  }

  /**
   * Sets the preferences.
   *
   * @param preferences the new preferences
   */
  public void setPreferences(PlayerPreference preferences) {
    this.preferences = preferences;
  }

  /**
   * Gets the default account.
   *
   * @return the default account
   */
  public String getDefaultAccount() {
    return defaultAccount;
  }

  /**
   * Sets the default account.
   *
   * @param defaultAccount the new default account
   */
  public void setDefaultAccount(String defaultAccount) {
    this.defaultAccount = defaultAccount;
  }

  /**
   * Gets the preferred game.
   *
   * @return the preferred game
   */
  public String getPreferredGame() {
    return preferredGame;
  }

  /**
   * Sets the preferred game.
   *
   * @param preferredGame the new preferred game
   */
  public void setPreferredGame(String preferredGame) {
    this.preferredGame = preferredGame;
  }

  /**
   * Gets the can login.
   *
   * @return the can login
   */
  public Boolean getCanLogin() {
    return canLogin;
  }

  /**
   * Sets the can login.
   *
   * @param canLogin the new can login
   */
  public void setCanLogin(Boolean canLogin) {
    this.canLogin = canLogin;
  }

  /**
   * Gets the player cards.
   *
   * @return the player cards
   */
  public ArrayList<PlayerCard> getPlayerCards() {
    return playerCards;
  }

  /**
   * Sets the player cards.
   *
   * @param playerCards the new player cards
   */
  public void setPlayerCards(ArrayList<PlayerCard> playerCards) {
    this.playerCards = playerCards;
  }

  /**
   * Gets the registration.
   *
   * @return the registration
   */
  public PlayerRegistration getRegistration() {
    return registration;
  }

  /**
   * Sets the registration.
   *
   * @param registration the registration to set
   */
  public void setRegistration(PlayerRegistration registration) {
    this.registration = registration;
  }

  /**
   * Gets the operator.
   *
   * @return the operator
   */
  public PlayerOperator getOperator() {
    return operator;
  }

  /**
   * Sets the operator.
   *
   * @param operator the operator to set
   */
  public void setOperator(PlayerOperator operator) {
    this.operator = operator;
  }

  /**
   * Gets the phones.
   *
   * @return the phones
   */
  public ArrayList<PlayerPhone> getPhones() {
    return phones;
  }

  /**
   * Sets the phones.
   *
   * @param phones the phones to set
   */
  public void setPhones(ArrayList<PlayerPhone> phones) {
    this.phones = phones;
  }

  /**
   * Gets the addresses.
   *
   * @return the addresses
   */
  public ArrayList<PlayerAddress> getAddresses() {
    return addresses;
  }

  /**
   * Sets the addresses.
   *
   * @param addresses the addresses to set
   */
  public void setAddresses(ArrayList<PlayerAddress> addresses) {
    this.addresses = addresses;
  }

  /**
   * Gets the identifications.
   *
   * @return the identifications
   */
  public ArrayList<Identification> getIdentifications() {
    return identifications;
  }

  /**
   * Sets the identifications.
   *
   * @param identifications the identifications to set
   */
  public void setIdentifications(ArrayList<Identification> identifications) {
    this.identifications = identifications;
  }

  /**
   * Gets the terms and conditions.
   *
   * @return the termsAndConditions
   */
  public ArrayList<TermsAndConditions> getTermsAndConditions() {
    return termsAndConditions;
  }

  /**
   * Sets the terms and conditions.
   *
   * @param termsAndConditions the termsAndConditions to set
   */
  public void setTermsAndConditions(ArrayList<TermsAndConditions> termsAndConditions) {
    this.termsAndConditions = termsAndConditions;
  }

  /**
   * Gets the social networks.
   *
   * @return the socialNetworks
   */
  public ArrayList<SocialNetwork> getSocialNetworks() {
    return socialNetworks;
  }

  /**
   * Sets the social networks.
   *
   * @param socialNetworks the socialNetworks to set
   */
  public void setSocialNetworks(ArrayList<SocialNetwork> socialNetworks) {
    this.socialNetworks = socialNetworks;
  }

  /**
   * Gets the affiliation.
   *
   * @return the affiliation
   */
  public PlayerAffiliate getAffiliation() {
    return affiliation;
  }

  /**
   * Sets the affiliation.
   *
   * @param affiliation the affiliation to set
   */
  public void setAffiliation(PlayerAffiliate affiliation) {
    this.affiliation = affiliation;
  }

  /**
   * Gets the username.
   *
   * @return the username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Sets the username.
   *
   * @param username the username to set
   */
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   * Gets the alias.
   *
   * @return the alias
   */
  public String getAlias() {
    return alias;
  }

  /**
   * Sets the alias.
   *
   * @param alias the alias to set
   */
  public void setAlias(String alias) {
    this.alias = alias;
  }

  /**
   * Gets the firstname.
   *
   * @return the firstname
   */
  public String getFirstname() {
    return firstname;
  }

  /**
   * Sets the firstname.
   *
   * @param firstname the firstname to set
   */
  public void setFirstname(String firstname) {
    this.firstname = firstname;
  }

  /**
   * Gets the lastname.
   *
   * @return the lastname
   */
  public String getLastname() {
    return lastname;
  }

  /**
   * Sets the lastname.
   *
   * @param lastname the lastname to set
   */
  public void setLastname(String lastname) {
    this.lastname = lastname;
  }

  /**
   * Gets the gender.
   *
   * @return the gender
   */
  public String getGender() {
    return gender;
  }

  /**
   * Sets the gender.
   *
   * @param gender the gender to set
   */
  public void setGender(String gender) {
    this.gender = gender;
  }

  /**
   * Gets the email.
   *
   * @return the email
   */
  public String getEmail() {
    return email;
  }

  /**
   * Sets the email.
   *
   * @param email the email to set
   */
  public void setEmail(String email) {
    this.email = email;
  }

  /**
   * Gets the password.
   *
   * @return the password
   */
  public String getPassword() {
    return password;
  }

  /**
   * Sets the password.
   *
   * @param password the password to set
   */
  public void setPassword(String password) {
    this.password = password;
  }

  /**
   * Gets the reason.
   *
   * @return the reason
   */
  public String getReason() {
    return reason;
  }

  /**
   * Sets the reason.
   *
   * @param reason the new reason
   */
  public void setReason(String reason) {
    this.reason = reason;
  }

  /**
   * Gets the birthdate.
   *
   * @return the birthdate
   */
  public Date getBirthdate() {
    return birthdate;
  }

  /**
   * Sets the birthdate.
   *
   * @param birthdate the birthdate to set
   */
  public void setBirthdate(Date birthdate) {
    this.birthdate = birthdate;
  }

  /**
   * Gets the exchcode.
   *
   * @return the exchcode
   */
  public String getExchcode() {
    return exchcode;
  }

  /**
   * Sets the exchcode.
   *
   * @param exchcode the exchcode to set
   */
  public void setExchcode(String exchcode) {
    this.exchcode = exchcode;
  }

  /**
   * Gets the locale.
   *
   * @return the locale
   */
  public String getLocale() {
    return locale;
  }

  /**
   * Sets the locale.
   *
   * @param locale the locale to set
   */
  public void setLocale(String locale) {
    this.locale = locale;
  }

  /**
   * Gets the vip level.
   *
   * @return the vipLevel
   */
  public String getVipLevel() {
    return vipLevel;
  }

  /**
   * Sets the vip level.
   *
   * @param vipLevel the vipLevel to set
   */
  public void setVipLevel(String vipLevel) {
    this.vipLevel = vipLevel;
  }

  /**
   * Gets the security question.
   *
   * @return the securityQuestion
   */
  public String getSecurityQuestion() {
    return securityQuestion;
  }

  /**
   * Sets the security question.
   *
   * @param securityQuestion the securityQuestion to set
   */
  public void setSecurityQuestion(String securityQuestion) {
    this.securityQuestion = securityQuestion;
  }

  /**
   * Gets the security answer.
   *
   * @return the securityAnswer
   */
  public String getSecurityAnswer() {
    return securityAnswer;
  }

  /**
   * Sets the security answer.
   *
   * @param securityAnswer the securityAnswer to set
   */
  public void setSecurityAnswer(String securityAnswer) {
    this.securityAnswer = securityAnswer;
  }

  /**
   * Gets the checks if is politically exposed.
   *
   * @return the isPoliticallyExposed
   */
  public String getIsPoliticallyExposed() {
    return isPoliticallyExposed;
  }

  /**
   * Sets the checks if is politically exposed.
   *
   * @param isPoliticallyExposed the isPoliticallyExposed to set
   */
  public void setIsPoliticallyExposed(String isPoliticallyExposed) {
    this.isPoliticallyExposed = isPoliticallyExposed;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public String getStatus() {
    return status;
  }

  /**
   * Sets the status.
   *
   * @param status the status to set
   */
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * Gets the checks if is A testing account.
   *
   * @return the isATestingAccount
   */
  public String getIsATestingAccount() {
    return isATestingAccount;
  }

  /**
   * Sets the checks if is A testing account.
   *
   * @param isATestingAccount the isATestingAccount to set
   */
  public void setIsATestingAccount(String isATestingAccount) {
    this.isATestingAccount = isATestingAccount;
  }

  /**
   * Gets the checks if is birthdate valid.
   *
   * @return the isBirthdateValid
   */
  public String getIsBirthdateValid() {
    return isBirthdateValid;
  }

  /**
   * Sets the checks if is birthdate valid.
   *
   * @param isBirthdateValid the isBirthdateValid to set
   */
  public void setIsBirthdateValid(String isBirthdateValid) {
    this.isBirthdateValid = isBirthdateValid;
  }

  /**
   * Gets the checks if is name valid.
   *
   * @return the isNameValid
   */
  public String getIsNameValid() {
    return isNameValid;
  }

  /**
   * Sets the checks if is name valid.
   *
   * @param isNameValid the isNameValid to set
   */
  public void setIsNameValid(String isNameValid) {
    this.isNameValid = isNameValid;
  }

  /**
   * Gets the checks if is email valid.
   *
   * @return the isEmailValid
   */
  public String getIsEmailValid() {
    return isEmailValid;
  }

  /**
   * Sets the checks if is email valid.
   *
   * @param isEmailValid the isEmailValid to set
   */
  public void setIsEmailValid(String isEmailValid) {
    this.isEmailValid = isEmailValid;
  }

  /**
   * Gets the can subscribe.
   *
   * @return the canSubscribe
   */
  public Boolean getCanSubscribe() {
    return canSubscribe;
  }

  /**
   * Sets the can subscribe.
   *
   * @param canSubscribe the canSubscribe to set
   */
  public void setCanSubscribe(Boolean canSubscribe) {
    this.canSubscribe = canSubscribe;
  }

  /**
   * Gets the occupation.
   *
   * @return the occupation
   */
  public String getOccupation() {
    return occupation;
  }

  /**
   * Sets the occupation.
   *
   * @param occupation the occupation to set
   */
  public void setOccupation(String occupation) {
    this.occupation = occupation;
  }

  /**
   * Gets the ip.
   *
   * @return the ip
   */
  public String getIp() {
    return ip;
  }

  /**
   * Sets the ip.
   *
   * @param ip the ip to set
   */
  public void setIp(String ip) {
    this.ip = ip;
  }

  /**
   * Gets the user agent.
   *
   * @return the userAgent
   */
  public String getUserAgent() {
    return userAgent;
  }

  /**
   * Sets the user agent.
   *
   * @param userAgent the userAgent to set
   */
  public void setUserAgent(String userAgent) {
    this.userAgent = userAgent;
  }

  /**
   * Gets the operator id.
   *
   * @return the operatorId
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the operatorId to set
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the promotion code.
   *
   * @return the promotionCode
   */
  public String getPromotionCode() {
    return promotionCode;
  }

  /**
   * Sets the promotion code.
   *
   * @param promotionCode the promotionCode to set
   */
  public void setPromotionCode(String promotionCode) {
    this.promotionCode = promotionCode;
  }

  /**
   * Gets the default winnings account.
   *
   * @return the defaultWinningsAccount
   */
  public String getDefaultWinningsAccount() {
    return defaultWinningsAccount;
  }

  /**
   * Sets the default winnings account.
   *
   * @param defaultWinningsAccount the defaultWinningsAccount to set
   */
  public void setDefaultWinningsAccount(String defaultWinningsAccount) {
    this.defaultWinningsAccount = defaultWinningsAccount;
  }
}
