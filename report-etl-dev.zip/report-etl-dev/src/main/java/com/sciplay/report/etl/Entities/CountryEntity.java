package com.sciplay.report.etl.Entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Country")
public class CountryEntity {

  /** */
  @Id
  @Column(name = "CountryIso")
  private String countryIso;
  /** */
  private String countryName;

  public CountryEntity(String countryIso, String countryName) {
    this.countryIso = countryIso;
    this.countryName = countryName;
  }

  public CountryEntity() {}

  /** @return the CountryIso */
  public String getCountryIso() {
    return countryIso;
  }

  /** @param countryIso the CountryIso to set */
  public void setCountryIso(String countryIso) {
    this.countryIso = countryIso;
  }

  /** @return the CountryName */
  public String getCountryName() {
    return countryName;
  }

  /** @param countryName the countryName to set */
  public void setCountryName(String countryName) {
    this.countryName = countryName;
  }
}
