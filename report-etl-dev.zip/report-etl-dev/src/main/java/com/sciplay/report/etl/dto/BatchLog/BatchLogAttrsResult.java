package com.sciplay.report.etl.dto.BatchLog;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BatchLogAttrsResult {

  @JsonProperty("numberOfSuccess")
  private Integer numberOfSuccess;

  @JsonProperty("numberOfFailure")
  private Integer numberOfFailure;

  @JsonProperty("message")
  private String message;

  @JsonProperty("numberOfSuccess")
  public Integer getNumberOfSuccess() {
    return numberOfSuccess;
  }

  @JsonProperty("numberOfSuccess")
  public void setNumberOfSuccess(Integer numberOfSuccess) {
    this.numberOfSuccess = numberOfSuccess;
  }

  @JsonProperty("numberOfFailure")
  public Integer getNumberOfFailure() {
    return numberOfFailure;
  }

  @JsonProperty("numberOfFailure")
  public void setNumberOfFailure(Integer numberOfFailure) {
    this.numberOfFailure = numberOfFailure;
  }

  @JsonProperty("message")
  public String getMessage() {
    return message;
  }

  @JsonProperty("message")
  public void setMessage(String message) {
    this.message = message;
  }
}
