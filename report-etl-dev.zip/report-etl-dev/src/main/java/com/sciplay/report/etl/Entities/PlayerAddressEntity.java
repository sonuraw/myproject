package com.sciplay.report.etl.Entities;

import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class PlayerAddressEntity. */
@Entity
@Table(name = "PlayerAddress")
public class PlayerAddressEntity {

  /** The id. */
  @Column(name = "Id")
  @Id
  private String id;

  /** The player id. */
  @Column(name = "PlayerId")
  private Integer playerId;

  /** The operator id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The address type. */
  @Column(name = "AddressType")
  private String addressType;

  /** The co name. */
  @Column(name = "CoName")
  private String coName;

  /** The house number. */
  @Column(name = "HouseNumber")
  private String houseNumber;

  /** The level. */
  @Column(name = "Level")
  private String level;

  /** The door. */
  @Column(name = "Door")
  private String door;

  /** The street. */
  @Column(name = "Street")
  private String street;

  /** The postal code. */
  @Column(name = "PostalCode")
  private String postalCode;

  /** The city. */
  @Column(name = "City")
  private String city;

  /** The state. */
  @Column(name = "State")
  private String state;

  /** The country. */
  @Column(name = "Country")
  private String country;

  /** The detail. */
  @Column(name = "Detail")
  private String detail;

  /** The is validated. */
  @Column(name = "IsValidated", nullable = false)
  private Boolean isValidated;

  /** The author player id. */
  @Column(name = "AuthorPlayerId")
  private Integer authorPlayerId;

  /** The author agent id. */
  @Column(name = "AuthorAgentId")
  private Integer authorAgentId;

  /** The author ip. */
  @Column(name = "AuthorIp")
  private String authorIp;

  /** The author session id. */
  @Column(name = "AuthorSessionId")
  private String authorSessionId;

  /** The created at. */
  @Column(name = "CreatedAt")
  private Date createdAt;

  /** The isDeleted. */
  @Column(name = "isDeleted")
  private Boolean isDeleted = false;

  /** The Modified at. */
  private Date modifiedAt;

  /** Instantiates a new player address entity. */
  public PlayerAddressEntity() {}

  /**
   * Instantiates a new player address entity.
   *
   * @param id the id
   * @param playerId the player id
   * @param operatorId the operator id
   * @param addressType the address type
   * @param coName the co name
   * @param houseNumber the house number
   * @param level the level
   * @param door the door
   * @param street the street
   * @param postalCode the postal code
   * @param city the city
   * @param state the state
   * @param country the country
   * @param detail the detail
   * @param isValidated the is validated
   * @param authorPlayerId the author player id
   * @param authorAgentId the author agent id
   * @param authorIp the author ip
   * @param authorSessionId the author session id
   * @param createdAt the created at
   */
  public PlayerAddressEntity(
      String id,
      Integer playerId,
      String operatorId,
      String addressType,
      String coName,
      String houseNumber,
      String level,
      String door,
      String street,
      String postalCode,
      String city,
      String state,
      String country,
      String detail,
      Boolean isValidated,
      Integer authorPlayerId,
      Integer authorAgentId,
      String authorIp,
      String authorSessionId,
      Date createdAt,
      Date modifiedAt) {
    this.id = id;
    this.playerId = playerId;
    this.operatorId = operatorId;
    this.addressType = addressType;
    this.coName = coName;
    this.houseNumber = houseNumber;
    this.level = level;
    this.door = door;
    this.street = street;
    this.postalCode = postalCode;
    this.city = city;
    this.state = state;
    this.country = country;
    this.detail = detail;
    this.isValidated = isValidated;
    this.authorPlayerId = Objects.isNull(authorPlayerId) ? 0 : authorPlayerId;
    this.authorAgentId = Objects.isNull(authorAgentId) ? 0 : authorAgentId;
    this.authorIp = authorIp;
    this.authorSessionId = authorSessionId;
    this.createdAt = createdAt;
    this.modifiedAt = modifiedAt;
  }

  /**
   * Gets the checks if is validated.
   *
   * @return the checks if is validated
   */
  public Boolean getIsValidated() {
    return isValidated;
  }

  /**
   * Sets the checks if is validated.
   *
   * @param isValidated the new checks if is validated
   */
  public void setIsValidated(Boolean isValidated) {
    this.isValidated = isValidated;
  }

  /**
   * Gets the modified at.
   *
   * @return the modified at
   */
  public Date getModifiedAt() {
    return modifiedAt;
  }

  /**
   * Sets the modified at.
   *
   * @param modifiedAt the new modified at
   */
  public void setModifiedAt(Date modifiedAt) {
    this.modifiedAt = modifiedAt;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the address type.
   *
   * @return the address type
   */
  public String getAddressType() {
    return addressType;
  }

  /**
   * Sets the address type.
   *
   * @param addressType the new address type
   */
  public void setAddressType(String addressType) {
    this.addressType = addressType;
  }

  /**
   * Gets the co name.
   *
   * @return the co name
   */
  public String getCoName() {
    return coName;
  }

  /**
   * Sets the co name.
   *
   * @param coName the new co name
   */
  public void setCoName(String coName) {
    this.coName = coName;
  }

  /**
   * Gets the house number.
   *
   * @return the house number
   */
  public String getHouseNumber() {
    return houseNumber;
  }

  /**
   * Sets the house number.
   *
   * @param houseNumber the new house number
   */
  public void setHouseNumber(String houseNumber) {
    this.houseNumber = houseNumber;
  }

  /**
   * Gets the level.
   *
   * @return the level
   */
  public String getLevel() {
    return level;
  }

  /**
   * Sets the level.
   *
   * @param level the new level
   */
  public void setLevel(String level) {
    this.level = level;
  }

  /**
   * Gets the door.
   *
   * @return the door
   */
  public String getDoor() {
    return door;
  }

  /**
   * Sets the door.
   *
   * @param door the new door
   */
  public void setDoor(String door) {
    this.door = door;
  }

  /**
   * Gets the street.
   *
   * @return the street
   */
  public String getStreet() {
    return street;
  }

  /**
   * Sets the street.
   *
   * @param street the new street
   */
  public void setStreet(String street) {
    this.street = street;
  }

  /**
   * Gets the postal code.
   *
   * @return the postal code
   */
  public String getPostalCode() {
    return postalCode;
  }

  /**
   * Sets the postal code.
   *
   * @param postalCode the new postal code
   */
  public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
  }

  /**
   * Gets the city.
   *
   * @return the city
   */
  public String getCity() {
    return city;
  }

  /**
   * Sets the city.
   *
   * @param city the new city
   */
  public void setCity(String city) {
    this.city = city;
  }

  /**
   * Gets the state.
   *
   * @return the state
   */
  public String getState() {
    return state;
  }

  /**
   * Sets the state.
   *
   * @param state the new state
   */
  public void setState(String state) {
    this.state = state;
  }

  /**
   * Gets the country.
   *
   * @return the country
   */
  public String getCountry() {
    return country;
  }

  /**
   * Sets the country.
   *
   * @param country the new country
   */
  public void setCountry(String country) {
    this.country = country;
  }

  /**
   * Gets the detail.
   *
   * @return the detail
   */
  public String getDetail() {
    return detail;
  }

  /**
   * Sets the detail.
   *
   * @param detail the new detail
   */
  public void setDetail(String detail) {
    this.detail = detail;
  }

  /**
   * Checks if is validated.
   *
   * @return the boolean
   */
  public Boolean isValidated() {
    return isValidated;
  }

  /**
   * Sets the validated.
   *
   * @param validated the new validated
   */
  public void setValidated(Boolean validated) {
    isValidated = validated;
  }

  /**
   * Gets the author player id.
   *
   * @return the author player id
   */
  public Integer getAuthorPlayerId() {
    return authorPlayerId;
  }

  /**
   * Sets the author player id.
   *
   * @param authorPlayerId the new author player id
   */
  public void setAuthorPlayerId(Integer authorPlayerId) {
    this.authorPlayerId = Objects.isNull(authorPlayerId) ? 0 : authorPlayerId;
  }

  /**
   * Gets the author agent id.
   *
   * @return the author agent id
   */
  public Integer getAuthorAgentId() {
    return authorAgentId;
  }

  /**
   * Sets the author agent id.
   *
   * @param authorAgentId the new author agent id
   */
  public void setAuthorAgentId(Integer authorAgentId) {
    this.authorAgentId = Objects.isNull(authorAgentId) ? 0 : authorAgentId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  /** @return the isDeleted */
  public Boolean getIsDeleted() {
    return isDeleted;
  }

  /** @param isDeleted the isDeleted to set */
  public void setIsDeleted(Boolean isDeleted) {
    this.isDeleted = Objects.isNull(isDeleted) ? false : isDeleted;
  }
}
