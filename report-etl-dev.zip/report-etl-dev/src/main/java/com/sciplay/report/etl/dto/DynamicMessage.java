package com.sciplay.report.etl.dto;

/**
 * The Class Message.
 *
 * @param <T> the generic type
 */
public class DynamicMessage<T> {

  /** The meta. */
  private Meta meta;

  /** The data. */
  private DynamicData<T> data = new DynamicData<>();

  /**
   * Gets the meta.
   *
   * @return the meta
   */
  public Meta getMeta() {
    return meta;
  }

  /**
   * Sets the meta.
   *
   * @param meta the new meta
   */
  public void setMeta(Meta meta) {
    this.meta = meta;
  }

  /**
   * Gets the data.
   *
   * @return the data
   */
  public DynamicData<T> getData() {
    return data;
  }

  /**
   * Sets the data.
   *
   * @param data the new data
   */
  public void setData(DynamicData<T> data) {
    this.data = data;
  }
}
