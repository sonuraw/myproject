package com.sciplay.report.etl.dto.agent;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentAccessAttributes {

  @JsonProperty("paramPlayerId")
  private Integer paramPlayerId;

  @JsonProperty("paramAgentId")
  private Integer paramAgentId;

  @JsonProperty("url")
  private String url;

  @JsonProperty("parameters")
  private String parameters;

  @JsonProperty("page")
  private String page;

  public Integer getParamPlayerId() {
    return paramPlayerId;
  }

  public void setParamPlayerId(Integer paramPlayerId) {
    this.paramPlayerId = paramPlayerId;
  }

  public Integer getParamAgentId() {
    return paramAgentId;
  }

  public void setParamAgentId(Integer paramAgentId) {
    this.paramAgentId = paramAgentId;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getParameters() {
    return parameters;
  }

  public void setParameters(String parameters) {
    this.parameters = parameters;
  }

  public String getPage() {
    return page;
  }

  public void setPage(String page) {
    this.page = page;
  }
}
