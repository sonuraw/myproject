package com.sciplay.report.etl;

import java.util.HashMap;
import java.util.Map;
import org.joda.time.DateTime;

/**
 * This class holds CsiDaemon constant variables.
 *
 * @author Balakumar
 */
public final class ReportEtlConsts {

  public static final String CONSUMED_A_NEW_MESSAGE = "Consumed a new message.";
  /** The constant used while consumed message from topic. */
  public static final String LOG_CONSUMED_MESSAGE =
      "Consumed message from topic: [{}], message: {}";
  /** The constant used on consume topic. */
  public static final String LOG_CONSUME_TOPIC = "Consuming topic";
  /** The constant used on consumer started to listen the topic. */
  public static final String LOG_CONSUMER_LISTENING =
      "ActiveMqConsumer started to listen [{}] topic";

  public static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
  public static final String DATE_ALONE = "yyyy-MM-dd";
  public static final String JSON_CONTENT_TYPE = "application/vnd.api+json";
  public static final String COPYRIGHT_TEMPLATE =
      "Copyright " + new DateTime().getYear() + " Scientific Games.";
  /** The Constant Thread Sleep. */
  public static final int THREAD_SLEEP = 10000;

  public static final String ACTION_ACTIVATE = "activate";
  public static final String ACTION_DEACTIVATE = "deactivate";
  public static final String ACTION_UPDATE = "update";
  public static final String ACTION_DELETED = "delete";
  public static final String ADDRESS_TYPE_HOME = "home";
  /** Agent constants. */
  public static final String AGENT_CREATED = "created";

  public static final String AGENT_UPDATED = "updated";
  public static final String AGENT_CRED_ADDED = "credentials-added";
  public static final String AGENT_CRED_REMOVED = "credentials-removed";
  public static final String OPERATOR_ACCESS_GRANTED = "operators-access-granted";
  public static final String OPERATOR_ACCESS_REVOKED = "operators-access-revoked";
  public static final String COUNTRY_ACCESS_GRANTED = "country-access-added";
  public static final String COUNTRY_ACCESS_REVOKED = "country-access-revoked";
  public static final String AGENT_LOGIN_SUCCESS = "agent-login-success";
  public static final String AGENT_LOGIN_FAILED = "agent-login-failed";
  public static final String AGENT_LOGOUT = "agent-logout";

  /** Wallet Limit ETL constants. */
  public static final String HEADER_OPERATOR_ID = "X-SG-SS-Operator-ID";

  public static final String HEADER_AUTHORIZATION = "Authorization";
  public static final String HEADER_USER_AGENT = "user-agent";
  public static final String REPORT_ETL_SCS_NAME = "report-etl";
  public static final String HEADER_CORRELATION_ID = "X-SG-SS-Correlation-ID";
  public static final String CONTENT_TYPE = "application/json";
  public static final String WALLET_TYPE = "limits";
  public static final String LIMIT_DURATION_P1D = "P1D";
  public static final String LIMIT_DURATION_P1W = "P1W";
  public static final String LIMIT_DURATION_P1M = "P1M";
  public static final String LIMIT_CATEGORY_TYPE_WAGER = "wager";
  public static final String LIMIT_CATEGORY_TYPE_LOSS = "loss";
  public static final String LIMIT_CATEGORY_TYPE_DEPOSIT = "deposit";
  public static final String CORRELATION_ID = "correlationId";
  public static final String EMPTY_STRING = "";
  /** Teams and leagues constants. */
  public static final String TEAM_CREATE = "create";

  public static final String TEAM_UPDATE = "update";
  public static final String TEAM_REMOVE = "remove";
  public static final String TEAM_PLAYER_ADD = "add_player";
  public static final String CHANGE_CHAIRMAN = "change_chairman";
  public static final String REMOVE_PLAYER = "remove_player";
  public static final String CREATE_INVITE = "create_invite";
  public static final String RESEND_INVITE = "resend_invite";
  public static final String UPDATE_INVITE = "update_invite";
  public static final String DECLINE_INVITE = "invite_decline";
  public static final String REMOVE_INVITE = "remove_invite";
  public static final String ACCEPT_INVITE = "invite_accept";
  public static final String LEAGUE_CREATE = "create";
  public static final String LEAGUE_UPDATE = "update";
  public static final String LEAGUE_PLAYER_ADD = "add_player";
  public static final String LEAGUE_REMOVE = "remove";
  public static final String ETL_JOB_NAME = "report-etl-service";
  public static final String ETL_TRANS_NAME_ADJUSTMENT = "Adjustment job";
  public static final String ETL_TRANS_NAME_WAGER = "Wager job";
  public static final String ETL_TRANS_NAME_WAGER_SET = "Wager Set job";
  public static final String ETL_TRANS_NAME_WIN = "Win job";
  public static final String ETL_TRANS_NAME_TRANSACTION = "Player Transaction";
  public static final String ETL_TRANS_NAME_TRANSACTION_UPDATE = "Player Transaction Update";
  public static final String ETL_TRANS_NAME_LIMIT = "Limit Job";
  public static final String ETL_TRANS_NAME_LIMI_CATEGORY = "Limit Category Job";
  public static final String ETL_TRANS_NAME_SELFEXCLUSION = "Self exclusion job";
  public static final String ETL_TRANS_NAME_PLAYERRESTRICTION = "Player Restriction job";
  public static final String ETL_SERVICE_NAME = "Report ETL Service";
  public static final String GAME_MANAGER_TOPIC = "game-manager";
  public static final String EXCLUSION_EVENTS_TOPIC = "exclusion-events-json";
  public static final String LIMIT_TOPIC = "limit";
  public static final String AGENT_TOPIC = "agent";
  public static final String LIMIT_CATEGORY_TOPIC = "category";
  public static final String PLAYER_TOPIC = "player";
  public static final String SESSION_TOPIC = "session";
  public static final String TEAM_TOPIC = "TEAM";
  public static final String LEAUGE_TOPIC = "LEAGUE";
  public static final String EXPECTED_SPENDING_TOPIC = "expected-spending";
  public static final String THIRD_PARTY_ERRORS = "third-party-failure";
  public static final String ACCESS_LOG_TOPIC = "access-log";
  public static final String PLAYER_CARD_TOPIC = "player_card";
  public static final String CREATE_SUBSCRIPTION_TOPIC = "subscriptions.NewSubscriptionCreated";
  public static final String UPDATE_SUBSCRIPTION_TOPIC = "subscriptions.SubscriptionUpdated";
  public static final String CANCEL_SUBSCRIPTION_TOPIC = "subscriptions.SubscriptionCancelled";
  public static final String SENT_TO_BANK_TOPIC = "sentToBank";
  public static final String CREATE_LEDGER_TOPIC = "ledger-creation-events";
  public static final String REAL_MONEY_TOPIC = "real-money";
  public static final String DYNAMIC_TOPIC = "dynamic";
  public static final String YEAR_SCHEDULE_UPDATE_TOPIC = "subscriptions.YearlyScheduleUpdated";
  public static final String YEAR_SCHEDULE_DELETE_TOPIC = "subscriptions.YearlyScheduleDeleted";
  public static final String GAME_SCHEDULE_UPDATE_TOPIC = "subscriptions.GameScheduleUpdated";
  public static final String GAME_SCHEDULE_DELETE_TOPIC = "subscriptions.GameScheduleDeleted";
  public static final String STATUS_ERROR = "Error";
  public static final String STATUS_SUCCESS = "Success";
  public static final String TEXT_PLAIN = "text/plain";
  /** Game Category Job. */
  public static final String ETL_TRANS_NAME_GAME_CATEGORY = "Game Category job";
  /** Game Sub Category Job. */
  public static final String ETL_TRANS_NAME_GAME_SUB_CATEGORY = "Game Sub Category job";
  /** Game Types Job. */
  public static final String ETL_TRANS_NAME_GAME_TYPES = "Game Types job";
  /** Game Providers Job. */
  public static final String ETL_TRANS_NAME_GAME_PROVIDERS = "Game Provider job";
  /** Game Job. */
  public static final Integer SYSTEM_AGENT_ID =
      ReportEtlContext.getInstance().getReportEtlServiceConfig().getSystemAgentId();

  public static final String ETL_TRANS_NAME_GAME = "Game job";
  public static final String GAME_TYPE = "GameType";
  public static final String GAME_PROVIDER = "GameProvider";
  public static final String GAME_CATEGORY = "GameCategory";
  public static final String GAME_SUB_CATEGORY = "GameSubCategory";
  public static final String GAME = "Game";
  public static final String ETL_TRANS_NAME_AGENT_CREATED = "Agent creation job";
  public static final String ETL_TRANS_NAME_AGENT_ACCESS = "Agent Access job";
  public static final String ETL_TRANS_NAME_AGENT_UPDATED = "Agent update job";
  public static final String ETL_TRANS_NAME_AGENT_CRED_JOB = "Agent credential job";
  public static final String ETL_TRANS_NAME_AGENT_ACCESS_JOB = "Agent Operator access job";
  public static final String ETL_TRANS_NAME_AGENT_COUNTRY_ACCESS_JOB = "Agent Country access job";
  public static final String ETL_TRANS_NAME_AGENT_SESSION_JOB = "Agent session job";
  public static final String ETL_TRANS_NAME_EXPECT_SPENDING_JOB = "Expected spending limit job";
  public static final String ETL_TRANS_NAME_UPDATE_WITHDRAWAL = "Update Withdrawal Status";
  public static final String UPDATE_AGENT_LAST_ACTIVITY_DATE = "Update Agent Last Activity";
  public static final String UPDATE_PLAYER_LAST_ACTIVITY_DATE = "Update Player Last Activity";
  public static final String UPDATE_LAST_ACTIVITY_DATE = "Update Last Activity";
  public static final String ETL_TRANS_NAME_TEAMS_JOB = "Teams process job";
  public static final String ETL_TRANS_NAME_LEAGUES_JOB = "Leagues process job";
  public static final String AGENT_SUCCESS_STATUS = "Online";
  public static final String AGENT_FAILED_STATUS = "Login attempt failure";
  public static final String AGENT_LOGUOT_STATUS = "Session terminated";
  public static final String CHANGE_TYPE_AGENT_PROFILE = "profile";
  public static final String CHANGE_TYPE_AGENT_CRED = "credential";
  public static final String CHANGE_TYPE_AGENT_OPERATOR = "Agent Operator Changes";
  public static final String AGENT_PROFILE_COLUMN_FNAME = "FirstName";
  public static final String AGENT_PROFILE_COLUMN_LNAME = "LastName";
  public static final String AGENT_PROFILE_COLUMN_EMAIL = "Email";
  public static final String AGENT_PROFILE_COLUMN_LOCALE = "Locale";
  public static final String AGENT_PROFILE_COLUMN_JTITLE = "JobTitle";
  public static final String AGENT_PROFILE_COLUMN_STATUS = "Status";
  public static final String AGENT_PROFILE_COLUMN_VFROM = "ValidFrom";
  public static final String AGENT_PROFILE_COLUMN_VTILL = "ValidTill";
  public static final String PLAYER_AFFILIATION = "Player Affiliation";
  public static final String PLAYER_ADDRESS = "Player Address";
  public static final String PLAYER_PHONE = "Player Phone";
  public static final String PLAYER_TERMS_CONDITIONS = "Player Terms and Conditions";
  public static final String PLAYER_SOCIAL_NETWORK = "Player Social Network";
  public static final String PLAYER_COLUMN_PLAYER_ID = "PlayerId";
  public static final String PLAYER_ADDRESS_COLUMN_ADDRESS_TYPE = "AddressType";
  public static final String PLAYER_ADDRESS_COLUMN_CO_NAME = "CoName";
  public static final String PLAYER_ADDRESS_COLUMN_HOUSE_NUMBER = "HouseNumber";
  public static final String PLAYER_ADDRESS_COLUMN_LEVEL = "Level";
  public static final String PLAYER_ADDRESS_COLUMN_DOOR = "Door";
  public static final String PLAYER_ADDRESS_COLUMN_STREET = "Street";
  public static final String PLAYER_ADDRESS_COLUMN_POSTAL_CODE = "PostalCode";
  public static final String PLAYER_ADDRESS_COLUMN_CITY = "City";
  public static final String PLAYER_ADDRESS_COLUMN_STATE = "State";
  public static final String PLAYER_ADDRESS_COLUMN_COUNTRY = "Country";
  public static final String PLAYER_ADDRESS_COLUMN_DETAIL = "Detail";
  public static final String PLAYER_ADDRESS_COLUMN_IS_VALIDATED = "Address Is Validated";
  public static final String AUTHOR_TYPE_AGENT = "Agent";
  public static final String AUTHOR_TYPE_PLAYER = "Player";
  public static final String PLAYER_PHONE_COLUMN_NUMBER = "Number";
  public static final String PLAYER_PHONE_COLUMN_HOME_NUMBER = "Home Number";
  public static final String PLAYER_PHONE_COLUMN_PERSONAL_NUMBER = "Personal Number";
  public static final String PLAYER_PAYMENT_METHOD = "Player Payment Method";
  public static final String PLAYER_IDENTIFICATION_DOCUMENT = "Player Identification Document";
  public static final String PLAYER_CARD = "Player Card";
  public static final String PLAYER_SESSION = "Player Session";
  public static final String LOGOUT_STATUS = "Session terminated";
  public static final String LOGIN_SUCCESS_STATUS = "Online";
  public static final String LOGIN_FAILURE_STATUS = "Login attempt failure";
  public static final String PLAYER_PHONE_ADDED_TYPE = "phone-created";
  public static final String PLAYER_ADDRESS_ADDED_TYPE = "address-created";
  public static final String PLAYER_TERMS_AND_CONDITIONS_TYPE = "general-terms-of-use";
  public static final String PLAYER_AFFILIATION_SUBMITTED_TYPE = "affiliation-created";
  public static final String PLAYER_SOCIAL_NETWORK_ADDED_TYPE = "social-network-created";
  public static final String PLAYER_IDENTIFICATION_ADDED_TYPE = "identification-created";
  public static final String PLAYER_CARD_ADDED_TYPE = "player-card-created";
  public static final String REAL_MONEY = "real-money";
  public static final String RESTRICTED_BWIN_POKER_WINNINGS = "RESTRICTED_BWIN_POKER_WINNINGS";
  public static final String PROMOTION_OPENBET = "PROMOTION_OPENBET";
  public static final String RESTRICTED_BWIN_BONUS = "RESTRICTED_BWIN_BONUS";
  public static final String PLAYER_PROFILE_UPDATE = "Player Profile Update";
  public static final String PLAYER_ACTIVATION = "Player Activation";
  public static final String PLAYER_PHONE_IS_VALIDATED = "Phone Is Validated";
  public static final String PLAYER_IDENT_IS_VALIDATED = "CPR Number Is Validated";
  public static final String PLAYER_EMAIL_IS_VALIDATED = "Email Is Validated";
  public static final String ETL_TRANS_NAME_GAME_DETAILS = "Game Details job";
  public static final String ETL_TRANS_NAME_SUBSCRIPTION = "Subscription";
  public static final String ETL_TRANS_NAME_SUBSCRIPTION_TRANSACTION = "Subscription Transaction";
  public static final String ETL_EXCLUDED_PLAYER_REGISTRATION = "Excluded Player Registration";
  public static final String ETL_PARSE_DATE = "Parse Date";
  public static final String ETL_SUBSCRIPTION_SCHEDULE_CREATED_UPDATED =
      "Subscription Schedule Created / Updated";
  public static final String ETL_SUBSCRIPTION_SCHEDULE_CREATED_DELETED =
      "Subscription Schedule Deleted";
  public static final String ETL_SUBSCRIPTION_GAME_SCHEDULE_CREATED_UPDATED =
      "Subscription Game Schedule Created /" + " Updated";
  public static final String ETL_SUBSCRIPTION_GAME_SCHEDULE_CREATED_DELETED =
      "Subscription Game Schedule Deleted";

  public static final Map<Integer, String> STATUS_TEXTS = new HashMap<>();
  public static final Map<Integer, String> STATUS_CODE = new HashMap<>();
  public static final Map<Integer, String> NUMBER_TEXT = new HashMap<>();

  public static final String ACTIVE_MQ_CLIENT_ID = "clientId";
  public static final String CONSUMER_POOL_SIZE = "consumerPoolSize";
  public static final String CONSUMER_TIME_OUT = "consumerTimeOut";
  public static final String ACTIVE_MQ_USERNAME = "userName";
  public static final String ACTIVE_MQ_PASSWORD = "password";
  public static final String SUBSCRIBER_RETRY_INTERVAL_MS = "subscriberRetryIntervalInMs";
  public static final String HEART_BEAT_TOPIC = "hearBeatTopicName";
  public static final String PREFETCH_LIMIT = "prefetchLimit";

  public static final String PLAYER_TRANSACTION_TABLE = "PlayerTransaction";
  public static final String SUBSCRIPTION_TRANSACTION_TABLE = "SubscriptionTransaction";

  public static final String MESSAGE_OLD_ERROR_MSG =
      "Message is too old, Record updated with latest date";

  public static final String ADDRESS_UPDATED = "address-updated";
  public static final String ADDRESS_DELETED = "address-deleted";
  public static final String AFFILIATION_UPDATED = "affiliation-updated";
  public static final String IDENTIFICATION_UPDATED = "identification-updated";
  public static final String IDENTIFICATION_DELETED = "identification-deleted";
  public static final String PAYMENT_METHOD_UPDATED = "payment-method-updated";
  public static final String PAYMENT_METHOD_DELETED = "payment-method-deleted";
  public static final String PHONE_UPDATED = "phone-updated";
  public static final String PHONE_DELETED = "phone-deleted";
  public static final String PLAYER_UPDATED = "player-updated";
  public static final String COMMENT_ADDED = "comment-added";
  public static final String AGENT_CREATED_TYPE = "agent-created";
  public static final String AGENT_UPDATED_TYPE = "agent-updated";

  static {
    STATUS_TEXTS.put(200, "Ok");
    STATUS_TEXTS.put(201, "Created");
    STATUS_TEXTS.put(204, "No Content");
    STATUS_TEXTS.put(400, "Bad Request");
    STATUS_TEXTS.put(401, "Unauthorized");
    STATUS_TEXTS.put(403, "Forbidden");
    STATUS_TEXTS.put(404, "Not Found");
    STATUS_TEXTS.put(405, "Method Not Allowed");
    STATUS_TEXTS.put(415, "Unsupported Media Type");
    STATUS_TEXTS.put(500, "Internal Server Error");
  }

  static {
    STATUS_CODE.put(400, "BAD-REQUEST");
    STATUS_CODE.put(401, "ILLEGAL_OPERATION");
    STATUS_CODE.put(403, "FORBIDDEN");
    STATUS_CODE.put(404, "DATA-NOT-FOUND");
    STATUS_CODE.put(415, "UNSUPPORTED-MEDIA-TYPE");
    STATUS_CODE.put(500, "SERVER_ERROR");
  }

  static {
    NUMBER_TEXT.put(1, "first");
    NUMBER_TEXT.put(2, "second");
    NUMBER_TEXT.put(3, "third");
    NUMBER_TEXT.put(4, "fourth");
    NUMBER_TEXT.put(5, "fifth");
    NUMBER_TEXT.put(6, "sixth");
    NUMBER_TEXT.put(7, "seventh");
    NUMBER_TEXT.put(8, "eightth");
    NUMBER_TEXT.put(9, "nineth");
    NUMBER_TEXT.put(10, "tenth");
  }

  /** default Constructor. */
  private ReportEtlConsts() {}

  public static Map<Integer, String> getStatusTexts() {
    return STATUS_TEXTS;
  }

  public static Map<Integer, String> getStatusCode() {
    return STATUS_CODE;
  }

  public static Map<Integer, String> getTextForNumber() {
    return NUMBER_TEXT;
  }
}
