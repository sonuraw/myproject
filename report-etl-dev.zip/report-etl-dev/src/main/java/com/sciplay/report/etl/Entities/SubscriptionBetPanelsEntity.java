package com.sciplay.report.etl.Entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class SubscriptionGamesEntity. */
@Entity
@Table(name = "SubscriptionBetPanels")
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubscriptionBetPanelsEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The Id. */
  @Id
  @Column(name = "Id")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int id;
  /** The Draw game template id. */
  private String drawGameTemplateId;
  /** The Subscription id. */
  private Long subscriptionId;
  /** The Selected values. */
  private String selectedValues;
  /** The Play type. */
  private Integer playType;
  /** The Cost per row. */
  private Integer costPerRow;

  /** Instantiates a new subscription games entity. */
  public SubscriptionBetPanelsEntity() {}

  /**
   * Instantiates a new subscription games entity.
   *
   * @param drawGameTemplateId the draw game template id
   * @param subscriptionId the subscription id
   */
  public SubscriptionBetPanelsEntity(String drawGameTemplateId, Long subscriptionId) {
    this.drawGameTemplateId = drawGameTemplateId;
    this.subscriptionId = subscriptionId;
  }

  /**
   * Gets the serialversionuid.
   *
   * @return the serialversionuid
   */
  public static long getSerialversionuid() {
    return serialVersionUID;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public int getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(int id) {
    this.id = id;
  }

  /**
   * Gets the selected values.
   *
   * @return the selected values
   */
  public String getSelectedValues() {
    return selectedValues;
  }

  /**
   * Sets the selected values.
   *
   * @param selectedValues the new selected values
   */
  public void setSelectedValues(String selectedValues) {
    this.selectedValues = selectedValues;
  }

  /**
   * Gets the play type.
   *
   * @return the play type
   */
  public Integer getPlayType() {
    return playType;
  }

  /**
   * Sets the play type.
   *
   * @param playType the new play type
   */
  public void setPlayType(Integer playType) {
    if (playType == null) {
      playType = 0;
    }
    this.playType = playType;
  }

  /**
   * Gets the cost per row.
   *
   * @return the cost per row
   */
  public Integer getCostPerRow() {
    return costPerRow;
  }

  /**
   * Sets the cost per row.
   *
   * @param costPerRow the new cost per row
   */
  public void setCostPerRow(Integer costPerRow) {
    if (costPerRow == null) {
      costPerRow = 0;
    }
    this.costPerRow = costPerRow;
  }

  /**
   * Gets the draw game template id.
   *
   * @return the draw game template id
   */
  public String getDrawGameTemplateId() {
    return drawGameTemplateId;
  }

  /**
   * Sets the draw game template id.
   *
   * @param drawGameTemplateId the new draw game template id
   */
  public void setDrawGameTemplateId(String drawGameTemplateId) {
    this.drawGameTemplateId = drawGameTemplateId;
  }

  /**
   * Gets the subscription id.
   *
   * @return the subscription id
   */
  public Long getSubscriptionId() {
    return subscriptionId;
  }

  /**
   * Sets the subscription id.
   *
   * @param subscriptionId the new subscription id
   */
  public void setSubscriptionId(Long subscriptionId) {
    if (subscriptionId == null) {
      subscriptionId = 0L;
    }
    this.subscriptionId = subscriptionId;
  }
}
