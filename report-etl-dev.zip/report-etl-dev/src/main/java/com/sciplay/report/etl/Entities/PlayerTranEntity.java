package com.sciplay.report.etl.Entities;

import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Type;

/** The Class PlayerTranEntity. */
@Entity
@Table(name = "PlayerTransaction")
@DynamicUpdate
public class PlayerTranEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** Player Transaction ID. */
  @Id
  @Column(name = "TranId")
  private long tranId;

  /** Wager ID. */
  private Long wagerId;

  /** Win ID. */
  private Long winId;

  /** The wager set id. */
  private Long wagerSetId;

  /** Player Unique ID. */
  private Integer playerId;

  /** Player's IpAddress. */
  private String ipAddress;

  /** Session ID. */
  private String sessionId;

  /** Game Channel. */
  private String channel;

  /** Transaction's Start Date. */
  private Date creationDate;

  /** The external created date. */
  private Date externalCreatedDate;

  /** Money Type of Transaction. */
  private String moneyType;

  /** Type of Transaction. */
  @Column(
      name = "TransactionType",
      columnDefinition =
          "enum('adjustment', 'credit', 'debit', 'deposit', 'wager', 'win', 'withdrawal')")
  private String transactionType;

  /** Status of Transaction. */
  @Id
  @Column(
      name = "TransactionStatus",
      columnDefinition =
          "enum('pending', 'processing', 'accepted', 'rejected', 'abandoned', 'cancelled', "
              + "'completed', 'processed')")
  private String transactionStatus;

  /** The external id. */
  private String externalId;

  /** The currency. */
  private String currency;

  /** The card type. */
  private String cardType;

  /** The account type. */
  private String accountType;

  /** The account number. */
  private String accountNumber;

  /** The card number last four. */
  private String cardNumberLastFour;

  /** The fee. */
  private Integer fee;

  /** The updated date. */
  @Column(name = "UpdatedDate")
  private Date updatedDate;

  /** The wallet updated date. */
  private Date walletUpdatedDate;

  /** The withdrawal processed date. */
  private Date withdrawalProcessedDate;

  /** The gvi state. */
  @Column(
      name = "GviState",
      columnDefinition =
          "enum('STARTED', 'PLAYED', 'REFUNDED', 'CANCELLED', 'ROLLEDBACK', 'CORRECTED', "
              + "'PENDING', 'PAID', 'CHECKED', 'ADJUSTED', 'CLAIMED')")
  private String gviState;

  /** The gvi previous state. */
  @Column(
      name = "GviPreviousState",
      columnDefinition =
          "enum('STARTED', 'PLAYED', 'REFUNDED', 'CANCELLED', 'ROLLEDBACK', 'CORRECTED', "
              + "'PENDING', 'PAID', 'CHECKED', 'ADJUSTED', 'CLAIMED')")
  private String gviPreviousState;

  /** The gvi state updated at. */
  private Date gviStateUpdatedAt;

  /** Game ID. */
  private Integer gameId;

  /** Amount of Transaction. */
  private Long amount;

  /** Player's Operator ID. */
  @Column(length = 3, columnDefinition = "CHAR")
  private String operatorId;

  /** Player Balance Before a Transaction. */
  private Long balanceBefore;

  /** Player Balance After a Transaction. */
  private Long balanceAfter;

  /** Author Agent Id. */
  private Integer authorAgentId;

  /** Comments of the Transaction. */
  @Column(name = "Comments")
  @Type(type = "text")
  private String comments;

  /** Transaction subtype. */
  private String subType;

  /** externalUrl. */
  private String externalUrl;

  /** Method ID of Transaction. */
  private Integer methodId;

  /** Bank Name of Transaction. */
  private String bankName;

  /** The approved date. */
  private Date approvedDate;

  /** The approved by. */
  private Integer approvedBy;

  /** The linked transaction id. */
  private Long linkedTransactionId;

  /** The game cycle id. */
  private String gameCycleId;

  /** The is Nation Account. */
  private Boolean isNationalAccount;

  /** The event id. */
  private Long eventId;

  /** The event created at. */
  private Date eventCreatedAt;

  /** The is reprocessed. */
  private Boolean isReprocessed;

  /** The is approved. */
  private Boolean isApproved;

  /** The Reprocessed date. */
  private Date reprocessedDate;

  /** The Player Card Type. */
  @Column(length = 1, columnDefinition = "CHAR")
  private String playerCardType;

  /** The Event Type. */
  private String eventType;

  /**
   * Instantiates a new player tran entity.
   *
   * @param tranId the tran id
   * @param wagerId the wager id
   * @param wagerSetId the wager set id
   * @param winId the win id
   * @param playerId the player id
   * @param ipAddress the ip address
   * @param sessionId the session id
   * @param channel the channel
   * @param creationDate the creation date
   * @param externalCreatedDate the external created date
   * @param moneyType the money type
   * @param transactionType the transaction type
   * @param transactionStatus the transaction status
   * @param externalId the external id
   * @param currency the currency
   * @param gameId the game id
   * @param gameCycleId the game cycle id
   * @param amount the amount
   * @param operatorId the operator id
   * @param decimal the decimal
   * @param balanceBefore the balance before
   * @param balanceAfter the balance after
   * @param authorPlayerId the author player id
   * @param authorAgentId the author agent id
   * @param comments the comments
   * @param subType the sub type
   * @param methodId the method id
   * @param cardType the card type
   * @param accountType the account type
   * @param cardNumberLastFour the card number last four
   * @param fee the fee
   * @param updatedDate the updated date
   * @param bankName the bank name
   * @param approvedDate the approved date
   * @param approvedBy the approved by
   */
  public PlayerTranEntity(
      long tranId,
      Long wagerId,
      Long wagerSetId,
      Long winId,
      Integer playerId,
      String ipAddress,
      String sessionId,
      String channel,
      Date creationDate,
      Date externalCreatedDate,
      String moneyType,
      String transactionType,
      String transactionStatus,
      String externalId,
      String currency,
      Integer gameId,
      String gameCycleId,
      Long amount,
      String operatorId,
      Long decimal,
      Long balanceBefore,
      Long balanceAfter,
      Integer authorPlayerId,
      Integer authorAgentId,
      String comments,
      String subType,
      Integer methodId,
      String cardType,
      String accountType,
      String cardNumberLastFour,
      Integer fee,
      Date updatedDate,
      String bankName,
      Date approvedDate,
      Integer approvedBy) {
    this.tranId = tranId;
    this.wagerId = wagerId;
    this.winId = winId;
    this.wagerSetId = wagerSetId;
    this.playerId = playerId;
    this.ipAddress = ipAddress;
    this.sessionId = sessionId;
    this.channel = channel;
    this.currency = currency;
    this.creationDate = creationDate;
    this.externalCreatedDate = externalCreatedDate;
    this.moneyType = moneyType;
    this.transactionType = transactionType;
    this.transactionStatus = transactionStatus;
    this.externalId = externalId;
    this.gameId = gameId;
    this.gameCycleId = gameCycleId;
    this.amount = amount;
    this.operatorId = operatorId;
    this.balanceBefore = balanceBefore;
    this.balanceAfter = balanceAfter;
    this.authorAgentId = authorAgentId;
    this.comments = comments;
    this.subType = subType;
    this.methodId = methodId;
    this.cardType = cardType;
    this.accountType = accountType;
    this.cardNumberLastFour = cardNumberLastFour;
    this.fee = fee;
    this.updatedDate = updatedDate;
    this.bankName = bankName;
    this.approvedDate = approvedDate;
    this.approvedBy = approvedBy;
  }

  /** Instantiates a new player tran entity. */
  public PlayerTranEntity() {}

  @Override
  public String toString() {
    return "PlayerTranEntity{"
        + "tranId="
        + tranId
        + ", wagerId="
        + wagerId
        + ", winId="
        + winId
        + ", wagerSetId="
        + wagerSetId
        + ", playerId="
        + playerId
        + ", ipAddress='"
        + ipAddress
        + '\''
        + ", sessionId='"
        + sessionId
        + '\''
        + ", channel='"
        + channel
        + '\''
        + ", creationDate="
        + creationDate
        + ", externalCreatedDate="
        + externalCreatedDate
        + ", moneyType='"
        + moneyType
        + '\''
        + ", transactionType='"
        + transactionType
        + '\''
        + ", transactionStatus='"
        + transactionStatus
        + '\''
        + ", externalId='"
        + externalId
        + '\''
        + ", currency='"
        + currency
        + '\''
        + ", cardType='"
        + cardType
        + '\''
        + ", accountType='"
        + accountType
        + '\''
        + ", accountNumber='"
        + accountNumber
        + '\''
        + ", cardNumberLastFour='"
        + cardNumberLastFour
        + '\''
        + ", fee="
        + fee
        + ", updatedDate="
        + updatedDate
        + ", walletUpdatedDate="
        + walletUpdatedDate
        + ", withdrawalProcessedDate="
        + withdrawalProcessedDate
        + ", gviState='"
        + gviState
        + '\''
        + ", gviPreviousState='"
        + gviPreviousState
        + '\''
        + ", gviStateUpdatedAt="
        + gviStateUpdatedAt
        + ", gameId="
        + gameId
        + ", amount="
        + amount
        + ", operatorId='"
        + operatorId
        + '\''
        + ", balanceBefore="
        + balanceBefore
        + ", balanceAfter="
        + balanceAfter
        + ", authorAgentId="
        + authorAgentId
        + ", comments='"
        + comments
        + '\''
        + ", subType='"
        + subType
        + '\''
        + ", externalUrl='"
        + externalUrl
        + '\''
        + ", methodId="
        + methodId
        + ", bankName='"
        + bankName
        + '\''
        + ", approvedDate="
        + approvedDate
        + ", approvedBy="
        + approvedBy
        + ", linkedTransactionId="
        + linkedTransactionId
        + ", gameCycleId='"
        + gameCycleId
        + '\''
        + ", isNationalAccount="
        + isNationalAccount
        + ", eventId="
        + eventId
        + ", eventCreatedAt="
        + eventCreatedAt
        + ", isReprocessed="
        + isReprocessed
        + ", isApproved="
        + isApproved
        + ", playerCardType='"
        + playerCardType
        + '\''
        + ", eventType='"
        + eventType
        + '\''
        + '}';
  }

  /**
   * Gets the checks if is reprocessed.
   *
   * @return the checks if is reprocessed
   */
  public Boolean getIsReprocessed() {
    return isReprocessed;
  }

  /**
   * Sets the checks if is reprocessed.
   *
   * @param isReprocessed the new checks if is reprocessed
   */
  public void setIsReprocessed(Boolean isReprocessed) {
    this.isReprocessed = (Objects.isNull(isReprocessed)) ? false : isReprocessed;
  }

  /**
   * Gets the reprocessed date.
   *
   * @return the reprocessed date
   */
  public Date getReprocessedDate() {
    return reprocessedDate;
  }

  /**
   * Sets the reprocessed date.
   *
   * @param reprocessedDate the new reprocessed date
   */
  public void setReprocessedDate(Date reprocessedDate) {
    this.reprocessedDate = reprocessedDate;
  }

  /**
   * Gets the wallet updated date.
   *
   * @return the walletUpdatedDate
   */
  public Date getWalletUpdatedDate() {
    return walletUpdatedDate;
  }

  /**
   * Sets the wallet updated date.
   *
   * @param walletUpdatedDate the walletUpdatedDate to set
   */
  public void setWalletUpdatedDate(Date walletUpdatedDate) {
    this.walletUpdatedDate = walletUpdatedDate;
  }

  /**
   * Gets the game cycle id.
   *
   * @return the game cycle id
   */
  public String getGameCycleId() {
    return gameCycleId;
  }

  /**
   * Sets the game cycle id.
   *
   * @param gameCycleId the new game cycle id
   */
  public void setGameCycleId(String gameCycleId) {
    this.gameCycleId = gameCycleId;
  }

  /**
   * Gets the bank name.
   *
   * @return the bank name
   */
  public String getBankName() {
    return bankName;
  }

  /**
   * Sets the bank name.
   *
   * @param bankName the new bank name
   */
  public void setBankName(String bankName) {
    this.bankName = bankName;
  }

  /**
   * Gets the tran id.
   *
   * @return the tranId
   */
  public long getTranId() {
    return tranId;
  }

  /**
   * Sets the tran id.
   *
   * @param tranId the tranId to set
   */
  public void setTranId(long tranId) {
    this.tranId = tranId;
  }

  /**
   * Gets the wager id.
   *
   * @return the wagerId
   */
  public Long getWagerId() {
    return wagerId;
  }

  /**
   * Sets the wager id.
   *
   * @param wagerId the wagerId to set
   */
  public void setWagerId(Long wagerId) {
    this.wagerId = (Objects.isNull(wagerId)) ? 0L : wagerId;
  }

  /**
   * Gets the win id.
   *
   * @return the winId
   */
  public Long getWinId() {
    return winId;
  }

  /**
   * Sets the win id.
   *
   * @param winId the winId to set
   */
  public void setWinId(Long winId) {
    this.winId = (Objects.isNull(winId)) ? 0L : winId;
  }

  /**
   * Gets the wager set id.
   *
   * @return the winId
   */
  public Long getWagerSetId() {
    return wagerSetId;
  }

  /**
   * Sets the wager set id.
   *
   * @param wagerSetId the new wager set id
   */
  public void setWagerSetId(Long wagerSetId) {
    this.wagerSetId = (Objects.isNull(wagerSetId)) ? 0L : wagerSetId;
  }

  /**
   * Gets the player id.
   *
   * @return the playerId
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the playerId to set
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the ip address.
   *
   * @return the ipAddress
   */
  public String getIpAddress() {
    return ipAddress;
  }

  /**
   * Sets the ip address.
   *
   * @param ipAddress the ipAddress to set
   */
  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }

  /**
   * Gets the session id.
   *
   * @return the sessionId
   */
  public String getSessionId() {
    return sessionId;
  }

  /**
   * Sets the session id.
   *
   * @param sessionId the sessionId to set
   */
  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  /**
   * Gets the channel.
   *
   * @return the channel
   */
  public String getChannel() {
    return channel;
  }

  /**
   * Sets the channel.
   *
   * @param channel the channel to set
   */
  public void setChannel(String channel) {
    this.channel = channel;
  }

  /**
   * Gets the currency.
   *
   * @return the channel
   */
  public String getCurrency() {
    return currency;
  }

  /**
   * Sets the currency.
   *
   * @param currency the new currency
   */
  public void setCurrency(String currency) {
    this.currency = currency;
  }

  /**
   * Gets the account number.
   *
   * @return the accountNumber
   */
  public String getAccountNumber() {
    return accountNumber;
  }

  /**
   * Sets the account number.
   *
   * @param accountNumber the accountNumber to set
   */
  public void setAccountNumber(String accountNumber) {
    this.accountNumber = accountNumber;
  }

  /**
   * Gets the external url.
   *
   * @return the externalUrl
   */
  public String getExternalUrl() {
    return externalUrl;
  }

  /**
   * Sets the external url.
   *
   * @param externalUrl the externalUrl to set
   */
  public void setExternalUrl(String externalUrl) {
    this.externalUrl = externalUrl;
  }

  /**
   * Gets the creation date.
   *
   * @return the creationDate
   */
  public Date getCreationDate() {
    return creationDate;
  }

  /**
   * Sets the creation date.
   *
   * @param creationDate the creationDate to set
   */
  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  /**
   * Gets the external created date.
   *
   * @return the externalCreatedDate
   */
  public Date getExternalCreatedDate() {
    return externalCreatedDate;
  }

  /**
   * Sets the external created date.
   *
   * @param externalCreatedDate the externalCreatedDate to set
   */
  public void setExternalCreatedDate(Date externalCreatedDate) {
    this.externalCreatedDate = externalCreatedDate;
  }

  /**
   * Gets the money type.
   *
   * @return the moneyType
   */
  public String getMoneyType() {
    return moneyType;
  }

  /**
   * Sets the money type.
   *
   * @param moneyType the moneyType to set
   */
  public void setMoneyType(String moneyType) {
    this.moneyType = moneyType;
  }

  /**
   * Gets the transaction type.
   *
   * @return the transactionType
   */
  public String getTransactionType() {
    return transactionType;
  }

  /**
   * Sets the transaction type.
   *
   * @param transactionType the transactionType to set
   */
  public void setTransactionType(String transactionType) {
    this.transactionType = transactionType;
  }

  /**
   * Gets the transaction status.
   *
   * @return the transactionStatus
   */
  public String getTransactionStatus() {
    return transactionStatus;
  }

  /**
   * Sets the transaction status.
   *
   * @param transactionStatus the transactionStatus to set
   */
  public void setTransactionStatus(String transactionStatus) {
    this.transactionStatus = transactionStatus;
  }

  /**
   * Gets the external id.
   *
   * @return the methodTypeDetails
   */
  public String getExternalId() {
    return externalId;
  }

  /**
   * Sets the external id.
   *
   * @param externalId the new external id
   */
  public void setExternalId(String externalId) {
    this.externalId = externalId;
  }

  /**
   * Gets the game id.
   *
   * @return the gameId
   */
  public Integer getGameId() {
    return gameId;
  }

  /**
   * Sets the game id.
   *
   * @param gameId the gameId to set
   */
  public void setGameId(Integer gameId) {
    this.gameId = (Objects.isNull(gameId)) ? 0 : gameId;
  }

  /**
   * Gets the amount.
   *
   * @return the amount
   */
  public Long getAmount() {
    return amount;
  }

  /**
   * Sets the amount.
   *
   * @param amount the amount to set
   */
  public void setAmount(Long amount) {
    this.amount = (Objects.isNull(amount)) ? 0L : amount;
  }

  /**
   * Gets the operator id.
   *
   * @return the OperatorId
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the balance before.
   *
   * @return the balanceBefore
   */
  public Long getBalanceBefore() {
    return balanceBefore;
  }

  /**
   * Sets the balance before.
   *
   * @param balanceBefore the balanceBefore to set
   */
  public void setBalanceBefore(Long balanceBefore) {
    this.balanceBefore = (Objects.isNull(balanceBefore)) ? 0L : balanceBefore;
  }

  /**
   * Gets the balance after.
   *
   * @return the balanceAfter
   */
  public Long getBalanceAfter() {
    return balanceAfter;
  }

  /**
   * Sets the balance after.
   *
   * @param balanceAfter the balanceAfter to set
   */
  public void setBalanceAfter(Long balanceAfter) {
    this.balanceAfter = (Objects.isNull(balanceAfter)) ? 0L : balanceAfter;
  }

  /**
   * Gets the author agent id.
   *
   * @return the authorAgentId
   */
  public Integer getAuthorAgentId() {
    return authorAgentId;
  }

  /**
   * Sets the author agent id.
   *
   * @param authorAgentId the authorAgentId to set
   */
  public void setAuthorAgentId(Integer authorAgentId) {
    this.authorAgentId = (Objects.isNull(authorAgentId)) ? 0 : authorAgentId;
  }

  /**
   * Gets the comments.
   *
   * @return the comments
   */
  public String getComments() {
    return comments;
  }

  /**
   * Sets the comments.
   *
   * @param comments the comments to set
   */
  public void setComments(String comments) {
    this.comments = comments;
  }

  /**
   * Gets the sub type.
   *
   * @return the subtype
   */
  public String getSubType() {
    return subType;
  }

  /**
   * Sets the sub type.
   *
   * @param subType the subtype to set
   */
  public void setSubType(String subType) {
    this.subType = subType;
  }

  /**
   * Gets the method id.
   *
   * @return the methodId
   */
  public Integer getMethodId() {
    return methodId;
  }

  /**
   * Sets the method id.
   *
   * @param methodId the methodId to set
   */
  public void setMethodId(Integer methodId) {
    this.methodId = (Objects.isNull(methodId)) ? 0 : methodId;
  }

  /**
   * Gets the card type.
   *
   * @return the CardType
   */
  public String getCardType() {
    return cardType;
  }

  /**
   * Sets the card type.
   *
   * @param cardType the new card type
   */
  public void setCardType(String cardType) {
    this.cardType = cardType;
  }

  /**
   * Gets the account type.
   *
   * @return the AccountType
   */
  public String getAccountType() {
    return accountType;
  }

  /**
   * Sets the account type.
   *
   * @param accountType the new account type
   */
  public void setAccountType(String accountType) {
    this.accountType = accountType;
  }

  /**
   * Gets the card number last four.
   *
   * @return the CardNumberLastFour
   */
  public String getCardNumberLastFour() {
    return cardNumberLastFour;
  }

  /**
   * Sets the card number last four.
   *
   * @param cardNumberLastFour the new card number last four
   */
  public void setCardNumberLastFour(String cardNumberLastFour) {
    this.cardNumberLastFour = cardNumberLastFour;
  }

  /**
   * Gets the fee.
   *
   * @return the fee
   */
  public Integer getFee() {
    return fee;
  }

  /**
   * Sets the fee.
   *
   * @param fee the new fee
   */
  public void setFee(Integer fee) {
    this.fee = (Objects.isNull(fee)) ? 0 : fee;
  }

  /**
   * Gets the updated date.
   *
   * @return the updatedDate
   */
  public Date getUpdatedDate() {
    return updatedDate;
  }

  /**
   * Sets the updated date.
   *
   * @param updatedDate the updatedDate to set
   */
  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  /**
   * Gets the approved date.
   *
   * @return the approvedDate
   */
  public Date getApprovedDate() {
    return approvedDate;
  }

  /**
   * Sets the approved date.
   *
   * @param approvedDate the approvedDate to set
   */
  public void setApprovedDate(Date approvedDate) {
    this.approvedDate = approvedDate;
  }

  /**
   * Gets the approved by.
   *
   * @return the approvedBy
   */
  public Integer getApprovedBy() {
    return approvedBy;
  }

  /**
   * Sets the approved by.
   *
   * @param approvedBy the approvedBy to set
   */
  public void setApprovedBy(Integer approvedBy) {
    this.approvedBy = (Objects.isNull(approvedBy)) ? 0 : approvedBy;
  }

  /**
   * Gets the withdrawal processed date.
   *
   * @return the withdrawalProcessedDate
   */
  public Date getWithdrawalProcessedDate() {
    return withdrawalProcessedDate;
  }

  /**
   * Sets the withdrawal processed date.
   *
   * @param withdrawalProcessedDate the withdrawalProcessedDate to set
   */
  public void setWithdrawalProcessedDate(Date withdrawalProcessedDate) {
    this.withdrawalProcessedDate = withdrawalProcessedDate;
  }

  /**
   * Gets the linked transaction id.
   *
   * @return the linkedTransactionId
   */
  public Long getLinkedTransactionId() {
    return linkedTransactionId;
  }

  /**
   * Sets the linked transaction id.
   *
   * @param linkedTransactionId the linkedTransactionId to set
   */
  public void setLinkedTransactionId(Long linkedTransactionId) {
    this.linkedTransactionId = (Objects.isNull(linkedTransactionId)) ? 0L : linkedTransactionId;
  }

  /**
   * Gets the gvi state.
   *
   * @return the gviState
   */
  public String getGviState() {
    return gviState;
  }

  /**
   * Sets the gvi state.
   *
   * @param gviState the gviState to set
   */
  public void setGviState(String gviState) {
    this.gviState = gviState;
  }

  /**
   * Gets the gvi previous state.
   *
   * @return the gviPreviousState
   */
  public String getGviPreviousState() {
    return gviPreviousState;
  }

  /**
   * Sets the gvi previous state.
   *
   * @param gviPreviousState the gviPreviousState to set
   */
  public void setGviPreviousState(String gviPreviousState) {
    this.gviPreviousState = gviPreviousState;
  }

  /**
   * Gets the gvi state updated at.
   *
   * @return the gviStateUpdatedAt
   */
  public Date getGviStateUpdatedAt() {
    return gviStateUpdatedAt;
  }

  /**
   * Sets the gvi state updated at.
   *
   * @param gviStateUpdatedAt the gviStateUpdatedAt to set
   */
  public void setGviStateUpdatedAt(Date gviStateUpdatedAt) {
    this.gviStateUpdatedAt = gviStateUpdatedAt;
  }

  /**
   * Gets the checks if is national account.
   *
   * @return the isNationalAccount
   */
  public Boolean getIsNationalAccount() {
    return isNationalAccount;
  }

  /**
   * Sets the checks if is national account.
   *
   * @param isNationalAccount the isNationalAccount to set
   */
  public void setIsNationalAccount(Boolean isNationalAccount) {
    this.isNationalAccount = (Objects.isNull(isNationalAccount)) ? false : isNationalAccount;
  }

  /**
   * Gets the event id.
   *
   * @return the eventId
   */
  public Long getEventId() {
    return eventId;
  }

  /**
   * Sets the event id.
   *
   * @param eventId the eventId to set
   */
  public void setEventId(Long eventId) {
    this.eventId = (Objects.isNull(eventId)) ? 0L : eventId;
  }

  /**
   * Gets the event created at.
   *
   * @return the eventCreatedAt
   */
  public Date getEventCreatedAt() {
    return eventCreatedAt;
  }

  /**
   * Sets the event created at.
   *
   * @param eventCreatedAt the eventCreatedAt to set
   */
  public void setEventCreatedAt(Date eventCreatedAt) {
    this.eventCreatedAt = eventCreatedAt;
  }

  /** @return the playerCardType */
  public String getPlayerCardType() {
    return playerCardType;
  }

  /** @param playerCardType the playerCardType to set */
  public void setPlayerCardType(String playerCardType) {
    this.playerCardType = playerCardType;
  }

  /** @return the eventType */
  public String getEventType() {
    return eventType;
  }

  /** @param eventType the eventType to set */
  public void setEventType(String eventType) {
    this.eventType = eventType;
  }

  /** @return the isApproved */
  public Boolean getIsApproved() {
    return isApproved;
  }

  /** @param isApproved the isApproved to set */
  public void setIsApproved(Boolean isApproved) {
    this.isApproved = (Objects.isNull(isApproved)) ? false : isApproved;
  }
}
