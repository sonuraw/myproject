package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** The Class Meta. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Meta {

  /** The creation time. */
  private String creationTime;

  /** The correlation id. */
  private String correlationId;

  /** The operator. */
  private String operator;

  /** The author. */
  private Author author;

  /** The operator id. */
  private String operatorId;

  /** The created at. */
  private String createdAt;

  /** The customer id. */
  private String customerId;

  /** The copyright. */
  private String copyright;

  /** @return the copyright */
  public String getCopyright() {
    return copyright;
  }

  /** @param copyright the copyright to set */
  public void setCopyright(String copyright) {
    this.copyright = copyright;
  }

  /**
   * Gets the customer id.
   *
   * @return the customer id
   */
  public String getCustomerId() {
    return customerId;
  }

  /**
   * Sets the customer id.
   *
   * @param customerId the new customer id
   */
  public void setCustomerId(String customerId) {
    this.customerId = customerId;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public String getCreatedAt() {
    return createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the creation time.
   *
   * @return the creation time
   */
  public String getCreationTime() {
    return creationTime;
  }

  /**
   * Sets the creation time.
   *
   * @param creationTime the new creation time
   */
  public void setCreationTime(String creationTime) {
    this.creationTime = creationTime;
  }

  /**
   * Gets the correlation id.
   *
   * @return the correlation id
   */
  public String getCorrelationId() {
    return correlationId;
  }

  /**
   * Sets the correlation id.
   *
   * @param correlationId the new correlation id
   */
  public void setCorrelationId(String correlationId) {
    this.correlationId = correlationId;
  }

  /**
   * Gets the operator.
   *
   * @return the operator
   */
  public String getOperator() {
    return operator;
  }

  /**
   * Sets the operator.
   *
   * @param operator the new operator
   */
  public void setOperator(String operator) {
    this.operator = operator;
  }

  /**
   * Gets the author.
   *
   * @return the author
   */
  public Author getAuthor() {
    return author;
  }

  /**
   * Sets the author.
   *
   * @param author the new author
   */
  public void setAuthor(Author author) {
    this.author = author;
  }
}
