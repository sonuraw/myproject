package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Date;

/** The Class Attributes. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ThirdPartyErrorAttributes {
  /** The CreatedDate. */
  private Date createdAt;

  /** The PartnerId. */
  private String partnerId;

  /** The Error. */
  private String error;

  /** @return the createdDate */
  public Date getCreatedAt() {
    return createdAt;
  }

  /** */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  /** @return the partnerId */
  public String getPartnerId() {
    return partnerId;
  }

  /** @param partnerId the partnerId to set */
  public void setPartnerId(String partnerId) {
    this.partnerId = partnerId;
  }

  /** @return the error */
  public String getError() {
    return error;
  }

  /** @param error the error to set */
  public void setError(String error) {
    this.error = error;
  }
}
