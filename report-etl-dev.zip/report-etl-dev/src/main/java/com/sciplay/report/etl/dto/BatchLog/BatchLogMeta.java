package com.sciplay.report.etl.dto.BatchLog;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BatchLogMeta {

  @JsonProperty("service")
  private String service;

  @JsonProperty("createdAt")
  private Date createdAt;

  @JsonProperty("service")
  public String getService() {
    return service;
  }

  @JsonProperty("service")
  public void setService(String service) {
    this.service = service;
  }

  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }

  @JsonProperty("createdAt")
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }
}
