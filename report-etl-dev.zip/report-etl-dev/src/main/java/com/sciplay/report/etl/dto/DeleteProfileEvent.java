package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DeleteProfileEvent {

  /** The meta. */
  private Meta meta;

  /** The data. */
  private DeleteProfileData data;

  /**
   * Gets the meta.
   *
   * @return the meta
   */
  public Meta getMeta() {
    return meta;
  }

  /**
   * Sets the meta.
   *
   * @param meta the new meta
   */
  public void setMeta(Meta meta) {
    this.meta = meta;
  }

  /**
   * Gets the data.
   *
   * @return the data
   */
  public DeleteProfileData getData() {
    return data;
  }

  /**
   * Sets the data.
   *
   * @param data the new data
   */
  public void setData(DeleteProfileData data) {
    this.data = data;
  }
}
