package com.sciplay.report.etl.Entities;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class PlayerActivationEntity. */
@Entity
@Table(name = "PlayerActivation")
public class PlayerActivationEntity implements Serializable {

  private static final long serialVersionUID = 1L;

  /** The player id. */
  @Id
  @Column(name = "PlayerId")
  private Integer playerId;

  /** The operator id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  @Id
  private String operatorId;

  /** The partner. */
  private String partner;

  /** The campaign. */
  private String campaign;

  /** The payload. */
  private String payload;

  /** The author player id. */
  private Integer authorPlayerId;

  /** The author agent id. */
  private Integer authorAgentId;

  /** The author ip. */
  private String authorIp;

  /** The author session id. */
  private String authorSessionId;

  /** The created at. */
  private Date createdAt;

  /**
   * Instantiates a new player activation entity.
   *
   * @param playerId the player id
   * @param operatorId the operator id
   * @param partner the partner
   * @param campaign the campaign
   * @param payload the payload
   * @param authorPlayerId the author player id
   * @param authorAgentId the author agent id
   * @param authorIp the author ip
   * @param authorSessionId the author session id
   * @param createdAt the created at
   */
  public PlayerActivationEntity(
      Integer playerId,
      String operatorId,
      String partner,
      String campaign,
      String payload,
      Integer authorPlayerId,
      Integer authorAgentId,
      String authorIp,
      String authorSessionId,
      Date createdAt) {
    this.playerId = playerId;
    this.operatorId = operatorId;
    this.partner = partner;
    this.campaign = campaign;
    this.payload = payload;
    this.authorPlayerId = Objects.isNull(authorPlayerId) ? 0 : authorPlayerId;
    this.authorAgentId = Objects.isNull(authorAgentId) ? 0 : authorAgentId;
    this.authorIp = authorIp;
    this.authorSessionId = authorSessionId;
    this.createdAt = createdAt;
  }

  public PlayerActivationEntity() {}

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the partner.
   *
   * @return the partner
   */
  public String getPartner() {
    return partner;
  }

  /**
   * Sets the partner.
   *
   * @param partner the new partner
   */
  public void setPartner(String partner) {
    this.partner = partner;
  }

  /**
   * Gets the campaign.
   *
   * @return the campaign
   */
  public String getCampaign() {
    return campaign;
  }

  /**
   * Sets the campaign.
   *
   * @param campaign the new campaign
   */
  public void setCampaign(String campaign) {
    this.campaign = campaign;
  }

  /**
   * Gets the payload.
   *
   * @return the payload
   */
  public String getPayload() {
    return payload;
  }

  /**
   * Sets the payload.
   *
   * @param payload the new payload
   */
  public void setPayload(String payload) {
    this.payload = payload;
  }

  /**
   * Gets the author player id.
   *
   * @return the author player id
   */
  public Integer getAuthorPlayerId() {
    return authorPlayerId;
  }

  /**
   * Sets the author player id.
   *
   * @param authorPlayerId the new author player id
   */
  public void setAuthorPlayerId(Integer authorPlayerId) {
    this.authorPlayerId = Objects.isNull(authorPlayerId) ? 0 : authorPlayerId;
  }

  /**
   * Gets the author agent id.
   *
   * @return the author agent id
   */
  public Integer getAuthorAgentId() {
    return authorAgentId;
  }

  /**
   * Sets the author agent id.
   *
   * @param authorAgentId the new author agent id
   */
  public void setAuthorAgentId(Integer authorAgentId) {
    this.authorAgentId = Objects.isNull(authorAgentId) ? 0 : authorAgentId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }
}
