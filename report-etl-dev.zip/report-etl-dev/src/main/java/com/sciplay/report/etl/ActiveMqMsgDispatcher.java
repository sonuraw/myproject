package com.sciplay.report.etl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sciplay.exclusion.events.ExclusionEvent;
import com.sciplay.report.etl.Entities.ErrorsLogEntity;
import com.sciplay.report.etl.Entities.SubscriptionScheduleEntity;
import com.sciplay.report.etl.Entities.SubscriptionsEntity;
import com.sciplay.report.etl.dto.CommittedTransactions;
import com.sciplay.report.etl.dto.CommittedTransactionsData;
import com.sciplay.report.etl.dto.CreatedLedgers;
import com.sciplay.report.etl.dto.CreatedLedgersData;
import com.sciplay.report.etl.dto.DeleteProfileEvent;
import com.sciplay.report.etl.dto.ExcludedPlayerRegistrationAttemptMessage;
import com.sciplay.report.etl.dto.GviStatusUpdate;
import com.sciplay.report.etl.dto.IdentificationMessage;
import com.sciplay.report.etl.dto.IhubAlertsMessage;
import com.sciplay.report.etl.dto.Message;
import com.sciplay.report.etl.dto.PaymentMethodMessage;
import com.sciplay.report.etl.dto.PlayerActivationMessage;
import com.sciplay.report.etl.dto.PlayerAddressMessage;
import com.sciplay.report.etl.dto.PlayerAffiliateMessage;
import com.sciplay.report.etl.dto.PlayerCardMessage;
import com.sciplay.report.etl.dto.PlayerCommentMessage;
import com.sciplay.report.etl.dto.PlayerPhoneMessage;
import com.sciplay.report.etl.dto.PlayerProfileMessage;
import com.sciplay.report.etl.dto.PlayerSessionMessage;
import com.sciplay.report.etl.dto.SocialNetworkMessage;
import com.sciplay.report.etl.dto.TermsAndConditionsMessage;
import com.sciplay.report.etl.dto.ThirdPartyErrorMessage;
import com.sciplay.report.etl.dto.WagerMessage;
import com.sciplay.report.etl.dto.WalletPayload;
import com.sciplay.report.etl.dto.agent.AgentAccessMessage;
import com.sciplay.report.etl.dto.agent.AgentLoginMessage;
import com.sciplay.report.etl.dto.agent.AgentMessage;
import com.sciplay.report.etl.dto.limits.ExpectedSpendingMessage;
import com.sciplay.report.etl.dto.subscriptions.FundingFailedMessage;
import com.sciplay.report.etl.dto.subscriptions.GviMessage;
import com.sciplay.report.etl.dto.subscriptions.SubscriptionMessage;
import com.sciplay.report.etl.dto.subscriptions.SubscriptionScheduleMessage;
import com.sciplay.report.etl.dto.subscriptions.SubscriptionTransactionMessage;
import com.sciplay.report.etl.dto.teamsleagues.TeamsLeaguesMessage;
import com.sciplay.report.etl.exception.CustomException;
import com.sciplay.report.etl.exception.DelayException;
import com.sciplay.report.etl.exception.SuppressException;
import com.sciplay.report.etl.infrastructure.service.UUIDGenerator;
import com.sciplay.report.etl.persistence.mysql.ErrorsLogDaoImpl;
import com.sciplay.report.etl.persistence.mysql.SubscriptionDaoImpl;
import com.sciplay.report.etl.service.BatchLogExecution;
import com.sciplay.report.etl.service.ReportEtlAgentProcessor;
import com.sciplay.report.etl.service.ReportEtlDeleteProfile;
import com.sciplay.report.etl.service.ReportEtlExclusionProcessor;
import com.sciplay.report.etl.service.ReportEtlFundingProcessor;
import com.sciplay.report.etl.service.ReportEtlGameProcessor;
import com.sciplay.report.etl.service.ReportEtlLeagueProcessor;
import com.sciplay.report.etl.service.ReportEtlLimitProcessor;
import com.sciplay.report.etl.service.ReportEtlProcessor;
import com.sciplay.report.etl.service.ReportEtlSubscriptionProcessor;
import com.sciplay.report.etl.service.ReportEtlTeamProcessor;
import com.sciplay.report.etl.utils.ReportEtlUtils;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.hibernate.Session;
import org.hibernate.resource.transaction.spi.TransactionStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class will route the request to various controllers based on message type.
 *
 * @author Thangadurai Ponnusamy
 */
public class ActiveMqMsgDispatcher {

  /** The logger object instance. */
  private static final Logger LOG = LoggerFactory.getLogger(ActiveMqMsgDispatcher.class);

  private final ObjectMapper objectMapper = new ObjectMapper();
  /** The topic. */
  private final String amqDestination;
  /** The errorId. */
  private final Integer errorId;
  /** The isReprocess. */
  private final boolean isReprocess;
  /** The message. */
  private String message;

  private ReportEtlProcessor reportEtlProcessor = null;
  private ReportEtlFundingProcessor reportEtlFundingProcessor = null;
  private ReportEtlGameProcessor reportEtlGameProcessor = null;
  private ReportEtlLimitProcessor reportEtlLimitProcessor = null;
  private ReportEtlDeleteProfile reportEtlDeleteProfile = null;

  /**
   * Routes request to various controllers based on message type, get response and send to activemq
   * topic.
   *
   * @param pTopic the topic
   * @param pMessage the message
   * @param pMsgBytes the msg bytes
   */
  public ActiveMqMsgDispatcher(
      String pTopic,
      String pMessage,
      byte[] pMsgBytes,
      ThreadLocal myThreadLocal,
      Integer errorId) {
    this.amqDestination = pTopic;
    this.message = pMessage;
    this.isReprocess = (boolean) myThreadLocal.get();
    this.errorId = errorId;
  }

  /** gets the Created Time in milliseconds and name of the event type for particular message. */
  public Map getCreatedDateAndEventType(String topicName, String msg, byte[] messageBytes) {
    String eventType = "";
    Long timeInMillis = 0L;
    try {
      objectMapper.configure(
          com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
      JsonNode jsonNode = objectMapper.readValue(msg, JsonNode.class);
      if (!jsonNode.findValues("type").isEmpty() && jsonNode.findValues("type").get(0) != null) {
        eventType = jsonNode.findValues("type").get(0).asText();
      }
      if (!jsonNode.findValues("createdAt").isEmpty()
          && jsonNode.findValues("createdAt").get(0) != null) {
        String createdDate = jsonNode.findValues("createdAt").get(0).asText();
        Date date = ReportEtlUtils.parseDate(createdDate);
        timeInMillis = date.getTime();
      }

    } catch (Exception ex) {
      LOG.error("Stacktrace: " + Arrays.toString(ex.getStackTrace()));
    }
    HashMap<String, Object> results = new HashMap<>();
    results.put("eventType", eventType);
    results.put("timeInMillis", timeInMillis);
    return results;
  }

  /**
   * Run.
   *
   * @throws IOException Signals that an I/O exception has occurred.
   */
  public void processMessage(
      ThreadLocal myThreadLocal,
      Session session,
      String correlationId,
      int jmsRedeliveryCount,
      Integer errorRetryCount)
      throws Exception {

    boolean isSuppressed = false;
    ErrorsLogEntity errorsLogEntity = null;
    ExclusionEvent exclusionEvent;
    boolean isXaSession = false;
    if (session == null) {
      session = XaAmqUtil.getInstance().getSessionFactory().openSession();
      isXaSession = true;
    }
    String messageType = null;
    String ledger = null;
    CommittedTransactionsData committedTran = null;
    CreatedLedgersData createdLedger = null;

    boolean isGviStatusUpdate = false;
    GviStatusUpdate gviStatusUpdate = null;

    reportEtlProcessor = new ReportEtlProcessor((boolean) myThreadLocal.get());
    reportEtlDeleteProfile = new ReportEtlDeleteProfile((boolean) myThreadLocal.get());
    ReportEtlAgentProcessor reportEtlAgentProcessor =
        new ReportEtlAgentProcessor((boolean) myThreadLocal.get());
    ReportEtlTeamProcessor reportEtlTeamProcessor =
        new ReportEtlTeamProcessor((boolean) myThreadLocal.get());
    ReportEtlLeagueProcessor reportEtlLeagueProcessor =
        new ReportEtlLeagueProcessor((boolean) myThreadLocal.get());
    boolean isCaptured = true, isApprovedSet = false;

    try {
      if (correlationId == null) {
        correlationId = UUIDGenerator.INSTANCE.random();
      }

      if (ReportEtlContext.getInstance()
              .getReportEtlConfig()
              .getGviDestination()
              .contains(this.amqDestination)
          || this.amqDestination.equalsIgnoreCase(
              ReportEtlContext.getInstance().getReportEtlConfig().getGviWagerCreateType())) {
        this.message = this.message.replace("\\", "");
        this.message = this.message.replace("}\"", "}");
        this.message = this.message.replace("\"{", "{");
        this.message = this.message.replace("}}\"", "}}");

        GviMessage gviMessage = objectMapper.readValue(this.message, GviMessage.class);
        String type = gviMessage.getMeta().getType();

        if (ReportEtlContext.getInstance()
            .getReportEtlServiceConfig()
            .getGviStatusUpdateTypes()
            .contains(type)) {
          reportEtlFundingProcessor = new ReportEtlFundingProcessor(this.isReprocess);
          objectMapper.configure(
              com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
          gviStatusUpdate = objectMapper.readValue(this.message, GviStatusUpdate.class);
          if (gviStatusUpdate.getMeta().getCreatedAt() != null
              && !gviStatusUpdate
                  .getData()
                  .getStatus()
                  .equals(gviStatusUpdate.getData().getPreviousStatus())) {
            isGviStatusUpdate = true;
          }
          updateGviStatus(gviStatusUpdate, session, type);
        } else if (type.equalsIgnoreCase(
            ReportEtlContext.getInstance().getReportEtlServiceConfig().getGviWagerFromWagerSet())) {
          WagerMessage wagerMessage = genericJsonMessageParser(this.message, WagerMessage.class);
          messageType = wagerMessage.getData().getType();
          reportEtlProcessor.processWagers(wagerMessage, session);
        } else if (type.equalsIgnoreCase(
            ReportEtlContext.getInstance().getReportEtlServiceConfig().getGviWagerCreateType())) {
          WagerMessage wagerMessage = genericJsonMessageParser(this.message, WagerMessage.class);
          messageType = wagerMessage.getData().getType();

          if (wagerMessage.getData().getAttributes().getAmount() != 0
              && wagerMessage.getData().getAttributes().getAmount() > 0L) {
            reportEtlProcessor.processWagers(wagerMessage, session);
          } else if (!this.isReprocess) {
            ErrorsLogEntity er =
                new ErrorsLogEntity(
                    type,
                    this.message,
                    "Need to process by 15 min cron",
                    "",
                    correlationId,
                    messageType,
                    ledger,
                    true);

            ErrorsLogDaoImpl.INSTANCE.saveErrorLog(er, jmsRedeliveryCount, false, session);
          } else {
            reportEtlProcessor.processWagers(wagerMessage, session);
          }
        } else if (type.equalsIgnoreCase(
            ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getGviWagerSetCreateType())) {
          WagerMessage wagerMessage = genericJsonMessageParser(this.message, WagerMessage.class);
          messageType = wagerMessage.getData().getType();
          reportEtlProcessor.processWagerSet(wagerMessage, this.message, session);
        }

      } else if (ReportEtlContext.getInstance()
          .getReportEtlServiceConfig()
          .getExclusionDestination()
          .contains(this.amqDestination)) {
        exclusionEvent = genericJsonMessageParser(this.message, ExclusionEvent.class);
        messageType = exclusionEvent.getData().getType();
        exclusionParser(this.message, session, exclusionEvent, messageType);
      } else if (ReportEtlContext.getInstance()
          .getReportEtlServiceConfig()
          .getGameManagerDestination()
          .contains(this.amqDestination)) {
        objectMapper.configure(
            com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
        JsonNode jsonNode = objectMapper.readValue(this.message, JsonNode.class);
        reportEtlGameProcessor = new ReportEtlGameProcessor();
        messageType = jsonNode.findValues("type").get(0).asText();
        generalMessageParser(this.message, session);
      } else if (ReportEtlContext.getInstance()
              .getReportEtlServiceConfig()
              .getAgentDestination()
              .contains(this.amqDestination)
          || ReportEtlContext.getInstance()
              .getReportEtlServiceConfig()
              .getSessionDestination()
              .contains(this.amqDestination)) {
        objectMapper.configure(
            com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
        JsonNode jsonNode = objectMapper.readValue(this.message, JsonNode.class);
        messageType = jsonNode.findValues("type").get(0).asText();
        if (messageType.equalsIgnoreCase("agent-login-success")
            || messageType.equalsIgnoreCase("agent-login-failed")
            || messageType.equalsIgnoreCase("agent-logout")) {
          AgentLoginMessage agentMessage =
              genericJsonMessageParser(this.message, AgentLoginMessage.class);
          reportEtlAgentProcessor.processAgentLogin(agentMessage, message, session);
        } else if (messageType.equalsIgnoreCase("player-login-success")
            || messageType.equalsIgnoreCase("player-login-failed")
            || messageType.equalsIgnoreCase("player-logout")) {
          // Player session management
          generalMessageParser(this.message, session);
        } else {
          AgentMessage agentMessage = genericJsonMessageParser(this.message, AgentMessage.class);
          reportEtlAgentProcessor.processAgent(agentMessage, message, session);
        }

      } else if (ReportEtlContext.getInstance()
          .getReportEtlServiceConfig()
          .getPlayerDestination()
          .contains(this.amqDestination)) {
        objectMapper.configure(
            com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
        JsonNode jsonNode = objectMapper.readValue(this.message, JsonNode.class);
        messageType = jsonNode.findValues("type").get(0).asText();
        generalMessageParser(this.message, session);
      } else if (ReportEtlContext.getInstance()
          .getReportEtlServiceConfig()
          .getAccessLogDestination()
          .contains(this.amqDestination)) {
        objectMapper.configure(
            com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
        JsonNode jsonNode = objectMapper.readValue(this.message, JsonNode.class);
        messageType = jsonNode.findValues("type").get(0).asText();
        AgentAccessMessage agentAccessMessage =
            genericJsonMessageParser(this.message, AgentAccessMessage.class);
        reportEtlAgentProcessor.processAgentAccess(agentAccessMessage, this.message, session);
      } else if (ReportEtlContext.getInstance()
          .getReportEtlServiceConfig()
          .getLimitDestination()
          .contains(this.amqDestination)) {
        this.message = this.message.replace("\\", "");
        this.message = this.message.replace("}\"", "}");
        this.message = this.message.replace("\"{", "{");
        this.message = this.message.replace("}}\"", "}}");
        JsonNode node = objectMapper.readValue(this.message, JsonNode.class);
        messageType = node.findValue("data").findValues("type").get(0).asText();
        jsonMessageParser(this.message, session);
      } else if (ReportEtlContext.getInstance()
          .getReportEtlServiceConfig()
          .getTeamDestination()
          .contains(this.amqDestination)) {
        TeamsLeaguesMessage teamsLeaguesMessage =
            genericJsonMessageParser(this.message, TeamsLeaguesMessage.class);
        messageType = teamsLeaguesMessage.getData().getType();
        reportEtlTeamProcessor.processTeam(teamsLeaguesMessage, session);
      } else if (ReportEtlContext.getInstance()
          .getReportEtlServiceConfig()
          .getExpectedSpendingDestination()
          .contains(this.amqDestination)) {
        ExpectedSpendingMessage expectedSpendingMessage =
            genericJsonMessageParser(this.message, ExpectedSpendingMessage.class);
        messageType = "create";
        reportEtlProcessor.processExpectedSpending(expectedSpendingMessage, this.message, session);
      } else if (ReportEtlContext.getInstance()
          .getReportEtlServiceConfig()
          .getLeagueDestination()
          .contains(this.amqDestination)) {
        TeamsLeaguesMessage teamsLeaguesMessage =
            genericJsonMessageParser(this.message, TeamsLeaguesMessage.class);
        messageType = teamsLeaguesMessage.getData().getType();
        reportEtlLeagueProcessor.processLeague(teamsLeaguesMessage, session);
      } else if (ReportEtlContext.getInstance()
          .getReportEtlServiceConfig()
          .getPlayerCardDestination()
          .contains(this.amqDestination)) {
        objectMapper.configure(
            com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
        JsonNode jsonNode = objectMapper.readValue(this.message, JsonNode.class);
        messageType = jsonNode.findValues("type").get(0).asText();
        generalMessageParser(this.message, session);
      } else if (ReportEtlContext.getInstance()
          .getReportEtlServiceConfig()
          .getWalletTransactionDestination()
          .contains(this.amqDestination)) {
        reportEtlFundingProcessor = new ReportEtlFundingProcessor(this.isReprocess);
        objectMapper.configure(
            com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
        committedTran = objectMapper.readValue(this.message, CommittedTransactions.class).getData();
        messageType = committedTran.getType();
        ledger = committedTran.getLedger();
        JsonNode jsonNode = objectMapper.readValue(this.message, JsonNode.class);
        if (!jsonNode.findValues("captured").isEmpty()) {
          isCaptured = jsonNode.findValues("captured").get(0).asBoolean();
        }
        if (!jsonNode.findValues("approved").isEmpty()) {
          isApprovedSet = true;
        }
        avroMessageParser(committedTran, session, isCaptured, isApprovedSet);
      } else if (ReportEtlContext.getInstance()
          .getReportEtlServiceConfig()
          .getSubscriptionDestination()
          .contains(this.amqDestination)) {
        objectMapper.configure(
            com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
        messageType = this.amqDestination;
        subscriptionMessageParser(this.message, session);
      } else if (ReportEtlContext.getInstance()
          .getReportEtlServiceConfig()
          .getLedgerDestination()
          .contains(this.amqDestination)) {
        reportEtlProcessor = new ReportEtlProcessor(this.isReprocess);
        reportEtlFundingProcessor = new ReportEtlFundingProcessor(this.isReprocess);
        objectMapper.configure(
            com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
        CreatedLedgers createdLedgers = objectMapper.readValue(this.message, CreatedLedgers.class);
        createdLedger = createdLedgers.getData();
        createdLedger.setOperator(createdLedgers.getMeta().getOperatorId());
        messageType = createdLedger.getName();
        dynamicLedgerAvroMessageParser(createdLedger, session);
      } else if (ReportEtlContext.getInstance()
          .getReportEtlServiceConfig()
          .getSubsPurchaseDestination()
          .contains(this.amqDestination)) {
        objectMapper.configure(
            com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
        JsonNode jsonNode = objectMapper.readValue(this.message, JsonNode.class);
        messageType = jsonNode.findValues("type").get(0).asText();
        subscriptionTransactionMessageParser(this.message, this.amqDestination, session);

      } else if (ReportEtlContext.getInstance()
          .getReportEtlServiceConfig()
          .getThirdPartyErrorsDestination()
          .contains(this.amqDestination)) {
        ThirdPartyErrorMessage thirdPartyErrorMessage =
            genericJsonMessageParser(this.message, ThirdPartyErrorMessage.class);
        messageType = thirdPartyErrorMessage.getData().getType();
        reportEtlProcessor.processThridPartyErrors(thirdPartyErrorMessage, this.message, session);
      } else if (ReportEtlContext.getInstance()
          .getReportEtlServiceConfig()
          .getIhubAlertsDestination()
          .contains(this.amqDestination)) {
        IhubAlertsMessage ihubAlertsMessage =
            genericJsonMessageParser(this.message, IhubAlertsMessage.class);
        reportEtlProcessor.processIhubAlerts(ihubAlertsMessage, session);

      } else if (ReportEtlContext.getInstance()
          .getReportEtlServiceConfig()
          .getNotificationBrokerErrorDestination()
          .contains(this.amqDestination)) {
        reportEtlProcessor.storeNotificationBrokerErrors(this.message, session);
      } else if (ReportEtlContext.getInstance()
          .getReportEtlServiceConfig()
          .getBatchLogDestination()
          .contains(this.amqDestination)) {
        BatchLogExecution.INSTANCE.processBatchLog(this.message, session);
      } else {
        throw new CustomException("Topic (" + this.amqDestination + ") not found");
      }
    } catch (SuppressException ex) {
      session.clear();
      ErrorsLogEntity er =
          new ErrorsLogEntity(
              this.amqDestination,
              this.message,
              ex.getMessage(),
              Arrays.toString(ex.getStackTrace()),
              correlationId,
              messageType,
              ledger,
              false,
              "Success");
      if (!this.isReprocess) {
        if (ex.getSuppressOn() != null && ex.getSuppressOn() > 0) {
          er.setIsReprocessRequired(true);
          er.setProcessedStatus("Error");
        } else {
          isSuppressed = true;
        }
        // INFO use amq session if not reprocess, no rollback and all
        ErrorsLogDaoImpl.INSTANCE.saveErrorLog(er, jmsRedeliveryCount, false, session);
      } else {
        // INFO save the Suppress Exception here itself, don't throw for reprocess
        er.setId(this.errorId);
        if (ex.getSuppressOn() != null && ex.getSuppressOn() > 0) {
          if (errorRetryCount >= ex.getSuppressOn()) {
            isSuppressed = true;
          } else {
            er.setIsReprocessRequired(true);
            er.setProcessedStatus("Error");
            throw ex;
          }
        } else {
          isSuppressed = true;
        }
        ErrorsLogDaoImpl.INSTANCE.saveErrorLog(er, 0, true);
      }
    } catch (DelayException ex) {
      session.clear();
      if (!this.isReprocess) { // INFO use amq session if not reprocess, no rollback and all
        ErrorsLogEntity er =
            new ErrorsLogEntity(
                this.amqDestination,
                this.message,
                ex.getMessage(),
                Arrays.toString(ex.getStackTrace()),
                correlationId,
                messageType,
                ledger,
                true);
        ErrorsLogDaoImpl.INSTANCE.saveErrorLog(er, jmsRedeliveryCount, false, session);
      } else {
        LOG.info(
            "Delay Exception: "
                + ex.getMessage()
                + " StackTrace:"
                + Arrays.toString(ex.getStackTrace()));
        if (null != session && session.getTransaction() != null) {
          session.getTransaction().rollback();
        }
        throw ex;
      }
    } catch (Exception ex) {
      LOG.error("Stacktrace: " + Arrays.toString(ex.getStackTrace()));
      if (ex.getClass().getSimpleName().equalsIgnoreCase("JsonParseException")) {
        jmsRedeliveryCount =
            ReportEtlContext.getInstance().getReportEtlServiceConfig().getAllowedJMXDeliveryCount()
                + 1;
      } else if (ex.getClass().getSimpleName().equalsIgnoreCase("JsonMappingException")) {
        jmsRedeliveryCount =
            ReportEtlContext.getInstance().getReportEtlServiceConfig().getAllowedJMXDeliveryCount();
      }

      if (null != session && session.getTransaction() != null) {
        session.getTransaction().rollback();
      }
      if (this.isReprocess) {
        throw ex;
      } else {
        errorsLogEntity =
            new ErrorsLogEntity(
                this.amqDestination,
                this.message,
                ex.getMessage(),
                Arrays.toString(ex.getStackTrace()),
                correlationId,
                messageType,
                ledger,
                true);
      }
    } finally {
      if (!isSuppressed) { //  for SuppressException , we don't need to do these, error log has
        // already saved
        ErrorsLogEntity errorDetail = new ErrorsLogEntity();
        if (this.isReprocess && errorsLogEntity == null && this.errorId != null) {
          errorDetail.setId(this.errorId);
          errorDetail = ErrorsLogDaoImpl.INSTANCE.getErrorDetails(errorDetail, session);
        }
        if (null != session
            && session.getTransaction() != null
            && session.getTransaction().getStatus().equals(TransactionStatus.ACTIVE)) {
          try {
            session.flush();
          } catch (Exception ex) {
            if (this.isReprocess) {
              // TODO
              throw ex;
            } else {
              errorsLogEntity =
                  new ErrorsLogEntity(
                      this.amqDestination,
                      this.message,
                      ex.getMessage(),
                      Arrays.toString(ex.getStackTrace()),
                      correlationId,
                      messageType,
                      ledger,
                      true);
            }
          }
        }
        if (this.isReprocess
            && errorsLogEntity == null
            && this.errorId != null
            && committedTran != null) {
          errorDetail =
              reportEtlFundingProcessor.getTransactionDate(errorDetail, committedTran, session);
          if (isGviStatusUpdate) {
            errorDetail.setTranGviUpdatedDate(
                ReportEtlUtils.parseDate(gviStatusUpdate.getMeta().getCreatedAt()));
          }
          ErrorsLogDaoImpl.INSTANCE.saveErrorLog(errorDetail, jmsRedeliveryCount, true);
        }
        if (errorsLogEntity != null && !this.isReprocess) {
          ErrorsLogDaoImpl.INSTANCE.saveErrorLog(errorsLogEntity, jmsRedeliveryCount, false);
        }
      }
      if (session != null && isXaSession) {
        session.close();
      }
    }
  }

  /** Method to parse avro message. */
  private void avroMessageParser(
      CommittedTransactionsData committedTran,
      Session session,
      boolean isCaptured,
      boolean isApprovedSet)
      throws Exception {
    if (!isCaptured) {
      LOG.debug("Message with captured false");
      return;
    }
    String ledgerType = committedTran.getLedger();
    if (committedTran.getExternalId() != null) {
      String externalId = committedTran.getExternalId();
      externalId = externalId.replace("\"", "");
      committedTran.setExternalId(externalId);
    }
    // US6508
    if (committedTran.getGvPayload() != null) {
      if (committedTran.getGvPayload().getGame() != null) {
        committedTran.setGame(committedTran.getGvPayload().getGame());
      }
    }

    switch (committedTran.getType()) {
      case "adjustment":
      case "credit":
      case "deposit":
      case "withdrawal":
      case "debit":
        reportEtlFundingProcessor.processDeposit(committedTran, ledgerType, session, isApprovedSet);
        break;
      case "wager":
        reportEtlFundingProcessor.processWager(committedTran, ledgerType, session, isApprovedSet);
        break;
      case "win":
        reportEtlFundingProcessor.processWin(committedTran, ledgerType, session, isApprovedSet);
        break;
      default:
        LOG.warn("Unknown type in Json Message: {}", committedTran.getType());
        break;
    }
    WalletPayload gvPayload = committedTran.getGvPayload();
    if (committedTran.getType() != null && gvPayload != null && gvPayload.getSubtype() != null) {
      reportEtlFundingProcessor.updateTypeSubType(
          committedTran.getType(), gvPayload.getSubtype(), session);
    }
    LOG.debug("exited avro message processor for topic: {}", amqDestination);
  }

  private void updateGviStatus(GviStatusUpdate gviStatusUpdate, Session session, String topic)
      throws Exception {
    LOG.debug("entered message processor for topic: {}", this.amqDestination);
    String type = "";
    if (topic.equalsIgnoreCase(GviConst.WAGER_UPDATE_EVENT_TYPE)
        || topic.equalsIgnoreCase(GviConst.WAGER_UPDATE_EVENT_TYPE_NEW)) {
      type = WalletConst.TRAN_WAGER;
    } else if (topic.equalsIgnoreCase(GviConst.WINNING_UPDATE_EVENT_TYPE)
        || topic.equalsIgnoreCase(GviConst.WINNING_UPDATE_EVENT_TYPE_NEW)) {
      type = WalletConst.TRAN_WIN;
    } else if (topic.equalsIgnoreCase(GviConst.WAGER_SET_UPDATE_EVENT_TYPE)
        || topic.equalsIgnoreCase(GviConst.WAGER_SET_UPDATE_EVENT_TYPE_NEW)) {
      type = WalletConst.TRAN_WAGER_SET;
    }
    reportEtlFundingProcessor.updateGviStatus(gviStatusUpdate, type, session);
  }

  /**
   * Method to parse dynamic ledger avro message.
   *
   * @throws IOException
   */
  private void dynamicLedgerAvroMessageParser(CreatedLedgersData createdLedger, Session session) {
    LOG.debug("entered message processor for topic: {}", amqDestination);
    reportEtlFundingProcessor.processDynamicLedger(createdLedger, session);
    LOG.debug("exited avro message processor for topic: {}", amqDestination);
  }

  /**
   * Method to parse json string.
   *
   * @param msg The json string
   */
  private void generalMessageParser(String msg, Session session) throws Exception {
    LOG.debug("entered general message processor for topic: {}", amqDestination);
    String messageType = null;

    objectMapper.configure(
        com.fasterxml.jackson.core.JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
    JsonNode jsonNode = objectMapper.readValue(msg, JsonNode.class);
    messageType = jsonNode.findValues("type").get(0).asText();
    reportEtlProcessor = new ReportEtlProcessor(this.isReprocess);
    reportEtlFundingProcessor = new ReportEtlFundingProcessor(this.isReprocess);

    switch (messageType) {
      case "game-category-created":
      case "game-category-updated":
      case "game-category-deleted":
        /*
         * The message object.
         */
        Message msg1 = objectMapper.readValue(msg, Message.class);
        reportEtlGameProcessor.processGameCategory(msg1, msg, session);
        break;
      case "game-sub-category-created":
      case "game-sub-category-updated":
      case "game-sub-category-deleted":
        msg1 = objectMapper.readValue(msg, Message.class);
        reportEtlGameProcessor.processGameSubCategory(msg1, msg, session);
        break;
      case "game-type-created":
      case "game-type-updated":
      case "game-type-deleted":
        msg1 = objectMapper.readValue(msg, Message.class);
        reportEtlGameProcessor.processGameType(msg1, msg, session);
        break;
      case "game-partner-created":
      case "game-partner-updated":
      case "game-partner-deleted":
        msg1 = objectMapper.readValue(msg, Message.class);
        reportEtlGameProcessor.processGamePartner(msg1, msg, session);
        break;
      case "game-created":
      case "game-updated":
      case "game-deleted":
        msg1 = objectMapper.readValue(msg, Message.class);
        reportEtlGameProcessor.processGame(msg1, msg, session);
        break;
      case "affiliation-submitted":
      case "affiliation-updated":
      case "affiliation-refused":
      case "affiliation-removed":
        PlayerAffiliateMessage playerAffiliateMessage =
            objectMapper.readValue(msg, PlayerAffiliateMessage.class);
        reportEtlProcessor.processAffiliation(playerAffiliateMessage, msg, session);
        break;
      case "address-added":
      case "address-updated":
      case "address-deleted":
        PlayerAddressMessage playerAddressMessage =
            objectMapper.readValue(msg, PlayerAddressMessage.class);
        reportEtlProcessor.processAddress(playerAddressMessage, msg, session);
        break;
      case "phone-added":
      case "phone-updated":
      case "phone-deleted":
        PlayerPhoneMessage playerPhoneMessage =
            objectMapper.readValue(msg, PlayerPhoneMessage.class);
        reportEtlProcessor.processPhone(playerPhoneMessage, msg, session);
        break;
      case "tnc-acknowledged":
        TermsAndConditionsMessage termsAndConditionsMessage =
            objectMapper.readValue(msg, TermsAndConditionsMessage.class);
        reportEtlProcessor.processTermsAndConditions(termsAndConditionsMessage, msg, session);
        break;
      case "social-network-added":
      case "social-network-updated":
      case "social-network-deleted":
        SocialNetworkMessage socialNetworkMessage =
            objectMapper.readValue(msg, SocialNetworkMessage.class);
        reportEtlProcessor.processSocialNetwork(socialNetworkMessage, msg, session);
        break;
      case "payment-method-added":
      case "payment-method-updated":
      case "payment-method-deleted":
        PaymentMethodMessage paymentMethodMessage =
            objectMapper.readValue(msg, PaymentMethodMessage.class);
        reportEtlProcessor.processPaymentMethod(paymentMethodMessage, msg, session);
        break;
      case "identification-added":
      case "identification-updated":
      case "identification-deleted":
        IdentificationMessage identificationMessage =
            objectMapper.readValue(msg, IdentificationMessage.class);
        reportEtlProcessor.processIdentificationDocument(identificationMessage, msg, session);
        break;
      case "player-card-created":
      case "player-card-requested":
      case "player-card-cancelled":
        PlayerCardMessage playerCardMessage = objectMapper.readValue(msg, PlayerCardMessage.class);
        reportEtlProcessor.processPlayerCard(playerCardMessage, msg, session);
        break;
      case "player-login-success":
      case "player-login-failed":
      case "player-logout":
        PlayerSessionMessage playerSessionMessage =
            objectMapper.readValue(msg, PlayerSessionMessage.class);
        reportEtlProcessor.processPlayerSession(playerSessionMessage, msg, session);
        break;
      case "registration":
        PlayerProfileMessage playerProfileMessage =
            objectMapper.readValue(msg, PlayerProfileMessage.class);
        reportEtlProcessor.processPlayerProfile(playerProfileMessage, msg, session);
        break;
      case "update-profile":
      case "player-preferred-game-updated":
      case "player-preferences-winnings-updated":
        PlayerProfileMessage playerProfileUpdateMessage =
            objectMapper.readValue(msg, PlayerProfileMessage.class);
        reportEtlProcessor.processPlayerProfileUpdate(playerProfileUpdateMessage, msg, session);
        break;
      case "player-reactivated":
        PlayerActivationMessage playerActivationMessage =
            objectMapper.readValue(msg, PlayerActivationMessage.class);
        reportEtlProcessor.processPlayerActivation(playerActivationMessage, msg, session);
        break;
      case "excluded-player-registration-attempt":
        ExcludedPlayerRegistrationAttemptMessage excludedPlayerRegistrationAttemptMessage =
            objectMapper.readValue(msg, ExcludedPlayerRegistrationAttemptMessage.class);
        reportEtlProcessor.processExcludedPlayerRegistrationAttempt(
            excludedPlayerRegistrationAttemptMessage, msg, session);
        break;
      case "comment-added":
        PlayerCommentMessage playerCommentMessage =
            objectMapper.readValue(msg, PlayerCommentMessage.class);
        reportEtlProcessor.processPlayerComment(playerCommentMessage, msg, session);
        break;

      case "delete-profile":
        DeleteProfileEvent deleteProfileEvent =
            genericJsonMessageParser(this.message, DeleteProfileEvent.class);
        reportEtlDeleteProfile.deleteProfile(deleteProfileEvent, session);
        break;
      default:
        LOG.warn("Unknown type in Json Message: {}", messageType);
        break;
    }
  }

  /**
   * Method to parse json message.
   *
   * @param msg The json string
   * @throws Exception
   */
  private void jsonMessageParser(String msg, Session session) throws Exception {
    LOG.debug("entered general message processor for topic: {}", amqDestination);
    String messageType = null;
    msg = msg.replace("\\", "");
    msg = msg.replace("}\"", "}");
    msg = msg.replace("\"{", "{");
    msg = msg.replace("}}\"", "}}");
    JsonNode node = objectMapper.readValue(msg, JsonNode.class);
    messageType = node.findValue("data").findValues("type").get(0).asText();
    reportEtlLimitProcessor = new ReportEtlLimitProcessor(this.isReprocess);
    switch (messageType) {
      case "limit-created":
      case "limit-updated":
        reportEtlLimitProcessor.processLimit(node, session);
        break;
      case "category-defined":
        reportEtlLimitProcessor.processLimitCategory(node, session);
        break;
      default:
        LOG.warn("Unknown type in Json Message: {}", messageType);
        break;
    }
    LOG.debug("exited general message processor for topic: {}", amqDestination);
  }

  /**
   * Exclusion parser.
   *
   * @param msg the msg
   * @throws CustomException
   * @throws Exception
   */
  private void exclusionParser(
      String msg, Session session, ExclusionEvent exclusionEvent, String messageType)
      throws CustomException, SuppressException {
    LOG.debug("entered message processor for topic: {}", amqDestination);
    ReportEtlExclusionProcessor exclusionProcessor =
        new ReportEtlExclusionProcessor(this.isReprocess);
    switch (messageType) {
      case "restriction":
        exclusionProcessor.processRestriction(exclusionEvent, msg, session);
        break;
      case "selfExclusion":
        exclusionProcessor.processSelfExclusion(exclusionEvent, msg, session);
        break;
      default:
        LOG.warn("Unknown type in Json Message: {}", messageType);
        break;
    }
    LOG.debug("exited avro message processor for topic: {}", amqDestination);
  }

  /**
   * Generic json message parser.
   *
   * @param <T> the generic type
   * @param message the message
   * @param clazz the clazz
   * @return the t
   * @throws IOException Signals that an I/O exception has occurred.
   */
  private <T> T genericJsonMessageParser(String message, Class<T> clazz) throws IOException {
    T clazzObject = null;
    clazzObject = objectMapper.readValue(message, clazz);

    return clazzObject;
  }

  private void subscriptionMessageParser(String msg, Session session) throws Exception {
    /*
     * ReportEtlSubscriptionProcessor object instance.
     */
    SubscriptionMessage subscriptionMessage =
        objectMapper.readValue(msg, SubscriptionMessage.class);
    ReportEtlSubscriptionProcessor reportEtlSubscriptionProcessor =
        new ReportEtlSubscriptionProcessor(this.isReprocess);
    String status;
    if (subscriptionMessage.getMeta().getType() == null) {
      throw new CustomException("The required field data.type should not be empty");
    }
    switch (subscriptionMessage.getMeta().getType()) {
      case "NewSubscriptionCreated":
      case "SubscriptionCancelled":
      case "SubscriptionUpdated":
        subscriptionMessage = objectMapper.readValue(msg, SubscriptionMessage.class);
        SubscriptionDaoImpl subscriptionDaoImpl = new SubscriptionDaoImpl();
        SubscriptionsEntity subscriptionsEntity = null;
        if (subscriptionMessage.getMeta().getType().equalsIgnoreCase("NewSubscriptionCreated")
            && !subscriptionMessage.getData().getType().equalsIgnoreCase("subscription_failure")) {
          subscriptionsEntity =
              subscriptionDaoImpl.getSubscriptionById(
                  subscriptionMessage.getData().getId(), session);
          if (subscriptionsEntity != null) {
            Date dateToCompare;
            if (subscriptionsEntity.getModifiedAt() != null) {
              dateToCompare = subscriptionsEntity.getModifiedAt();
            } else {
              dateToCompare = subscriptionsEntity.getCreatedDate();
            }
            session.detach(subscriptionsEntity);
            status =
                ReportEtlUtils.isDateGreaterThanOrEqual(
                    ReportEtlUtils.parseDate(subscriptionMessage.getMeta().getCreatedAt()),
                    dateToCompare);
            if (status.equalsIgnoreCase("Before")) {
              throw new SuppressException(ReportEtlConsts.MESSAGE_OLD_ERROR_MSG);
            }
          }
        } else {
          subscriptionsEntity =
              subscriptionDaoImpl.getSubscriptionById(
                  subscriptionMessage.getData().getId(), session);
          if (subscriptionsEntity != null) {
            Date dateToCompare;
            if (subscriptionsEntity.getModifiedAt() != null) {
              dateToCompare = subscriptionsEntity.getModifiedAt();
            } else {
              dateToCompare = subscriptionsEntity.getCreatedDate();
            }
            session.detach(subscriptionsEntity);
            status =
                ReportEtlUtils.isDateGreaterThanOrEqual(
                    ReportEtlUtils.parseDate(subscriptionMessage.getMeta().getCreatedAt()),
                    dateToCompare);
            if (status.equalsIgnoreCase("Before")) {
              throw new SuppressException(ReportEtlConsts.MESSAGE_OLD_ERROR_MSG);
            }
          }
        }
        break;
      case "YearlyScheduleUpdated":
      case "YearlyScheduleDeleted":
        subscriptionMessage = objectMapper.readValue(msg, SubscriptionMessage.class);
        SubscriptionScheduleEntity subscriptionScheduleEntity = new SubscriptionScheduleEntity();
        subscriptionScheduleEntity.setYear(subscriptionMessage.getData().getYear());
        subscriptionScheduleEntity.setOperatorId(subscriptionMessage.getMeta().getOperatorId());
        subscriptionScheduleEntity =
            session.get(SubscriptionScheduleEntity.class, subscriptionScheduleEntity);
        if (subscriptionScheduleEntity != null) {
          status =
              ReportEtlUtils.isDateGreaterThanOrEqual(
                  ReportEtlUtils.parseDate(subscriptionMessage.getMeta().getCreatedAt()),
                  subscriptionScheduleEntity.getModifiedAt());
          session.detach(subscriptionScheduleEntity);
          if (status.equalsIgnoreCase("Before")) {
            throw new SuppressException(ReportEtlConsts.MESSAGE_OLD_ERROR_MSG);
          }
        }
        break;
      default:
        LOG.warn("Unknown type in Json Message: {}", subscriptionMessage.getMeta().getType());
        break;
    }
    switch (subscriptionMessage.getMeta().getType()) {
      case "NewSubscriptionCreated":
        if (subscriptionMessage.getData().getType().equalsIgnoreCase("template")) {
          reportEtlSubscriptionProcessor.processNewSubscriptionCreated(
              subscriptionMessage, msg, session);
        } else if (subscriptionMessage
            .getData()
            .getType()
            .equalsIgnoreCase("subscription_failure")) {
          FundingFailedMessage fundingFailedMessage =
              objectMapper.readValue(msg, FundingFailedMessage.class);
          reportEtlSubscriptionProcessor.processFundingFailure(fundingFailedMessage, msg, session);
        } else {
          reportEtlSubscriptionProcessor.processUpdateSubscription(
              subscriptionMessage, msg, session);
        }
        break;
      case "SubscriptionCancelled":
        SubscriptionMessage cancelSubscriptionMessage =
            objectMapper.readValue(msg, SubscriptionMessage.class);
        reportEtlSubscriptionProcessor.processCancelSubscription(
            cancelSubscriptionMessage, msg, session);
        break;
      case "SubscriptionUpdated":
        SubscriptionMessage updateSubscriptionMessage =
            objectMapper.readValue(msg, SubscriptionMessage.class);
        reportEtlSubscriptionProcessor.processUpdateSubscription(
            updateSubscriptionMessage, msg, session);
        break;
      case "YearlyScheduleUpdated":
        SubscriptionScheduleMessage subscriptionScheduleMessage =
            objectMapper.readValue(msg, SubscriptionScheduleMessage.class);
        reportEtlSubscriptionProcessor.processYearlyScheduleUpdated(
            subscriptionScheduleMessage, msg, session);
        break;
      case "YearlyScheduleDeleted":
        SubscriptionScheduleMessage deleteSubscriptionScheduleMessage =
            objectMapper.readValue(msg, SubscriptionScheduleMessage.class);
        reportEtlSubscriptionProcessor.processYearlyScheduleDeleted(
            deleteSubscriptionScheduleMessage, msg, session);
        break;
      default:
        LOG.warn("Unknown type in Json Message: {}", subscriptionMessage.getMeta().getType());
        break;
    }
  }

  /**
   * Subscription Transaction Message Parser.
   *
   * @param msg the msg
   * @param topicName the message type
   * @throws Exception
   */
  private void subscriptionTransactionMessageParser(String msg, String topicName, Session session)
      throws Exception {
    LOG.debug("Entered subscriptionTransactionMessageParser for topic: {}", topicName);
    ReportEtlSubscriptionProcessor reportEtlSubscriptionProcessor =
        new ReportEtlSubscriptionProcessor(this.isReprocess);

    SubscriptionTransactionMessage subscriptionPurchaseMessage =
        objectMapper.readValue(msg, SubscriptionTransactionMessage.class);
    reportEtlSubscriptionProcessor.processPurchaseSubscription(
        subscriptionPurchaseMessage, msg, session);
  }
}
