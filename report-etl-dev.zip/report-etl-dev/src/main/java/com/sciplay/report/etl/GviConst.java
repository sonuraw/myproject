package com.sciplay.report.etl;

public final class GviConst {

  public static final String WAGER_UPDATE_EVENT_TYPE = "upam_gvi_wager_update_status";
  public static final String WINNING_UPDATE_EVENT_TYPE = "upam_gvi_winning_update_status";
  public static final String WAGER_SET_UPDATE_EVENT_TYPE = "upam_gvi_wagerset_update_status";

  public static final String WAGER_UPDATE_EVENT_TYPE_NEW = "wager-updates";
  public static final String WINNING_UPDATE_EVENT_TYPE_NEW = "winning-updates";
  public static final String WAGER_SET_UPDATE_EVENT_TYPE_NEW = "wagerset-updates";
}
