package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** @author Sundar */
@JsonIgnoreProperties(ignoreUnknown = true)
public class IhubAlertsMessage {

  private IhubAlertMeta meta;

  private IhubAlertData data;

  public IhubAlertMeta getMeta() {
    return meta;
  }

  public void setMeta(IhubAlertMeta meta) {
    this.meta = meta;
  }

  public IhubAlertData getData() {
    return data;
  }

  public void setData(IhubAlertData data) {
    this.data = data;
  }
}
