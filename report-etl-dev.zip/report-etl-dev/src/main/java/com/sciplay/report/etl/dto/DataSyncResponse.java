package com.sciplay.report.etl.dto;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

@Produces("application/json")
@Consumes("application/json")
public final class DataSyncResponse {

  /** The meta. */
  private Meta meta;

  private List<DataSyncResponseData> data;

  public Meta getMeta() {
    return meta;
  }

  public void setMeta(Meta meta) {
    this.meta = meta;
  }

  public List<DataSyncResponseData> getData() {
    return data;
  }

  public void setData(List<DataSyncResponseData> data) {
    this.data = data;
  }
}
