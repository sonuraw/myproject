package com.sciplay.report.etl.dto;

/** The Class Author. */
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CreatedLedgersData {
  private Integer walletId;

  private String operator;

  private boolean subscription;

  private String name;

  public Integer getWalletID() {
    return this.walletId;
  }

  public void setWalletID(Integer value) {
    this.walletId = value;
  }

  public String getOperator() {
    return this.operator;
  }

  public void setOperator(String value) {
    this.operator = value;
  }

  /** @return the subscription */
  public boolean isSubscription() {
    return subscription;
  }

  /** @param subscription the subscription to set */
  public void setSubscription(boolean subscription) {
    this.subscription = subscription;
  }

  /** @return the name */
  public String getName() {
    return name;
  }

  /** @param name the name to set */
  public void setName(String name) {
    this.name = name;
  }
}
