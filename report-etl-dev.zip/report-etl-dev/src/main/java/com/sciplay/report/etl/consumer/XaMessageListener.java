package com.sciplay.report.etl.consumer;

import com.sciplay.report.etl.ActiveMqMsgDispatcher;
import com.sciplay.report.etl.Entities.ErrorsLogEntity;
import com.sciplay.report.etl.Entities.JmsMessageDetailsEntity;
import com.sciplay.report.etl.ReportEtlContext;
import com.sciplay.report.etl.persistence.mysql.ErrorsLogDaoImpl;
import com.sciplay.report.etl.persistence.mysql.JmsMessageDetailsDaoImpl;
import com.sciplay.report.etl.utils.ReportEtlUtils;
import java.util.Arrays;
import java.util.Map;
import java.util.UUID;
import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import org.apache.activemq.command.ActiveMQBytesMessage;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

public class XaMessageListener implements com.atomikos.jms.extra.MessageListener {

  private static final Logger LOG = LoggerFactory.getLogger(XaMessageListener.class);
  private static final int ALLOWED_JMS_DELIVERY_COUNT =
      ReportEtlContext.getInstance().getReportEtlServiceConfig().getAllowedJMXDeliveryCount();
  private final String topicName;
  private final String threadId;
  private final ThreadLocal<Boolean> myThreadLocal = new ThreadLocal<>();
  private long previousEndTime = System.currentTimeMillis();

  public XaMessageListener(String topicName) {
    this.topicName = topicName;
    this.threadId = UUID.randomUUID().toString();
    LOG.info(
        "New Thread Created for topicName / QueueName {}, with the threadId {}",
        topicName,
        this.threadId);
  }

  @Override
  public void onMessage(Message message, String mySQLXATranId) {
    long startTime = System.currentTimeMillis();
    long gapTime = System.currentTimeMillis() - previousEndTime;
    String jmsMessageId = "";
    int messageDeliveryCount = -1;
    long eventId = 0L;

    try {
      messageDeliveryCount = message.getIntProperty("JMSXDeliveryCount");
      jmsMessageId = message.getJMSMessageID();
      MDC.put("correlationId", jmsMessageId);
      if (message.getStringProperty("eventId") != null
          && !message.getStringProperty("eventId").equalsIgnoreCase("")) {
        eventId = Long.parseLong(message.getStringProperty("eventId"));
      }
    } catch (JMSException e) {
      MDC.put("correlationId", UUID.randomUUID().toString());
      LOG.error("getJMSMessageID error " + e.getMessage());
    }
    LOG.debug(
        "MYSQL XA Transaction started with " + mySQLXATranId + " for JMSMessageId " + jmsMessageId);
    String messageText = null;
    String eventType = "";
    try {
      byte[] messageBytes;
      if (message instanceof TextMessage) {
        ActiveMQTextMessage textMessage = (ActiveMQTextMessage) message;
        messageText = textMessage.getText();
        messageBytes = messageText.getBytes();
      } else if (message instanceof BytesMessage) {
        ActiveMQBytesMessage bytesMessage = (ActiveMQBytesMessage) message;
        messageText = new String(bytesMessage.getContent().data);

        BytesMessage bm = (BytesMessage) message;
        byte[] data;
        data = new byte[(int) bm.getBodyLength()];
        bm.readBytes(data);

        messageBytes = data;
      } else {
        // TODO INSERT INTO Error as well - but this case will not happen
        try {
          JmsMessageDetailsEntity jmsMessageDetailsEntity =
              new JmsMessageDetailsEntity(
                  jmsMessageId,
                  this.topicName,
                  eventType,
                  messageDeliveryCount,
                  ReportEtlUtils.getCurrentDateWithMs(),
                  ReportEtlUtils.getCurrentDateWithMs(),
                  gapTime,
                  (System.currentTimeMillis() - startTime),
                  0L,
                  this.threadId,
                  mySQLXATranId,
                  eventId);
          JmsMessageDetailsDaoImpl.INSTANCE.insertJmsMessageDetailsEntity(jmsMessageDetailsEntity);
        } catch (Exception e) {
          LOG.error(
              "Error in JmsMessageDetails insert"
                  + e.getMessage()
                  + "Stack: "
                  + Arrays.toString(e.getStackTrace()));
          throw new RuntimeException(e);
        }
        LOG.error("ActiveMq message instance not matched as BytesMessage");
        return;
      }

      if (messageDeliveryCount > ALLOWED_JMS_DELIVERY_COUNT) {
        Session sessionJms = null;
        try {
          sessionJms = ReportEtlContext.getInstance().getSessionFactory().openSession();
          sessionJms.beginTransaction();
          try {
            JmsMessageDetailsEntity jmsMessageDetailsEntity =
                new JmsMessageDetailsEntity(
                    jmsMessageId,
                    this.topicName,
                    eventType,
                    messageDeliveryCount,
                    ReportEtlUtils.getCurrentDateWithMs(),
                    null,
                    gapTime,
                    (System.currentTimeMillis() - startTime),
                    0L,
                    this.threadId,
                    mySQLXATranId,
                    eventId);

            JmsMessageDetailsDaoImpl.INSTANCE.insertJmsMessageDetailsEntity(
                jmsMessageDetailsEntity, sessionJms);
          } catch (Exception insertEr) {
            LOG.error(
                "JMS msg insert err: "
                    + insertEr.getMessage()
                    + " Stack: "
                    + Arrays.toString(insertEr.getStackTrace()));
          }

          ErrorsLogEntity errorsLogEntity;
          errorsLogEntity =
              new ErrorsLogEntity(
                  this.topicName,
                  messageText,
                  "redelivery-threshold-crossed-message",
                  "JMSXDeliveryCount: " + messageDeliveryCount,
                  jmsMessageId,
                  eventType,
                  "",
                  true);
          LOG.info(
              "redelivery-threshold-crossed-message, topic: "
                  + this.topicName
                  + " messageText: "
                  + messageText
                  + " correlationId: "
                  + jmsMessageId
                  + " JMSXDeliveryCount: "
                  + messageDeliveryCount);
          ErrorsLogDaoImpl.INSTANCE.saveErrorLog(
              errorsLogEntity, messageDeliveryCount, false, sessionJms);
          sessionJms.getTransaction().commit();

        } catch (Exception e) {
          LOG.error(
              "Error in saving threshold crossed msg: "
                  + e.getMessage()
                  + "Stack: "
                  + Arrays.toString(e.getStackTrace()));
          throw new RuntimeException(e);
        } finally {
          if (sessionJms != null) {
            sessionJms.close();
          }
        }
        previousEndTime = System.currentTimeMillis();
        return;
      }

      LOG.info(
          "CorrelationId: "
              + jmsMessageId
              + ", Topic: "
              + this.topicName
              + " Message received from ActiveMq: "
              + messageText
              + ", messageDeliveryCount: "
              + messageDeliveryCount);

      Long createdTime = 0L;
      myThreadLocal.set(false);
      ActiveMqMsgDispatcher msgDispatcher =
          new ActiveMqMsgDispatcher(this.topicName, messageText, messageBytes, myThreadLocal, null);

      Map logResult =
          msgDispatcher.getCreatedDateAndEventType(this.topicName, messageText, messageBytes);

      eventType = logResult.get("eventType").toString();
      createdTime = (Long) logResult.get("timeInMillis");

      msgDispatcher.processMessage(myThreadLocal, null, jmsMessageId, messageDeliveryCount, null);
      long delayTime = 0;
      long processTime = 0;
      if (createdTime != 0) {
        delayTime = (startTime - createdTime);
      }
      processTime = (System.currentTimeMillis() - startTime);
      LOG.info(
          "ETL Metrics : Report-ETL-processing-delay: "
              + delayTime
              + ", Report-ETL-processTime:"
              + processTime
              + ", EventType: "
              + eventType
              + ", Topic: "
              + this.topicName
              + ", Message: "
              + messageText
              + ", CorrelationId: "
              + jmsMessageId
              + ", messageDeliveryCount: "
              + messageDeliveryCount);

      try {
        JmsMessageDetailsEntity jmsMessageDetailsEntity =
            new JmsMessageDetailsEntity(
                jmsMessageId,
                this.topicName,
                eventType,
                messageDeliveryCount,
                ReportEtlUtils.getCurrentDateWithMs(),
                null,
                gapTime,
                processTime,
                delayTime,
                this.threadId,
                mySQLXATranId,
                eventId);

        JmsMessageDetailsDaoImpl.INSTANCE.insertJmsMessageDetailsEntity(jmsMessageDetailsEntity);
      } catch (Exception e) {
        LOG.error(
            "Error in saving JmsMessageDetails: "
                + e.getMessage()
                + "StackTrace: "
                + Arrays.toString(e.getStackTrace()));
        throw new RuntimeException(e);
      }
      previousEndTime = System.currentTimeMillis();
      LOG.debug(
          "MYSQL XA Transaction gonna end with "
              + mySQLXATranId
              + " for JMSMessageId "
              + jmsMessageId);
    } catch (Exception e) {
      // TODO check if the error is related to any mYsql connection , shut down the consumers or go
      // for retry
      LOG.error(e.getMessage());
      String stackTrace = ReportEtlUtils.stackTraceToString(e);
      ErrorsLogEntity errorsLogEntity =
          new ErrorsLogEntity(
              this.topicName,
              messageText,
              e.getMessage(),
              stackTrace,
              jmsMessageId,
              eventType,
              "",
              true);
      try {
        ErrorsLogDaoImpl.INSTANCE.saveErrorLog(errorsLogEntity, messageDeliveryCount, false);
      } catch (Exception ex) {
        // TODO inform to ETO for zenoss alert
        LOG.error(
            "FATAL CRITICAL Error on saving to ErrorsLogTable , exception : "
                + ex.getMessage()
                + " "
                + "stackTrace: "
                + Arrays.toString(ex.getStackTrace()));
      }
      previousEndTime = System.currentTimeMillis();
      throw new RuntimeException("Rollback due to error");
    }
  }
}
