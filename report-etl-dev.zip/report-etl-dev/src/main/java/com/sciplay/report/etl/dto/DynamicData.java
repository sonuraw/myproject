package com.sciplay.report.etl.dto;

import java.util.ArrayList;
import java.util.List;

/** The Class Data. */
public class DynamicData<T> {

  /** The transactions. */
  private List<Transactions> transactions = new ArrayList<>();
  /** The type. */
  private String type;
  /** The id. */
  private String id;
  /** The attributes. */
  private T attributes;

  /** @return the transactions */
  public List<Transactions> getTransactions() {
    return transactions;
  }

  /** @param transactions the transactions to set */
  public void setTransactions(ArrayList<Transactions> transactions) {
    this.transactions = transactions;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Sets the type.
   *
   * @param type the new type
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(String id) {
    this.id = id;
  }

  public T getAttributes() {
    return attributes;
  }

  public void setAttributes(T attributes) {
    this.attributes = attributes;
  }
}
