package com.sciplay.report.etl.Entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class TermsAndConditionsAcknowledgementId. */
@Entity
@Table(name = "PlayerTermsAndConditionsAcknowledgement")
@JsonIgnoreProperties(ignoreUnknown = true)
public class TermsAndCondAckEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The player id. */
  @Id private Integer playerId;

  /** The operator id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  @Id
  private String operatorId;

  /** The acknoledgement type. */
  @Id private String acknowledgementType;

  /** The revision. */
  @Id private String revision;

  /** The author player id. */
  private Integer authorPlayerId;

  /** The author agent id. */
  private Integer authorAgentId;

  /** The author ip. */
  private String authorIp;

  /** The author session id. */
  private String authorSessionId;

  /** The created at. */
  private Date createdAt;

  /** The link. */
  private String link;

  /** Instantiates a new terms and conditions acknowledgement id. */
  public TermsAndCondAckEntity() {}

  /**
   * Instantiates a new terms and conditions acknowledgement id.
   *
   * @param playerId the player id
   * @param createdAt the created at
   */
  public TermsAndCondAckEntity(Integer playerId, Date createdAt) {
    this.playerId = playerId;
    this.createdAt = createdAt;
  }

  /**
   * Instantiates a new terms and conditions acknowledgement id.
   *
   * @param acknoledgementType the acknoledgement type
   * @param playerId the player id
   * @param operatorId the operator id
   * @param revision the revision
   * @param authorPlayerId the author player id
   * @param authorAgentId the author agent id
   * @param authorIp the author ip
   * @param authorSessionId the author session id
   * @param createdAt the created at
   */
  public TermsAndCondAckEntity(
      String acknoledgementType,
      Integer playerId,
      String operatorId,
      String revision,
      Integer authorPlayerId,
      Integer authorAgentId,
      String authorIp,
      String authorSessionId,
      Date createdAt) {
    this.acknowledgementType = acknoledgementType;
    this.playerId = playerId;
    this.operatorId = operatorId;
    this.revision = revision;
    this.authorPlayerId = authorPlayerId;
    this.authorAgentId = authorAgentId;
    this.authorIp = authorIp;
    this.authorSessionId = authorSessionId;
    this.createdAt = createdAt;
  }

  /**
   * Gets the acknowledgement type.
   *
   * @return the acknowledgement type
   */
  public String getAcknowledgementType() {
    return acknowledgementType;
  }

  /**
   * Sets the acknowledgement type.
   *
   * @param acknowledgementType the new acknowledgement type
   */
  public void setAcknowledgementType(String acknowledgementType) {
    this.acknowledgementType = acknowledgementType;
  }

  /**
   * Gets the link.
   *
   * @return the link
   */
  public String getLink() {
    return link;
  }

  /**
   * Sets the link.
   *
   * @param link the new link
   */
  public void setLink(String link) {
    this.link = link;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return this.playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return this.operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the revision.
   *
   * @return the revision
   */
  public String getRevision() {
    return this.revision;
  }

  /**
   * Sets the revision.
   *
   * @param revision the new revision
   */
  public void setRevision(String revision) {
    this.revision = revision;
  }

  /**
   * Gets the author player id.
   *
   * @return the author player id
   */
  public Integer getAuthorPlayerId() {
    return this.authorPlayerId;
  }

  /**
   * Sets the author player id.
   *
   * @param authorPlayerId the new author player id
   */
  public void setAuthorPlayerId(Integer authorPlayerId) {
    this.authorPlayerId = (Objects.isNull(authorPlayerId)) ? 0 : authorPlayerId;
  }

  /**
   * Gets the author agent id.
   *
   * @return the author agent id
   */
  public Integer getAuthorAgentId() {
    return this.authorAgentId;
  }

  /**
   * Sets the author agent id.
   *
   * @param authorAgentId the new author agent id
   */
  public void setAuthorAgentId(Integer authorAgentId) {
    this.authorAgentId = (Objects.isNull(authorAgentId)) ? 0 : authorAgentId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return this.authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return this.authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return this.createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }
}
