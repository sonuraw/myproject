package com.sciplay.report.etl.dto;

public class SocialNetworkMessage extends DynamicMessage<SocialNetwork> {}
