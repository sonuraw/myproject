package com.sciplay.report.etl.Entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.DynamicUpdate;

/** The Class WinningArchiveEntity. */
@Entity
@Table(name = "WinningArchive")
@DynamicUpdate
public class WinningArchiveEntity {

  /** The revision number. */
  @Column(name = "RevisionNumber")
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long revisionNumber;

  /** The revision date. */
  private Date revisionDate;

  /** The revision state. */
  private String revisionState;

  /** The Id. */
  @Column(name = "Id")
  private long id;

  /** The Event type. */
  private String eventType;

  /** The Player id. */
  private Integer playerId;

  /** The OperatorId id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The Wager id. */
  private long wagerId;

  /** The Type. */
  private String type;

  /** The External URL. */
  private String externalURL;

  /** The State. */
  @Column(
      name = "State",
      columnDefinition = "enum('PENDING', 'PAID', 'CHECKED', 'ADJUSTED', 'CLAIMED')")
  private String state;

  /** The Value. */
  private long value;

  /** The Updated date. */
  @Column(name = "UpdatedDate")
  private Date updatedDate;

  /** The Creation date. */
  private Date creationDate;

  /** The player card prize. */
  private Boolean playerCardPrize;

  /** The rollback prizes. */
  private Boolean rollbackPrizes;

  /** The external creation date. */
  private Date externalCreationDate;

  /** The previousStatus. */
  @Column(
      name = "PreviousStatus",
      columnDefinition = "enum('PENDING', 'PAID', 'CHECKED', 'ADJUSTED', 'CLAIMED')")
  private String previousStatus;

  /** The is reprocessed. */
  private Boolean isReprocessed;

  /** The Reprocessed date. */
  private Date reprocessedDate;

  /** The is reConciled. */
  private Boolean isReConciled;

  /** Instantiates a new winning archive entity. */
  public WinningArchiveEntity() {}

  /**
   * Instantiates a new winning archive entity.
   *
   * @param id the id
   * @param eventType the event type
   * @param playerId the player id
   * @param wagerId the wager id
   * @param state the state
   * @param value the value
   * @param updatedDate the updated date
   * @param creationDate the creation date
   * @param playerCardPrize the player card prize
   * @param rollbackPrizes the rollback prizes
   */
  public WinningArchiveEntity(
      long id,
      String eventType,
      Integer playerId,
      long wagerId,
      String state,
      long value,
      Date updatedDate,
      Date creationDate,
      Boolean playerCardPrize,
      Boolean rollbackPrizes,
      Date externalCreationDate) {
    this.id = id;
    this.eventType = eventType;
    this.playerId = playerId;
    this.wagerId = wagerId;
    this.state = state;
    this.value = value;
    this.updatedDate = updatedDate;
    this.creationDate = creationDate;
    this.playerCardPrize = playerCardPrize;
    this.rollbackPrizes = rollbackPrizes;
    this.externalCreationDate = externalCreationDate;
  }

  /**
   * Instantiates a new winning archive entity.
   *
   * @param id the id
   * @param eventType the event type
   * @param playerId the player id
   * @param wagerId the wager id
   * @param type the type
   * @param externalURL the external URL
   * @param state the state
   * @param value the value
   * @param updatedDate the updated date
   * @param creationDate the creation date
   * @param playerCardPrize the player card prize
   * @param rollbackPrizes the rollback prizes
   */
  public WinningArchiveEntity(
      long id,
      String eventType,
      Integer playerId,
      long wagerId,
      String type,
      String externalURL,
      String state,
      long value,
      Date updatedDate,
      Date creationDate,
      Boolean playerCardPrize,
      Boolean rollbackPrizes,
      Date externalCreationDate) {
    this.id = id;
    this.eventType = eventType;
    this.playerId = playerId;
    this.wagerId = wagerId;
    this.type = type;
    this.externalURL = externalURL;
    this.state = state;
    this.value = value;
    this.updatedDate = updatedDate;
    this.creationDate = creationDate;
    this.playerCardPrize = playerCardPrize;
    this.rollbackPrizes = rollbackPrizes;
    this.externalCreationDate = externalCreationDate;
  }

  /**
   * Gets the checks if is reprocessed.
   *
   * @return the checks if is reprocessed
   */
  public Boolean getIsReprocessed() {
    return isReprocessed;
  }

  /**
   * Sets the checks if is reprocessed.
   *
   * @param isReprocessed the new checks if is reprocessed
   */
  public void setIsReprocessed(Boolean isReprocessed) {
    if (isReprocessed == null) {
      isReprocessed = false;
    }
    this.isReprocessed = isReprocessed;
  }

  /**
   * Gets the reprocessed date.
   *
   * @return the reprocessed date
   */
  public Date getReprocessedDate() {
    return reprocessedDate;
  }

  /**
   * Sets the reprocessed date.
   *
   * @param reprocessedDate the new reprocessed date
   */
  public void setReprocessedDate(Date reprocessedDate) {
    this.reprocessedDate = reprocessedDate;
  }

  /**
   * Gets the revision number.
   *
   * @return the revision number
   */
  public long getRevisionNumber() {
    return revisionNumber;
  }

  /**
   * Sets the revision number.
   *
   * @param revisionNumber the new revision number
   */
  public void setRevisionNumber(long revisionNumber) {
    this.revisionNumber = revisionNumber;
  }

  /**
   * Gets the revision date.
   *
   * @return the revision date
   */
  public Date getRevisionDate() {
    return revisionDate;
  }

  /**
   * Sets the revision date.
   *
   * @param revisionDate the new revision date
   */
  public void setRevisionDate(Date revisionDate) {
    this.revisionDate = revisionDate;
  }

  /**
   * Gets the revision state.
   *
   * @return the revision state
   */
  public String getRevisionState() {
    return revisionState;
  }

  /**
   * Sets the revision state.
   *
   * @param revisionState the new revision state
   */
  public void setRevisionState(String revisionState) {
    this.revisionState = revisionState;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public long getId() {
    return this.id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(long id) {
    this.id = id;
  }

  /**
   * Gets the event type.
   *
   * @return the event type
   */
  public String getEventType() {
    return this.eventType;
  }

  /**
   * Sets the event type.
   *
   * @param eventType the new event type
   */
  public void setEventType(String eventType) {
    this.eventType = eventType;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return this.playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /** @return the operatorId */
  public String getOperatorId() {
    return operatorId;
  }

  /** */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the wager id.
   *
   * @return the wager id
   */
  public long getWagerId() {
    return this.wagerId;
  }

  /**
   * Sets the wager id.
   *
   * @param wagerId the new wager id
   */
  public void setWagerId(long wagerId) {
    this.wagerId = wagerId;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return this.type;
  }

  /**
   * Sets the type.
   *
   * @param type the new type
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the external url.
   *
   * @return the external url
   */
  public String getExternalUrl() {
    return this.externalURL;
  }

  /**
   * Sets the external url.
   *
   * @param externalURL the new external url
   */
  public void setExternalUrl(String externalURL) {
    this.externalURL = externalURL;
  }

  /**
   * Gets the state.
   *
   * @return the state
   */
  public String getState() {
    return this.state;
  }

  /**
   * Sets the state.
   *
   * @param state the new state
   */
  public void setState(String state) {
    this.state = state;
  }

  /**
   * Gets the value.
   *
   * @return the value
   */
  public long getValue() {
    return this.value;
  }

  /**
   * Sets the value.
   *
   * @param value the new value
   */
  public void setValue(long value) {
    this.value = value;
  }

  /**
   * Gets the updated date.
   *
   * @return the updated date
   */
  public Date getUpdatedDate() {
    return this.updatedDate;
  }

  /**
   * Sets the updated date.
   *
   * @param updatedDate the new updated date
   */
  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  /**
   * Gets the creation date.
   *
   * @return the creation date
   */
  public Date getCreationDate() {
    return this.creationDate;
  }

  /**
   * Sets the creation date.
   *
   * @param creationDate the new creation date
   */
  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  /**
   * Checks if is player card prize.
   *
   * @return true, if is player card prize
   */
  public Boolean isPlayerCardPrize() {
    return this.playerCardPrize;
  }

  /**
   * Sets the player card prize.
   *
   * @param playerCardPrize the new player card prize
   */
  public void setPlayerCardPrize(Boolean playerCardPrize) {
    if (playerCardPrize == null) {
      playerCardPrize = false;
    }
    this.playerCardPrize = playerCardPrize;
  }

  /**
   * Checks if is rollback prizes.
   *
   * @return true, if is rollback prizes
   */
  public Boolean isRollbackPrizes() {
    return this.rollbackPrizes;
  }

  /**
   * Sets the rollback prizes.
   *
   * @param rollbackPrizes the new rollback prizes
   */
  public void setRollbackPrizes(Boolean rollbackPrizes) {
    if (rollbackPrizes == null) {
      rollbackPrizes = false;
    }
    this.rollbackPrizes = rollbackPrizes;
  }

  /** @return the externalCreationDate */
  public Date getExternalCreationDate() {
    return externalCreationDate;
  }

  /** @param externalCreationDate the externalCreationDate to set */
  public void setExternalCreationDate(Date externalCreationDate) {
    this.externalCreationDate = externalCreationDate;
  }

  /** @return the previousStatus */
  public String getPreviousStatus() {
    return previousStatus;
  }

  /** @param previousStatus the previousStatus to set */
  public void setPreviousStatus(String previousStatus) {
    this.previousStatus = previousStatus;
  }

  /** @return the isReConciled */
  public Boolean getIsReConciled() {
    return isReConciled;
  }

  /** @param isReConciled the isReConciled to set */
  public void setIsReConciled(Boolean isReConciled) {
    if (isReConciled == null) {
      isReConciled = false;
    }
    this.isReConciled = isReConciled;
  }
}
