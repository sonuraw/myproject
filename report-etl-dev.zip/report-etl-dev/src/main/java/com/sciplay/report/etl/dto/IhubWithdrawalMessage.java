package com.sciplay.report.etl.dto;

public class IhubWithdrawalMessage extends DynamicMessage<IhubWithdrawal> {}
