package com.sciplay.report.etl.Entities;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class SubscriptionVersionHistoryEntity. */
@Entity
@Table(name = "SubscriptionVersionHistory")
public class SubscriptionVersionHistoryEntity implements Serializable {

  private static final long serialVersionUID = 1L;

  /** The Version id. */
  @Id
  @Column(name = "VersionId")
  private int versionId;

  /** The Subscription id. */
  @Id
  @Column(name = "SubscriptionId")
  private Long subscriptionId;

  /** The Player id. */
  private Integer playerId;

  /** The Operatorid. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The Modification date. */
  private Date modificationDate;

  /** The Modified by. */
  private Integer modifiedBy;

  /** The Session id. */
  private String sessionId;

  /** The Ip address. */
  private String ipAddress;

  /** The Author type. */
  private String authorType;

  /**
   * Gets the version id.
   *
   * @return the version id
   */
  public int getVersionId() {
    return versionId;
  }

  /**
   * Sets the version id.
   *
   * @param versionId the new version id
   */
  public void setVersionId(int versionId) {
    this.versionId = versionId;
  }

  /**
   * Gets the subscription id.
   *
   * @return the subscription id
   */
  public Long getSubscriptionId() {
    return subscriptionId;
  }

  /**
   * Sets the subscription id.
   *
   * @param subscriptionId the new subscription id
   */
  public void setSubscriptionId(Long subscriptionId) {
    this.subscriptionId = subscriptionId;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = Objects.isNull(playerId) ? 0 : playerId;
  }

  /**
   * Gets the operatorid.
   *
   * @return the operatorid
   */
  public String getOperatorId() {
    return operatorId;
  }

  /** Sets the operatorid. */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the modification date.
   *
   * @return the modification date
   */
  public Date getModificationDate() {
    return modificationDate;
  }

  /**
   * Sets the modification date.
   *
   * @param modificationDate the new modification date
   */
  public void setModificationDate(Date modificationDate) {
    this.modificationDate = modificationDate;
  }

  /**
   * Gets the modified by.
   *
   * @return the modified by
   */
  public Integer getModifiedBy() {
    return modifiedBy;
  }

  /**
   * Sets the modified by.
   *
   * @param modifiedBy the new modified by
   */
  public void setModifiedBy(Integer modifiedBy) {
    this.modifiedBy = Objects.isNull(modifiedBy) ? 0 : modifiedBy;
  }

  /**
   * Gets the session id.
   *
   * @return the session id
   */
  public String getSessionId() {
    return sessionId;
  }

  /**
   * Sets the session id.
   *
   * @param sessionId the new session id
   */
  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  /**
   * Gets the ip address.
   *
   * @return the ip address
   */
  public String getIpAddress() {
    return ipAddress;
  }

  /**
   * Sets the ip address.
   *
   * @param ipAddress the new ip address
   */
  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }

  /**
   * Gets the author type.
   *
   * @return the author type
   */
  public String getAuthorType() {
    return authorType;
  }

  /**
   * Sets the author type.
   *
   * @param authorType the new author type
   */
  public void setAuthorType(String authorType) {
    this.authorType = authorType;
  }
}
