package com.sciplay.report.etl.Entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class AgentOperatorArchiveEntity.
 *
 * @author salman
 */
@Entity
@Table(name = "AgentOperatorArchive")
public class AgentOperatorArchiveEntity {

  /** The revision number. */
  @Column(name = "RevisionNumber")
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long revisionNumber;

  /** The revision date. */
  @Column(name = "RevisionDate")
  private Date revisionDate;

  /** The revision state. */
  @Column(name = "RevisionState")
  private String revisionState;

  /** The agent id. */
  @Column(name = "AgentId")
  private Integer agentId;

  /** The operator. */
  @Column(name = "Operator")
  private String operator;

  /** The author id. */
  @Column(name = "AuthorId")
  private Integer authorId;

  /** The author ip. */
  @Column(name = "AuthorIp")
  private String authorIp;

  /** The author session id. */
  @Column(name = "AuthorSessionId")
  private String authorSessionId;

  /** The created at. */
  @Column(name = "CreatedAt")
  private Date createdAt;

  /**
   * Instantiates a new agent operator archive entity.
   *
   * @param revisionState the revision state
   * @param agentId the agent id
   * @param operator the operator
   * @param authorId the author id
   * @param authorIp the author ip
   * @param authorSessionId the author session id
   * @param createdAt the created at
   * @param revisionDate the revision date
   */
  public AgentOperatorArchiveEntity(
      String revisionState,
      Integer agentId,
      String operator,
      Integer authorId,
      String authorIp,
      String authorSessionId,
      Date createdAt,
      Date revisionDate) {
    this.revisionState = revisionState;
    this.agentId = agentId;
    this.operator = operator;
    this.authorId = authorId;
    this.authorIp = authorIp;
    this.authorSessionId = authorSessionId;
    this.createdAt = createdAt;
    this.revisionDate = revisionDate;
  }

  /** Instantiates a new agent operator archive entity. */
  public AgentOperatorArchiveEntity() {}

  /**
   * Gets the revision number.
   *
   * @return the revision number
   */
  public long getRevisionNumber() {
    return revisionNumber;
  }

  /**
   * Sets the revision number.
   *
   * @param revisionNumber the new revision number
   */
  public void setRevisionNumber(long revisionNumber) {
    this.revisionNumber = revisionNumber;
  }

  /**
   * Gets the revision date.
   *
   * @return the revision date
   */
  public Date getRevisionDate() {
    return revisionDate;
  }

  /**
   * Sets the revision date.
   *
   * @param revisionDate the new revision date
   */
  public void setRevisionDate(Date revisionDate) {
    this.revisionDate = revisionDate;
  }

  /**
   * Gets the revision state.
   *
   * @return the revision state
   */
  public String getRevisionState() {
    return revisionState;
  }

  /**
   * Sets the revision state.
   *
   * @param revisionState the new revision state
   */
  public void setRevisionState(String revisionState) {
    this.revisionState = revisionState;
  }

  /**
   * Gets the agent id.
   *
   * @return the agent id
   */
  public Integer getAgentId() {
    return agentId;
  }

  /**
   * Sets the agent id.
   *
   * @param agentId the new agent id
   */
  public void setAgentId(Integer agentId) {
    this.agentId = agentId;
  }

  /**
   * Gets the operator.
   *
   * @return the operator
   */
  public String getOperator() {
    return operator;
  }

  /**
   * Sets the operator.
   *
   * @param operator the new operator
   */
  public void setOperator(String operator) {
    this.operator = operator;
  }

  /**
   * Gets the author id.
   *
   * @return the author id
   */
  public Integer getAuthorId() {
    return authorId;
  }

  /**
   * Sets the author id.
   *
   * @param authorId the new author id
   */
  public void setAuthorId(Integer authorId) {
    this.authorId = authorId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }
}
