package com.sciplay.report.etl.Entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class TransactionTypeSubTypeEntity. */
@Entity
@Table(name = "TransactionTypeSubType")
public class TransactionTypeSubTypeEntity implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The id. */
  @Id
  @Column(name = "id")
  private int id;

  /** The Transaction type code. */
  private String transactionTypeCode;

  /** The Transaction type name. */
  private String transactionTypeName;

  /** The Sub type code. */
  private String subTypeCode;

  /** The Sub type name. */
  private String subTypeName;

  /**
   * Gets id.
   *
   * @return the id
   */
  public int getId() {
    return id;
  }

  /**
   * Sets id.
   *
   * @param id the id to set
   */
  public void setId(int id) {
    this.id = id;
  }

  /**
   * Gets the sub type code.
   *
   * @return the sub type code
   */
  public String getSubTypeCode() {
    return subTypeCode;
  }

  /**
   * Sets the sub type code.
   *
   * @param subTypeCode the new sub type code
   */
  public void setSubTypeCode(String subTypeCode) {
    this.subTypeCode = subTypeCode;
  }

  /**
   * Gets the sub type name.
   *
   * @return the sub type name
   */
  public String getSubTypeName() {
    return subTypeName;
  }

  /**
   * Sets the sub type name.
   *
   * @param subTypeName the new sub type name
   */
  public void setSubTypeName(String subTypeName) {
    this.subTypeName = subTypeName;
  }

  /**
   * Gets the transaction type code.
   *
   * @return the transaction type code
   */
  public String getTransactionTypeCode() {
    return transactionTypeCode;
  }

  /**
   * Sets the transaction type code.
   *
   * @param transactionTypeCode the new transaction type code
   */
  public void setTransactionTypeCode(String transactionTypeCode) {
    this.transactionTypeCode = transactionTypeCode;
  }

  /**
   * Gets the transaction type name.
   *
   * @return the transaction type name
   */
  public String getTransactionTypeName() {
    return transactionTypeName;
  }

  /**
   * Sets the transaction type name.
   *
   * @param transactionTypeName the new transaction type name
   */
  public void setTransactionTypeName(String transactionTypeName) {
    this.transactionTypeName = transactionTypeName;
  }
}
