package com.sciplay.report.etl.Entities.Exclusion;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** @author salman */
@Entity
@Table(name = "SelfExclusion")
public class SelfExclusionEntity {

  @Column(name = "id")
  @Id
  private String id;

  @Column(name = "EventType")
  private String eventType;

  @Column(name = "PlayerId")
  private Integer playerId;

  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  @Column(name = "AppliedFrom")
  private Date appliedFrom;

  @Column(name = "AppliedUntil")
  private Date appliedUntil;

  @Column(name = "Period")
  private String period;

  @Column(name = "ExclusionType")
  private String exclusionType;

  @Column(name = "Reason")
  private String reason;

  @Column(name = "AuthorPlayerId")
  private Integer authorPlayerId;

  @Column(name = "AuthorAgentId")
  private Integer authorAgentId;

  @Column(name = "AuthorIp")
  private String authorIp;

  @Column(name = "AuthorSessionId")
  private String authorSessionId;

  @Column(name = "CreatedAt")
  private Date createdAt;

  private Date modifiedAt;

  public SelfExclusionEntity() {}

  public SelfExclusionEntity(
      String id,
      String eventType,
      Integer playerId,
      Date appliedFrom,
      Date appliedUntil,
      String period,
      String exclusionType,
      String reason,
      Integer authorPlayerId,
      Integer authorAgentId,
      String authorIp,
      String authorSessionId,
      Date createdAt,
      String operatorId,
      Date modifiedAt) {
    this.id = id;
    this.eventType = eventType;
    this.playerId = playerId;
    this.appliedFrom = appliedFrom;
    this.appliedUntil = appliedUntil;
    this.period = period;
    this.exclusionType = exclusionType;
    this.reason = reason;
    this.authorPlayerId = authorPlayerId;
    this.authorAgentId = authorAgentId;
    this.authorIp = authorIp;
    this.authorSessionId = authorSessionId;
    this.createdAt = createdAt;
    this.operatorId = operatorId;
    this.modifiedAt = modifiedAt;
  }

  public Date getModifiedAt() {
    return modifiedAt;
  }

  public void setModifiedAt(Date modifiedAt) {
    this.modifiedAt = modifiedAt;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getEventType() {
    return eventType;
  }

  public void setEventType(String eventType) {
    this.eventType = eventType;
  }

  public Integer getPlayerId() {
    return playerId;
  }

  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /** @return the operatorId */
  public String getOperatorId() {
    return operatorId;
  }

  /** @param operatorId the operatorId to set */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  public Date getAppliedFrom() {
    return appliedFrom;
  }

  public void setAppliedFrom(Date appliedFrom) {
    this.appliedFrom = appliedFrom;
  }

  public Date getAppliedUntil() {
    return appliedUntil;
  }

  public void setAppliedUntil(Date appliedUntil) {
    this.appliedUntil = appliedUntil;
  }

  public String getPeriod() {
    return period;
  }

  public void setPeriod(String period) {
    this.period = period;
  }

  public String getExclusionType() {
    return exclusionType;
  }

  public void setExclusionType(String exclusionType) {
    this.exclusionType = exclusionType;
  }

  public String getReason() {
    return reason;
  }

  public void setReason(String reason) {
    this.reason = reason;
  }

  public Integer getAuthorPlayerId() {
    return authorPlayerId;
  }

  public void setAuthorPlayerId(Integer authorPlayerId) {
    this.authorPlayerId = authorPlayerId;
  }

  public Integer getAuthorAgentId() {
    return authorAgentId;
  }

  public void setAuthorAgentId(Integer authorAgentId) {
    this.authorAgentId = authorAgentId;
  }

  public String getAuthorIp() {
    return authorIp;
  }

  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  public String getAuthorSessionId() {
    return authorSessionId;
  }

  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  public Date getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }
}
