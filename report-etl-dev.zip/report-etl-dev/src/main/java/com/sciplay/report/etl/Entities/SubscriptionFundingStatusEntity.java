package com.sciplay.report.etl.Entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class SubscriptionFundingStatusEntity. */
@Entity
@Table(name = "SubscriptionFundingStatus")
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubscriptionFundingStatusEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The Subscription id. */
  @Id
  @Column(name = "SubscriptionId")
  private Long subscriptionId;

  /** The is first funding. */
  private Boolean isFunding;

  /** The funding state. */
  private String fundingState;

  /**
   * Gets the subscription id.
   *
   * @return the subscription id
   */
  public Long getSubscriptionId() {
    return subscriptionId;
  }

  /**
   * Sets the subscription id.
   *
   * @param subscriptionId the new subscription id
   */
  public void setSubscriptionId(Long subscriptionId) {
    this.subscriptionId = subscriptionId;
  }

  /**
   * Checks if is first funding.
   *
   * @return true, if is first funding
   */
  public Boolean isFunding() {
    return isFunding;
  }

  /**
   * Sets the first funding.
   *
   * @param isFirstFunding the new first funding
   */
  public void setFunding(Boolean isFunding) {
    if (isFunding == null) {
      isFunding = false;
    }
    this.isFunding = isFunding;
  }

  /**
   * Gets the funding state.
   *
   * @return the funding state
   */
  public String getFundingState() {
    return fundingState;
  }

  /**
   * Sets the funding state.
   *
   * @param fundingState the new funding state
   */
  public void setFundingState(String fundingState) {
    this.fundingState = fundingState;
  }
}
