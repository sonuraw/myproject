package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CreatedLedgers {
  private Meta meta;

  private CreatedLedgersData data;

  public Meta getMeta() {
    return meta;
  }

  public void setMeta(Meta meta) {
    this.meta = meta;
  }

  public CreatedLedgersData getData() {
    return data;
  }

  public void setData(CreatedLedgersData data) {
    this.data = data;
  }
}
