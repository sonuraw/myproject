package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Date;
import java.util.Objects;

/** The Class Attributes. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class WagerAttributes {

  private String sessionId;

  private String currency;

  /** The playerId. */
  private Integer playerId;

  /** The requestID. */
  private String requestID;

  /** The wagerSetId. */
  private String wagerSetId;

  /** The brand. */
  private String brand;

  /** The game. */
  private Integer game;

  /** The type. */
  private String type;

  /** The channel. */
  private String channel;

  /** The externalCreatedTime. */
  private Date externalCreatedTime;

  /** The subURL. */
  private String subURL;

  /** The wagerSetExternalId. */
  private String wagerSetExternalId;

  /** The wagerSetExternalCreatedTime. */
  private String wagerSetExternalCreatedTime;

  /** The wagerSetNotifyWin. */
  private boolean wagerSetNotifyWin;

  /** The value. */
  private long amount;

  /** The externalID. */
  private String externalID;

  /** The state. */
  private String state;

  /** The notifyWin. */
  private boolean notifyWin;

  /** The wager id. */
  private Long wagerId;

  /** The wager state. */
  private String wagerState;

  /** The wager external id. */
  private String wagerExternalId;

  /** The wager external created time. */
  private Date wagerExternalCreatedTime;

  /** The wager notify win. */
  private Boolean wagerNotifyWin;

  /** The wager brand. */
  private String wagerBrand;

  /** The payload. */
  private Payload payload;

  /** The external id. */
  private String externalId;

  /** The wager expected End Date */
  private Date wagerExpectedEndDate;

  /**
   * Gets the external id.
   *
   * @return the external id
   */
  public String getExternalId() {
    return externalId;
  }

  /**
   * Sets the external id.
   *
   * @param externalId the new external id
   */
  public void setExternalId(String externalId) {
    this.externalId = externalId;
  }

  /**
   * Gets the wager id.
   *
   * @return the wager id
   */
  public Long getWagerId() {
    return wagerId;
  }

  /**
   * Sets the wager id.
   *
   * @param wagerId the new wager id
   */
  public void setWagerId(Long wagerId) {
    this.wagerId = wagerId;
  }

  /**
   * Gets the wager state.
   *
   * @return the wager state
   */
  public String getWagerState() {
    return wagerState;
  }

  /**
   * Sets the wager state.
   *
   * @param wagerState the new wager state
   */
  public void setWagerState(String wagerState) {
    this.wagerState = wagerState;
  }

  /**
   * Gets the wager external id.
   *
   * @return the wager external id
   */
  public String getWagerExternalId() {
    return wagerExternalId;
  }

  /**
   * Sets the wager external id.
   *
   * @param wagerExternalId the new wager external id
   */
  public void setWagerExternalId(String wagerExternalId) {
    this.wagerExternalId = wagerExternalId;
  }

  /**
   * Gets the wager external created time.
   *
   * @return the wager external created time
   */
  public Date getWagerExternalCreatedTime() {
    return wagerExternalCreatedTime;
  }

  /**
   * Sets the wager external created time.
   *
   * @param wagerExternalCreatedTime the new wager external created time
   */
  public void setWagerExternalCreatedTime(Date wagerExternalCreatedTime) {
    this.wagerExternalCreatedTime = wagerExternalCreatedTime;
  }

  /**
   * Gets the wager notify win.
   *
   * @return the wager notify win
   */
  public Boolean getWagerNotifyWin() {
    return wagerNotifyWin;
  }

  /**
   * Sets the wager notify win.
   *
   * @param wagerNotifyWin the new wager notify win
   */
  public void setWagerNotifyWin(Boolean wagerNotifyWin) {
    this.wagerNotifyWin = wagerNotifyWin;
  }

  /**
   * Gets the wager brand.
   *
   * @return the wager brand
   */
  public String getWagerBrand() {
    return wagerBrand;
  }

  /**
   * Sets the wager brand.
   *
   * @param wagerBrand the new wager brand
   */
  public void setWagerBrand(String wagerBrand) {
    this.wagerBrand = wagerBrand;
  }

  /**
   * Gets the payload.
   *
   * @return the payload
   */
  public Payload getPayload() {
    return payload;
  }

  /**
   * Sets the payload.
   *
   * @param payload the new payload
   */
  public void setPayload(Payload payload) {
    this.payload = payload;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the request ID.
   *
   * @return the request ID
   */
  public String getRequestID() {
    return requestID;
  }

  /**
   * Sets the request ID.
   *
   * @param requestID the new request ID
   */
  public void setRequestID(String requestID) {
    this.requestID = requestID;
  }

  /**
   * Gets the wager set id.
   *
   * @return the wager set id
   */
  public long getWagerSetId() {
    if (Objects.equals(wagerSetId, "") || wagerSetId == null) {
      return Long.valueOf(Long.parseLong("0"));
    } else {
      return Long.valueOf(wagerSetId);
    }
  }

  /**
   * Sets the wager set id.
   *
   * @param wagerSetId the new wager set id
   */
  public void setWagerSetId(String wagerSetId) {
    this.wagerSetId = wagerSetId;
  }

  /**
   * Gets the brand.
   *
   * @return the brand
   */
  public String getBrand() {
    return brand;
  }

  /**
   * Sets the brand.
   *
   * @param brand the new brand
   */
  public void setBrand(String brand) {
    this.brand = brand;
  }

  /**
   * Gets the game.
   *
   * @return the game
   */
  public Integer getGame() {
    return game;
  }

  /**
   * Sets the game.
   *
   * @param game the new game
   */
  public void setGame(Integer game) {
    this.game = game;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Sets the type.
   *
   * @param type the new type
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the channel.
   *
   * @return the channel
   */
  public String getChannel() {
    return channel;
  }

  /**
   * Sets the channel.
   *
   * @param channel the new channel
   */
  public void setChannel(String channel) {
    this.channel = channel;
  }

  /**
   * Gets the external created time.
   *
   * @return the external created time
   */
  public Date getExternalCreatedTime() {
    return externalCreatedTime;
  }

  /**
   * Sets the external created time.
   *
   * @param externalCreatedTime the new external created time
   */
  public void setExternalCreatedTime(Date externalCreatedTime) {
    this.externalCreatedTime = externalCreatedTime;
  }

  /**
   * Gets the sub URL.
   *
   * @return the sub URL
   */
  public String getSubURL() {
    return subURL;
  }

  /**
   * Sets the sub URL.
   *
   * @param subURL the new sub URL
   */
  public void setSubURL(String subURL) {
    this.subURL = subURL;
  }

  /**
   * Gets the wager set external id.
   *
   * @return the wager set external id
   */
  public String getWagerSetExternalId() {
    return wagerSetExternalId;
  }

  /**
   * Sets the wager set external id.
   *
   * @param wagerSetExternalId the new wager set external id
   */
  public void setWagerSetExternalId(String wagerSetExternalId) {
    this.wagerSetExternalId = wagerSetExternalId;
  }

  /**
   * Gets the wager set external created time.
   *
   * @return the wager set external created time
   */
  public String getWagerSetExternalCreatedTime() {
    return wagerSetExternalCreatedTime;
  }

  /**
   * Sets the wager set external created time.
   *
   * @param wagerSetExternalCreatedTime the new wager set external created time
   */
  public void setWagerSetExternalCreatedTime(String wagerSetExternalCreatedTime) {
    this.wagerSetExternalCreatedTime = wagerSetExternalCreatedTime;
  }

  /**
   * Checks if is wager set notify win.
   *
   * @return true, if is wager set notify win
   */
  public boolean isWagerSetNotifyWin() {
    return wagerSetNotifyWin;
  }

  /**
   * Sets the wager set notify win.
   *
   * @param wagerSetNotifyWin the new wager set notify win
   */
  public void setWagerSetNotifyWin(boolean wagerSetNotifyWin) {
    this.wagerSetNotifyWin = wagerSetNotifyWin;
  }

  /**
   * Gets the amount.
   *
   * @return the amount
   */
  public long getAmount() {
    return amount;
  }

  /**
   * Sets the amount.
   *
   * @param amount the new amount
   */
  public void setAmount(long amount) {
    this.amount = amount;
  }

  /**
   * Gets the external ID.
   *
   * @return the external ID
   */
  public String getExternalID() {
    return externalID;
  }

  /**
   * Sets the external ID.
   *
   * @param externalID the new external ID
   */
  public void setExternalID(String externalID) {
    this.externalID = externalID;
  }

  /**
   * Gets the state.
   *
   * @return the state
   */
  public String getState() {
    return state;
  }

  /**
   * Sets the state.
   *
   * @param state the new state
   */
  public void setState(String state) {
    this.state = state;
  }

  /**
   * Checks if is notify win.
   *
   * @return true, if is notify win
   */
  public boolean isNotifyWin() {
    return notifyWin;
  }

  /**
   * Sets the notify win.
   *
   * @param notifyWin the new notify win
   */
  public void setNotifyWin(boolean notifyWin) {
    this.notifyWin = notifyWin;
  }

  public String getSessionId() {
    return sessionId;
  }

  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  /** @return the wagerExpectedEndDate */
  public Date getWagerExpectedEndDate() {
    return wagerExpectedEndDate;
  }

  /** @param wagerExpectedEndDate the wagerExpectedEndDate to set */
  public void setWagerExpectedEndDate(Date wagerExpectedEndDate) {
    this.wagerExpectedEndDate = wagerExpectedEndDate;
  }
}
