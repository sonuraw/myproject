package com.sciplay.report.etl;

import java.io.File;
import org.hibernate.cfg.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class is created to instantiate all the necessary properties/configuration which the service
 * required at the time of startup.
 *
 * @author dhaya
 */
public class ReportEtlManaged {
  /** Holds Logger Object. */
  private static final Logger LOG = LoggerFactory.getLogger(ReportEtlManaged.class);

  private static final ReportEtlManaged INSTANCE = new ReportEtlManaged();

  private ReportEtlManaged() {}

  /** @return the instance */
  public static ReportEtlManaged getInstance() {
    return INSTANCE;
  }

  public void start() {
    // MetricsService.getInstance().start();
    // MetricsService.getInstance().emit("service-startup","service started
    // successfully at "+ ReportServiceConstant.getCurrentTimestamp());
    LOG.info("Start the ReportServiceManaged");
    startHibernate();
  }

  /**
   * This methods gives call to another methods to setup Connection pooling, Start watcher services
   * and loading the Templates present in the configurable template folder. This also initializes
   * the Kafka consumer.
   */
  public void startHibernate() {
    try {
      File f =
          new File(
              ReportEtlContext.getInstance().getReportEtlServiceConfig().getHibernateConfigPath()
                  + "hibernate.cfg.xml");
      if (f.exists()) {
        LOG.debug("Using hibernate ENVIRONMENT variables...!!! ");
        Configuration cfg = new Configuration().configure(f);
        cfg.setProperty(
            "hibernate.connection.url",
            ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getHibernateConfig()
                .getUrl());
        cfg.setProperty(
            "hibernate.connection.username",
            ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getHibernateConfig()
                .getUser());
        cfg.setProperty(
            "hibernate.connection.password",
            ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getHibernateConfig()
                .getPassword());
        cfg.setProperty(
            "hibernate.connection.pool_size",
            ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getHibernateConfig()
                .getMinSize());
        cfg.setProperty(
            "hibernate.hbm2ddl.auto",
            ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getHibernateConfig()
                .getSchemaValidateOption());
        ReportEtlContext.getInstance().setSessionFactory(cfg.buildSessionFactory());
      } else {
        LOG.warn(
            "Hibernate custom config file not found..!! Using DEFAULT hibernate.cfg.xml...!!!");
        ReportEtlContext.getInstance()
            .setSessionFactory(new Configuration().configure().buildSessionFactory());
      }
      ReportEtlContext.setIsHibernateInitialized(true);
      LOG.info("Started Hibernate ..!!");
    } catch (Exception e) {
      LOG.error(e.getMessage());
      LOG.error("Hibernate ERROR ..!!");
      LOG.error("Cannot establish connection to Database. Please check the database configuration");
      ReportEtlContext.setIsHibernateInitialized(false);
      throw e;
    }
  }

  public void stop() {
    // ReportEtlContext.getInstance().getSessionFactory().close();
    LOG.info("stopped Hibernate..!!");
  }
}
