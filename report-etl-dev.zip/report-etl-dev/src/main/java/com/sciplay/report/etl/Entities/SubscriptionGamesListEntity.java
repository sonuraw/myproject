package com.sciplay.report.etl.Entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.SerializedName;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class SubscriptionGamesEntity. */
@Entity
@Table(name = "SubscriptionGamesList")
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubscriptionGamesListEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  @SerializedName("playTypeId")
  @Id
  private Integer playTypeNo;

  private String playTypeName;

  /** The Game id. */
  @Id private Integer gameId;

  private Integer rows;

  /** The Game name. */
  private String gameName;

  /** game type */
  @SerializedName("gameType")
  private String type;

  /** The Selected numbers in the purchase of subscribed games. */
  private String selectedNumbers;

  /** Is the game active or deleted. */
  private Boolean isDeleted = false;

  /** Instantiates a new subscription games entity. */
  public SubscriptionGamesListEntity() {}

  /**
   * Instantiates a new subscription games entity.
   *
   * @param gameId the game id
   * @param gameName the game name
   * @param playTypeNo the play type number
   * @param playTypeName the play type name
   * @param type the play method
   * @param rows the number of rows
   * @param selectedNumbers count of numbers to be selected
   * @param isDeleted the game is active or not
   */
  public SubscriptionGamesListEntity(
      Integer gameId,
      String gameName,
      Integer playTypeNo,
      String playTypeName,
      String type,
      Integer rows,
      String selectedNumbers,
      Boolean isDeleted) {
    this.gameId = gameId;
    this.gameName = gameName;
    this.playTypeNo = playTypeNo;
    this.playTypeName = playTypeName;
    this.type = type;
    this.rows = rows;
    this.selectedNumbers = selectedNumbers;
    this.isDeleted = isDeleted;
  }

  /**
   * Gets the serialversionuid.
   *
   * @return the serialversionuid
   */
  public static long getSerialVersionUID() {
    return serialVersionUID;
  }

  /**
   * Gets the partner id.
   *
   * @return the partner id
   */
  public String getSelectedNumbers() {
    return selectedNumbers;
  }

  /**
   * Sets the partner id.
   *
   * @param selectedNumbers the new partner id
   */
  public void setSelectedNumbers(String selectedNumbers) {
    this.selectedNumbers = selectedNumbers;
  }

  /**
   * Gets the adds the on trigger value.
   *
   * @return the adds the on trigger value
   */
  public Boolean getIsDeleted() {
    return this.isDeleted;
  }

  /**
   * Sets the adds the on trigger value.
   *
   * @param isDeleted the new adds the on trigger value
   */
  public void setIsDeleted(Boolean isDeleted) {
    if (isDeleted == null) {
      isDeleted = false;
    }
    this.isDeleted = isDeleted;
  }

  /**
   * Gets the game active.
   *
   * @return the game is active or not
   */
  public boolean getIsActive() {
    return !isDeleted;
  }

  /**
   * Sets the game active.
   *
   * @param isActive the game is active or not
   */
  public void setIsActive(boolean isActive) {
    this.isDeleted = !isActive;
  }

  /**
   * Gets the game id.
   *
   * @return the game id
   */
  public Integer getGameId() {
    return gameId;
  }

  /**
   * Sets the game id.
   *
   * @param gameId the new game id
   */
  public void setGameId(Integer gameId) {
    this.gameId = gameId;
  }

  /**
   * Gets the game name.
   *
   * @return the game name
   */
  public String getGameName() {
    return gameName;
  }

  /**
   * Sets the game name.
   *
   * @param gameName the new game name
   */
  public void setGameName(String gameName) {
    this.gameName = gameName;
  }

  /**
   * Gets the checks if is random.
   *
   * @return the checks if is random
   */
  public String getType() {
    return type;
  }

  /**
   * Sets the checks if is random.
   *
   * @param isRandom the new checks if is random
   */
  public void setType(String isRandom) {
    type = isRandom;
  }

  /** Play type number. */
  public Integer getPlayTypeNo() {
    return playTypeNo;
  }

  public void setPlayTypeNo(Integer playTypeNo) {
    this.playTypeNo = playTypeNo;
  }

  /** The play type name. */
  public String getPlayTypeName() {
    return playTypeName;
  }

  public void setPlayTypeName(String playTypeName) {
    this.playTypeName = playTypeName;
  }

  /** The number of rows. */
  public Integer getRows() {
    return rows;
  }

  public void setRows(Integer rows) {
    this.rows = rows;
  }
}
