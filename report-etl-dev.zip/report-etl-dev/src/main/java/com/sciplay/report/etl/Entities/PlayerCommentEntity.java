package com.sciplay.report.etl.Entities;

import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class PlayerCommentEntity. */
@Entity
@Table(name = "PlayerComment")
public class PlayerCommentEntity {

  /** The Id. */
  @Id
  @Column(name = "Id")
  private String id;

  /** The Player id. */
  private Integer playerId;

  /** The Type. */
  private String type;

  /** The Comment. */
  private String comment;

  /** The Created at. */
  private Date createdAt;

  /** The Operator id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The Correlation id. */
  private String correlationId;

  /** The Author player id. */
  private Integer authorPlayerId;

  /** The Author agent id. */
  private Integer authorAgentId;

  /** The Author session id. */
  private String authorSessionId;

  /** The Author ip. */
  private String authorIp;

  /**
   * Gets the id.
   *
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Sets the type.
   *
   * @param type the new type
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the comment.
   *
   * @return the comment
   */
  public String getComment() {
    return comment;
  }

  /**
   * Sets the comment.
   *
   * @param comment the new comment
   */
  public void setComment(String comment) {
    this.comment = comment;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the correlation id.
   *
   * @return the correlation id
   */
  public String getCorrelationId() {
    return correlationId;
  }

  /**
   * Sets the correlation id.
   *
   * @param correlationId the new correlation id
   */
  public void setCorrelationId(String correlationId) {
    this.correlationId = correlationId;
  }

  /**
   * Gets the author player id.
   *
   * @return the author player id
   */
  public Integer getAuthorPlayerId() {
    return authorPlayerId;
  }

  /**
   * Sets the author player id.
   *
   * @param authorPlayerId the new author player id
   */
  public void setAuthorPlayerId(Integer authorPlayerId) {
    this.authorPlayerId = Objects.isNull(authorPlayerId) ? 0 : authorPlayerId;
  }

  /**
   * Gets the author agent id.
   *
   * @return the author agent id
   */
  public Integer getAuthorAgentId() {
    return authorAgentId;
  }

  /**
   * Sets the author agent id.
   *
   * @param authorAgentId the new author agent id
   */
  public void setAuthorAgentId(Integer authorAgentId) {
    this.authorAgentId = Objects.isNull(authorAgentId) ? 0 : authorAgentId;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }
}
