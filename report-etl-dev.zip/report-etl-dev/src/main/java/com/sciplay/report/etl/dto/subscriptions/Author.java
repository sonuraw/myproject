package com.sciplay.report.etl.dto.subscriptions;

/** The Class Author. */
public class Author {

  /** The id. */
  private String id;

  /** The ip. */
  private String ip;

  /** The session id. */
  private String sessionId;

  /** The agent id. */
  private Integer agentId;

  /** The player id. */
  private Integer playerId;

  /**
   * Gets the agent id.
   *
   * @return the agent id
   */
  public Integer getAgentId() {
    return agentId;
  }

  /**
   * Sets the agent id.
   *
   * @param agentId the new agent id
   */
  public void setAgentId(Integer agentId) {
    this.agentId = agentId;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Gets the ip.
   *
   * @return the ip
   */
  public String getIp() {
    return ip;
  }

  /**
   * Sets the ip.
   *
   * @param ip the new ip
   */
  public void setIp(String ip) {
    this.ip = ip;
  }

  /**
   * Gets the session id.
   *
   * @return the session id
   */
  public String getSessionId() {
    return sessionId;
  }

  /**
   * Sets the session id.
   *
   * @param sessionId the new session id
   */
  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }
}
