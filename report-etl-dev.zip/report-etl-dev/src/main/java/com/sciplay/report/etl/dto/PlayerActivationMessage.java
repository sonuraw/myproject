package com.sciplay.report.etl.dto;

public class PlayerActivationMessage extends DynamicMessage<PlayerActivation> {}
