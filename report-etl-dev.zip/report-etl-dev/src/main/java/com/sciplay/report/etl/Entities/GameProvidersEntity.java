package com.sciplay.report.etl.Entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** Entity class for GameProviders. */
@Entity
@Table(name = "GameProviders")
@JsonIgnoreProperties(ignoreUnknown = true)
public class GameProvidersEntity implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The id. */
  @Id
  @Column(name = "Id")
  private String id;

  /** The operator id. */
  @Id
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The name. */
  private String name;

  /** The author id. */
  private Integer authorId;

  /** The author ip. */
  private String authorIp;

  /** The author session id. */
  private String authorSessionId;

  /** The created at. */
  private Date createdAt;

  /** The Modified at. */
  private Date modifiedAt;

  /** The Is deleted. */
  private boolean isDeleted = false;

  /** The Domain. */
  private String domain;

  /** The backoffice url template. */
  private String backofficeUrlTemplate;

  /** Instantiates a new game providers entity. */
  public GameProvidersEntity() {}

  /**
   * Instantiates a new game providers entity.
   *
   * @param id the id
   * @param operatorId the operator id
   * @param name the name
   * @param createdAt the created at
   * @param modifiedAt the modified at
   */
  public GameProvidersEntity(
      String id, String operatorId, String name, Date createdAt, Date modifiedAt) {
    this.id = id;
    this.operatorId = operatorId;
    this.name = name;
    this.createdAt = createdAt;
    this.modifiedAt = modifiedAt;
  }

  /**
   * Instantiates a new game providers entity.
   *
   * @param id the id
   * @param operatorId the operator id
   * @param name the name
   * @param authorId the author id
   * @param authorIp the author ip
   * @param authorSessionId the author session id
   * @param createdAt the created at
   * @param modifiedAt the modified at
   * @param domain the domain
   */
  public GameProvidersEntity(
      String id,
      String operatorId,
      String name,
      Integer authorId,
      String authorIp,
      String authorSessionId,
      Date createdAt,
      Date modifiedAt,
      String domain,
      String backofficeUrlTemplate) {
    this.id = id;
    this.operatorId = operatorId;
    this.name = name;
    this.authorId = Objects.isNull(authorId) ? 0 : authorId;
    this.authorIp = authorIp;
    this.authorSessionId = authorSessionId;
    this.createdAt = createdAt;
    this.modifiedAt = modifiedAt;
    this.domain = domain;
    this.backofficeUrlTemplate = backofficeUrlTemplate;
  }

  /**
   * Checks if is deleted.
   *
   * @return true, if is deleted
   */
  public boolean isDeleted() {
    return isDeleted;
  }

  /**
   * Sets the deleted.
   *
   * @param isDeleted the new deleted
   */
  public void setDeleted(boolean isDeleted) {
    this.isDeleted = isDeleted;
  }

  /**
   * Gets the backoffice url template.
   *
   * @return the backoffice url template
   */
  public String getBackofficeUrlTemplate() {
    return backofficeUrlTemplate;
  }

  /**
   * Sets the backoffice url template.
   *
   * @param backofficeUrlTemplate the new backoffice url template
   */
  public void setBackofficeUrlTemplate(String backofficeUrlTemplate) {
    this.backofficeUrlTemplate = backofficeUrlTemplate;
  }

  /**
   * Gets the domain.
   *
   * @return the domain
   */
  public String getDomain() {
    return domain;
  }

  /**
   * Sets the domain.
   *
   * @param domain the new domain
   */
  public void setDomain(String domain) {
    this.domain = domain;
  }

  /**
   * Checks if is checks if is deleted.
   *
   * @return true, if is checks if is deleted
   */
  public boolean isIsDeleted() {
    return isDeleted;
  }

  /**
   * Sets the checks if is deleted.
   *
   * @param isDeleted the new checks if is deleted
   */
  public void setIsDeleted(boolean isDeleted) {
    this.isDeleted = isDeleted;
  }

  /**
   * Gets the modified at.
   *
   * @return the modified at
   */
  public Date getModifiedAt() {
    return modifiedAt;
  }

  /**
   * Sets the modified at.
   *
   * @param modifiedAt the new modified at
   */
  public void setModifiedAt(Date modifiedAt) {
    this.modifiedAt = modifiedAt;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Sets the name.
   *
   * @param name the new name
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Gets the author id.
   *
   * @return the author id
   */
  public Integer getAuthorId() {
    return authorId;
  }

  /**
   * Sets the author id.
   *
   * @param authorId the new author id
   */
  public void setAuthorId(Integer authorId) {
    this.authorId = Objects.isNull(authorId) ? 0 : authorId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }
}
