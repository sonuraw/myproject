package com.sciplay.report.etl.dto.BatchLog;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BatchLogAttributes {

  @JsonProperty("correlationId")
  private String correlationId;

  @JsonProperty("batchGroupId")
  private String batchGroupId;

  @JsonProperty("batchId")
  private String batchId;

  @JsonProperty("status")
  private String status;

  @JsonProperty("startDate")
  private Date startDate;

  @JsonProperty("endDate")
  private Date endDate;

  @JsonProperty("nextRunDate")
  private Date nextRunDate;

  @JsonProperty("result")
  private BatchLogAttrsResult result;

  @JsonProperty("correlationId")
  public String getCorrelationId() {
    return correlationId;
  }

  @JsonProperty("correlationId")
  public void setCorrelationId(String correlationId) {
    this.correlationId = correlationId;
  }

  @JsonProperty("batchGroupId")
  public String getBatchGroupId() {
    return batchGroupId;
  }

  @JsonProperty("batchGroupId")
  public void setBatchGroupId(String batchGroupId) {
    this.batchGroupId = batchGroupId;
  }

  @JsonProperty("batchId")
  public String getBatchId() {
    return batchId;
  }

  @JsonProperty("batchId")
  public void setBatchId(String batchId) {
    this.batchId = batchId;
  }

  @JsonProperty("status")
  public String getStatus() {
    return status;
  }

  @JsonProperty("status")
  public void setStatus(String status) {
    this.status = status;
  }

  @JsonProperty("startDate")
  public Date getStartDate() {
    return startDate;
  }

  @JsonProperty("startDate")
  public void setStartDate(Date startDate) {
    this.startDate = startDate;
  }

  @JsonProperty("endDate")
  public Date getEndDate() {
    return endDate;
  }

  @JsonProperty("endDate")
  public void setEndDate(Date endDate) {
    this.endDate = endDate;
  }

  @JsonProperty("nextRunDate")
  public Date getNextRunDate() {
    return nextRunDate;
  }

  @JsonProperty("nextRunDate")
  public void setNextRunDate(Date nextRunDate) {
    this.nextRunDate = nextRunDate;
  }

  @JsonProperty("result")
  public BatchLogAttrsResult getResult() {
    return result;
  }

  @JsonProperty("result")
  public void setResult(BatchLogAttrsResult result) {
    this.result = result;
  }
}
