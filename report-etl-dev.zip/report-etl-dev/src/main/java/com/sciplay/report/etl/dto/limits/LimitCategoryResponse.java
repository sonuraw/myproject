package com.sciplay.report.etl.dto.limits;

import com.sciplay.report.etl.dto.Links;

public class LimitCategoryResponse {

  private final LimitMeta meta;

  private final LimitCategoryData data;

  private final Links links;

  public LimitCategoryResponse(LimitMeta meta, LimitCategoryData data, Links links) {
    this.meta = meta;
    this.data = data;
    this.links = links;
  }

  public LimitCategoryResponse() {
    this.meta = null;
    this.data = null;
    this.links = null;
  }

  public LimitMeta getMeta() {
    return meta;
  }

  public LimitCategoryData getData() {
    return data;
  }

  public Links getLinks() {
    return links;
  }
}
