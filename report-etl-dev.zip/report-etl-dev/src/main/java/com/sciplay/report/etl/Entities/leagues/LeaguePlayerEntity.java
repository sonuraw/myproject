package com.sciplay.report.etl.Entities.leagues;

import com.sciplay.report.etl.dto.teamsleagues.TeamsLeaguesAuthor;
import com.sciplay.report.etl.dto.teamsleagues.TeamsLeaguesMessage;
import com.sciplay.report.etl.utils.ReportEtlUtils;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/** @author salman */
@Entity
@Table(name = "LeaguePlayer")
public class LeaguePlayerEntity implements Serializable {

  private static final long serialVersionUID = 1L;

  @javax.persistence.Id
  @Column(name = "PlayerId")
  private Integer playerId;

  @javax.persistence.Id
  @Column(name = "LeagueId")
  private String leagueId;

  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  @Column(
      name = "Status",
      columnDefinition = "enum('ACTIVE','JOINED','LEFT','REMOVED','A','J','L','R')")
  private String status;

  @Column(name = "AuthorId")
  private Integer authorId;

  @Column(name = "AuthorIp")
  private String authorIp;

  @Column(name = "AuthorSessionId")
  private String authorSessionId;

  @Column(name = "UpdatedAt")
  private Date updatedAt;

  @Column(name = "CreatedAt")
  private Date createdAt;

  public LeaguePlayerEntity() {}

  public LeaguePlayerEntity(TeamsLeaguesMessage teamsLeaguesMessage, Integer playerId) {
    TeamsLeaguesAuthor author = teamsLeaguesMessage.getMeta().getAuthor();
    this.playerId = playerId;
    this.leagueId = teamsLeaguesMessage.getData().getAttributes().getLeagueId();
    this.operatorId = teamsLeaguesMessage.getMeta().getOperatorId();
    this.status = teamsLeaguesMessage.getData().getAttributes().getStatus();
    this.authorId = ((author.getAgentId() == null) ? author.getPlayerId() : author.getAgentId());
    this.authorId = (Objects.isNull(authorId)) ? 0 : authorId;
    this.authorIp = author.getIp();
    this.authorSessionId = author.getSessionId();
    this.updatedAt = ReportEtlUtils.parseDate(teamsLeaguesMessage.getMeta().getCreatedAt());
    this.createdAt = ReportEtlUtils.parseDate(teamsLeaguesMessage.getMeta().getCreatedAt());
  }

  public LeaguePlayerEntity(LeagueEntity leagueEntity, Integer playerId) {
    this.playerId = playerId;
    this.leagueId = leagueEntity.getId();
    this.operatorId = leagueEntity.getOperatorId();
    this.status = "ACTIVE";
    this.authorId = leagueEntity.getAuthorId();
    this.authorIp = leagueEntity.getAuthorIp();
    this.authorSessionId = leagueEntity.getAuthorSessionId();
    this.updatedAt = leagueEntity.getUpdatedAt();
    this.createdAt = leagueEntity.getCreatedAt();
  }

  public Integer getPlayerId() {
    return playerId;
  }

  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  public String getLeagueId() {
    return leagueId;
  }

  public void setLeagueId(String leagueId) {
    this.leagueId = leagueId;
  }

  public String getOperatorId() {
    return operatorId;
  }

  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public Integer getAuthorId() {
    return authorId;
  }

  public void setAuthorId(Integer authorId) {
    this.authorId = (Objects.isNull(authorId)) ? 0 : authorId;
  }

  public String getAuthorIp() {
    return authorIp;
  }

  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  public String getAuthorSessionId() {
    return authorSessionId;
  }

  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  public Date getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(Date updatedAt) {
    this.updatedAt = updatedAt;
  }

  public Date getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }
}
