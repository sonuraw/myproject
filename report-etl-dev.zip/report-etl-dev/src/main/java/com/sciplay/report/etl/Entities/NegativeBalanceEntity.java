package com.sciplay.report.etl.Entities;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class NegativeBalanceEntity. */
@Entity
@Table(name = "NegativeBalance")
public class NegativeBalanceEntity implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The id. */
  @Id
  @Column(name = "Id")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int id;

  /** The negative occurrence date. */
  private Date negativeOccurrenceDate;

  /** The adjustment date. */
  private Date adjustmentDate;

  /** The player id. */
  private Integer playerId;

  /** The operatorId id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The agent id. */
  private Integer agentId;

  /** The wallet. */
  private String wallet;

  /** The write off status. */
  private String writeOffStatus;

  /** The negative balance amount. */
  private long negativeBalanceAmount;

  /** The adjustment amount. */
  private long adjustmentAmount;

  /** The adjustment comments. */
  private String adjustmentComments;

  /** The Group id. */
  private Integer groupId;

  /** The First negative occurence date. */
  @Column(name = "FirstNegativeOccurenceDate")
  private Date firstNegativeOccurrenceDate;

  /** The First negative balance amount. */
  @Column(name = "FirstNegativeBalanceAmount")
  private long firstNegativeBalanceAmount;

  /** The Is first occurence. */
  @Column(name = "IsFirstOccurence")
  private Boolean isFirstOccurence;

  /** The status. */
  @Column(name = "Status")
  private Boolean status;

  /** The transaction amount. */
  private Long transactionAmount;

  /** The transaction type. */
  private String transactionType;

  /** The sub type. */
  private String subType;

  /** The transaction status. */
  private String transactionStatus;

  /** The positive transaction amount. */
  private Long positiveTransactionAmount;

  /** The positive transaction type. */
  private String positiveTransactionType;

  /** The positive sub type. */
  private String positiveSubType;

  /** The positive transaction status. */
  private String positiveTransactionStatus;

  /** The is last occurence. */
  private Boolean isLastOccurence;

  /** Instantiates a new negative balance entity. */
  public NegativeBalanceEntity() {}

  /**
   * Instantiates a new negative balance entity.
   *
   * @param negativeOccurrenceDate the negative occurrence date
   * @param adjustmentDate the adjustment date
   * @param playerId the player id
   * @param agentId the agent id
   * @param wallet the wallet
   * @param writeOffStatus the write off status
   * @param negativeBalanceAmount the negative balance amount
   * @param adjustmentAmount the adjustment amount
   * @param adjustmentComments the adjustment comments
   */
  public NegativeBalanceEntity(
      Date negativeOccurrenceDate,
      Date adjustmentDate,
      Integer playerId,
      Integer agentId,
      String wallet,
      String writeOffStatus,
      int negativeBalanceAmount,
      int adjustmentAmount,
      String adjustmentComments) {
    this.negativeOccurrenceDate = negativeOccurrenceDate;
    this.adjustmentDate = adjustmentDate;
    this.playerId = Objects.isNull(playerId) ? 0 : playerId;
    this.agentId = Objects.isNull(agentId) ? 0 : agentId;
    this.wallet = wallet;
    this.writeOffStatus = writeOffStatus;
    this.negativeBalanceAmount = Objects.isNull(negativeBalanceAmount) ? 0L : negativeBalanceAmount;
    this.adjustmentAmount = Objects.isNull(adjustmentAmount) ? 0L : adjustmentAmount;
    this.adjustmentComments = adjustmentComments;
  }

  /**
   * Gets the checks if is last occurence.
   *
   * @return the checks if is last occurence
   */
  public Boolean getIsLastOccurence() {
    return isLastOccurence;
  }

  /**
   * Sets the checks if is last occurence.
   *
   * @param isLastOccurence the new checks if is last occurence
   */
  public void setIsLastOccurence(Boolean isLastOccurence) {
    this.isLastOccurence = Objects.isNull(isLastOccurence) ? false : isLastOccurence;
  }

  /**
   * Gets the transaction amount.
   *
   * @return the transaction amount
   */
  public Long getTransactionAmount() {
    return transactionAmount;
  }

  /**
   * Sets the transaction amount.
   *
   * @param transactionAmount the new transaction amount
   */
  public void setTransactionAmount(Long transactionAmount) {
    this.transactionAmount = Objects.isNull(transactionAmount) ? 0L : transactionAmount;
  }

  /**
   * Gets the transaction type.
   *
   * @return the transaction type
   */
  public String getTransactionType() {
    return transactionType;
  }

  /**
   * Sets the transaction type.
   *
   * @param transactionType the new transaction type
   */
  public void setTransactionType(String transactionType) {
    this.transactionType = transactionType;
  }

  /**
   * Gets the sub type.
   *
   * @return the sub type
   */
  public String getSubType() {
    return subType;
  }

  /**
   * Sets the sub type.
   *
   * @param subType the new sub type
   */
  public void setSubType(String subType) {
    this.subType = subType;
  }

  /**
   * Gets the transaction status.
   *
   * @return the transaction status
   */
  public String getTransactionStatus() {
    return transactionStatus;
  }

  /**
   * Sets the transaction status.
   *
   * @param transactionStatus the new transaction status
   */
  public void setTransactionStatus(String transactionStatus) {
    this.transactionStatus = transactionStatus;
  }

  /**
   * Gets the positive transaction amount.
   *
   * @return the positive transaction amount
   */
  public Long getPositiveTransactionAmount() {
    return positiveTransactionAmount;
  }

  /**
   * Sets the positive transaction amount.
   *
   * @param positiveTransactionAmount the new positive transaction amount
   */
  public void setPositiveTransactionAmount(Long positiveTransactionAmount) {
    this.positiveTransactionAmount =
        Objects.isNull(positiveTransactionAmount) ? 0L : positiveTransactionAmount;
  }

  /**
   * Gets the positive transaction type.
   *
   * @return the positive transaction type
   */
  public String getPositiveTransactionType() {
    return positiveTransactionType;
  }

  /**
   * Sets the positive transaction type.
   *
   * @param positiveTransactionType the new positive transaction type
   */
  public void setPositiveTransactionType(String positiveTransactionType) {
    this.positiveTransactionType = positiveTransactionType;
  }

  /**
   * Gets the positive sub type.
   *
   * @return the positive sub type
   */
  public String getPositiveSubType() {
    return positiveSubType;
  }

  /**
   * Sets the positive sub type.
   *
   * @param positiveSubType the new positive sub type
   */
  public void setPositiveSubType(String positiveSubType) {
    this.positiveSubType = positiveSubType;
  }

  /**
   * Gets the positive transaction status.
   *
   * @return the positive transaction status
   */
  public String getPositiveTransactionStatus() {
    return positiveTransactionStatus;
  }

  /**
   * Sets the positive transaction status.
   *
   * @param positiveTransactionStatus the new positive transaction status
   */
  public void setPositiveTransactionStatus(String positiveTransactionStatus) {
    this.positiveTransactionStatus = positiveTransactionStatus;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public Boolean getStatus() {
    return status;
  }

  /**
   * Sets the status.
   *
   * @param status the new status
   */
  public void setStatus(Boolean status) {
    this.status = status;
  }

  /**
   * Gets the group id.
   *
   * @return the group id
   */
  public Integer getGroupId() {
    return groupId;
  }

  /**
   * Sets the group id.
   *
   * @param groupId the new group id
   */
  public void setGroupId(Integer groupId) {
    this.groupId = Objects.isNull(groupId) ? 0 : groupId;
  }

  /**
   * Gets the first negative occurence date.
   *
   * @return the first negative occurence date
   */
  public Date getFirstNegativeOccurrenceDate() {
    return firstNegativeOccurrenceDate;
  }

  /**
   * Sets the first negative occurence date.
   *
   * @param firstNegativeOccurrenceDate the new first negative occurence date
   */
  public void setFirstNegativeOccurrenceDate(Date firstNegativeOccurrenceDate) {
    this.firstNegativeOccurrenceDate = firstNegativeOccurrenceDate;
  }

  /**
   * Gets the first negative balance amount.
   *
   * @return the first negative balance amount
   */
  public long getFirstNegativeBalanceAmount() {
    return firstNegativeBalanceAmount;
  }

  /**
   * Sets the first negative balance amount.
   *
   * @param firstNegativeBalanceAmount the new first negative balance amount
   */
  public void setFirstNegativeBalanceAmount(long firstNegativeBalanceAmount) {
    this.firstNegativeBalanceAmount =
        Objects.isNull(firstNegativeBalanceAmount) ? 0L : firstNegativeBalanceAmount;
  }

  /**
   * Gets the checks if is first occurence.
   *
   * @return the checks if is first occurence
   */
  public Boolean getIsFirstOccurence() {
    return isFirstOccurence;
  }

  /**
   * Sets the checks if is first occurence.
   *
   * @param isFirstOccurence the new checks if is first occurence
   */
  public void setIsFirstOccurence(Boolean isFirstOccurence) {
    this.isFirstOccurence = Objects.isNull(isFirstOccurence) ? false : isFirstOccurence;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public int getId() {
    return this.id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(int id) {
    this.id = id;
  }

  /**
   * Gets the negative occurrence date.
   *
   * @return the negative occurrence date
   */
  public Date getNegativeOccurrenceDate() {
    return this.negativeOccurrenceDate;
  }

  /**
   * Sets the negative occurrence date.
   *
   * @param negativeOccurrenceDate the new negative occurrence date
   */
  public void setNegativeOccurrenceDate(Date negativeOccurrenceDate) {
    this.negativeOccurrenceDate = negativeOccurrenceDate;
  }

  /**
   * Gets the adjustment date.
   *
   * @return the adjustment date
   */
  public Date getAdjustmentDate() {
    return this.adjustmentDate;
  }

  /**
   * Sets the adjustment date.
   *
   * @param adjustmentDate the new adjustment date
   */
  public void setAdjustmentDate(Date adjustmentDate) {
    this.adjustmentDate = adjustmentDate;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return this.playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = Objects.isNull(playerId) ? 0 : playerId;
  }

  /**
   * Gets the operator id.
   *
   * @return the operatorId
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the operatorId to set
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the agent id.
   *
   * @return the agent id
   */
  public Integer getAgentId() {
    return this.agentId;
  }

  /**
   * Sets the agent id.
   *
   * @param agentId the new agent id
   */
  public void setAgentId(Integer agentId) {
    this.agentId = Objects.isNull(agentId) ? 0 : agentId;
  }

  /**
   * Gets the wallet.
   *
   * @return the wallet
   */
  public String getWallet() {
    return this.wallet;
  }

  /**
   * Sets the wallet.
   *
   * @param wallet the new wallet
   */
  public void setWallet(String wallet) {
    this.wallet = wallet;
  }

  /**
   * Gets the write off status.
   *
   * @return the write off status
   */
  public String getWriteOffStatus() {
    return this.writeOffStatus;
  }

  /**
   * Sets the write off status.
   *
   * @param writeOffStatus the new write off status
   */
  public void setWriteOffStatus(String writeOffStatus) {
    this.writeOffStatus = writeOffStatus;
  }

  /**
   * Gets the negative balance amount.
   *
   * @return the negative balance amount
   */
  public long getNegativeBalanceAmount() {
    return this.negativeBalanceAmount;
  }

  /**
   * Sets the negative balance amount.
   *
   * @param negativeBalanceAmount the new negative balance amount
   */
  public void setNegativeBalanceAmount(long negativeBalanceAmount) {
    this.negativeBalanceAmount = Objects.isNull(negativeBalanceAmount) ? 0L : negativeBalanceAmount;
  }

  /**
   * Gets the adjustment amount.
   *
   * @return the adjustment amount
   */
  public long getAdjustmentAmount() {
    return this.adjustmentAmount;
  }

  /**
   * Sets the adjustment amount.
   *
   * @param adjustmentAmount the new adjustment amount
   */
  public void setAdjustmentAmount(long adjustmentAmount) {
    this.adjustmentAmount = Objects.isNull(adjustmentAmount) ? 0L : adjustmentAmount;
  }

  /**
   * Gets the adjustment comments.
   *
   * @return the adjustment comments
   */
  public String getAdjustmentComments() {
    return this.adjustmentComments;
  }

  /**
   * Sets the adjustment comments.
   *
   * @param adjustmentComments the new adjustment comments
   */
  public void setAdjustmentComments(String adjustmentComments) {
    this.adjustmentComments = adjustmentComments;
  }
}
