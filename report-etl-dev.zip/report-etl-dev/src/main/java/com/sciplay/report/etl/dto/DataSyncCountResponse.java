package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public final class DataSyncCountResponse {

  /** The meta. */
  private List<DataSyncCountResponseData> statistics;

  public List<DataSyncCountResponseData> getStatistics() {
    return statistics;
  }

  public void setStatistics(List<DataSyncCountResponseData> statistics) {
    this.statistics = statistics;
  }
}
