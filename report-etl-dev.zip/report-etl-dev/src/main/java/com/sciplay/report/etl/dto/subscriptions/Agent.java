package com.sciplay.report.etl.dto.subscriptions;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** The Class Meta. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Agent {

  /** The id. */
  private Integer id;

  /** The loginIp. */
  private String loginIp;

  /** The sessionId. */
  private String sessionId;

  /** @return the id */
  public Integer getId() {
    return id;
  }

  /** @param id the id to set */
  public void setId(Integer id) {
    this.id = id;
  }

  /** @return the loginIp */
  public String getLoginIp() {
    return loginIp;
  }

  /** @param loginIp the loginIp to set */
  public void setLoginIp(String loginIp) {
    this.loginIp = loginIp;
  }

  /** @return the sessionId */
  public String getSessionId() {
    return sessionId;
  }

  /** @param sessionId the sessionId to set */
  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }
}
