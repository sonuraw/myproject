package com.sciplay.report.etl.Entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class SubscriptionFundingFailureEntity. */
@Table(name = "SubscriptionFundingFailure")
@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
public class SubscriptionFundingFailureEntity implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The player id. */
  @Id
  @Column(name = "PlayerId")
  private Integer playerId;

  /** The operator id. */
  @Id
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The subscription id. */
  @Id
  @Column(name = "SubscriptionId")
  private Long subscriptionId;

  /** The payment method id. */
  @Id
  @Column(name = "PaymentMethodId")
  private Integer paymentMethodId;

  /** The created at. */
  @Id private Date createdAt;

  /** The correlation id. */
  @Id private String correlationId;

  /** The agent id. */
  private Integer agentId;

  /** The login ip. */
  private String loginIp;

  /** The funding type. */
  private String fundingType;

  /** The reason. */
  @Column(name = "Reason", columnDefinition = "TEXT")
  private String reason;

  /** The transaction id. */
  private String transactionId;

  /** The error code. */
  private String errorCode;

  /** The transaction type. */
  private String transactionType;

  /** The amount. */
  private Long amount;

  /** The external id. */
  private String externalId;

  /** The account type. */
  private String accountType;

  /** The card type. */
  private String cardType;

  /** The card number last four. */
  private String cardNumberLastFour;

  /** The bank name. */
  private String bankName;

  /** The account number. */
  private String accountNumber;

  /** The author type. */
  private String authorType;

  /** The is national account. */
  private Boolean isNationalAccount;

  /** The status. */
  private String status;

  /**
   * Gets the checks if is national account.
   *
   * @return the checks if is national account
   */
  public Boolean getIsNationalAccount() {
    return isNationalAccount;
  }

  /**
   * Sets the checks if is national account.
   *
   * @param isNationalAccount the new checks if is national account
   */
  public void setIsNationalAccount(Boolean isNationalAccount) {
    if (isNationalAccount == null) {
      isNationalAccount = false;
    }
    this.isNationalAccount = isNationalAccount;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public String getStatus() {
    return status;
  }

  /**
   * Sets the status.
   *
   * @param status the new status
   */
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * Gets the external id.
   *
   * @return the external id
   */
  public String getExternalId() {
    return externalId;
  }

  /**
   * Sets the external id.
   *
   * @param externalId the new external id
   */
  public void setExternalId(String externalId) {
    this.externalId = externalId;
  }

  /**
   * Gets the account type.
   *
   * @return the account type
   */
  public String getAccountType() {
    return accountType;
  }

  /**
   * Sets the account type.
   *
   * @param accountType the new account type
   */
  public void setAccountType(String accountType) {
    this.accountType = accountType;
  }

  /**
   * Gets the card type.
   *
   * @return the card type
   */
  public String getCardType() {
    return cardType;
  }

  /**
   * Sets the card type.
   *
   * @param cardType the new card type
   */
  public void setCardType(String cardType) {
    this.cardType = cardType;
  }

  /**
   * Gets the card number last four.
   *
   * @return the card number last four
   */
  public String getCardNumberLastFour() {
    return cardNumberLastFour;
  }

  /**
   * Sets the card number last four.
   *
   * @param cardNumberLastFour the new card number last four
   */
  public void setCardNumberLastFour(String cardNumberLastFour) {
    this.cardNumberLastFour = cardNumberLastFour;
  }

  /**
   * Gets the bank name.
   *
   * @return the bank name
   */
  public String getBankName() {
    return bankName;
  }

  /**
   * Sets the bank name.
   *
   * @param bankName the new bank name
   */
  public void setBankName(String bankName) {
    this.bankName = bankName;
  }

  /**
   * Gets the account number.
   *
   * @return the account number
   */
  public String getAccountNumber() {
    return accountNumber;
  }

  /**
   * Sets the account number.
   *
   * @param accountNumber the new account number
   */
  public void setAccountNumber(String accountNumber) {
    this.accountNumber = accountNumber;
  }

  /**
   * Gets the author type.
   *
   * @return the author type
   */
  public String getAuthorType() {
    return authorType;
  }

  /**
   * Sets the author type.
   *
   * @param authorType the new author type
   */
  public void setAuthorType(String authorType) {
    this.authorType = authorType;
  }

  /**
   * Checks if is national account.
   *
   * @return true, if is national account
   */
  public boolean isNationalAccount() {
    return isNationalAccount;
  }

  /**
   * Sets the national account.
   *
   * @param isNationalAccount the new national account
   */
  public void setNationalAccount(boolean isNationalAccount) {
    this.isNationalAccount = isNationalAccount;
  }

  /**
   * Gets the transaction id.
   *
   * @return the transaction id
   */
  public String getTransactionId() {
    return transactionId;
  }

  /**
   * Sets the transaction id.
   *
   * @param transactionId the new transaction id
   */
  public void setTransactionId(String transactionId) {
    this.transactionId = transactionId;
  }

  /**
   * Gets the error code.
   *
   * @return the error code
   */
  public String getErrorCode() {
    return errorCode;
  }

  /**
   * Sets the error code.
   *
   * @param errorCode the new error code
   */
  public void setErrorCode(String errorCode) {
    this.errorCode = errorCode;
  }

  /**
   * Gets the transaction type.
   *
   * @return the transaction type
   */
  public String getTransactionType() {
    return transactionType;
  }

  /**
   * Sets the transaction type.
   *
   * @param transactionType the new transaction type
   */
  public void setTransactionType(String transactionType) {
    this.transactionType = transactionType;
  }

  /**
   * Gets the amount.
   *
   * @return the amount
   */
  public Long getAmount() {
    return amount;
  }

  /**
   * Sets the amount.
   *
   * @param amount the new amount
   */
  public void setAmount(Long amount) {
    if (amount == null) {
      amount = 0L;
    }
    this.amount = amount;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the subscription id.
   *
   * @return the subscription id
   */
  public Long getSubscriptionId() {
    return subscriptionId;
  }

  /**
   * Sets the subscription id.
   *
   * @param subscriptionId the new subscription id
   */
  public void setSubscriptionId(Long subscriptionId) {
    this.subscriptionId = subscriptionId;
  }

  /**
   * Gets the payment method id.
   *
   * @return the payment method id
   */
  public Integer getPaymentMethodId() {
    return paymentMethodId;
  }

  /**
   * Sets the payment method id.
   *
   * @param paymentMethodId the new payment method id
   */
  public void setPaymentMethodId(Integer paymentMethodId) {
    this.paymentMethodId = paymentMethodId;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  /**
   * Gets the correlation id.
   *
   * @return the correlation id
   */
  public String getCorrelationId() {
    return correlationId;
  }

  /**
   * Sets the correlation id.
   *
   * @param correlationId the new correlation id
   */
  public void setCorrelationId(String correlationId) {
    this.correlationId = correlationId;
  }

  /**
   * Gets the agent id.
   *
   * @return the agent id
   */
  public Integer getAgentId() {
    return agentId;
  }

  /**
   * Sets the agent id.
   *
   * @param agentId the new agent id
   */
  public void setAgentId(Integer agentId) {
    if (agentId == null) {
      agentId = 0;
    }
    this.agentId = agentId;
  }

  /**
   * Gets the login ip.
   *
   * @return the login ip
   */
  public String getLoginIp() {
    return loginIp;
  }

  /**
   * Sets the login ip.
   *
   * @param loginIp the new login ip
   */
  public void setLoginIp(String loginIp) {
    this.loginIp = loginIp;
  }

  /**
   * Gets the funding type.
   *
   * @return the funding type
   */
  public String getFundingType() {
    return fundingType;
  }

  /**
   * Sets the funding type.
   *
   * @param fundingType the new funding type
   */
  public void setFundingType(String fundingType) {
    this.fundingType = fundingType;
  }

  /**
   * Gets the reason.
   *
   * @return the reason
   */
  public String getReason() {
    return reason;
  }

  /**
   * Sets the reason.
   *
   * @param reason the new reason
   */
  public void setReason(String reason) {
    this.reason = reason;
  }
}
