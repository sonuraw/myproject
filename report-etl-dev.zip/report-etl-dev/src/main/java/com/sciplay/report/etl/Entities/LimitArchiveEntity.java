package com.sciplay.report.etl.Entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Entity
@Table(name = "LimitArchive")
@JsonIgnoreProperties(ignoreUnknown = true)
public class LimitArchiveEntity {

  @Id
  @Column(name = "RevisionNumber")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long revisionNumber;

  private Date revisionDate;
  private String revisionState;
  private String limitId;
  private String limitType;
  private String scopeType;

  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  private Integer playerId;
  private String categoryId;
  private String extent;
  private long value;
  private Date creationDate;
  private Date appliedFrom;
  private Date appliedTill;
  private String eventType;
  private String categoryType;
  private Integer author;
  private String authorType;

  public LimitArchiveEntity() {}

  public LimitArchiveEntity(
      int revisionNumber,
      Date revisionDate,
      String revisionState,
      String limitId,
      String limitType,
      String scopeType,
      String operatorId,
      Integer playerId,
      String categoryId,
      String extent,
      long value,
      Date creationDate,
      Date appliedFrom,
      Date appliedTill,
      Date plannedDate,
      String limitStatus,
      String eventType) {
    this.revisionNumber = revisionNumber;
    this.revisionDate = revisionDate;
    this.revisionState = revisionState;
    this.limitId = limitId;
    this.limitType = limitType;
    this.scopeType = scopeType;
    this.operatorId = operatorId;
    this.playerId = playerId;
    this.categoryId = categoryId;
    this.extent = extent;
    this.value = value;
    this.creationDate = creationDate;
    this.appliedFrom = appliedFrom;
    this.appliedTill = appliedTill;
    this.eventType = eventType;
  }

  public long getRevisionNumber() {
    return this.revisionNumber;
  }

  public void setRevisionNumber(long revisionNumber) {
    this.revisionNumber = revisionNumber;
  }

  public Date getRevisionDate() {
    return this.revisionDate;
  }

  public void setRevisionDate(Date revisionDate) {
    this.revisionDate = revisionDate;
  }

  public String getRevisionState() {
    return this.revisionState;
  }

  public void setRevisionState(String revisionState) {
    this.revisionState = revisionState;
  }

  public String getLimitId() {
    return this.limitId;
  }

  public void setLimitId(String limitId) {
    this.limitId = limitId;
  }

  public String getLimitType() {
    return this.limitType;
  }

  public void setLimitType(String limitType) {
    this.limitType = limitType;
  }

  public String getScopeType() {
    return this.scopeType;
  }

  public void setScopeType(String scopeType) {
    this.scopeType = scopeType;
  }

  public String getOperatorId() {
    return this.operatorId;
  }

  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  public Integer getPlayerId() {
    return this.playerId;
  }

  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  public String getCategoryId() {
    return this.categoryId;
  }

  public void setCategoryId(String categoryId) {
    this.categoryId = categoryId;
  }

  public String getExtent() {
    return this.extent;
  }

  public void setExtent(String extent) {
    this.extent = extent;
  }

  public long getValue() {
    return this.value;
  }

  public void setValue(long value) {
    this.value = value;
  }

  public Date getCreationDate() {
    return this.creationDate;
  }

  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  public Date getAppliedFrom() {
    return this.appliedFrom;
  }

  public void setAppliedFrom(Date appliedFrom) {
    this.appliedFrom = appliedFrom;
  }

  public Date getAppliedTill() {
    return this.appliedTill;
  }

  public void setAppliedTill(Date appliedTill) {
    this.appliedTill = appliedTill;
  }

  public String getEventType() {
    return this.eventType;
  }

  public void setEventType(String eventType) {
    this.eventType = eventType;
  }

  /** @return the categoryType */
  public String getCategoryType() {
    return categoryType;
  }

  /** @param categoryType the categoryType to set */
  public void setCategoryType(String categoryType) {
    this.categoryType = categoryType;
  }

  /** @return the author */
  public Integer getAuthor() {
    return author;
  }

  /** @param author the author to set */
  public void setAuthor(Integer author) {
    this.author = author;
  }

  /** @return the authorType */
  public String getAuthorType() {
    return authorType;
  }

  /** @param authorType the authorType to set */
  public void setAuthorType(String authorType) {
    this.authorType = authorType;
  }
}
