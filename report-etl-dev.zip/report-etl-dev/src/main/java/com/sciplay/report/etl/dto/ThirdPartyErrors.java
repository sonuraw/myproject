package com.sciplay.report.etl.dto;

import java.util.ArrayList;

/** The Class Data. */
public class ThirdPartyErrors {

  /** The type. */
  private ArrayList<ThirdPartyErrorDetails> errors;

  /** @return the errors */
  public ArrayList<ThirdPartyErrorDetails> getErrors() {
    return errors;
  }

  /** @param errors the errors to set */
  public void setErrors(ArrayList<ThirdPartyErrorDetails> errors) {
    this.errors = errors;
  }
}
