package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** The Class Meta. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class IhubAlertMeta {

  /** The operator id. */
  private String operatorId;

  /** The created at. */
  private String createdAt;

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public String getCreatedAt() {
    return createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }
}
