package com.sciplay.report.etl.dto;

import com.sciplay.report.etl.ReportEtlContext;
import java.io.IOException;

/** @author salman */
public class WagerMessage {

  private Meta meta;

  private WagerData data;

  public WagerData getData() {
    return data;
  }

  public void setData(WagerData data) {
    this.data = data;
  }

  public String getJsonString() throws IOException {
    return ReportEtlContext.getInstance().getObjectMapper().writeValueAsString(this);
  }

  public Meta getMeta() {
    return meta;
  }

  public void setMeta(Meta meta) {
    this.meta = meta;
  }
}
