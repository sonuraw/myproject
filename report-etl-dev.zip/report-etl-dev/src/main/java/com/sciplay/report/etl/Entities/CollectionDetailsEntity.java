package com.sciplay.report.etl.Entities;

import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class CollectionDetailsId. */
@Entity
@Table(name = "CollectionDetails")
public class CollectionDetailsEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The id. */
  @Id
  @Column(name = "Id")
  private String id;

  /** The type. */
  private String type;

  /** The name. */
  private String name;

  /** Instantiates a new collection details id. */
  public CollectionDetailsEntity() {}

  /**
   * Instantiates a new collection details id.
   *
   * @param id the id
   * @param type the type
   * @param name the name
   */
  public CollectionDetailsEntity(String id, String type, String name) {
    this.id = id;
    this.type = type;
    this.name = name;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  private String getId() {
    return this.id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  private String getType() {
    return this.type;
  }

  /**
   * Sets the type.
   *
   * @param type the new type
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the name.
   *
   * @return the name
   */
  public String getName() {
    return this.name;
  }

  /**
   * Sets the name.
   *
   * @param name the new name
   */
  public void setName(String name) {
    this.name = name;
  }

  /*
   * (non-Javadoc)
   *
   * @see java.lang.Object#equals(java.lang.Object)
   */
  public boolean equals(Object other) {
    if ((this == other)) {
      return true;
    }

    if ((other == null)) {
      return false;
    }
    if (!(other instanceof CollectionDetailsEntity)) {
      return false;
    }

    CollectionDetailsEntity castOther = (CollectionDetailsEntity) other;

    return ((Objects.equals(this.getId(), castOther.getId()))
            || (this.getId() != null
                && castOther.getId() != null
                && this.getId().equals(castOther.getId())))
        && ((Objects.equals(this.getType(), castOther.getType()))
            || (this.getType() != null
                && castOther.getType() != null
                && this.getType().equals(castOther.getType())))
        && ((Objects.equals(this.getName(), castOther.getName()))
            || (this.getName() != null
                && castOther.getName() != null
                && this.getName().equals(castOther.getName())));
  }

  /*
   * (non-Javadoc)
   *
   * @see java.lang.Object#hashCode()
   */
  public int hashCode() {
    int result = 17;

    result = 37 * result + (getId() == null ? 0 : this.getId().hashCode());
    result = 37 * result + (getType() == null ? 0 : this.getType().hashCode());
    result = 37 * result + (getName() == null ? 0 : this.getName().hashCode());
    return result;
  }
}
