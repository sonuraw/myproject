package com.sciplay.report.etl.dto;

/** The Class Author. */
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sciplay.report.etl.Entities.PlayerTranEntity;
import com.sciplay.report.etl.Entities.WagerEntity;
import com.sciplay.report.etl.Entities.WinningEntity;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GviUpdateTran {

  /** The gviPlayerTran. */
  private PlayerTranEntity gviPlayerTran;

  /** The wager. */
  private WagerEntity wager;

  /** The winning. */
  private WinningEntity winning;

  /** @return the gviPlayerTran */
  public PlayerTranEntity getGviPlayerTran() {
    return gviPlayerTran;
  }

  /** @param gviPlayerTran the gviPlayerTran to set */
  public void setGviPlayerTran(PlayerTranEntity gviPlayerTran) {
    this.gviPlayerTran = gviPlayerTran;
  }

  /** @return the wager */
  public WagerEntity getWager() {
    return wager;
  }

  /** @param wager the wager to set */
  public void setWager(WagerEntity wager) {
    this.wager = wager;
  }

  /** @return the winning */
  public WinningEntity getWinning() {
    return winning;
  }

  /** @param winning the winning to set */
  public void setWinning(WinningEntity winning) {
    this.winning = winning;
  }
}
