package com.sciplay.report.etl.Entities;

import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class GameDetailsEntity. */
@Entity
@Table(name = "GameDetails")
public class GameDetailsEntity {

  /** The Game id. */
  @Id private Integer gameId;

  /** The ExternalGameId. */
  private String externalGameID;

  /** The Game type id. */
  private Integer gameTypeId;

  /** The Game type. */
  private String gameType;

  /** The Game provider id. */
  private String gameProviderId;

  /** The Game provider. */
  private String gameProvider;

  /** The Category id. */
  private Integer categoryId;

  /** The Category. */
  private String category;

  /** The Sub category id. */
  private Integer subCategoryId;

  /** The Sub category. */
  private String subCategory;

  /** The Game. */
  private String game;

  /** The Operator id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The Channel. */
  private String channel;

  /** The Status. */
  private Boolean status;

  /** The Theoretical payout percentage. */
  private int theoreticalPayoutPercentage;

  /** The Tax percentage. */
  private int taxPercentage;

  /** The Is deleted. */
  private boolean isDeleted = false;

  /** The subscription available. */
  private Boolean subscriptionAvailable;

  /** Instantiates a new game details entity. */
  public GameDetailsEntity() {}

  /**
   * Instantiates a new game details entity.
   *
   * @param gameTypeId the game type id
   * @param externalGameID the external game ID
   * @param gameType the game type
   * @param gameProviderId the game provider id
   * @param gameProvider the game provider
   * @param categoryId the category id
   * @param category the category
   * @param subCategoryId the sub category id
   * @param subCategory the sub category
   * @param gameId the game id
   * @param game the game
   * @param operatorId the operator id
   * @param channel the channel
   * @param status the status
   * @param theoreticalPayoutPercentage the theoretical payout percentage
   * @param taxPercentage the tax percentage
   * @param subscriptionAvailable the subscription available
   */
  public GameDetailsEntity(
      Integer gameTypeId,
      String externalGameID,
      String gameType,
      String gameProviderId,
      String gameProvider,
      Integer categoryId,
      String category,
      Integer subCategoryId,
      String subCategory,
      Integer gameId,
      String game,
      String operatorId,
      String channel,
      Boolean status,
      Integer theoreticalPayoutPercentage,
      Integer taxPercentage,
      Boolean subscriptionAvailable) {
    this.gameTypeId = Objects.isNull(gameTypeId) ? 0 : gameTypeId;
    this.gameType = gameType;
    this.gameProviderId = gameProviderId;
    this.gameProvider = gameProvider;
    this.categoryId = Objects.isNull(categoryId) ? 0 : categoryId;
    this.category = category;
    this.subCategoryId = Objects.isNull(subCategoryId) ? 0 : subCategoryId;
    this.subCategory = subCategory;
    this.gameId = gameId;
    this.externalGameID = externalGameID;
    this.game = game;
    this.operatorId = operatorId;
    this.channel = channel;
    this.status = Objects.isNull(status) ? false : status;
    this.theoreticalPayoutPercentage =
        Objects.isNull(theoreticalPayoutPercentage) ? 0 : theoreticalPayoutPercentage;
    this.taxPercentage = Objects.isNull(taxPercentage) ? 0 : taxPercentage;
    this.subscriptionAvailable =
        Objects.isNull(subscriptionAvailable) ? false : subscriptionAvailable;
  }

  /**
   * Gets the subscription available.
   *
   * @return the subscription available
   */
  public Boolean getSubscriptionAvailable() {
    return subscriptionAvailable;
  }

  /**
   * Sets the subscription available.
   *
   * @param subscriptionAvailable the new subscription available
   */
  public void setSubscriptionAvailable(Boolean subscriptionAvailable) {
    this.subscriptionAvailable =
        Objects.isNull(subscriptionAvailable) ? false : subscriptionAvailable;
  }

  /**
   * Checks if is checks if is deleted.
   *
   * @return true, if is checks if is deleted
   */
  public boolean isIsDeleted() {
    return isDeleted;
  }

  /**
   * Sets the checks if is deleted.
   *
   * @param isDeleted the new checks if is deleted
   */
  public void setIsDeleted(Boolean isDeleted) {
    this.isDeleted = Objects.isNull(isDeleted) ? false : isDeleted;
  }

  /**
   * Gets the game type id.
   *
   * @return the game type id
   */
  public Integer getGameTypeId() {
    return this.gameTypeId;
  }

  /**
   * Sets the game type id.
   *
   * @param gameTypeId the new game type id
   */
  public void setGameTypeId(Integer gameTypeId) {
    this.gameTypeId = Objects.isNull(gameTypeId) ? 0 : gameTypeId;
  }

  /**
   * Gets the game type.
   *
   * @return the game type
   */
  public String getGameType() {
    return this.gameType;
  }

  /**
   * Sets the game type.
   *
   * @param gameType the new game type
   */
  public void setGameType(String gameType) {
    this.gameType = gameType;
  }

  /**
   * Gets the game provider id.
   *
   * @return the game provider id
   */
  public String getGameProviderId() {
    return this.gameProviderId;
  }

  /**
   * Sets the game provider id.
   *
   * @param gameProviderId the new game provider id
   */
  public void setGameProviderId(String gameProviderId) {
    this.gameProviderId = gameProviderId;
  }

  /**
   * Gets the game provider.
   *
   * @return the game provider
   */
  public String getGameProvider() {
    return this.gameProvider;
  }

  /**
   * Sets the game provider.
   *
   * @param gameProvider the new game provider
   */
  public void setGameProvider(String gameProvider) {
    this.gameProvider = gameProvider;
  }

  /**
   * Gets the category id.
   *
   * @return the category id
   */
  public Integer getCategoryId() {
    return this.categoryId;
  }

  /**
   * Sets the category id.
   *
   * @param categoryId the new category id
   */
  public void setCategoryId(Integer categoryId) {
    this.categoryId = Objects.isNull(categoryId) ? 0 : categoryId;
  }

  /**
   * Gets the category.
   *
   * @return the category
   */
  public String getCategory() {
    return this.category;
  }

  /**
   * Sets the category.
   *
   * @param category the new category
   */
  public void setCategory(String category) {
    this.category = category;
  }

  /**
   * Gets the sub category id.
   *
   * @return the sub category id
   */
  public Integer getSubCategoryId() {
    return this.subCategoryId;
  }

  /**
   * Sets the sub category id.
   *
   * @param subCategoryId the new sub category id
   */
  public void setSubCategoryId(Integer subCategoryId) {
    this.subCategoryId = Objects.isNull(subCategoryId) ? 0 : subCategoryId;
  }

  /**
   * Gets the sub category.
   *
   * @return the sub category
   */
  public String getSubCategory() {
    return this.subCategory;
  }

  /**
   * Sets the sub category.
   *
   * @param subCategory the new sub category
   */
  public void setSubCategory(String subCategory) {
    this.subCategory = subCategory;
  }

  /**
   * Gets the game id.
   *
   * @return the game id
   */
  public Integer getGameId() {
    return this.gameId;
  }

  /**
   * Sets the game id.
   *
   * @param gameId the new game id
   */
  public void setGameId(Integer gameId) {
    this.gameId = gameId;
  }

  /**
   * Gets the game id.
   *
   * @return the game id
   */
  public String getExternalGameID() {
    return this.externalGameID;
  }

  /**
   * Sets the game id.
   *
   * @param externalGameID the new external game ID
   */
  public void setExternalGameID(String externalGameID) {
    this.externalGameID = externalGameID;
  }

  /**
   * Gets the game.
   *
   * @return the game
   */
  public String getGame() {
    return this.game;
  }

  /**
   * Sets the game.
   *
   * @param game the new game
   */
  public void setGame(String game) {
    this.game = game;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return this.operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the channel.
   *
   * @return the channel
   */
  public String getChannel() {
    return this.channel;
  }

  /**
   * Sets the channel.
   *
   * @param channel the new channel
   */
  public void setChannel(String channel) {
    this.channel = channel;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public Boolean getStatus() {
    return this.status;
  }

  /**
   * Sets the status.
   *
   * @param status the new status
   */
  public void setStatus(Boolean status) {
    this.status = Objects.isNull(status) ? false : status;
  }

  /**
   * Gets the theoretical payout percentage.
   *
   * @return the theoretical payout percentage
   */
  public int getTheoreticalPayoutPercentage() {
    return this.theoreticalPayoutPercentage;
  }

  /**
   * Sets the theoretical payout percentage.
   *
   * @param theoreticalPayoutPercentage the new theoretical payout percentage
   */
  public void setTheoreticalPayoutPercentage(Integer theoreticalPayoutPercentage) {
    this.theoreticalPayoutPercentage =
        Objects.isNull(theoreticalPayoutPercentage) ? 0 : theoreticalPayoutPercentage;
  }

  /**
   * Gets the tax percentage.
   *
   * @return the tax percentage
   */
  public int getTaxPercentage() {
    return this.taxPercentage;
  }

  /**
   * Sets the tax percentage.
   *
   * @param taxPercentage the new tax percentage
   */
  public void setTaxPercentage(Integer taxPercentage) {
    this.taxPercentage = Objects.isNull(taxPercentage) ? 0 : taxPercentage;
  }
}
