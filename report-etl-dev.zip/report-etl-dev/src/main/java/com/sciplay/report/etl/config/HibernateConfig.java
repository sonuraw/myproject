package com.sciplay.report.etl.config;

public class HibernateConfig {

  private String url;
  private String user;
  private String password;
  private String minSize;
  private String maxSize;
  private int borrowTimeout;
  private int maxIdleTime;
  private String validationQuery;
  private String schemaValidateOption;
  private int xaRollbackInterval;
  private long xaRollbackCheckInterval;

  public HibernateConfig() {}

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getUser() {
    return user;
  }

  public void setUser(String user) {
    this.user = user;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getMinSize() {
    return minSize;
  }

  public void setMinSize(String minSize) {
    this.minSize = minSize;
  }

  public String getMaxSize() {
    return maxSize;
  }

  public void setMaxSize(String maxSize) {
    this.maxSize = maxSize;
  }

  public int getBorrowTimeout() {
    return borrowTimeout;
  }

  public void setBorrowTimeout(int borrowTimeout) {
    this.borrowTimeout = borrowTimeout;
  }

  public int getMaxIdleTime() {
    return maxIdleTime;
  }

  public void setMaxIdleTime(int maxIdleTime) {
    this.maxIdleTime = maxIdleTime;
  }

  public String getValidationQuery() {
    return validationQuery;
  }

  public void setValidationQuery(String validationQuery) {
    this.validationQuery = validationQuery;
  }

  public String getSchemaValidateOption() {
    return schemaValidateOption;
  }

  public void setSchemaValidateOption(String schemaValidateOption) {
    this.schemaValidateOption = schemaValidateOption;
  }

  public int getXaRollbackInterval() {
    return xaRollbackInterval;
  }

  public void setXaRollbackInterval(int xaRollbackInterval) {
    this.xaRollbackInterval = xaRollbackInterval;
  }

  public long getXaRollbackCheckInterval() {
    return xaRollbackCheckInterval;
  }

  public void setXaRollbackCheckInterval(long xaRollbackCheckInterval) {
    this.xaRollbackCheckInterval = xaRollbackCheckInterval;
  }
}
