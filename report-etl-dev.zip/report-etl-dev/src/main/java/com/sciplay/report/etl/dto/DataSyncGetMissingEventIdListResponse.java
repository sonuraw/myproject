package com.sciplay.report.etl.dto;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

@Produces("application/json")
@Consumes("application/json")
public final class DataSyncGetMissingEventIdListResponse {

  private List<String> eventIdList;
  private String serviceName;

  public List<String> getEventIdList() {
    return eventIdList;
  }

  public void setEventIdList(List<String> missingIdList) {
    this.eventIdList = missingIdList;
  }

  /** @return the serviceName */
  public String getServiceName() {
    return serviceName;
  }

  /** @param serviceName the serviceName to set */
  public void setServiceName(String serviceName) {
    this.serviceName = serviceName;
  }
}
