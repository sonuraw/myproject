package com.sciplay.report.etl;

import io.dropwizard.lifecycle.Managed;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XaRollBack implements Managed {
  private static final Logger LOG = LoggerFactory.getLogger(XaRollBack.class);
  private static XaRollBack instance = new XaRollBack();

  public static XaRollBack getInstance() {
    return instance;
  }

  public static void setInstance(XaRollBack instance) {
    XaRollBack.instance = instance;
  }

  @Override
  public void start() throws Exception {
    new Thread(
            new Runnable() {
              @Override
              public void run() {
                while (true) {
                  try {
                    if (ReportEtlContext.isHibernateInitialized()) {
                      doXaRollBack();
                    }
                    Thread.sleep(
                        (ReportEtlContext.getInstance()
                                .getReportEtlServiceConfig()
                                .getHibernateConfig()
                                .getXaRollbackCheckInterval())
                            * 60
                            * 1000);
                  } catch (InterruptedException e) {
                    LOG.error(e.getMessage());
                  }
                }
              }
            })
        .start();
  }

  private void doXaRollBack() {
    Connection con = null;
    Statement stmt = null;
    CallableStatement statement = null;
    try {
      Class.forName("com.mysql.cj.jdbc.Driver");
      con =
          DriverManager.getConnection(
              ReportEtlContext.getInstance()
                  .getReportEtlServiceConfig()
                  .getHibernateConfig()
                  .getUrl(),
              ReportEtlContext.getInstance()
                  .getReportEtlServiceConfig()
                  .getHibernateConfig()
                  .getUser(),
              ReportEtlContext.getInstance()
                  .getReportEtlServiceConfig()
                  .getHibernateConfig()
                  .getPassword());
      stmt = con.createStatement();
      ResultSet rs = stmt.executeQuery("XA RECOVER");
      StringBuilder sb = new StringBuilder();
      while (rs.next()) {
        sb.append("Select ")
            .append(rs.getInt(1))
            .append(" as formatID, ")
            .append(rs.getInt(2))
            .append(" as gtrid_length, ")
            .append(rs.getInt(3))
            .append(" as bqual_length, '")
            .append(rs.getString(4))
            .append("' as data UNION ");
      }
      rs.close();
      stmt.close();
      if (sb.toString().length() > 0) {
        String finalStr = sb.toString().substring(0, sb.toString().length() - 6);
        statement = con.prepareCall("{call XA_Rollback_TranId(?, ?, ?)}");

        statement.registerOutParameter(3, Types.VARCHAR);

        statement.setString(1, finalStr);
        statement.setInt(
            2,
            ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getHibernateConfig()
                .getXaRollbackInterval());

        statement.execute();
        String toRollBack = statement.getObject(3, String.class);
        statement.close();
        String[] arrOfStr = toRollBack.split(";");
        if (toRollBack.length() > 0 && arrOfStr.length > 0) {
          LOG.debug("XA ROLLBACK for : " + toRollBack);
          for (String a : arrOfStr) {
            try {
              stmt = con.createStatement();
              stmt.executeQuery(a);
            } catch (Exception ex) {
              LOG.error("XA ROLLBACK Error for " + a);
            } finally {
              if (stmt != null) {
                try {
                  stmt.close();
                } catch (SQLException e) {
                  LOG.error(e.toString());
                }
              }
            }
          }
        } else {
          LOG.debug("No rows obtained for xa rollback on interval based check");
        }
      } else {
        LOG.debug("No rows obtained in XA RECOVER");
      }
    } catch (Exception e) {
      LOG.error(e.toString());
    } finally {
      if (statement != null) {
        try {
          statement.close();
        } catch (SQLException e) {
          LOG.error(e.toString());
        }
      }
      if (stmt != null) {
        try {
          stmt.close();
        } catch (SQLException e) {
          LOG.error(e.toString());
        }
      }

      if (con != null) {
        try {
          con.close();
        } catch (SQLException e) {
          LOG.error(e.toString());
        }
      }
    }
  }

  @Override
  public void stop() throws Exception {}
}
