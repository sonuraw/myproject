package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ProcessErrorRequestContainer {

  private MessageParams params;

  /** @return the params */
  @JsonProperty("Params")
  public MessageParams getParams() {
    return params;
  }

  /** @param params the params to set */
  public void setParams(MessageParams params) {
    this.params = params;
  }
}
