package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.ArrayList;

/** The Class ExcludedPlayerRegistrationAttempt. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExcludedPlayerRegistrationAttempt {

  /** The identifications. */
  private ArrayList<Identification> identifications = new ArrayList<>();
  /** The first name. */
  private String firstName;
  /** The last name. */
  private String lastName;

  /**
   * Gets the first name.
   *
   * @return the first name
   */
  public String getFirstName() {
    return firstName;
  }

  /**
   * Sets the first name.
   *
   * @param firstName the new first name
   */
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  /**
   * Gets the last name.
   *
   * @return the last name
   */
  public String getLastName() {
    return lastName;
  }

  /**
   * Sets the last name.
   *
   * @param lastName the new last name
   */
  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  /**
   * Gets the identifications.
   *
   * @return the identifications
   */
  public ArrayList<Identification> getIdentifications() {
    return identifications;
  }

  /**
   * Sets the identifications.
   *
   * @param identifications the new identifications
   */
  public void setIdentifications(ArrayList<Identification> identifications) {
    this.identifications = identifications;
  }
}
