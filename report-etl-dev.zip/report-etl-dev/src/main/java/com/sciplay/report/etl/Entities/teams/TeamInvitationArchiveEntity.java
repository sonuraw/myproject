package com.sciplay.report.etl.Entities.teams;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** @author salman */
@Entity
@Table(name = "TeamInvitationArchive")
public class TeamInvitationArchiveEntity {

  @Id
  @Column(name = "RevisionNumber")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long revisionNumber;

  @Column(name = "RevisionDate")
  private Date revisionDate;

  @Column(name = "RevisionState")
  private String revisionState;

  @Column(name = "Id")
  private String id;

  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  @Column(name = "Email")
  private String email;

  @Column(name = "AcceptHash", columnDefinition = "longtext")
  private String acceptHash;

  @Column(name = "DeclineHash", columnDefinition = "longtext")
  private String declineHash;

  @Column(name = "TeamId")
  private String teamId;

  @Column(name = "PlayerId")
  private Integer playerId;

  @Column(
      name = "Status",
      columnDefinition = "enum('SENT','ACCEPTED','DECLINED','EXPIRED','INVALID','S','A','D')")
  private String status;

  @Column(name = "AuthorId")
  private Integer authorId;

  @Column(name = "AuthorIp")
  private String authorIp;

  @Column(name = "AuthorSessionId")
  private String authorSessionId;

  @Column(name = "CreatedAt")
  private Date createdAt;

  public TeamInvitationArchiveEntity() {}

  public TeamInvitationArchiveEntity(
      TeamInvitationEntity teamInvitationEntity, String revisionState) {
    id = teamInvitationEntity.getId();
    this.operatorId = teamInvitationEntity.getOperatorId();
    email = teamInvitationEntity.getEmail();
    this.acceptHash = teamInvitationEntity.getAcceptHash();
    this.declineHash = teamInvitationEntity.getDeclineHash();
    teamId = teamInvitationEntity.getTeamId();
    this.playerId = teamInvitationEntity.getPlayerId();
    status = teamInvitationEntity.getStatus();
    authorId = teamInvitationEntity.getAuthorId();
    authorIp = teamInvitationEntity.getAuthorIp();
    authorSessionId = teamInvitationEntity.getAuthorSessionId();
    createdAt = teamInvitationEntity.getCreatedAt();
    this.revisionDate = teamInvitationEntity.getUpdatedAt();
    this.revisionState = revisionState;
  }

  public long getRevisionNumber() {
    return revisionNumber;
  }

  public void setRevisionNumber(long revisionNumber) {
    this.revisionNumber = revisionNumber;
  }

  public Date getRevisionDate() {
    return revisionDate;
  }

  public void setRevisionDate(Date revisionDate) {
    this.revisionDate = revisionDate;
  }

  public String getRevisionState() {
    return revisionState;
  }

  public void setRevisionState(String revisionState) {
    this.revisionState = revisionState;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getOperatorId() {
    return operatorId;
  }

  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getAcceptHash() {
    return acceptHash;
  }

  public void setAcceptHash(String acceptHash) {
    this.acceptHash = acceptHash;
  }

  public String getDeclineHash() {
    return declineHash;
  }

  public void setDeclineHash(String declineHash) {
    this.declineHash = declineHash;
  }

  public String getTeamId() {
    return teamId;
  }

  public void setTeamId(String teamId) {
    this.teamId = teamId;
  }

  public Integer getPlayerId() {
    return playerId;
  }

  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public Integer getAuthorId() {
    return authorId;
  }

  public void setAuthorId(Integer authorId) {
    this.authorId = authorId;
  }

  public String getAuthorIp() {
    return authorIp;
  }

  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  public String getAuthorSessionId() {
    return authorSessionId;
  }

  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  public Date getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }
}
