package com.sciplay.report.etl.Entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** @author salman */
@Entity
@Table(name = "AgentProfileArchive")
public class AgentProfileArchiveEntity {

  @Column(name = "RevisionNumber")
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long revisionNumber;

  @Column(name = "RevisionDate")
  private Date revisionDate;

  @Column(name = "RevisionState")
  private String revisionState;

  @Column(name = "Id")
  private Integer id;

  @Column(name = "UserName")
  private String userName;

  @Column(name = "FirstName")
  private String firstName;

  @Column(name = "LastName")
  private String lastName;

  @Column(name = "Email")
  private String email;

  @Column(name = "Locale")
  private String locale;

  @Column(name = "jobTitle")
  private String jobTitle;

  @Column(name = "Status")
  private String status;

  @Column(name = "ValidFrom")
  private Date validFrom;

  @Column(name = "ValidTill")
  private Date validTill;

  @Column(name = "AuthorId")
  private Integer authorId;

  @Column(name = "AuthorIp")
  private String authorIp;

  @Column(name = "AuthorSessionId")
  private String authorSessionId;

  @Column(name = "CreatedAt")
  private Date createdAt;

  @Column(name = "LastLogin")
  private Date lastLogin;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getLocale() {
    return locale;
  }

  public void setLocale(String locale) {
    this.locale = locale;
  }

  public String getJobTitle() {
    return jobTitle;
  }

  public void setJobTitle(String jobTitle) {
    this.jobTitle = jobTitle;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public Date getValidFrom() {
    return validFrom;
  }

  public void setValidFrom(Date validFrom) {
    this.validFrom = validFrom;
  }

  public Date getValidTill() {
    return validTill;
  }

  public void setValidTill(Date validTill) {
    this.validTill = validTill;
  }

  public Integer getAuthorId() {
    return authorId;
  }

  public void setAuthorId(Integer authorId) {
    this.authorId = authorId;
  }

  public String getAuthorIp() {
    return authorIp;
  }

  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  public String getAuthorSessionId() {
    return authorSessionId;
  }

  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  public Date getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  public Date getLastLogin() {
    return lastLogin;
  }

  public void setLastLogin(Date lastLogin) {
    this.lastLogin = lastLogin;
  }

  public String getRevisionState() {
    return revisionState;
  }

  public void setRevisionState(String revisionState) {
    this.revisionState = revisionState;
  }

  public long getRevisionNumber() {
    return revisionNumber;
  }

  public void setRevisionNumber(long revisionNumber) {
    this.revisionNumber = revisionNumber;
  }

  public Date getRevisionDate() {
    return revisionDate;
  }

  public void setRevisionDate(Date revisionDate) {
    this.revisionDate = revisionDate;
  }
}
