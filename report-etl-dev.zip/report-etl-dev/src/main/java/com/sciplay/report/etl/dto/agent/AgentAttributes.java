package com.sciplay.report.etl.dto.agent;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentAttributes {

  @JsonProperty("username")
  private String userName;

  @JsonProperty("firstname")
  private String firstName;

  @JsonProperty("lastname")
  private String lastName;

  @JsonProperty("email")
  private String email;

  @JsonProperty("locale")
  private String locale;

  @JsonProperty("jobTitle")
  private String jobTitle;

  @JsonProperty("status")
  private String status;

  @JsonProperty("validFrom")
  private String validFrom;

  @JsonProperty("validTill")
  private String valdTill;

  @JsonProperty("agentId")
  private Integer agentId;

  @JsonProperty("credentials")
  private List<String> credentials;

  @JsonProperty("operators")
  private List<AgentOperator> operators;

  @JsonProperty("countries")
  private List<String> countries;

  @JsonProperty("ip")
  private String ip;

  @JsonProperty("reason")
  private String reason;

  @JsonProperty("endReason")
  private String endReason;

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getLocale() {
    return locale;
  }

  public void setLocale(String locale) {
    this.locale = locale;
  }

  public String getJobTitle() {
    return jobTitle;
  }

  public void setJobTitle(String jobTitle) {
    this.jobTitle = jobTitle;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getValidFrom() {
    return validFrom;
  }

  public void setValidFrom(String validFrom) {
    this.validFrom = validFrom;
  }

  public String getValdTill() {
    return valdTill;
  }

  public void setValdTill(String valdTill) {
    this.valdTill = valdTill;
  }

  public Integer getAgentId() {
    return agentId;
  }

  public void setAgentId(Integer agentId) {
    this.agentId = agentId;
  }

  public List<String> getCredentials() {
    return credentials;
  }

  public void setCredentials(List<String> credentials) {
    this.credentials = credentials;
  }

  public List<AgentOperator> getOperators() {
    return operators;
  }

  public void setOperators(List<AgentOperator> operators) {
    this.operators = operators;
  }

  public List<String> getCountries() {
    return countries;
  }

  public void setCountries(List<String> countries) {
    this.countries = countries;
  }

  public String getIp() {
    return ip;
  }

  public void setIp(String ip) {
    this.ip = ip;
  }

  public String getReason() {
    return reason;
  }

  public void setReason(String reason) {
    this.reason = reason;
  }

  public String getEndReason() {
    return endReason;
  }

  public void setEndReason(String endReason) {
    this.endReason = endReason;
  }
}
