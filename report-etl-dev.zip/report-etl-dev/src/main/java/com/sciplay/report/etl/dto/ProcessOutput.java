package com.sciplay.report.etl.dto;

import com.sciplay.report.etl.error.ErrorMessage;

public class ProcessOutput {

  private int statusCode;

  private ErrorMessage errorMessage;

  public ProcessOutput(int statusCode, ErrorMessage errorMessage) {
    this.errorMessage = errorMessage;
    this.statusCode = statusCode;
  }

  public int getStatusCode() {
    return statusCode;
  }

  public void setStatusCode(int statusCode) {
    this.statusCode = statusCode;
  }

  public ErrorMessage getErrorMessage() {
    return errorMessage;
  }

  public void setErrorMessage(ErrorMessage errorMessage) {
    this.errorMessage = errorMessage;
  }
}
