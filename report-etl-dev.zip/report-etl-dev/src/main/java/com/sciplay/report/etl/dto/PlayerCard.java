package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** The Class PlayerCard. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PlayerCard {

  /** The player id. */
  private Integer playerId;

  /** The number. */
  private String number;

  /** The reason. */
  private String reason;

  /** The expiration date. */
  private String expirationDate;

  /** The printed date. */
  private String printedDate;

  /** The cancel date. */
  private String cancelDate;

  /** The type. */
  private String type;

  /** The id. */
  private String id;

  /** The card number. */
  private String cardNumber;

  /** The status. */
  private String status;

  /**
   * Gets the id.
   *
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Gets the card number.
   *
   * @return the card number
   */
  public String getCardNumber() {
    return cardNumber;
  }

  /**
   * Sets the card number.
   *
   * @param cardNumber the new card number
   */
  public void setCardNumber(String cardNumber) {
    this.cardNumber = cardNumber;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public String getStatus() {
    return status;
  }

  /**
   * Sets the status.
   *
   * @param status the new status
   */
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Sets the type.
   *
   * @param type the new type
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the number.
   *
   * @return the number
   */
  public String getNumber() {
    return number;
  }

  /**
   * Sets the number.
   *
   * @param number the new number
   */
  public void setNumber(String number) {
    this.number = number;
  }

  /**
   * Gets the reason.
   *
   * @return the reason
   */
  public String getReason() {
    return reason;
  }

  /**
   * Sets the reason.
   *
   * @param reason the new reason
   */
  public void setReason(String reason) {
    this.reason = reason;
  }

  /**
   * Gets the expiration date.
   *
   * @return the expiration date
   */
  public String getExpirationDate() {
    return expirationDate;
  }

  /**
   * Sets the expiration date.
   *
   * @param expirationDate the new expiration date
   */
  public void setExpirationDate(String expirationDate) {
    this.expirationDate = expirationDate;
  }

  /**
   * Gets the printed date.
   *
   * @return the printed date
   */
  public String getPrintedDate() {
    return printedDate;
  }

  /**
   * Sets the printed date.
   *
   * @param printedDate the new printed date
   */
  public void setPrintedDate(String printedDate) {
    this.printedDate = printedDate;
  }

  /**
   * Gets the cancel date.
   *
   * @return the cancel date
   */
  public String getCancelDate() {
    return cancelDate;
  }

  /**
   * Sets the cancel date.
   *
   * @param cancelDate the new cancel date
   */
  public void setCancelDate(String cancelDate) {
    this.cancelDate = cancelDate;
  }
}
