package com.sciplay.report.etl.dto;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

@Produces("application/json")
@Consumes("application/json")
public final class DataSyncAllMessageProcessedResponse {

  /** The message. */
  private List<DataSyncMessageProcessedResponse> data;

  /** @return the data */
  public List<DataSyncMessageProcessedResponse> getData() {
    return data;
  }

  /** @param data the data to set */
  public void setData(List<DataSyncMessageProcessedResponse> data) {
    this.data = data;
  }
}
