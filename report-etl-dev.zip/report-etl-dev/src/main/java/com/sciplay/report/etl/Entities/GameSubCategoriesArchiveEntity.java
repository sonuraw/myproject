package com.sciplay.report.etl.Entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** Entity class for GameSubCategoriesArchive. */
@Entity
@Table(name = "GameSubCategoriesArchive")
public class GameSubCategoriesArchiveEntity {

  /** The revision number. */
  @Id
  @Column(name = "RevisionNumber")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long revisionNumber;

  /** The revision date. */
  private Date revisionDate;

  /** The revision state. */
  private String revisionState;

  /** The id. */
  private Integer id;

  /** The game category id. */
  private Integer gameCategoryId;

  /** The name. */
  private String name;

  /** The author id. */
  private Integer authorId;

  /** The author ip. */
  private String authorIp;

  /** The author session id. */
  private String authorSessionId;

  /** The created at. */
  private Date createdAt;

  /** The operator id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** Instantiates a new game sub categories archive entity. */
  public GameSubCategoriesArchiveEntity() {}

  /**
   * Instantiates a new game sub categories archive entity.
   *
   * @param revisionDate the revision date
   * @param revisionState the revision state
   * @param id the id
   * @param gameCategoryId the game category id
   * @param name the name
   * @param createdAt the created at
   */
  public GameSubCategoriesArchiveEntity(
      Date revisionDate,
      String revisionState,
      Integer id,
      Integer gameCategoryId,
      String name,
      Date createdAt) {
    this.revisionDate = revisionDate;
    this.revisionState = revisionState;
    this.id = id;
    this.gameCategoryId = gameCategoryId;
    this.name = name;
    this.createdAt = createdAt;
  }

  /**
   * Instantiates a new game sub categories archive entity.
   *
   * @param revisionState the revision state
   * @param id the id
   * @param gameCategoryId the game category id
   * @param name the name
   * @param authorId the author id
   * @param authorIp the author ip
   * @param authorSessionId the author session id
   * @param createdAt the created at
   * @param operatorId the operator id
   */
  public GameSubCategoriesArchiveEntity(
      String revisionState,
      Integer id,
      Integer gameCategoryId,
      String name,
      Integer authorId,
      String authorIp,
      String authorSessionId,
      Date createdAt,
      String operatorId,
      Date revisionDate) {
    this.revisionState = revisionState;
    this.id = id;
    this.gameCategoryId = gameCategoryId;
    this.name = name;
    this.authorId = authorId;
    this.authorIp = authorIp;
    this.authorSessionId = authorSessionId;
    this.createdAt = createdAt;
    this.operatorId = operatorId;
    this.revisionDate = revisionDate;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the revision number.
   *
   * @return the revision number
   */
  public long getRevisionNumber() {
    return this.revisionNumber;
  }

  /**
   * Sets the revision number.
   *
   * @param revisionNumber the new revision number
   */
  public void setRevisionNumber(long revisionNumber) {
    this.revisionNumber = revisionNumber;
  }

  /**
   * Gets the revision date.
   *
   * @return the revision date
   */
  public Date getRevisionDate() {
    return this.revisionDate;
  }

  /**
   * Sets the revision date.
   *
   * @param revisionDate the new revision date
   */
  public void setRevisionDate(Date revisionDate) {
    this.revisionDate = revisionDate;
  }

  /**
   * Gets the revision state.
   *
   * @return the revision state
   */
  public String getRevisionState() {
    return this.revisionState;
  }

  /**
   * Sets the revision state.
   *
   * @param revisionState the new revision state
   */
  public void setRevisionState(String revisionState) {
    this.revisionState = revisionState;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public Integer getId() {
    return this.id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(Integer id) {
    this.id = id;
  }

  /**
   * Gets the game category id.
   *
   * @return the game category id
   */
  public Integer getGameCategoryId() {
    return this.gameCategoryId;
  }

  /**
   * Sets the game category id.
   *
   * @param gameCategoryId the new game category id
   */
  public void setGameCategoryId(Integer gameCategoryId) {
    this.gameCategoryId = gameCategoryId;
  }

  /**
   * Gets the name.
   *
   * @return the name
   */
  public String getName() {
    return this.name;
  }

  /**
   * Sets the name.
   *
   * @param name the new name
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Gets the author id.
   *
   * @return the author id
   */
  public Integer getAuthorId() {
    return this.authorId;
  }

  /**
   * Sets the author id.
   *
   * @param authorId the new author id
   */
  public void setAuthorId(Integer authorId) {
    this.authorId = authorId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return this.authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return this.authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return this.createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }
}
