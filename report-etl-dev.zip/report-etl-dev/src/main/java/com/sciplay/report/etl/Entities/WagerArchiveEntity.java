package com.sciplay.report.etl.Entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.DynamicUpdate;

/** The Class WagerArchiveEntity. */
@Entity
@Table(name = "WagerArchive")
@DynamicUpdate
public class WagerArchiveEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The revision number. */
  @Column(name = "RevisionNumber")
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long revisionNumber;

  /** The revision date. */
  private Date revisionDate;

  /** The revision state. */
  private String revisionState;

  /** The id. */
  @Column(name = "Id")
  private long id;

  /** The event type. */
  private String eventType;

  /** The player id. */
  private Integer playerId;

  /** The wager set id. */
  private Long wagerSetId;

  /** The external wager id. */
  private String externalWagerId;

  /** The brand. */
  private String brand;

  /** The game id. */
  private Integer gameId;

  /** The external url. */
  private String externalUrl;

  /** The channel. */
  private String channel;

  /** The state. */
  @Column(
      name = "State",
      columnDefinition =
          "enum('STARTED', 'PLAYED', 'REFUNDED', 'CANCELLED', 'ROLLEDBACK', 'CORRECTED')")
  private String state;

  /** The updated date. */
  @Column(name = "UpdatedDate")
  private Date updatedDate;

  /** The creation date. */
  private Date creationDate;

  /** The external creation date. */
  private Date externalCreationDate;

  /** The value. */
  private long value;

  /** The notify win. */
  private boolean notifyWin;

  /** The round id. */
  private String roundId;

  /** The expected end date. */
  private Date expectedEndDate;

  /** The currency. */
  private String currency;

  /** The ip address. */
  private String ipAddress;

  /** The operatorId. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The SubscriptionId. */
  private Long subscriptionId;

  /** The Session id. */
  private String sessionId;

  /** The previousStatus. */
  @Column(
      name = "PreviousStatus",
      columnDefinition =
          "enum('STARTED', 'PLAYED', 'REFUNDED', 'CANCELLED', 'ROLLEDBACK', 'CORRECTED')")
  private String previousStatus;

  /** The is reprocessed. */
  private Boolean isReprocessed;

  /** The Reprocessed date. */
  private Date reprocessedDate;

  /** The is reConciled. */
  private Boolean isReConciled;

  /** The wager type. */
  private String wagerType;

  /** Below new variables got added as part of CR129 */
  @Column(name = "gameVariant")
  private String gameVariantArchive;

  @Column(name = "numberOfWagersInSet")
  private Byte numberOfWagersInSetArchive;

  @Column(name = " wagerNumberInSet")
  private Byte wagerNumberInSetArchive;

  /** Instantiates a new wager entity. */
  public WagerArchiveEntity() {}

  /**
   * Instantiates a new wager entity.
   *
   * @param id the id
   * @param eventType the event type
   * @param playerId the player id
   * @param brand the brand
   * @param gameId the game id
   * @param state the state
   * @param updatedDate the updated date
   * @param creationDate the creation date
   * @param externalCreationDate the external creation date
   * @param value the value
   * @param notifyWin the notify win
   * @param roundId the round id
   * @param currency the currency
   * @param ipAddress the ip address
   * @param operatorId the operatorId
   */
  public WagerArchiveEntity(
      long id,
      String eventType,
      Integer playerId,
      String brand,
      Integer gameId,
      String state,
      Date updatedDate,
      Date creationDate,
      Date externalCreationDate,
      long value,
      boolean notifyWin,
      String roundId,
      String currency,
      String ipAddress,
      String operatorId) {
    this.id = id;
    this.eventType = eventType;
    this.playerId = playerId;
    this.brand = brand;
    this.gameId = gameId;
    this.state = state;
    this.updatedDate = updatedDate;
    this.creationDate = creationDate;
    this.externalCreationDate = externalCreationDate;
    this.value = value;
    this.notifyWin = notifyWin;
    this.roundId = roundId;
    this.currency = currency;
    this.ipAddress = ipAddress;
    this.operatorId = operatorId;
  }

  /**
   * Instantiates a new wager entity.
   *
   * @param id the id
   * @param eventType the event type
   * @param playerId the player id
   * @param wagerSetId the wager set id
   * @param externalWagerId the external wager id
   * @param brand the brand
   * @param gameId the game id
   * @param type the type
   * @param externalUrl the external url
   * @param channel the channel
   * @param state the state
   * @param updatedDate the updated date
   * @param creationDate the creation date
   * @param externalCreationDate the external creation date
   * @param value the value
   * @param notifyWin the notify win
   * @param roundId the round id
   * @param expectedEndDate the expected end date
   */
  public WagerArchiveEntity(
      long id,
      String eventType,
      Integer playerId,
      Long wagerSetId,
      String externalWagerId,
      String brand,
      Integer gameId,
      String externalUrl,
      String channel,
      String state,
      Date updatedDate,
      Date creationDate,
      Date externalCreationDate,
      int value,
      boolean notifyWin,
      String roundId,
      Date expectedEndDate) {
    this.id = id;
    this.eventType = eventType;
    this.playerId = playerId;
    this.wagerSetId = wagerSetId;
    this.externalWagerId = externalWagerId;
    this.brand = brand;
    this.gameId = gameId;
    this.externalUrl = externalUrl;
    this.channel = channel;
    this.state = state;
    this.updatedDate = updatedDate;
    this.creationDate = creationDate;
    this.externalCreationDate = externalCreationDate;
    this.value = value;
    this.notifyWin = notifyWin;
    this.roundId = roundId;
    this.expectedEndDate = expectedEndDate;
  }

  /**
   * Gets the wager type.
   *
   * @return the wager type
   */
  public String getWagerType() {
    return wagerType;
  }

  /**
   * Sets the wager type.
   *
   * @param wagerType the new wager type
   */
  public void setWagerType(String wagerType) {
    this.wagerType = wagerType;
  }

  /**
   * Gets the checks if is reprocessed.
   *
   * @return the checks if is reprocessed
   */
  public Boolean getIsReprocessed() {
    return isReprocessed;
  }

  /**
   * Sets the checks if is reprocessed.
   *
   * @param isReprocessed the new checks if is reprocessed
   */
  public void setIsReprocessed(Boolean isReprocessed) {
    if (isReprocessed == null) {
      isReprocessed = false;
    }
    this.isReprocessed = isReprocessed;
  }

  /**
   * Gets the reprocessed date.
   *
   * @return the reprocessed date
   */
  public Date getReprocessedDate() {
    return reprocessedDate;
  }

  /**
   * Sets the reprocessed date.
   *
   * @param reprocessedDate the new reprocessed date
   */
  public void setReprocessedDate(Date reprocessedDate) {
    this.reprocessedDate = reprocessedDate;
  }

  /**
   * Gets the session id.
   *
   * @return the session id
   */
  public String getSessionId() {
    return sessionId;
  }

  /**
   * Sets the session id.
   *
   * @param sessionId the new session id
   */
  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  /**
   * Gets the revision number.
   *
   * @return the revision number
   */
  public long getRevisionNumber() {
    return revisionNumber;
  }

  /**
   * Sets the revision number.
   *
   * @param revisionNumber the new revision number
   */
  public void setRevisionNumber(long revisionNumber) {
    this.revisionNumber = revisionNumber;
  }

  /**
   * Gets the revision date.
   *
   * @return the revision date
   */
  public Date getRevisionDate() {
    return revisionDate;
  }

  /**
   * Sets the revision date.
   *
   * @param revisionDate the new revision date
   */
  public void setRevisionDate(Date revisionDate) {
    this.revisionDate = revisionDate;
  }

  /**
   * Gets the revision state.
   *
   * @return the revision state
   */
  public String getRevisionState() {
    return revisionState;
  }

  /**
   * Sets the revision state.
   *
   * @param revisionState the new revision state
   */
  public void setRevisionState(String revisionState) {
    this.revisionState = revisionState;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public long getId() {
    return this.id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(long id) {
    this.id = id;
  }

  /**
   * Gets the event type.
   *
   * @return the event type
   */
  public String getEventType() {
    return this.eventType;
  }

  /**
   * Sets the event type.
   *
   * @param eventType the new event type
   */
  public void setEventType(String eventType) {
    this.eventType = eventType;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return this.playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the wager set id.
   *
   * @return the wager set id
   */
  public Long getWagerSetId() {
    return this.wagerSetId;
  }

  /**
   * Sets the wager set id.
   *
   * @param wagerSetId the new wager set id
   */
  public void setWagerSetId(Long wagerSetId) {
    if (wagerSetId == null) {
      wagerSetId = 0L;
    }
    this.wagerSetId = wagerSetId;
  }

  /**
   * Gets the external wager id.
   *
   * @return the external wager id
   */
  public String getExternalWagerId() {
    return this.externalWagerId;
  }

  /**
   * Sets the external wager id.
   *
   * @param externalWagerId the new external wager id
   */
  public void setExternalWagerId(String externalWagerId) {
    this.externalWagerId = externalWagerId;
  }

  /**
   * Gets the brand.
   *
   * @return the brand
   */
  public String getBrand() {
    return this.brand;
  }

  /**
   * Sets the brand.
   *
   * @param brand the new brand
   */
  public void setBrand(String brand) {
    this.brand = brand;
  }

  /**
   * Gets the game id.
   *
   * @return the game id
   */
  public Integer getGameId() {
    return this.gameId;
  }

  /**
   * Sets the game id.
   *
   * @param gameId the new game id
   */
  public void setGameId(Integer gameId) {
    this.gameId = gameId;
  }

  /**
   * Gets the external url.
   *
   * @return the external url
   */
  public String getExternalUrl() {
    return this.externalUrl;
  }

  /**
   * Sets the external url.
   *
   * @param externalUrl the new external url
   */
  public void setExternalUrl(String externalUrl) {
    this.externalUrl = externalUrl;
  }

  /**
   * Gets the channel.
   *
   * @return the channel
   */
  public String getChannel() {
    return this.channel;
  }

  /**
   * Sets the channel.
   *
   * @param channel the new channel
   */
  public void setChannel(String channel) {
    this.channel = channel;
  }

  /**
   * Gets the state.
   *
   * @return the state
   */
  public String getState() {
    return this.state;
  }

  /**
   * Sets the state.
   *
   * @param state the new state
   */
  public void setState(String state) {
    this.state = state;
  }

  /**
   * Gets the updated date.
   *
   * @return the updated date
   */
  public Date getUpdatedDate() {
    return this.updatedDate;
  }

  /**
   * Sets the updated date.
   *
   * @param updatedDate the new updated date
   */
  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  /**
   * Gets the creation date.
   *
   * @return the creation date
   */
  public Date getCreationDate() {
    return this.creationDate;
  }

  /**
   * Sets the creation date.
   *
   * @param creationDate the new creation date
   */
  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  /**
   * Gets the external creation date.
   *
   * @return the external creation date
   */
  public Date getExternalCreationDate() {
    return this.externalCreationDate;
  }

  /**
   * Sets the external creation date.
   *
   * @param externalCreationDate the new external creation date
   */
  public void setExternalCreationDate(Date externalCreationDate) {
    this.externalCreationDate = externalCreationDate;
  }

  /**
   * Gets the value.
   *
   * @return the value
   */
  public long getValue() {
    return this.value;
  }

  /**
   * Sets the value.
   *
   * @param value the new value
   */
  public void setValue(long value) {
    this.value = value;
  }

  /**
   * Checks if is notify win.
   *
   * @return true, if is notify win
   */
  public boolean isNotifyWin() {
    return this.notifyWin;
  }

  /**
   * Sets the notify win.
   *
   * @param notifyWin the new notify win
   */
  public void setNotifyWin(boolean notifyWin) {
    this.notifyWin = notifyWin;
  }

  /**
   * Gets the round id.
   *
   * @return the round id
   */
  public String getRoundId() {
    return this.roundId;
  }

  /**
   * Sets the round id.
   *
   * @param roundId the new round id
   */
  public void setRoundId(String roundId) {
    this.roundId = roundId;
  }

  /**
   * Gets the expected end date.
   *
   * @return the expected end date
   */
  public Date getExpectedEndDate() {
    return this.expectedEndDate;
  }

  /**
   * Sets the expected end date.
   *
   * @param expectedEndDate the new expected end date
   */
  public void setExpectedEndDate(Date expectedEndDate) {
    this.expectedEndDate = expectedEndDate;
  }

  /**
   * Gets the operatorId.
   *
   * @return the operatorId
   */
  public String getOperatorId() {
    return this.operatorId;
  }

  /**
   * Sets the operatorId.
   *
   * @param operatorId the new operatorId
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the currency.
   *
   * @return the currency
   */
  public String getCurrency() {
    return this.currency;
  }

  /**
   * Sets the currency.
   *
   * @param currency the new currency
   */
  public void setCurrency(String currency) {
    this.currency = currency;
  }

  /**
   * Gets the ip address.
   *
   * @return the ip address
   */
  public String getIpAddress() {
    return this.ipAddress;
  }

  /**
   * Sets the ip address.
   *
   * @param ipAddress the new ip address
   */
  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }

  /** @return the subscriptionId */
  public Long getSubscriptionId() {
    return subscriptionId;
  }

  /** @param subscriptionId the subscriptionId to set */
  public void setSubscriptionId(Long subscriptionId) {
    if (subscriptionId == null) {
      subscriptionId = 0L;
    }
    this.subscriptionId = subscriptionId;
  }

  /** @return the previousStatus */
  public String getPreviousStatus() {
    return previousStatus;
  }

  /** @param previousStatus the previousStatus to set */
  public void setPreviousStatus(String previousStatus) {
    this.previousStatus = previousStatus;
  }

  /** @return the isReConciled */
  public Boolean getIsReConciled() {
    return isReConciled;
  }

  /** @param isReConciled the isReConciled to set */
  public void setIsReConciled(Boolean isReConciled) {
    if (isReConciled == null) {
      isReConciled = false;
    }
    this.isReConciled = isReConciled;
  }

  /** @return the gameVariantArchive */
  public String getGameVariantArchive() {
    return gameVariantArchive;
  }

  /** @param gameVariantArchive the gameVariantArchive to set */
  public void setGameVariantArchive(String gameVariantArchive) {
    this.gameVariantArchive = gameVariantArchive;
  }

  /** @return the numberOfWagersInSetArchive */
  public Byte getNumberOfWagersInSetArchive() {
    return numberOfWagersInSetArchive;
  }

  /** @param numberOfWagersInSetArchive the numberOfWagersInSetArchive to set */
  public void setNumberOfWagersInSetArchive(Byte numberOfWagersInSetArchive) {
    this.numberOfWagersInSetArchive = numberOfWagersInSetArchive;
  }

  /** @return the wagerNumberInSetArchive */
  public Byte getWagerNumberInSetArchive() {
    return wagerNumberInSetArchive;
  }

  /** @param wagerNumberInSetArchive the wagerNumberInSetArchive to set */
  public void setWagerNumberInSetArchive(Byte wagerNumberInSetArchive) {
    this.wagerNumberInSetArchive = wagerNumberInSetArchive;
  }
}
