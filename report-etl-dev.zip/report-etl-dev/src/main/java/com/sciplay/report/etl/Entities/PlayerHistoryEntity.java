package com.sciplay.report.etl.Entities;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.Type;

/** The Class PlayerHistoryEntity. */
@Entity
@Table(name = "PlayerHistory")
public class PlayerHistoryEntity implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The id. */
  @Column(name = "Id")
  @Id
  private String id;

  /** The player id. */
  @Column(name = "PlayerId")
  @Id
  private Integer playerId;

  /** The operator id. */
  @Column(name = "OperatorId", length = 3, columnDefinition = "CHAR")
  @Id
  private String operatorId;

  /** The change column name. */
  @Column(name = "ChangeColumnName")
  @Id
  private String changeColumnName;

  /** The old value. */
  private String oldValue;

  /** The new value. */
  private String newValue;

  /** The modification date. */
  @Column(name = "ModificationDate")
  @Id
  private Date modificationDate;

  /** The modified by. */
  @Column(name = "ModifiedBy")
  private Integer modifiedBy;

  /** The session id. */
  private String sessionId;

  /** The ip address. */
  private String ipAddress;

  /** The author type. */
  private String authorType;

  /** The comments. */
  @Type(type = "text")
  private String comments;

  /** Instantiates a new player history entity. */
  public PlayerHistoryEntity() {}

  /**
   * Instantiates a new player history entity.
   *
   * @param id the id
   * @param playerId the player id
   * @param changeColumnName the change column name
   * @param oldValue the old value
   * @param newValue the new value
   * @param modificationDate the modification date
   * @param modifiedBy the modified by
   * @param sessionId the session id
   * @param ipAddress the ip address
   * @param authorType the author type
   */
  public PlayerHistoryEntity(
      String id,
      Integer playerId,
      String changeColumnName,
      String oldValue,
      String newValue,
      Date modificationDate,
      Integer modifiedBy,
      String sessionId,
      String ipAddress,
      String authorType) {
    this.id = id;
    this.playerId = playerId;
    this.changeColumnName = changeColumnName;
    this.oldValue = oldValue;
    this.newValue = newValue;
    this.modificationDate = modificationDate;
    this.modifiedBy = Objects.isNull(modifiedBy) ? 0 : modifiedBy;
    this.sessionId = sessionId;
    this.ipAddress = ipAddress;
    this.authorType = authorType;
  }

  /**
   * Gets the comments.
   *
   * @return the comments
   */
  public String getComments() {
    return comments;
  }

  /**
   * Sets the comments.
   *
   * @param comments the new comments
   */
  public void setComments(String comments) {
    this.comments = comments;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return this.playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the operator id.
   *
   * @return the operatorId
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the operatorId to set
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the change column name.
   *
   * @return the change column name
   */
  public String getChangeColumnName() {
    return this.changeColumnName;
  }

  /**
   * Sets the change column name.
   *
   * @param changeColumnName the new change column name
   */
  public void setChangeColumnName(String changeColumnName) {
    this.changeColumnName = changeColumnName;
  }

  /**
   * Gets the old value.
   *
   * @return the old value
   */
  public String getOldValue() {
    return this.oldValue;
  }

  /**
   * Sets the old value.
   *
   * @param oldValue the new old value
   */
  public void setOldValue(String oldValue) {
    this.oldValue = oldValue;
  }

  /**
   * Gets the new value.
   *
   * @return the new value
   */
  public String getNewValue() {
    return this.newValue;
  }

  /**
   * Sets the new value.
   *
   * @param newValue the new new value
   */
  public void setNewValue(String newValue) {
    this.newValue = newValue;
  }

  /**
   * Gets the modification date.
   *
   * @return the modification date
   */
  public Date getModificationDate() {
    return this.modificationDate;
  }

  /**
   * Sets the modification date.
   *
   * @param modificationDate the new modification date
   */
  public void setModificationDate(Date modificationDate) {
    this.modificationDate = modificationDate;
  }

  /**
   * Gets the modified by.
   *
   * @return the modified by
   */
  public Integer getModifiedBy() {
    return this.modifiedBy;
  }

  /**
   * Sets the modified by.
   *
   * @param modifiedBy the new modified by
   */
  public void setModifiedBy(Integer modifiedBy) {
    this.modifiedBy = Objects.isNull(modifiedBy) ? 0 : modifiedBy;
  }

  /**
   * Gets the session id.
   *
   * @return the session id
   */
  public String getSessionId() {
    return this.sessionId;
  }

  /**
   * Sets the session id.
   *
   * @param sessionId the new session id
   */
  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  /**
   * Gets the ip address.
   *
   * @return the ip address
   */
  public String getIpAddress() {
    return this.ipAddress;
  }

  /**
   * Sets the ip address.
   *
   * @param ipAddress the new ip address
   */
  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }

  /**
   * Gets the author type.
   *
   * @return the author type
   */
  public String getAuthorType() {
    return this.authorType;
  }

  /**
   * Sets the author type.
   *
   * @param authorType the new author type
   */
  public void setAuthorType(String authorType) {
    this.authorType = authorType;
  }
}
