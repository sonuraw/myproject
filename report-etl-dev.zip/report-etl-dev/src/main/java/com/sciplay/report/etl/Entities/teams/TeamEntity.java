package com.sciplay.report.etl.Entities.teams;

import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** @author salman */
@Entity
@Table(name = "Team")
public class TeamEntity {

  @Id private String id;

  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  private String name;
  private String chairmanId;
  private String creatorId;
  private Integer maxNumberOfParticipants;
  private Integer minNumberOfParticipants;

  @Column(name = "Status", columnDefinition = "enum('OPEN','CLOSED','LOCKED','O','C','L')")
  private String status;

  @Column(name = "Purpose", columnDefinition = "enum('COMPETITION', 'GROUP_PLAY')")
  private String purpose;

  @Column(name = "AltGroupRef")
  private String altGroupRef;

  private String competitionId;
  private String competitionName;
  private Date competitionStartDatetime;
  private Date closeDate;
  private boolean multipleTeams;
  private Integer authorId;
  private String authorIp;
  private String authorSessionId;
  private Date updatedAt;
  private Date createdAt;

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getChairmanId() {
    return chairmanId;
  }

  public void setChairmanId(String chairmanId) {
    this.chairmanId = chairmanId;
  }

  public String getCreatorId() {
    return creatorId;
  }

  public void setCreatorId(String creatorId) {
    this.creatorId = creatorId;
  }

  public Integer getMaxNumberOfParticipants() {
    return maxNumberOfParticipants;
  }

  public void setMaxNumberOfParticipants(Integer maxNumberOfParticipants) {
    this.maxNumberOfParticipants =
        Objects.isNull(maxNumberOfParticipants) ? 0 : maxNumberOfParticipants;
  }

  public Integer getMinNumberOfParticipants() {
    return minNumberOfParticipants;
  }

  public void setMinNumberOfParticipants(Integer minNumberOfParticipants) {
    this.minNumberOfParticipants =
        Objects.isNull(minNumberOfParticipants) ? 0 : minNumberOfParticipants;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getPurpose() {
    return purpose;
  }

  public void setPurpose(String purpose) {
    this.purpose = purpose;
  }

  public String getAltGroupRef() {
    return altGroupRef;
  }

  public void setAltGroupRef(String altGroupRef) {
    this.altGroupRef = altGroupRef;
  }

  public String getCompetitionId() {
    return competitionId;
  }

  public void setCompetitionId(String competitionId) {
    this.competitionId = competitionId;
  }

  public String getCompetitionName() {
    return competitionName;
  }

  public void setCompetitionName(String competitionName) {
    this.competitionName = competitionName;
  }

  public Date getCompetitionStartDatetime() {
    return competitionStartDatetime;
  }

  public void setCompetitionStartDatetime(Date competitionStartDatetime) {
    this.competitionStartDatetime = competitionStartDatetime;
  }

  public Date getCloseDate() {
    return closeDate;
  }

  public void setCloseDate(Date closeDate) {
    this.closeDate = closeDate;
  }

  public boolean isMultipleTeams() {
    return multipleTeams;
  }

  public void setMultipleTeams(boolean multipleTeams) {
    this.multipleTeams = multipleTeams;
  }

  public Integer getAuthorId() {
    return authorId;
  }

  public void setAuthorId(Integer authorId) {
    this.authorId = Objects.isNull(authorId) ? 0 : authorId;
  }

  public String getAuthorIp() {
    return authorIp;
  }

  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  public String getAuthorSessionId() {
    return authorSessionId;
  }

  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  public Date getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  public String getOperatorId() {
    return operatorId;
  }

  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  public Date getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(Date updatedAt) {
    this.updatedAt = updatedAt;
  }
}
