package com.sciplay.report.etl.Entities.BatchLog;

import com.sciplay.report.etl.ReportEtlContext;
import com.sciplay.report.etl.dto.BatchLog.BatchLogAttrsResult;
import com.sciplay.report.etl.utils.ReportEtlUtils;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "batch_log")
public class BatchLogEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id")
  private long id;

  @Column(name = "correlation_id", nullable = false)
  private String correlationId;

  @Column(name = "service_name", nullable = false)
  private String serviceName;

  /** job name */
  @Column(name = "batch_group_id", nullable = false)
  private String batchGroupId;

  /** sub job / transformation name */
  @Column(name = "batch_id")
  private String batchId;

  /** run date is CEST version of start Date */
  @Column(name = "run_date", nullable = false)
  private Date runDate;

  @Column(name = "start_date", nullable = false)
  private Date startDate;

  @Column(name = "end_date")
  private Date endDate;

  @Column(name = "start_period")
  private Date startPeriod;

  @Column(name = "end_period")
  private Date endPeriod;

  @Column(name = "number_of_successes")
  private Integer numberOfSuccesses;

  @Column(name = "number_of_failures")
  private Integer numberOfFailures;

  @Column(name = "next_run_date")
  private Date nextRunDate;

  @Column(
      name = "status",
      columnDefinition = "enum('in_progress','success','error', 'not_ready', 'incomplete'")
  private String status;

  @Column(name = "summary")
  @Type(type = "text")
  private String summary;

  public BatchLogEntity() {}

  public BatchLogEntity(
      String correlationId,
      String serviceName,
      String batchGroupId,
      String batchId,
      Date runDate,
      Date startDate,
      Date endDate,
      Date startPeriod,
      Date endPeriod,
      Date nextRunDate,
      String status,
      BatchLogAttrsResult batchLogAttrsResult) {

    this.correlationId = correlationId;
    this.serviceName = serviceName;
    this.batchGroupId = batchGroupId;
    this.batchId = batchId;
    this.runDate =
        (runDate == null
            ? null
            : ReportEtlUtils.changeTimeZone(
                runDate, ReportEtlContext.getInstance().getReportEtlServiceConfig().getTimeZone()));
    this.startDate = startDate;
    this.endDate = endDate;
    this.startPeriod = startPeriod;
    this.endPeriod = endPeriod;
    this.nextRunDate = nextRunDate;
    this.status = status;

    if (batchLogAttrsResult != null) {
      this.numberOfSuccesses = batchLogAttrsResult.getNumberOfSuccess();
      this.numberOfFailures = batchLogAttrsResult.getNumberOfFailure();
      this.summary = batchLogAttrsResult.getMessage();
    }
  }

  public String getCorrelationId() {
    return correlationId;
  }

  public void setCorrelationId(String correlationId) {
    this.correlationId = correlationId;
  }

  public String getServiceName() {
    return serviceName;
  }

  public void setServiceName(String serviceName) {
    this.serviceName = serviceName;
  }

  public String getBatchGroupId() {
    return batchGroupId;
  }

  public void setBatchGroupId(String batchGroupId) {
    this.batchGroupId = batchGroupId;
  }

  public String getBatchId() {
    return batchId;
  }

  public void setBatchId(String batchId) {
    this.batchId = batchId;
  }

  public Date getRunDate() {
    return runDate;
  }

  public void setRunDate(Date runDate) {
    this.runDate =
        (runDate == null
            ? null
            : ReportEtlUtils.changeTimeZone(
                runDate, ReportEtlContext.getInstance().getReportEtlServiceConfig().getTimeZone()));
  }

  public Date getStartDate() {
    return startDate;
  }

  public void setStartDate(Date startDate) {
    this.startDate = startDate;
  }

  public Date getEndDate() {
    return endDate;
  }

  public void setEndDate(Date endDate) {
    this.endDate = endDate;
  }

  public Date getStartPeriod() {
    return startPeriod;
  }

  public void setStartPeriod(Date startPeriod) {
    this.startPeriod = startPeriod;
  }

  public Date getEndPeriod() {
    return endPeriod;
  }

  public void setEndPeriod(Date endPeriod) {
    this.endPeriod = endPeriod;
  }

  public Integer getNumberOfSuccesses() {
    return numberOfSuccesses;
  }

  public void setNumberOfSuccesses(Integer numberOfSuccesses) {
    this.numberOfSuccesses = numberOfSuccesses;
  }

  public Integer getNumberOfFailures() {
    return numberOfFailures;
  }

  public void setNumberOfFailures(Integer numberOfFailures) {
    this.numberOfFailures = numberOfFailures;
  }

  public Date getNextRunDate() {
    return nextRunDate;
  }

  public void setNextRunDate(Date nextRunDate) {
    this.nextRunDate = nextRunDate;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getSummary() {
    return summary;
  }

  public void setSummary(String summary) {
    this.summary = summary;
  }

  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }
}
