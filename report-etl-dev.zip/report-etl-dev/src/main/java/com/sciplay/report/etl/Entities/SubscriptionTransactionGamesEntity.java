package com.sciplay.report.etl.Entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class SubscriptionTransactionGamesEntity. */
@Entity
@Table(name = "SubscriptionTransactionGames")
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubscriptionTransactionGamesEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The Backend Transaction Id. */
  @Id private String backendTransactionId;

  /** The Game id. */
  @Id private Integer gameId;

  /** The correlation id. */
  private String correlationId;

  /** The Draw game template id. */
  @Column(name = "DrawGameTemplateId")
  private String drawGameTemplateId;

  /** The Subscription id. */
  private Long subscriptionId;

  /** The Game name. */
  private String gameName;

  /** The No of tickets. */
  private Integer noOfTickets;

  /** The Is random. */
  private String playMethod;

  /** The Cost per draw. */
  private Integer costPerDraw;

  /** The Partner id. */
  private String partnerId;

  /** The Add on trigger value. */
  private long addOnTriggerValue;

  /** The External wager id. */
  private String externalId;

  /** The Player id. */
  private Integer playerId;

  /** The Created at. */
  private Date createdAt;

  /** The Operator id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The Author id. */
  private Integer authorId;

  /** The Author ip. */
  private String authorIp;

  /** The Type. */
  private String type;

  /** The result code. */
  private String resultCode;

  /** The Purchase order id. */
  private String purchaseOrderId;

  /** Instantiates a new subscription games entity. */
  public SubscriptionTransactionGamesEntity() {}

  /**
   * Instantiates a new subscription games entity.
   *
   * @param drawGameTemplateId the draw game template id
   * @param subscriptionId the subscription id
   * @param gameId the game id
   * @param gameName the game name
   * @param noOfTickets the no of tickets
   * @param playMethod the play method
   * @param costPerDraw the cost per draw
   */
  public SubscriptionTransactionGamesEntity(
      String drawGameTemplateId,
      Long subscriptionId,
      Integer gameId,
      String gameName,
      Integer noOfTickets,
      String playMethod,
      Integer costPerDraw) {
    this.drawGameTemplateId = drawGameTemplateId;
    this.subscriptionId = Objects.isNull(subscriptionId) ? 0 : subscriptionId;
    this.gameId = gameId;
    this.gameName = gameName;
    this.noOfTickets = Objects.isNull(noOfTickets) ? 0 : noOfTickets;
    this.playMethod = playMethod;
    this.costPerDraw = Objects.isNull(costPerDraw) ? 0 : costPerDraw;
  }

  /**
   * Gets the serialversionuid.
   *
   * @return the serialversionuid
   */
  public static long getSerialversionuid() {
    return serialVersionUID;
  }

  /**
   * Gets the purchase order id.
   *
   * @return the purchase order id
   */
  public String getPurchaseOrderId() {
    return purchaseOrderId;
  }

  /**
   * Sets the purchase order id.
   *
   * @param purchaseOrderId the new purchase order id
   */
  public void setPurchaseOrderId(String purchaseOrderId) {
    this.purchaseOrderId = purchaseOrderId;
  }

  /**
   * Gets the result code.
   *
   * @return the result code
   */
  public String getResultCode() {
    return resultCode;
  }

  /**
   * Sets the result code.
   *
   * @param resultCode the new result code
   */
  public void setResultCode(String resultCode) {
    this.resultCode = resultCode;
  }

  /**
   * Gets the backend transaction id.
   *
   * @return the backend transaction id
   */
  public String getBackendTransactionId() {
    return backendTransactionId;
  }

  /**
   * Sets the backend transaction id.
   *
   * @param backendTransactionId the new backend transaction id
   */
  public void setBackendTransactionId(String backendTransactionId) {
    this.backendTransactionId = backendTransactionId;
  }

  /**
   * Gets the correlation id.
   *
   * @return the correlation id
   */
  public String getCorrelationId() {
    return correlationId;
  }

  /**
   * Sets the correlation id.
   *
   * @param correlationId the new correlation id
   */
  public void setCorrelationId(String correlationId) {
    this.correlationId = correlationId;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = Objects.isNull(playerId) ? 0 : playerId;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the author id.
   *
   * @return the author id
   */
  public Integer getAuthorId() {
    return authorId;
  }

  /**
   * Sets the author id.
   *
   * @param authorId the new author id
   */
  public void setAuthorId(Integer authorId) {
    this.authorId = Objects.isNull(authorId) ? 0 : authorId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Sets the type.
   *
   * @param type the new type
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the external wager id.
   *
   * @return the external wager id
   */
  public String getExternalId() {
    return externalId;
  }

  /**
   * Sets the external wager id.
   *
   * @param externalWagerId the new external wager id
   */
  public void setExternalId(String externalId) {
    this.externalId = externalId;
  }

  /**
   * Gets the partner id.
   *
   * @return the partner id
   */
  public String getPartnerId() {
    return partnerId;
  }

  /**
   * Sets the partner id.
   *
   * @param partnerId the new partner id
   */
  public void setPartnerId(String partnerId) {
    this.partnerId = partnerId;
  }

  /**
   * Gets the adds the on trigger value.
   *
   * @return the adds the on trigger value
   */
  public long getAddOnTriggerValue() {
    return addOnTriggerValue;
  }

  /**
   * Sets the adds the on trigger value.
   *
   * @param addOnTriggerValue the new adds the on trigger value
   */
  public void setAddOnTriggerValue(Long addOnTriggerValue) {
    this.addOnTriggerValue = Objects.isNull(addOnTriggerValue) ? 0L : addOnTriggerValue;
  }

  /**
   * Sets the adds the on trigger value.
   *
   * @param addOnTriggerValue the new adds the on trigger value
   */
  public void setAddOnTriggerValue(Integer addOnTriggerValue) {
    this.addOnTriggerValue = Objects.isNull(addOnTriggerValue) ? 0 : addOnTriggerValue;
  }

  /**
   * Gets the draw game template id.
   *
   * @return the draw game template id
   */
  public String getDrawGameTemplateId() {
    return drawGameTemplateId;
  }

  /**
   * Sets the draw game template id.
   *
   * @param drawGameTemplateId the new draw game template id
   */
  public void setDrawGameTemplateId(String drawGameTemplateId) {
    this.drawGameTemplateId = drawGameTemplateId;
  }

  /**
   * Gets the subscription id.
   *
   * @return the subscription id
   */
  public Long getSubscriptionId() {
    return subscriptionId;
  }

  /**
   * Sets the subscription id.
   *
   * @param subscriptionId the new subscription id
   */
  public void setSubscriptionId(Long subscriptionId) {
    this.subscriptionId = Objects.isNull(subscriptionId) ? 0L : subscriptionId;
  }

  /**
   * Gets the game id.
   *
   * @return the game id
   */
  public Integer getGameId() {
    return gameId;
  }

  /**
   * Sets the game id.
   *
   * @param gameId the new game id
   */
  public void setGameId(Integer gameId) {
    this.gameId = gameId;
  }

  /**
   * Gets the game name.
   *
   * @return the game name
   */
  public String getGameName() {
    return gameName;
  }

  /**
   * Sets the game name.
   *
   * @param gameName the new game name
   */
  public void setGameName(String gameName) {
    this.gameName = gameName;
  }

  /**
   * Gets the no of tickets.
   *
   * @return the no of tickets
   */
  public Integer getNoOfTickets() {
    return noOfTickets;
  }

  /**
   * Sets the no of tickets.
   *
   * @param noOfTickets the new no of tickets
   */
  public void setNoOfTickets(Integer noOfTickets) {
    this.noOfTickets = Objects.isNull(noOfTickets) ? 0 : noOfTickets;
  }

  /**
   * Gets the checks if is random.
   *
   * @return the checks if is random
   */
  public String getPlayMethod() {
    return playMethod;
  }

  /**
   * Sets the checks if is random.
   *
   * @param isRandom the new checks if is random
   */
  public void setPlayMethod(String isRandom) {
    playMethod = isRandom;
  }

  /**
   * Gets the cost per draw.
   *
   * @return the cost per draw
   */
  public Integer getCostPerDraw() {
    return costPerDraw;
  }

  /**
   * Sets the cost per draw.
   *
   * @param costPerDraw the new cost per draw
   */
  public void setCostPerDraw(Integer costPerDraw) {
    this.costPerDraw = Objects.isNull(costPerDraw) ? 0 : costPerDraw;
  }
}
