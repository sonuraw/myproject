package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MessageParams {

  @JsonProperty("id")
  private int id;

  @JsonProperty("author")
  private Integer author;

  public MessageParams() {}

  public MessageParams(int id, Integer author) {
    this.id = id;
    this.author = author;
  }

  /** @return the id */
  public int getId() {
    return this.id;
  }

  /** @param id the id to set */
  public void setId(int id) {
    this.id = id;
  }

  /** @return the author */
  public Integer getAuthor() {
    return this.author;
  }

  /** @param author the author to set */
  public void setAuthor(Integer author) {
    this.author = author;
  }
}
