package com.sciplay.report.etl.dto.limits;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LimitCategoryAttributes {
  private final String type;
  private final String label;
  private final String deferDelayDown;
  private final String deferDelayUp;
  private final String operatorId;
  private final Date createdAt;
  private final Date updatedAt;

  public LimitCategoryAttributes(
      String type,
      String label,
      String deferDelayDown,
      String deferDelayUp,
      String operatorId,
      Date createdAt,
      Date updatedAt) {
    this.type = type;
    this.label = label;
    this.deferDelayDown = deferDelayDown;
    this.deferDelayUp = deferDelayUp;
    this.operatorId = operatorId;
    this.createdAt = createdAt;
    this.updatedAt = updatedAt;
  }

  public LimitCategoryAttributes() {
    this.type = null;
    this.label = null;
    this.deferDelayDown = null;
    this.deferDelayUp = null;
    this.operatorId = null;
    this.createdAt = null;
    this.updatedAt = null;
  }

  public String getType() {
    return type;
  }

  public String getLabel() {
    return label;
  }

  public String getDeferDelayDown() {
    return deferDelayDown;
  }

  public String getDeferDelayUp() {
    return deferDelayUp;
  }

  public String getOperatorId() {
    return operatorId;
  }

  public Date getCreatedAt() {
    return createdAt;
  }

  public Date getUpdatedAt() {
    return updatedAt;
  }
}
