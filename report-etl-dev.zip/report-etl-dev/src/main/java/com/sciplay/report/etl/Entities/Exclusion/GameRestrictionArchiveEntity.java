package com.sciplay.report.etl.Entities.Exclusion;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** @author salman */
@Entity
@Table(name = "GameRestrictionArchive")
public class GameRestrictionArchiveEntity {

  @Id
  @Column(name = "RevisionNumber")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long revisionNumber;

  @Column(name = "RevisionDate")
  private Date revisionDate;

  @Column(name = "RevisionState")
  private String revisionState;

  @Column(name = "Id")
  private String id;

  @Column(name = "PlayerId")
  private Integer playerId;

  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  @Column(name = "AppliedFrom")
  private Date appliedFrom;

  @Column(name = "AppliedUntil")
  private Date appliedUntil;

  @Column(name = "Period")
  private String period;

  @Column(name = "Reason")
  private String reason;

  @Column(name = "RestrictionType")
  private String restrictionType;

  @Column(name = "ScopeGameId")
  private Integer scopeGameId;

  @Column(name = "ScopeGameType")
  private Integer scopeGameType;

  @Column(name = "ScopeGameCategoryId")
  private Integer scopeGameCategoryId;

  @Column(name = "ScopeGameProviderId")
  private String scopeGameProviderId;

  @Column(name = "ScopeGameSubCategoryId")
  private Integer scopeGameSubCategoryId;

  @Column(name = "AuthorPlayerId")
  private Integer authorPlayerId;

  @Column(name = "AuthorAgentId")
  private Integer authorAgentId;

  @Column(name = "AuthorIp")
  private String authorIp;

  @Column(name = "AuthorSessionId")
  private String authorSessionId;

  @Column(name = "CreatedAt")
  private Date createdAt;

  public GameRestrictionArchiveEntity(
      String id,
      Integer playerId,
      Date appliedFrom,
      Date appliedUntil,
      String period,
      String reason,
      String restrictionType,
      Integer scopeGameId,
      Integer scopeGameType,
      Integer scopeGameCategoryId,
      String scopeGameProviderId,
      Integer scopeGameSubCategoryId,
      Integer authorPlayerId,
      Integer authorAgentId,
      String authorIp,
      String authorSessionId,
      Date createdAt,
      Date revisionDate,
      String revisionState,
      String operatorId) {
    this.revisionDate = revisionDate;
    this.revisionState = revisionState;
    this.id = id;
    this.playerId = playerId;
    this.appliedFrom = appliedFrom;
    this.appliedUntil = appliedUntil;
    this.period = period;
    this.reason = reason;
    this.restrictionType = restrictionType;
    this.scopeGameId = scopeGameId;
    this.scopeGameType = scopeGameType;
    this.scopeGameCategoryId = scopeGameCategoryId;
    this.scopeGameProviderId = scopeGameProviderId;
    this.scopeGameSubCategoryId = scopeGameSubCategoryId;
    this.authorPlayerId = authorPlayerId;
    this.authorAgentId = authorAgentId;
    this.authorIp = authorIp;
    this.authorSessionId = authorSessionId;
    this.createdAt = createdAt;
    this.operatorId = operatorId;
  }

  public GameRestrictionArchiveEntity() {}

  public long getRevisionNumber() {
    return revisionNumber;
  }

  public void setRevisionNumber(long revisionNumber) {
    this.revisionNumber = revisionNumber;
  }

  public Date getRevisionDate() {
    return revisionDate;
  }

  public void setRevisionDate(Date revisionDate) {
    this.revisionDate = revisionDate;
  }

  public String getRevisionState() {
    return revisionState;
  }

  public void setRevisionState(String revisionState) {
    this.revisionState = revisionState;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public Integer getPlayerId() {
    return playerId;
  }

  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /** @return the operatorId */
  public String getOperatorId() {
    return operatorId;
  }

  /** @param operatorId the operatorId to set */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  public Date getAppliedFrom() {
    return appliedFrom;
  }

  public void setAppliedFrom(Date appliedFrom) {
    this.appliedFrom = appliedFrom;
  }

  public Date getAppliedUntil() {
    return appliedUntil;
  }

  public void setAppliedUntil(Date appliedUntil) {
    this.appliedUntil = appliedUntil;
  }

  public String getPeriod() {
    return period;
  }

  public void setPeriod(String period) {
    this.period = period;
  }

  public String getReason() {
    return reason;
  }

  public void setReason(String reason) {
    this.reason = reason;
  }

  public String getRestrictionType() {
    return restrictionType;
  }

  public void setRestrictionType(String restrictionType) {
    this.restrictionType = restrictionType;
  }

  public Integer getScopeGameId() {
    return scopeGameId;
  }

  public void setScopeGameId(Integer scopeGameId) {
    this.scopeGameId = scopeGameId;
  }

  public Integer getScopeGameType() {
    return scopeGameType;
  }

  public void setScopeGameType(Integer scopeGameType) {
    this.scopeGameType = scopeGameType;
  }

  public Integer getScopeGameCategoryId() {
    return scopeGameCategoryId;
  }

  public void setScopeGameCategoryId(Integer scopeGameCategoryId) {
    this.scopeGameCategoryId = scopeGameCategoryId;
  }

  public String getScopeGameProviderId() {
    return scopeGameProviderId;
  }

  public void setScopeGameProviderId(String scopeGameProviderId) {
    this.scopeGameProviderId = scopeGameProviderId;
  }

  public Integer getScopeGameSubCategoryId() {
    return scopeGameSubCategoryId;
  }

  public void setScopeGameSubCategoryId(Integer scopeGameSubCategoryId) {
    this.scopeGameSubCategoryId = scopeGameSubCategoryId;
  }

  public Integer getAuthorPlayerId() {
    return authorPlayerId;
  }

  public void setAuthorPlayerId(Integer authorPlayerId) {
    this.authorPlayerId = authorPlayerId;
  }

  public Integer getAuthorAgentId() {
    return authorAgentId;
  }

  public void setAuthorAgentId(Integer authorAgentId) {
    this.authorAgentId = authorAgentId;
  }

  public String getAuthorIp() {
    return authorIp;
  }

  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  public String getAuthorSessionId() {
    return authorSessionId;
  }

  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  public Date getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }
}
