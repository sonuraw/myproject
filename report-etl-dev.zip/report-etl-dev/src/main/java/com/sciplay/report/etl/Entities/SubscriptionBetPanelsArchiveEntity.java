package com.sciplay.report.etl.Entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class SubscriptionBetPanelsArchiveEntity. */
@Entity
@Table(name = "SubscriptionBetPanelsArchive")
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubscriptionBetPanelsArchiveEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The revision number. */
  @Column(name = "RevisionNumber")
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long revisionNumber;

  /** The revision date. */
  private Date revisionDate;

  /** The revision state. */
  private String revisionState;

  /** The Draw game template id. */
  @Column(name = "DrawGameTemplateId")
  private String drawGameTemplateId;

  /** The Subscription id. */
  private Long subscriptionId;

  /** The Selected values. */
  private String selectedValues;

  /** The Play type. */
  private int playType;

  /** The Cost per row. */
  private Integer costPerRow;

  /** The Version id. */
  private int versionId;

  /** Instantiates a new subscription games entity. */
  public SubscriptionBetPanelsArchiveEntity() {}

  /**
   * Instantiates a new subscription games entity.
   *
   * @param drawGameTemplateId the draw game template id
   * @param subscriptionId the subscription id
   */
  public SubscriptionBetPanelsArchiveEntity(String drawGameTemplateId, Long subscriptionId) {
    this.drawGameTemplateId = drawGameTemplateId;
    this.subscriptionId = subscriptionId;
  }

  /**
   * Gets the serialversionuid.
   *
   * @return the serialversionuid
   */
  public static long getSerialversionuid() {
    return serialVersionUID;
  }

  /**
   * Gets the version id.
   *
   * @return the version id
   */
  public int getVersionId() {
    return versionId;
  }

  /**
   * Sets the version id.
   *
   * @param versionId the new version id
   */
  public void setVersionId(int versionId) {
    this.versionId = versionId;
  }

  /**
   * Gets the revision number.
   *
   * @return the revision number
   */
  public long getRevisionNumber() {
    return revisionNumber;
  }

  /**
   * Sets the revision number.
   *
   * @param revisionNumber the new revision number
   */
  public void setRevisionNumber(long revisionNumber) {
    this.revisionNumber = revisionNumber;
  }

  /**
   * Gets the revision date.
   *
   * @return the revision date
   */
  public Date getRevisionDate() {
    return revisionDate;
  }

  /**
   * Sets the revision date.
   *
   * @param revisionDate the new revision date
   */
  public void setRevisionDate(Date revisionDate) {
    this.revisionDate = revisionDate;
  }

  /**
   * Gets the revision state.
   *
   * @return the revision state
   */
  public String getRevisionState() {
    return revisionState;
  }

  /**
   * Sets the revision state.
   *
   * @param revisionState the new revision state
   */
  public void setRevisionState(String revisionState) {
    this.revisionState = revisionState;
  }

  /**
   * Gets the selected values.
   *
   * @return the selected values
   */
  public String getSelectedValues() {
    return selectedValues;
  }

  /**
   * Sets the selected values.
   *
   * @param selectedValues the new selected values
   */
  public void setSelectedValues(String selectedValues) {
    this.selectedValues = selectedValues;
  }

  /**
   * Gets the play type.
   *
   * @return the play type
   */
  public int getPlayType() {
    return playType;
  }

  /**
   * Sets the play type.
   *
   * @param playType the new play type
   */
  public void setPlayType(int playType) {
    this.playType = playType;
  }

  /**
   * Gets the cost per row.
   *
   * @return the cost per row
   */
  public Integer getCostPerRow() {
    return costPerRow;
  }

  /**
   * Sets the cost per row.
   *
   * @param costPerRow the new cost per row
   */
  public void setCostPerRow(Integer costPerRow) {
    this.costPerRow = costPerRow;
  }

  /**
   * Gets the draw game template id.
   *
   * @return the draw game template id
   */
  public String getDrawGameTemplateId() {
    return drawGameTemplateId;
  }

  /**
   * Sets the draw game template id.
   *
   * @param drawGameTemplateId the new draw game template id
   */
  public void setDrawGameTemplateId(String drawGameTemplateId) {
    this.drawGameTemplateId = drawGameTemplateId;
  }

  /**
   * Gets the subscription id.
   *
   * @return the subscription id
   */
  public Long getSubscriptionId() {
    return subscriptionId;
  }

  /**
   * Sets the subscription id.
   *
   * @param subscriptionId the new subscription id
   */
  public void setSubscriptionId(Long subscriptionId) {
    this.subscriptionId = subscriptionId;
  }
}
