package com.sciplay.report.etl.Entities.leagues;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

/** @author salman */
@Entity
@Table(name = "LeagueInvitationArchive")
public class LeagueInvitationArchiveEntity {

  @javax.persistence.Id
  @Column(name = "RevisionNumber")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long revisionNumber;

  @Column(name = "RevisionDate")
  private Date revisionDate;

  @Column(name = "RevisionState")
  private String revisionState;

  @Column(name = "Id")
  private String id;

  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  @Column(name = "Email")
  private String email;

  @Column(name = "LeagueId")
  private String leagueId;

  @Column(name = "PlayerId")
  private Integer playerId;

  @Column(
      name = "Status",
      columnDefinition = "enum('SENT','ACCEPTED','DECLINED','EXPIRED','INVALID','S','A','D')")
  private String status;

  @Column(name = "AcceptHash", columnDefinition = "longtext")
  private String acceptHash;

  @Column(name = "DeclineHash", columnDefinition = "longtext")
  private String declineHash;

  @Column(name = "AuthorId")
  private Integer authorId;

  @Column(name = "AuthorIp")
  private String authorIp;

  @Column(name = "AuthorSessionId")
  private String authorSessionId;

  @Column(name = "CreatedAt")
  private Date createdAt;

  public LeagueInvitationArchiveEntity() {}

  public LeagueInvitationArchiveEntity(
      LeagueInvitationEntity leagueInvitationEntity, String revisionState) {
    this.id = leagueInvitationEntity.getId();
    this.operatorId = leagueInvitationEntity.getOperatorId();
    this.email = leagueInvitationEntity.getEmail();
    this.leagueId = leagueInvitationEntity.getLeagueId();
    this.playerId = leagueInvitationEntity.getPlayerId();
    this.status = leagueInvitationEntity.getStatus();
    this.acceptHash = leagueInvitationEntity.getAcceptHash();
    this.declineHash = leagueInvitationEntity.getDeclineHash();
    this.authorId = leagueInvitationEntity.getAuthorId();
    this.authorIp = leagueInvitationEntity.getAuthorIp();
    this.authorSessionId = leagueInvitationEntity.getAuthorSessionId();
    this.createdAt = leagueInvitationEntity.getCreatedAt();
    this.revisionDate = leagueInvitationEntity.getUpdatedAt();
    this.revisionState = revisionState;
  }

  public long getRevisionNumber() {
    return revisionNumber;
  }

  public void setRevisionNumber(long revisionNumber) {
    this.revisionNumber = revisionNumber;
  }

  public Date getRevisionDate() {
    return revisionDate;
  }

  public void setRevisionDate(Date revisionDate) {
    this.revisionDate = revisionDate;
  }

  public String getRevisionState() {
    return revisionState;
  }

  public void setRevisionState(String revisionState) {
    this.revisionState = revisionState;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getOperatorId() {
    return operatorId;
  }

  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getLeagueId() {
    return leagueId;
  }

  public void setLeagueId(String leagueId) {
    this.leagueId = leagueId;
  }

  public Integer getPlayerId() {
    return playerId;
  }

  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getAcceptHash() {
    return acceptHash;
  }

  public void setAcceptHash(String acceptHash) {
    this.acceptHash = acceptHash;
  }

  public String getDeclineHash() {
    return declineHash;
  }

  public void setDeclineHash(String declineHash) {
    this.declineHash = declineHash;
  }

  public Integer getAuthorId() {
    return authorId;
  }

  public void setAuthorId(Integer authorId) {
    this.authorId = authorId;
  }

  public String getAuthorIp() {
    return authorIp;
  }

  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  public String getAuthorSessionId() {
    return authorSessionId;
  }

  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  public Date getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }
}
