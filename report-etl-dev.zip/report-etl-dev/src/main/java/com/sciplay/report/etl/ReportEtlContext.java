package com.sciplay.report.etl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sciplay.report.etl.config.ApplicationConfiguration;
import org.hibernate.SessionFactory;

/**
 * This class is created using "Initialization-on-demand holder idiom" Pattern (Singleton) to Make
 * one time initialization of the Instance. At the time of initialization of the Service call comes
 * to create the instance of this class from ReportServiceManaged Class. Contains method to load the
 * Templates. This class StartWatcher Service. This class contains All the configurable properties
 * and Methods for shutdown the Pools and services.
 *
 * @author akhandelwal
 */
public final class ReportEtlContext {
  /** INSTANCE is instance of ReportApplication class. */
  private static final ReportEtlContext INSTANCE = new ReportEtlContext();

  private static boolean isHibernateInitialized;
  private static boolean isActiveMQInitialized;

  private static Boolean isMaster = false;

  private static boolean isXaActiveMQInitialized;
  private static boolean isXaHibernateInitialized;
  private final ObjectMapper objectMapper = new ObjectMapper();
  /** */
  private SessionFactory sessionFactory;

  private ApplicationConfiguration reportEtlConfig;
  private ApplicationConfiguration reportEtlServiceConfig;

  private String serviceVersion;

  /** @return INSTANCE of ReportApplication. */
  public static ReportEtlContext getInstance() {
    return INSTANCE;
  }

  /** */
  public static boolean isHibernateInitialized() {
    return isHibernateInitialized;
  }

  public static void setIsHibernateInitialized(boolean isHibernateInitialized) {
    ReportEtlContext.isHibernateInitialized = isHibernateInitialized;
  }

  public static boolean isXaActiveMQInitialized() {
    return isXaActiveMQInitialized;
  }

  public static boolean isXaHibernateInitialized() {
    return isXaHibernateInitialized;
  }

  public static void setIsXaHibernateInitialized(boolean isXaHibernateInitialized) {
    ReportEtlContext.isXaHibernateInitialized = isXaHibernateInitialized;
  }

  public static void setIsXaActiveMQInitialized(boolean isXaActiveMQInitialized) {
    ReportEtlContext.isXaActiveMQInitialized = isXaActiveMQInitialized;
  }

  public static Boolean getIsMaster() {
    return isMaster;
  }

  public static void setIsMaster(Boolean isMaster) {
    ReportEtlContext.isMaster = isMaster;
  }

  public static boolean isActiveMQInitialized() {
    return isActiveMQInitialized;
  }

  public static void setIsActiveMQInitialized(boolean isActiveMQInitialized) {
    ReportEtlContext.isActiveMQInitialized = isActiveMQInitialized;
  }

  public String getServiceVersion() {
    return serviceVersion;
  }

  public void setServiceVersion(String serviceVersion) {
    this.serviceVersion = serviceVersion;
  }

  /** @return */
  public SessionFactory getSessionFactory() {
    return sessionFactory;
  }

  /** */
  public void setSessionFactory(SessionFactory sessionFactoryObj) {
    sessionFactory = sessionFactoryObj;
  }

  /** @return the reportEtlConfig */
  public ApplicationConfiguration getReportEtlServiceConfig() {
    return reportEtlConfig;
  }

  /** @param reportEtlServiceConfig the reportEtlServiceConfig to set */
  public void setReportEtlServiceConfig(ApplicationConfiguration reportEtlServiceConfig) {
    this.reportEtlServiceConfig = reportEtlServiceConfig;
  }

  /** @return the reportEtlServiceConfig */
  public ApplicationConfiguration getReportEtlConfig() {
    return reportEtlServiceConfig;
  }

  /** @param reportEtlConfig the reportEtlConfig to set */
  public void setReportEtlConfig(ApplicationConfiguration reportEtlConfig) {
    this.reportEtlConfig = reportEtlConfig;
  }

  public ObjectMapper getObjectMapper() {
    return objectMapper;
  }
}
