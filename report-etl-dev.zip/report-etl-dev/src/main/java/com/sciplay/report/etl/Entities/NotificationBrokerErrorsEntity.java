package com.sciplay.report.etl.Entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Type;

/**
 * The Class JmsMessageDetailsEntity.
 *
 * @author Ananth
 */
@Entity
@Table(name = "NotificationBrokerErrors")
@DynamicUpdate
public class NotificationBrokerErrorsEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "Id")
  private Long id;

  @Column(name = "Topic", unique = true)
  private String topic;

  @Column(name = "CorrelationId", unique = true)
  private String correlationId;

  @Column(name = "Message")
  @Type(type = "text")
  private String message;

  @Column(name = "Error")
  @Type(type = "text")
  private String error;

  @Column(name = "RetryAttempts")
  private int retryAttempts;

  @Column(name = "UpdatedDate")
  private Date updatedDate;

  @Column(name = "isRePublished")
  private Boolean isRePublished;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getTopic() {
    return topic;
  }

  public void setTopic(String topic) {
    this.topic = topic;
  }

  public String getCorrelationId() {
    return correlationId;
  }

  public void setCorrelationId(String correlationId) {
    this.correlationId = correlationId;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public String getError() {
    return error;
  }

  public void setError(String error) {
    this.error = error;
  }

  public int getRetryAttempts() {
    return retryAttempts;
  }

  public void setRetryAttempts(int retryAttempts) {
    this.retryAttempts = retryAttempts;
  }

  public Date getUpdatedDate() {
    return updatedDate;
  }

  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  public Boolean getRePublished() {
    return isRePublished;
  }

  public void setRePublished(Boolean rePublished) {
    isRePublished = rePublished;
  }
}
