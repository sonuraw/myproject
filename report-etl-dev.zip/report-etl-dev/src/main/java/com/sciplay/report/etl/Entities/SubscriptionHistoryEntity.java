package com.sciplay.report.etl.Entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class SubscriptionHistoryEntity. */
@Entity
@Table(name = "SubscriptionHistory")
public class SubscriptionHistoryEntity implements Serializable {

  private static final long serialVersionUID = 1L;

  /** The subscription id. */
  @Column(name = "SubscriptionId")
  @Id
  private Long subscriptionId;

  /** The change column name. */
  @Column(name = "ChangeColumnName")
  @Id
  private String changeColumnName;

  /** The old value. */
  private String oldValue;

  /** The new value. */
  private String newValue;

  /** The modification date. */
  @Column(name = "ModificationDate")
  @Id
  private Date modificationDate;

  /** The modified by. */
  private Integer modifiedBy;

  /** The session id. */
  private String sessionId;

  /** The ip address. */
  private String ipAddress;

  /** The author type. */
  private String authorType;

  /** Instantiates a new player history entity. */
  public SubscriptionHistoryEntity() {}

  /**
   * Instantiates a new player history entity.
   *
   * @param subscriptionId the player id
   * @param changeColumnName the change column name
   * @param oldValue the old value
   * @param newValue the new value
   * @param modificationDate the modification date
   * @param modifiedBy the modified by
   * @param sessionId the session id
   * @param ipAddress the ip address
   * @param authorType the author type
   */
  public SubscriptionHistoryEntity(
      Long subscriptionId,
      String changeColumnName,
      String oldValue,
      String newValue,
      Date modificationDate,
      Integer modifiedBy,
      String sessionId,
      String ipAddress,
      String authorType) {
    this.subscriptionId = subscriptionId;
    this.changeColumnName = changeColumnName;
    this.oldValue = oldValue;
    this.newValue = newValue;
    this.modificationDate = modificationDate;
    this.modifiedBy = modifiedBy;
    this.sessionId = sessionId;
    this.ipAddress = ipAddress;
    this.authorType = authorType;
  }

  /**
   * Gets the subscription id.
   *
   * @return the subscription id
   */
  public Long getSubscriptionId() {
    return this.subscriptionId;
  }

  /**
   * Sets the subscription id.
   *
   * @param subscriptionId the new subscription id
   */
  public void setSubscriptionId(Long subscriptionId) {
    this.subscriptionId = subscriptionId;
  }

  /**
   * Gets the change column name.
   *
   * @return the change column name
   */
  public String getChangeColumnName() {
    return this.changeColumnName;
  }

  /**
   * Sets the change column name.
   *
   * @param changeColumnName the new change column name
   */
  public void setChangeColumnName(String changeColumnName) {
    this.changeColumnName = changeColumnName;
  }

  /**
   * Gets the old value.
   *
   * @return the old value
   */
  public String getOldValue() {
    return this.oldValue;
  }

  /**
   * Sets the old value.
   *
   * @param oldValue the new old value
   */
  public void setOldValue(String oldValue) {
    this.oldValue = oldValue;
  }

  /**
   * Gets the new value.
   *
   * @return the new value
   */
  public String getNewValue() {
    return this.newValue;
  }

  /**
   * Sets the new value.
   *
   * @param newValue the new new value
   */
  public void setNewValue(String newValue) {
    this.newValue = newValue;
  }

  /**
   * Gets the modification date.
   *
   * @return the modification date
   */
  public Date getModificationDate() {
    return this.modificationDate;
  }

  /**
   * Sets the modification date.
   *
   * @param modificationDate the new modification date
   */
  public void setModificationDate(Date modificationDate) {
    this.modificationDate = modificationDate;
  }

  /**
   * Gets the modified by.
   *
   * @return the modified by
   */
  public Integer getModifiedBy() {
    return this.modifiedBy;
  }

  /**
   * Sets the modified by.
   *
   * @param modifiedBy the new modified by
   */
  public void setModifiedBy(Integer modifiedBy) {
    if (modifiedBy == null) {
      modifiedBy = 0;
    }
    this.modifiedBy = modifiedBy;
  }

  /**
   * Gets the session id.
   *
   * @return the session id
   */
  public String getSessionId() {
    return this.sessionId;
  }

  /**
   * Sets the session id.
   *
   * @param sessionId the new session id
   */
  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  /**
   * Gets the ip address.
   *
   * @return the ip address
   */
  public String getIpAddress() {
    return this.ipAddress;
  }

  /**
   * Sets the ip address.
   *
   * @param ipAddress the new ip address
   */
  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }

  /**
   * Gets the author type.
   *
   * @return the author type
   */
  public String getAuthorType() {
    return this.authorType;
  }

  /**
   * Sets the author type.
   *
   * @param authorType the new author type
   */
  public void setAuthorType(String authorType) {
    this.authorType = authorType;
  }
}
