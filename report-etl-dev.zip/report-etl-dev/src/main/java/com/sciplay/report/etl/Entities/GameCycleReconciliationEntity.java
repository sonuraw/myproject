package com.sciplay.report.etl.Entities;

import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.Type;

/** The Class GameCycleReconciliationEntity. */
@Entity
@Table(name = "GameCycleReconciliation")
public class GameCycleReconciliationEntity {

  /** The Tran id. */
  @Id private long tranId;

  /** The Manual reconciliation amount. */
  private long manualReconciliationAmount;

  /** The Reconciliation comment. */
  private String reconciliationComment;

  /** The Reconciliation attempt. */
  private int reconciliationAttempt;

  /** The Reconciliation attempt log. */
  @Type(type = "text")
  private String reconciliationAttemptLog;

  /** The Reconciliation last attempt date. */
  private Date reconciliationLastAttemptDate;

  /** The Reconciliation status. */
  private String reconciliationStatus;

  /** The Author id. */
  private Integer authorId;

  /** The player id. */
  private Integer playerId;

  /** The round id. */
  private String roundId;

  /** The operator id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The game id. */
  private Integer gameId;

  /** The event type. */
  private String eventType;

  /** The money type. */
  private String moneyType;

  /** The amount. */
  private long amount;

  /** The currency. */
  private String currency;

  /** The external URL. */
  private String externalURL;

  /** The creation date. */
  private Date creationDate;

  /** The wager creation date. */
  private Date wagerCreationDate;

  /** Instantiates a new game cycle reconciliation entity. */
  public GameCycleReconciliationEntity() {}

  /**
   * Instantiates a new game cycle reconciliation entity.
   *
   * @param id the id
   * @param tranId the tran id
   * @param manualReconciliationAmount the manual reconciliation amount
   * @param reconciliationComment the reconciliation comment
   * @param reconciliationAttempt the reconciliation attempt
   * @param reconciliationAttemptLog the reconciliation attempt log
   * @param reconciliationLastAttemptDate the reconciliation last attempt date
   * @param reconciliationStatus the reconciliation status
   */
  public GameCycleReconciliationEntity(
      int id,
      long tranId,
      Long manualReconciliationAmount,
      String reconciliationComment,
      Integer reconciliationAttempt,
      String reconciliationAttemptLog,
      Date reconciliationLastAttemptDate,
      String reconciliationStatus) {
    this.tranId = tranId;
    this.manualReconciliationAmount =
        Objects.isNull(manualReconciliationAmount) ? 0L : manualReconciliationAmount;
    this.reconciliationComment = reconciliationComment;
    this.reconciliationAttempt = Objects.isNull(reconciliationAttempt) ? 0 : reconciliationAttempt;
    this.reconciliationAttemptLog = reconciliationAttemptLog;
    this.reconciliationLastAttemptDate = reconciliationLastAttemptDate;
    this.reconciliationStatus = reconciliationStatus;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = Objects.isNull(playerId) ? 0 : playerId;
  }

  /**
   * Gets the round id.
   *
   * @return the round id
   */
  public String getRoundId() {
    return roundId;
  }

  /**
   * Sets the round id.
   *
   * @param roundId the new round id
   */
  public void setRoundId(String roundId) {
    this.roundId = roundId;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the game id.
   *
   * @return the game id
   */
  public Integer getGameId() {
    return gameId;
  }

  /**
   * Sets the game id.
   *
   * @param gameId the new game id
   */
  public void setGameId(Integer gameId) {
    this.gameId = Objects.isNull(gameId) ? 0 : gameId;
  }

  /**
   * Gets the event type.
   *
   * @return the event type
   */
  public String getEventType() {
    return eventType;
  }

  /**
   * Sets the event type.
   *
   * @param eventType the new event type
   */
  public void setEventType(String eventType) {
    this.eventType = eventType;
  }

  /**
   * Gets the money type.
   *
   * @return the money type
   */
  public String getMoneyType() {
    return moneyType;
  }

  /**
   * Sets the money type.
   *
   * @param moneyType the new money type
   */
  public void setMoneyType(String moneyType) {
    this.moneyType = moneyType;
  }

  /**
   * Gets the amount.
   *
   * @return the amount
   */
  public long getAmount() {
    return amount;
  }

  /**
   * Sets the amount.
   *
   * @param amount the new amount
   */
  public void setAmount(Long amount) {
    this.amount = Objects.isNull(amount) ? 0L : amount;
  }

  /**
   * Gets the currency.
   *
   * @return the currency
   */
  public String getCurrency() {
    return currency;
  }

  /**
   * Sets the currency.
   *
   * @param currency the new currency
   */
  public void setCurrency(String currency) {
    this.currency = currency;
  }

  /**
   * Gets the external URL.
   *
   * @return the external URL
   */
  public String getExternalURL() {
    return externalURL;
  }

  /**
   * Sets the external URL.
   *
   * @param externalURL the new external URL
   */
  public void setExternalURL(String externalURL) {
    this.externalURL = externalURL;
  }

  /**
   * Gets the creation date.
   *
   * @return the creation date
   */
  public Date getCreationDate() {
    return creationDate;
  }

  /**
   * Sets the creation date.
   *
   * @param creationDate the new creation date
   */
  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  /**
   * Gets the wager creation date.
   *
   * @return the wager creation date
   */
  public Date getWagerCreationDate() {
    return wagerCreationDate;
  }

  /**
   * Sets the wager creation date.
   *
   * @param wagerCreationDate the new wager creation date
   */
  public void setWagerCreationDate(Date wagerCreationDate) {
    this.wagerCreationDate = wagerCreationDate;
  }

  /**
   * Gets the author id.
   *
   * @return the author id
   */
  public Integer getAuthorId() {
    return authorId;
  }

  /**
   * Sets the author id.
   *
   * @param authorId the new author id
   */
  public void setAuthorId(Integer authorId) {
    this.authorId = Objects.isNull(authorId) ? 0 : authorId;
  }

  /**
   * Gets the tran id.
   *
   * @return the tran id
   */
  public long getTranId() {
    return tranId;
  }

  /**
   * Sets the tran id.
   *
   * @param tranId the new tran id
   */
  public void setTranId(long tranId) {
    this.tranId = tranId;
  }

  /**
   * Gets the manual reconciliation amount.
   *
   * @return the manualReconciliationAmount
   */
  public long getManualReconciliationAmount() {
    return manualReconciliationAmount;
  }

  /**
   * Sets the manual reconciliation amount.
   *
   * @param manualReconciliationAmount the manualReconciliationAmount to set
   */
  public void setManualReconciliationAmount(Long manualReconciliationAmount) {
    this.manualReconciliationAmount =
        Objects.isNull(manualReconciliationAmount) ? 0L : manualReconciliationAmount;
  }

  /**
   * Gets the reconciliation comment.
   *
   * @return the reconciliationComment
   */
  public String getReconciliationComment() {
    return reconciliationComment;
  }

  /**
   * Sets the reconciliation comment.
   *
   * @param reconciliationComment the reconciliationComment to set
   */
  public void setReconciliationComment(String reconciliationComment) {
    this.reconciliationComment = reconciliationComment;
  }

  /**
   * Gets the reconciliation attempt.
   *
   * @return the reconciliationAttempt
   */
  public int getReconciliationAttempt() {
    return reconciliationAttempt;
  }

  /**
   * Sets the reconciliation attempt.
   *
   * @param reconciliationAttempt the reconciliationAttempt to set
   */
  public void setReconciliationAttempt(Integer reconciliationAttempt) {
    this.reconciliationAttempt = Objects.isNull(reconciliationAttempt) ? 0 : reconciliationAttempt;
  }

  /**
   * Gets the reconciliation attempt log.
   *
   * @return the reconciliationAttemptLog
   */
  public String getReconciliationAttemptLog() {
    return reconciliationAttemptLog;
  }

  /**
   * Sets the reconciliation attempt log.
   *
   * @param reconciliationAttemptLog the reconciliationAttemptLog to set
   */
  public void setReconciliationAttemptLog(String reconciliationAttemptLog) {
    this.reconciliationAttemptLog = reconciliationAttemptLog;
  }

  /**
   * Gets the reconciliation last attempt date.
   *
   * @return the reconciliationLastAttemptDate
   */
  public Date getReconciliationLastAttemptDate() {
    return reconciliationLastAttemptDate;
  }

  /**
   * Sets the reconciliation last attempt date.
   *
   * @param reconciliationLastAttemptDate the reconciliationLastAttemptDate to set
   */
  public void setReconciliationLastAttemptDate(Date reconciliationLastAttemptDate) {
    this.reconciliationLastAttemptDate = reconciliationLastAttemptDate;
  }

  /**
   * Gets the reconciliation status.
   *
   * @return the reconciliationStatus
   */
  public String getReconciliationStatus() {
    return reconciliationStatus;
  }

  /**
   * Sets the reconciliation status.
   *
   * @param reconciliationStatus the reconciliationStatus to set
   */
  public void setReconciliationStatus(String reconciliationStatus) {
    this.reconciliationStatus = reconciliationStatus;
  }
}
