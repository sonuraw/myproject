package com.sciplay.report.etl.Entities;

import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class PlayerCard. */
@Entity
@Table(name = "PlayerCard")
public class PlayerCardEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The id. */
  @Id
  @Column(name = "Id")
  private String id;

  /** The player id. */
  private Integer playerId;

  /** The operator id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The card number. */
  private String cardNumber;

  /** The reason. */
  private String reason;

  /** The author player id. */
  private Integer authorPlayerId;

  /** The author agent id. */
  private Integer authorAgentId;

  /** The author ip. */
  private String authorIp;

  /** The author session id. */
  private String authorSessionId;

  /** The printed date. */
  private Date printedDate;

  /** The expiration date. */
  private Date expirationDate;

  /** The cancel date. */
  private Date cancelDate;

  /** The created at. */
  private Date createdAt;

  /** The Modified at. */
  private Date modifiedAt;

  /** The Type. */
  private String type;

  /** The isDeleted. */
  @Column(name = "isDeleted")
  private Boolean isDeleted = false;

  /** Instantiates a new player card. */
  public PlayerCardEntity() {}

  /**
   * Instantiates a new player card.
   *
   * @param id the id
   * @param playerId the player id
   * @param operatorId the operator id
   * @param cardNumber the card number
   * @param expirationDate the expiration date
   * @param createdAt the created at
   * @param modifiedAt the modified at
   */
  public PlayerCardEntity(
      String id,
      Integer playerId,
      String operatorId,
      String cardNumber,
      Date expirationDate,
      Date createdAt,
      Date modifiedAt) {
    this.id = id;
    this.playerId = playerId;
    this.operatorId = operatorId;
    this.cardNumber = cardNumber;
    this.expirationDate = expirationDate;
    this.createdAt = createdAt;
    this.modifiedAt = modifiedAt;
  }

  /**
   * Instantiates a new player card.
   *
   * @param id the id
   * @param playerId the player id
   * @param operatorId the operator id
   * @param cardNumber the card number
   * @param reason the reason
   * @param authorPlayerId the author player id
   * @param authorAgentId the author agent id
   * @param authorIp the author ip
   * @param authorSessionId the author session id
   * @param printedDate the printed date
   * @param expirationDate the expiration date
   * @param cancelDate the cancel date
   * @param createdAt the created at
   * @param modifiedAt the modified at
   */
  public PlayerCardEntity(
      String id,
      Integer playerId,
      String operatorId,
      String cardNumber,
      String reason,
      Integer authorPlayerId,
      Integer authorAgentId,
      String authorIp,
      String authorSessionId,
      Date printedDate,
      Date expirationDate,
      Date cancelDate,
      Date createdAt,
      Date modifiedAt,
      String type) {
    this.id = id;
    this.playerId = playerId;
    this.operatorId = operatorId;
    this.cardNumber = cardNumber;
    this.reason = reason;
    this.authorPlayerId = Objects.isNull(authorPlayerId) ? 0 : authorPlayerId;
    this.authorAgentId = Objects.isNull(authorAgentId) ? 0 : authorAgentId;
    this.authorIp = authorIp;
    this.authorSessionId = authorSessionId;
    this.printedDate = printedDate;
    this.expirationDate = expirationDate;
    this.cancelDate = cancelDate;
    this.createdAt = createdAt;
    this.modifiedAt = modifiedAt;
    this.type = type;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Sets the type.
   *
   * @param type the new type
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the modified at.
   *
   * @return the modified at
   */
  public Date getModifiedAt() {
    return modifiedAt;
  }

  /**
   * Sets the modified at.
   *
   * @param modifiedAt the new modified at
   */
  public void setModifiedAt(Date modifiedAt) {
    this.modifiedAt = modifiedAt;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public String getId() {
    return this.id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return this.playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return this.operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the card number.
   *
   * @return the card number
   */
  public String getCardNumber() {
    return this.cardNumber;
  }

  /**
   * Sets the card number.
   *
   * @param cardNumber the new card number
   */
  public void setCardNumber(String cardNumber) {
    this.cardNumber = cardNumber;
  }

  /**
   * Gets the reason.
   *
   * @return the reason
   */
  public String getReason() {
    return this.reason;
  }

  /**
   * Sets the reason.
   *
   * @param reason the new reason
   */
  public void setReason(String reason) {
    this.reason = reason;
  }

  /**
   * Gets the author player id.
   *
   * @return the author player id
   */
  public Integer getAuthorPlayerId() {
    return this.authorPlayerId;
  }

  /**
   * Sets the author player id.
   *
   * @param authorPlayerId the new author player id
   */
  public void setAuthorPlayerId(Integer authorPlayerId) {
    this.authorPlayerId = Objects.isNull(authorPlayerId) ? 0 : authorPlayerId;
  }

  /**
   * Gets the author agent id.
   *
   * @return the author agent id
   */
  public Integer getAuthorAgentId() {
    return this.authorAgentId;
  }

  /**
   * Sets the author agent id.
   *
   * @param authorAgentId the new author agent id
   */
  public void setAuthorAgentId(Integer authorAgentId) {
    this.authorAgentId = Objects.isNull(authorAgentId) ? 0 : authorAgentId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return this.authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return this.authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the printed date.
   *
   * @return the printed date
   */
  public Date getPrintedDate() {
    return this.printedDate;
  }

  /**
   * Sets the printed date.
   *
   * @param printedDate the new printed date
   */
  public void setPrintedDate(Date printedDate) {
    this.printedDate = printedDate;
  }

  /**
   * Gets the expiration date.
   *
   * @return the expiration date
   */
  public Date getExpirationDate() {
    return this.expirationDate;
  }

  /**
   * Sets the expiration date.
   *
   * @param expirationDate the new expiration date
   */
  public void setExpirationDate(Date expirationDate) {
    this.expirationDate = expirationDate;
  }

  /**
   * Gets the cancel date.
   *
   * @return the cancel date
   */
  public Date getCancelDate() {
    return this.cancelDate;
  }

  /**
   * Sets the cancel date.
   *
   * @param cancelDate the new cancel date
   */
  public void setCancelDate(Date cancelDate) {
    this.cancelDate = cancelDate;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return this.createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  /** @return the isDeleted */
  public Boolean getIsDeleted() {
    return isDeleted;
  }

  /** @param isDeleted the isDeleted to set */
  public void setIsDeleted(Boolean isDeleted) {
    this.isDeleted = Objects.isNull(isDeleted) ? false : isDeleted;
  }
}
