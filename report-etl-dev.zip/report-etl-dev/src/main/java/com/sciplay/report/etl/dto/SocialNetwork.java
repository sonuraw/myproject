package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** The Class SocialNetwork. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SocialNetwork {

  /** The player id. */
  private Integer playerId;

  /** The network. */
  private String network;

  /** The id. */
  private String id;

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the network.
   *
   * @return the network
   */
  public String getNetwork() {
    return network;
  }

  /**
   * Sets the network.
   *
   * @param network the new network
   */
  public void setNetwork(String network) {
    this.network = network;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(String id) {
    this.id = id;
  }
}
