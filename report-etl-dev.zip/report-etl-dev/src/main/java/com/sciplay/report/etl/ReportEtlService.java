package com.sciplay.report.etl;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.util.ContextInitializer;
import com.sciplay.report.etl.config.ApplicationConfiguration;
import com.sciplay.report.etl.config.HibernateConfig;
import com.sciplay.report.etl.resources.DataSyncResource;
import com.sciplay.report.etl.resources.DocumentationResource;
import com.sciplay.report.etl.resources.EtlErrorLogResource;
import com.sciplay.report.etl.resources.HealthResource;
import com.sciplay.report.etl.resources.SubscriptionGameScheduleSyncResource;
import com.sciplay.report.etl.resources.SubscriptionGameSyncResource;
import com.sciplay.report.etl.resources.VersionResource;
import io.dropwizard.Application;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.lifecycle.setup.LifecycleEnvironment;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import io.federecio.dropwizard.swagger.SwaggerBundle;
import io.federecio.dropwizard.swagger.SwaggerBundleConfiguration;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Properties;
import java.util.UUID;
import org.flywaydb.core.Flyway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

/**
 * This is the Parent class for the DropWizard Application. Containing methods for Swagger
 * Configuration and Registered resources of Service
 *
 * @author Ananth ShanmugaSundaram
 */
public class ReportEtlService extends Application<ApplicationConfiguration> {
  /** instance of Logger. */
  private static final Logger LOG = LoggerFactory.getLogger(ReportEtlService.class);
  /** instance of Report Configuration. */
  private static ApplicationConfiguration cfg;

  static { // runs when the main class is loaded.
    System.setProperty("org.jboss.logging.provider", "slf4j");
  }

  /**
   * Returns the Report Configuration.
   *
   * @return cfg ReportConfiguration
   */
  public static ApplicationConfiguration getConfig() {
    return cfg;
  }

  /**
   * Set the Report Configuration.
   *
   * @param configuration configuration
   */
  private static void setConfig(ApplicationConfiguration configuration) {
    cfg = configuration;
  }

  public static void main(String[] args) {
    try {
      new ReportEtlService().run(args[0], args[1]);

    } catch (Exception e) {
      LOG.error(e.getMessage(), e);
    }
  }

  /** Returns the application name. */
  @Override
  public String getName() {
    return ReportEtlConsts.ETL_SERVICE_NAME;
  }

  @Override
  public void initialize(Bootstrap<ApplicationConfiguration> bootstrap) {
    LOG.info("Initializing the service.");
    super.initialize(bootstrap);
    bootstrap.addBundle(new ReportWizardBundle());

    bootstrap.setConfigurationSourceProvider(
        new SubstitutingSourceProvider(
            bootstrap.getConfigurationSourceProvider(), new EnvironmentVariableSubstitutor(false)));
  }

  @Override
  public void run(ApplicationConfiguration configuration, Environment environment)
      throws Exception {
    String tmUniqueNameSuffix = "-" + configuration.getServiceId() + "-";
    // XID limitation = 64 cf MAX_TID_LENGTH in AssemblerImp and keep 13 bytes to its own usage
    String tmUniqueNamePrefix =
        configuration.getHostname().length() + tmUniqueNameSuffix.length() > 64 - 13 - 8
            ? configuration.getHostname().substring(0, 64 - tmUniqueNameSuffix.length() - 13 - 8)
            : configuration.getHostname();
    System.setProperty("unique_name", tmUniqueNamePrefix + tmUniqueNameSuffix);

    LOG.info("START:: Report Etl Service");

    String correlationId = UUID.randomUUID().toString();
    MDC.put("correlationId", correlationId);
    LOG.info("Generated Correlation Id: " + correlationId);

    // Reset LoggerContext for LogBack(JSON encoder) to be effect
    LoggerContext loggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();
    loggerContext.reset();

    ContextInitializer initializer = new ContextInitializer(loggerContext);
    initializer.autoConfig();
    // set log properties
    MDC.put("serviceId", configuration.getServiceId());
    // Save configurations for access this configurations by anywhere
    setConfig(configuration);
    ReportEtlContext.getInstance().setReportEtlServiceConfig(configuration);
    ReportEtlContext.getInstance().setReportEtlConfig(configuration);

    manageFlyway(configuration);

    // set service version by reading from version props <> pom
    setServiceVersion();

    EtlErrorLogResource etlErrorLogResource = new EtlErrorLogResource();
    HealthResource healthResource = new HealthResource();
    VersionResource versionResource = new VersionResource();
    SubscriptionGameSyncResource gameSyncResource = new SubscriptionGameSyncResource();
    SubscriptionGameScheduleSyncResource gameScheduleSyncResource =
        new SubscriptionGameScheduleSyncResource();
    DocumentationResource documentationResource = new DocumentationResource();
    DataSyncResource dataSyncResource = new DataSyncResource();
    environment.jersey().register(etlErrorLogResource);
    environment.jersey().register(healthResource);
    environment.jersey().register(versionResource);
    environment.jersey().register(gameSyncResource);
    environment.jersey().register(gameScheduleSyncResource);
    environment.jersey().register(documentationResource);
    environment.jersey().register(dataSyncResource);

    LifecycleEnvironment lifecycle = environment.lifecycle();
    manageAmq(lifecycle, configuration);

    LOG.info("Report Etl Service started successfully.");
  }

  private void setServiceVersion() {
    InputStream resourceAsStream = null;
    try {
      resourceAsStream = this.getClass().getResourceAsStream("/version.properties");
      Properties prop = new Properties();
      prop.load(resourceAsStream);
      ReportEtlContext.getInstance().setServiceVersion(prop.getProperty("version"));
    } catch (Exception exp) {
      LOG.error(
          "get version error : "
              + exp.getMessage()
              + " ,stack: "
              + Arrays.toString(exp.getStackTrace()));

    } finally {
      if (resourceAsStream != null) {
        try {
          resourceAsStream.close();
        } catch (IOException e) {
          LOG.error(
              "stream close error: "
                  + e.getMessage()
                  + ", stack: "
                  + Arrays.toString(e.getStackTrace()));
        }
      }
    }
  }

  private void manageFlyway(ApplicationConfiguration applicationConfiguration) {
    try {
      LOG.info("Flyway Migration Started");
      HibernateConfig hibernateConfig = applicationConfiguration.getHibernateConfig();
      Flyway flyway =
          Flyway.configure()
              .dataSource(
                  hibernateConfig.getUrl(),
                  hibernateConfig.getUser(),
                  hibernateConfig.getPassword())
              .table(applicationConfiguration.getFlyway().getTable())
              .baselineVersion(applicationConfiguration.getFlyway().getBaselineVersion())
              .baselineOnMigrate(applicationConfiguration.getFlyway().getBaselineOnMigrate())
              .ignoreMissingMigrations(
                  applicationConfiguration.getFlyway().isIgnoreMissingMigrations())
              .ignoreIgnoredMigrations(
                  applicationConfiguration.getFlyway().isIgnoreIgnoredMigrations())
              .load();
      flyway.repair();
      flyway.migrate();
      LOG.info("Flyway Migration Completed Successfully");
    } catch (Exception ex) {
      LOG.error(
          "Flyway initialize error: "
              + ex.getMessage()
              + ", message: "
              + ex.getLocalizedMessage()
              + ", stack: "
              + ex.getMessage());
      System.exit(1);
    }
  }

  private void manageAmq(LifecycleEnvironment lifecycle, ApplicationConfiguration config) {
    if (config.getAmqXAConnectionMode()) {
      lifecycle.manage(XaAmqUtil.getInstance());
      lifecycle.manage(XaRollBack.getInstance());
    } else {
      lifecycle.manage(NonXaAmqUtil.getInstance());
    }
  }

  /** This is static ReportWizardBundle class extending from SwaggerBundle. */
  static class ReportWizardBundle extends SwaggerBundle<ApplicationConfiguration> {
    @Override
    protected SwaggerBundleConfiguration getSwaggerBundleConfiguration(
        ApplicationConfiguration sampleConfiguration) {
      // set up swagger
      return sampleConfiguration.getSwaggerBundleConfiguration();
    }
  }
}
