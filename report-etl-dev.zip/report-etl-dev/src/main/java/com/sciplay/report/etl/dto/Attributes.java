package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** The Class Attributes. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Attributes {

  /** The name. */
  private String name;

  /** The category id. */
  private Integer categoryId;

  /** The applied from. */
  private String appliedFrom;

  /** The applied until. */
  private String appliedUntil;

  /** The category. */
  private String category;

  /** The created at. */
  private String createdAt;

  /** The period. */
  private String period;

  /** The planned at. */
  private String plannedAt;

  /** The status. */
  private Boolean status;

  /** The value. */
  private Integer value;

  /** The external game id. */
  private String externalGameId;

  /** The partner id. */
  private String partnerId;

  /** The sub category id. */
  private Integer subCategoryId;

  /** The type id. */
  private Integer typeId;

  /** The channel. */
  private String channel;

  /** The enabled. */
  private Boolean enabled;

  /** The notify. */
  private Boolean notify;

  /** The notify. */
  private Boolean subscriptionAvailable;

  /** The tax percentage. */
  private Integer taxPercentage;

  /** The theoretical payout percentage. */
  private Integer theoreticalPayoutPercentage;

  /** The payout. */
  private String payout;

  /** The comment. */
  private String comment;

  /** The payload. */
  private String payload;

  /** The domain. */
  private String domain;

  /** The type. */
  private String type;

  /** The type. */
  private Integer playerId;

  /** The backoffice url template. */
  private String backofficeUrlTemplate;

  /**
   * Gets the backoffice url template.
   *
   * @return the backoffice url template
   */
  public String getBackofficeUrlTemplate() {
    return backofficeUrlTemplate;
  }

  /**
   * Sets the backoffice url template.
   *
   * @param backofficeUrlTemplate the new backoffice url template
   */
  public void setBackofficeUrlTemplate(String backofficeUrlTemplate) {
    this.backofficeUrlTemplate = backofficeUrlTemplate;
  }

  /**
   * Gets the domain.
   *
   * @return the domain
   */
  public String getDomain() {
    return domain;
  }

  /**
   * Sets the domain.
   *
   * @param domain the new domain
   */
  public void setDomain(String domain) {
    this.domain = domain;
  }

  /**
   * Gets the external game id.
   *
   * @return the external game id
   */
  public String getExternalGameId() {
    return externalGameId;
  }

  /**
   * Sets the external game id.
   *
   * @param externalGameId the new external game id
   */
  public void setExternalGameId(String externalGameId) {
    this.externalGameId = externalGameId;
  }

  /**
   * Gets the partner id.
   *
   * @return the partner id
   */
  public String getPartnerId() {
    return partnerId;
  }

  /**
   * Sets the partner id.
   *
   * @param partnerId the new partner id
   */
  public void setPartnerId(String partnerId) {
    this.partnerId = partnerId;
  }

  /**
   * Gets the sub category id.
   *
   * @return the sub category id
   */
  public Integer getSubCategoryId() {
    return subCategoryId;
  }

  /**
   * Sets the sub category id.
   *
   * @param subCategoryId the new sub category id
   */
  public void setSubCategoryId(Integer subCategoryId) {
    this.subCategoryId = subCategoryId;
  }

  /**
   * Gets the type id.
   *
   * @return the type id
   */
  public Integer getTypeId() {
    return typeId;
  }

  /**
   * Sets the type id.
   *
   * @param typeId the new type id
   */
  public void setTypeId(Integer typeId) {
    this.typeId = typeId;
  }

  /**
   * Gets the channel.
   *
   * @return the channel
   */
  public String getChannel() {
    return channel;
  }

  /**
   * Sets the channel.
   *
   * @param channel the new channel
   */
  public void setChannel(String channel) {
    this.channel = channel;
  }

  /**
   * Gets the enabled.
   *
   * @return the enabled
   */
  public Boolean getEnabled() {
    return enabled;
  }

  /**
   * Sets the enabled.
   *
   * @param enabled the new enabled
   */
  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  /**
   * Gets the notify.
   *
   * @return the notify
   */
  public Boolean getNotify() {
    return notify;
  }

  /**
   * Sets the notify.
   *
   * @param notify the new notify
   */
  public void setNotify(Boolean notify) {
    this.notify = notify;
  }

  /**
   * Gets the subscriptionAvailable.
   *
   * @return the subscriptionAvailable
   */
  public Boolean getSubscriptionAvailable() {
    return subscriptionAvailable;
  }

  /**
   * Sets the subscriptionAvailable.
   *
   * @param subscriptionAvailable the new subscription available
   */
  public void setSubscriptionAvailable(Boolean subscriptionAvailable) {
    this.subscriptionAvailable = subscriptionAvailable;
  }

  /**
   * Gets the tax percentage.
   *
   * @return the tax percentage
   */
  public Integer getTaxPercentage() {
    return taxPercentage;
  }

  /**
   * Sets the tax percentage.
   *
   * @param taxPercentage the new tax percentage
   */
  public void setTaxPercentage(Integer taxPercentage) {
    this.taxPercentage = taxPercentage;
  }

  /**
   * Gets the theoretical payout percentage.
   *
   * @return the theoretical payout percentage
   */
  public Integer getTheoreticalPayoutPercentage() {
    return theoreticalPayoutPercentage;
  }

  /**
   * Sets the theoretical payout percentage.
   *
   * @param theoreticalPayoutPercentage the new theoretical payout percentage
   */
  public void setTheoreticalPayoutPercentage(Integer theoreticalPayoutPercentage) {
    this.theoreticalPayoutPercentage = theoreticalPayoutPercentage;
  }

  /**
   * Gets the payout.
   *
   * @return the payout
   */
  public String getPayout() {
    return payout;
  }

  /**
   * Sets the payout.
   *
   * @param payout the new payout
   */
  public void setPayout(String payout) {
    this.payout = payout;
  }

  /**
   * Gets the comment.
   *
   * @return the comment
   */
  public String getComment() {
    return comment;
  }

  /**
   * Sets the comment.
   *
   * @param comment the new comment
   */
  public void setComment(String comment) {
    this.comment = comment;
  }

  /**
   * Gets the category id.
   *
   * @return the category id
   */
  public Integer getCategoryId() {
    return categoryId;
  }

  /**
   * Sets the category id.
   *
   * @param categoryId the new category id
   */
  public void setCategoryId(Integer categoryId) {
    this.categoryId = categoryId;
  }

  /**
   * Gets the name.
   *
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * Sets the name.
   *
   * @param name the new name
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Gets the applied from.
   *
   * @return the applied from
   */
  public String getAppliedFrom() {
    return appliedFrom;
  }

  /**
   * Sets the applied from.
   *
   * @param appliedFrom the new applied from
   */
  public void setAppliedFrom(String appliedFrom) {
    this.appliedFrom = appliedFrom;
  }

  /**
   * Gets the applied until.
   *
   * @return the applied until
   */
  public String getAppliedUntil() {
    return appliedUntil;
  }

  /**
   * Sets the applied until.
   *
   * @param appliedUntil the new applied until
   */
  public void setAppliedUntil(String appliedUntil) {
    this.appliedUntil = appliedUntil;
  }

  /**
   * Gets the category.
   *
   * @return the category
   */
  public String getCategory() {
    return category;
  }

  /**
   * Sets the category.
   *
   * @param category the new category
   */
  public void setCategory(String category) {
    this.category = category;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public String getCreatedAt() {
    return createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }

  /**
   * Gets the planned at.
   *
   * @return the planned at
   */
  public String getPlannedAt() {
    return plannedAt;
  }

  /**
   * Sets the planned at.
   *
   * @param plannedAt the new planned at
   */
  public void setPlannedAt(String plannedAt) {
    this.plannedAt = plannedAt;
  }

  /**
   * Gets the period.
   *
   * @return the period
   */
  public String getPeriod() {
    return period;
  }

  /**
   * Sets the period.
   *
   * @param period the new period
   */
  public void setPeriod(String period) {
    this.period = period;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public Boolean getStatus() {
    return status;
  }

  /**
   * Sets the status.
   *
   * @param status the new status
   */
  public void setStatus(Boolean status) {
    this.status = status;
  }

  /**
   * Gets the value.
   *
   * @return the value
   */
  public Integer getValue() {
    return value;
  }

  /**
   * Sets the value.
   *
   * @param value the new value
   */
  public void setValue(Integer value) {
    this.value = value;
  }

  /**
   * Gets the payload.
   *
   * @return the payload
   */
  public String getPayload() {
    return payload;
  }

  /**
   * Sets the payload.
   *
   * @param payload the new payload
   */
  public void setPayload(String payload) {
    this.payload = payload;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Sets the type.
   *
   * @param type the type to set
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the player id.
   *
   * @return the playerId
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the playerId to set
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }
}
