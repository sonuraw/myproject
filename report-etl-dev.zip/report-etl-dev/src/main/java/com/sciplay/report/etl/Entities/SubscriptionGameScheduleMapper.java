package com.sciplay.report.etl.Entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;

/** The Class SubscriptionGameScheduleEntity. */
public class SubscriptionGameScheduleMapper implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The Game id. */
  private Integer gameId;

  /** The Game name. */
  private String gameName;

  /** The Operator id. */
  private String operatorId;

  /** The Draw Date Array. */
  private Date[] drawDates;

  /** The Advance Hours. */
  @Column(name = "AdvanceHours")
  private int advanceHours;

  /** The Advance Hours ends. */
  @Column(name = "AdvanceHoursEnds")
  private int advanceHoursEnds;

  /** The Modified at. */
  @Column(name = "UpdatedAt")
  private Date updatedAt;

  /**
   * Gets the updated at.
   *
   * @return the updated at
   */
  public Date getUpdatedAt() {
    return updatedAt;
  }

  /**
   * Sets the updated at.
   *
   * @param updatedAt the new updated at
   */
  public void setUpdatedAt(Date updatedAt) {
    this.updatedAt = updatedAt;
  }

  /**
   * Gets the advance hours.
   *
   * @return the advance hours
   */
  public int getAdvanceHours() {
    return advanceHours;
  }

  /**
   * Sets the advance hours.
   *
   * @param advanceHours the new advance hours
   */
  public void setAdvanceHours(int advanceHours) {
    this.advanceHours = advanceHours;
  }

  /**
   * Gets the advance hours ends.
   *
   * @return the advance hours ends
   */
  public int getAdvanceHoursEnds() {
    return advanceHoursEnds;
  }

  /**
   * Sets the advance hours ends.
   *
   * @param advanceHoursEnds the new advance hours ends.
   */
  public void setAdvanceHoursEnds(int advanceHoursEnds) {
    this.advanceHoursEnds = advanceHoursEnds;
  }

  /**
   * Gets the game id.
   *
   * @return the game id
   */
  public Integer getGameId() {
    return gameId;
  }

  /**
   * Sets the game id.
   *
   * @param gameId the new game id
   */
  public void setGameId(Integer gameId) {
    this.gameId = gameId;
  }

  /**
   * Gets the game name.
   *
   * @return the game name
   */
  public String getGameName() {
    return gameName;
  }

  /**
   * Sets the game name.
   *
   * @param gameName the new game name
   */
  public void setGameName(String gameName) {
    this.gameName = gameName;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the draw date array.
   *
   * @return the draw date array.
   */
  public Date[] getDrawDates() {
    return drawDates;
  }

  /**
   * Sets the draw dates.
   *
   * @param drawDates the new draw dates
   */
  public void setDrawDates(Date[] drawDates) {
    this.drawDates = drawDates;
  }
}
