package com.sciplay.report.etl.dto;

public class TermsAndConditionsMessage extends DynamicMessage<TermsAndConditions> {}
