package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.annotations.ApiModelProperty;

@JsonInclude(Include.ALWAYS)
public class MessageFields {

  @ApiModelProperty(required = true, value = "user defined status code")
  private final String code;

  @ApiModelProperty(required = true, value = "status code")
  private final String status;

  @ApiModelProperty(required = true, value = "status detail")
  private final String detail;

  @ApiModelProperty(required = true, value = "resource title")
  private final String title;

  @ApiModelProperty(required = true, value = "message action type")
  private final String type;

  @ApiModelProperty(required = true, value = "message topic")
  private final String topic;

  public MessageFields(
      String code, String status, String detail, String title, String type, String topic) {
    this.code = code;
    this.status = status;
    this.detail = detail;
    this.title = title;
    this.type = type;
    this.topic = topic;
  }

  /** @return the code */
  public String getCode() {
    return code;
  }

  /** @return the status */
  public String getStatus() {
    return status;
  }

  /** @return the detail */
  public String getDetail() {
    return detail;
  }

  /** @return the title */
  public String getTitle() {
    return title;
  }

  /** @return the type */
  public String getType() {
    return type;
  }

  /** @return the topic */
  public String getTopic() {
    return topic;
  }
}
