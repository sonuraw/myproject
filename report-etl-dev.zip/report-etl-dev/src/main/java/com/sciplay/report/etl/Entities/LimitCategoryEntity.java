package com.sciplay.report.etl.Entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Entity
@Table(name = "LimitCategory")
@JsonIgnoreProperties(ignoreUnknown = true)
public class LimitCategoryEntity {

  @Id
  @Column(name = "CategoryId")
  private String categoryId;

  private String categoryName;
  private String categoryType;
  private String categoryLabel;
  private String operator;
  private Date createdDate;
  private String delayDown;
  private String delayUp;
  private Date updatedDate;

  public LimitCategoryEntity() {}

  public LimitCategoryEntity(
      String categoryId,
      String categoryName,
      String categoryType,
      String categoryLabel,
      String operator,
      Date createdDate,
      String delayDown,
      String delayUp,
      Date updatedDate) {
    this.categoryId = categoryId;
    this.categoryName = categoryName;
    this.categoryType = categoryType;
    this.categoryLabel = categoryLabel;
    this.operator = operator;
    this.createdDate = createdDate;
    this.delayDown = delayDown;
    this.delayUp = delayUp;
    this.updatedDate = updatedDate;
  }

  public String getCategoryId() {
    return this.categoryId;
  }

  public void setCategoryId(String categoryId) {
    this.categoryId = categoryId;
  }

  public String getCategoryName() {
    return this.categoryName;
  }

  public void setCategoryName(String categoryName) {
    this.categoryName = categoryName;
  }

  public String getCategoryType() {
    return this.categoryType;
  }

  public void setCategoryType(String categoryType) {
    this.categoryType = categoryType;
  }

  public String getCategoryLabel() {
    return this.categoryLabel;
  }

  public void setCategoryLabel(String categoryLabel) {
    this.categoryLabel = categoryLabel;
  }

  public String getOperator() {
    return this.operator;
  }

  public void setOperator(String operator) {
    this.operator = operator;
  }

  public Date getCreatedDate() {
    return this.createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public String getDelayDown() {
    return this.delayDown;
  }

  public void setDelayDown(String delayDown) {
    this.delayDown = delayDown;
  }

  public String getDelayUp() {
    return this.delayUp;
  }

  public void setDelayUp(String delayUp) {
    this.delayUp = delayUp;
  }

  public Date getUpdatedDate() {
    return this.updatedDate;
  }

  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }
}
