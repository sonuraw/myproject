package com.sciplay.report.etl.Entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class IhubAlertsEntity.
 *
 * @author Sundar
 */
@Entity
@Table(name = "IhubAlerts")
public class IhubAlertsEntity implements java.io.Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  @Id
  @Column(name = "Type")
  private String type;

  @Id
  @Column(name = "Date")
  private Date date;

  @Column(name = "Amount")
  private Long amount;

  @Column(name = "TotalRecords")
  private Long totalRecords;

  @Column(name = "EventCreatedAt")
  private Date eventCreatedAt;

  public IhubAlertsEntity() {}

  public String getOperatorId() {
    return operatorId;
  }

  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public Long getAmount() {
    return amount;
  }

  public void setAmount(Long amount) {
    this.amount = amount;
  }

  public Long getTotalRecords() {
    return totalRecords;
  }

  public void setTotalRecords(Long totalRecords) {
    this.totalRecords = totalRecords;
  }

  public Date getEventCreatedAt() {
    return eventCreatedAt;
  }

  public void setEventCreatedAt(Date eventCreatedAt) {
    this.eventCreatedAt = eventCreatedAt;
  }

  public Date getDate() {
    return date;
  }

  public void setDate(Date date) {
    this.date = date;
  }
}
