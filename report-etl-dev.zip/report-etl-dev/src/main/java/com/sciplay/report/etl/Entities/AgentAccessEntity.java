package com.sciplay.report.etl.Entities;

import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.Type;

/**
 * The Class AgentCountryListEntity.
 *
 * @author Kaliyappan
 */
@Entity
@Table(name = "AgentAccessHistory")
public class AgentAccessEntity {

  /** The id. */
  @Id
  @Column(name = "Id")
  private long id;

  /** The agent id. */
  @Column(name = "AgentId")
  private Integer agentId;

  /** The access type. */
  @Column(name = "AccessType")
  private String accessType;

  /** The page. */
  @Column(name = "Page")
  private String page;

  /** The url. */
  @Column(name = "URL")
  private String url;

  /** The PlayerId parameter. */
  @Column(name = "ParamPlayerId")
  private Integer paramPlayerId;

  /** The AgentId parameter. */
  @Column(name = "ParamAgentId")
  private Integer paramAgentId;

  /** The parameters. */
  @Column(name = "Parameters")
  @Type(type = "text")
  private String parameters;

  /** The author id. */
  @Column(name = "AuthorId")
  private Integer authorId;

  /** The author ip. */
  @Column(name = "AuthorIp")
  private String authorIp;

  /** The author session id. */
  @Column(name = "AuthorSessionId")
  private String authorSessionId;

  /** The created at. */
  @Column(name = "CreatedAt")
  private Date createdAt;

  /**
   * Instantiates a new agent country list entity.
   *
   * @param agentId the agent id
   * @param authorId the author id
   * @param authorIp the author ip
   * @param authorSessionId the author session id
   * @param createdAt the created at
   */
  public AgentAccessEntity(
      Integer agentId,
      String accessType,
      String page,
      String url,
      String parameters,
      Integer paramPlayerId,
      Integer paramAgentId,
      Integer authorId,
      String authorIp,
      String authorSessionId,
      Date createdAt) {
    this.agentId = agentId;
    this.accessType = accessType;
    this.page = page;
    this.parameters = parameters;
    this.url = url;
    this.paramPlayerId = Objects.isNull(paramPlayerId) ? 0 : paramPlayerId;
    this.paramAgentId = Objects.isNull(paramAgentId) ? 0 : paramAgentId;
    this.authorId = Objects.isNull(authorId) ? 0 : authorId;
    this.authorIp = authorIp;
    this.authorSessionId = authorSessionId;
    this.createdAt = createdAt;
  }

  /** Instantiates a new agent country list entity. */
  public AgentAccessEntity() {}

  /**
   * Gets the agent id.
   *
   * @return the agent id
   */
  public Integer getAgentId() {
    return agentId;
  }

  /**
   * Sets the agent id.
   *
   * @param agentId the new agent id
   */
  public void setAgentId(Integer agentId) {
    this.agentId = agentId;
  }

  /**
   * Gets the access type.
   *
   * @return the access type
   */
  public String getAccessType() {
    return accessType;
  }

  /**
   * Sets the access type.
   *
   * @param accessType the new access type.
   */
  public void setAccessType(String accessType) {
    this.accessType = accessType;
  }

  /**
   * Gets the page.
   *
   * @return the page
   */
  public String getPage() {
    return page;
  }

  /**
   * Sets the page.
   *
   * @param page the new page.
   */
  public void setPage(String page) {
    this.page = page;
  }

  /**
   * Gets the url.
   *
   * @return the url
   */
  public String getUrl() {
    return url;
  }

  /**
   * Sets the url.
   *
   * @param url the new url.
   */
  public void setUrl(String url) {
    this.url = url;
  }

  /**
   * Gets the parameters.
   *
   * @return the parameters
   */
  public String getParameters() {
    return parameters;
  }

  /**
   * Sets the parameters.
   *
   * @param parameters the new parameters.
   */
  public void setParameters(String parameters) {
    this.parameters = parameters;
  }

  /**
   * Gets the paramPlayerId.
   *
   * @return the paramPlayerId
   */
  public Integer getParamPlayerId() {
    return paramPlayerId;
  }

  /**
   * Sets the paramPlayerId.
   *
   * @param paramPlayerId the new paramPlayerId.
   */
  public void setParamPlayerId(Integer paramPlayerId) {
    this.paramPlayerId = Objects.isNull(paramPlayerId) ? 0 : paramPlayerId;
  }

  /**
   * Gets the paramAgentId.
   *
   * @return the paramAgentId
   */
  public Integer getParamAgentId() {
    return paramAgentId;
  }

  /**
   * Sets the paramAgentId.
   *
   * @param paramAgentId the new paramAgentId.
   */
  public void setParamAgentId(Integer paramAgentId) {
    this.paramAgentId = Objects.isNull(paramAgentId) ? 0 : paramAgentId;
  }

  /**
   * Gets the author id.
   *
   * @return the author id
   */
  public Integer getAuthorId() {
    return authorId;
  }

  /**
   * Sets the author id.
   *
   * @param authorId the new author id
   */
  public void setAuthorId(Integer authorId) {
    this.authorId = Objects.isNull(authorId) ? 0 : authorId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  /** @return the id */
  public long getId() {
    return id;
  }

  /** @param id the id to set */
  public void setId(long id) {
    this.id = id;
  }
}
