package com.sciplay.report.etl;

import com.atomikos.jdbc.AtomikosDataSourceBean;
import com.atomikos.jdbc.AtomikosSQLException;
import com.atomikos.jms.AtomikosConnectionFactoryBean;
import com.atomikos.jms.extra.MessageDrivenContainer;
import com.sciplay.report.etl.consumer.DurableSubscriberCheck;
import com.sciplay.report.etl.consumer.XaMessageListener;
import io.dropwizard.lifecycle.Managed;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import javax.jms.InvalidClientIDException;
import javax.jms.JMSException;
import javax.jms.Topic;
import org.apache.activemq.ActiveMQXAConnectionFactory;
import org.apache.activemq.command.ActiveMQQueue;
import org.apache.activemq.command.ActiveMQTopic;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Created by 105450 on 7/27/2017. */
public class XaAmqUtil implements Managed {

  private static final Logger LOG = LoggerFactory.getLogger(XaAmqUtil.class);
  private static XaAmqUtil instance = new XaAmqUtil();

  private static AtomikosDataSourceBean reportDataSource;
  private static SessionFactory reportSessionFactory;

  private static ArrayList<MessageDrivenContainer> containers = new ArrayList<>();
  private static AtomikosConnectionFactoryBean connFactory;
  private static String brokerUrl =
      ReportEtlContext.getInstance().getReportEtlServiceConfig().getAMQFailoverUrl();
  private static String threadId = UUID.randomUUID().toString();

  private DurableSubscriberCheck durableSubscriberCheck = new DurableSubscriberCheck();

  public static XaAmqUtil getInstance() {
    return instance;
  }

  public static void setInstance(XaAmqUtil instance) {
    XaAmqUtil.instance = instance;
  }

  private static AtomikosDataSourceBean createDataSource() throws AtomikosSQLException {

    String resourceName = "report_datasource";

    AtomikosDataSourceBean ds = new AtomikosDataSourceBean();

    ds.setUniqueResourceName(resourceName);
    ds.setXaDataSourceClassName("com.mysql.cj.jdbc.MysqlXADataSource");

    Properties props = new Properties();

    props.put(
        "url",
        ReportEtlContext.getInstance().getReportEtlServiceConfig().getHibernateConfig().getUrl());
    props.put(
        "user",
        ReportEtlContext.getInstance().getReportEtlServiceConfig().getHibernateConfig().getUser());
    props.put(
        "password",
        ReportEtlContext.getInstance()
            .getReportEtlServiceConfig()
            .getHibernateConfig()
            .getPassword());
    props.put("pinGlobalTxToPhysicalConnection", true);

    ds.setXaProperties(props);
    ds.setMinPoolSize(
        Integer.parseInt(
            ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getHibernateConfig()
                .getMinSize()));

    ds.setMaxPoolSize(
        Integer.parseInt(
            ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getHibernateConfig()
                .getMaxSize()));
    ds.setBorrowConnectionTimeout(
        ReportEtlContext.getInstance()
            .getReportEtlServiceConfig()
            .getHibernateConfig()
            .getBorrowTimeout());
    ds.setMaxIdleTime(
        ReportEtlContext.getInstance()
            .getReportEtlServiceConfig()
            .getHibernateConfig()
            .getMaxIdleTime());
    ds.setTestQuery(
        ReportEtlContext.getInstance()
            .getReportEtlServiceConfig()
            .getHibernateConfig()
            .getValidationQuery());
    ds.init();
    return ds;
  }

  private static AtomikosConnectionFactoryBean getConnectionFactory(String jmsBrokerUrl) {
    ActiveMQXAConnectionFactory xaConnFactory = new ActiveMQXAConnectionFactory();
    xaConnFactory.setBrokerURL(jmsBrokerUrl);
    xaConnFactory.setUserName(
        ReportEtlContext.getInstance()
            .getReportEtlServiceConfig()
            .getMqconsumer()
            .get(ReportEtlConsts.ACTIVE_MQ_USERNAME)
            .toString());
    xaConnFactory.setPassword(
        ReportEtlContext.getInstance()
            .getReportEtlServiceConfig()
            .getMqconsumer()
            .get(ReportEtlConsts.ACTIVE_MQ_PASSWORD)
            .toString());
    AtomikosConnectionFactoryBean connFactory = new AtomikosConnectionFactoryBean();
    connFactory.setXaConnectionFactory(xaConnFactory);
    connFactory.setUniqueResourceName(ReportEtlConsts.ETL_SERVICE_NAME + "_" + "ActiveMqConsumer");
    connFactory.setMaxPoolSize(
        Integer.parseInt(
            ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getMqconsumer()
                .get(ReportEtlConsts.CONSUMER_POOL_SIZE)
                .toString()));
    return connFactory;
  }

  private static Topic getTopic(String qName) {
    ActiveMQTopic topic = new ActiveMQTopic();
    topic.setPhysicalName(qName);
    return topic;
  }

  private static ActiveMQQueue getQueue(String topicName) {
    ActiveMQQueue topic = new ActiveMQQueue();
    topic.setPhysicalName(
        topicName
            + "?consumer.prefetchSize="
            + ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getMqconsumer()
                .get(ReportEtlConsts.PREFETCH_LIMIT)
                .toString());
    return topic;
  }

  private static MessageDrivenContainer createMessageDrivenContainer(
      AtomikosConnectionFactoryBean connFactory, Topic topic) {
    try {
      MessageDrivenContainer container = new MessageDrivenContainer();
      container.setPoolSize(1);
      container.setTransactionTimeout(
          Integer.parseInt(
              ReportEtlContext.getInstance()
                  .getReportEtlServiceConfig()
                  .getMqconsumer()
                  .get(ReportEtlConsts.CONSUMER_TIME_OUT)
                  .toString()));
      container.setAtomikosConnectionFactoryBean(connFactory);
      container.setDestination(topic);
      container.setClientID(
          ReportEtlContext.getInstance()
                  .getReportEtlServiceConfig()
                  .getMqconsumer()
                  .get(ReportEtlConsts.ACTIVE_MQ_CLIENT_ID)
              + ":"
              + topic.getTopicName());
      container.setSubscriberName(topic.getTopicName());
      container.setExceptionListener(
          e ->
              LOG.error(
                  "createMessageDrivenContainer Error : "
                      + e.getMessage()
                      + " StackTrace: "
                      + Arrays.toString(e.getStackTrace())
                      + " "
                      + "linkedException: "
                      + (e.getLinkedException() != null
                          ? e.getLinkedException().getMessage()
                          : "")));
      return container;

    } catch (Exception ex) {
      LOG.error("createMessageDrivenContainer Exception : " + ex.getMessage());
      return null;
    }
  }

  private static MessageDrivenContainer createMessageDrivenContainerQueue(
      AtomikosConnectionFactoryBean connFactory, ActiveMQQueue topic) {
    MessageDrivenContainer container = new MessageDrivenContainer();
    container.setPoolSize(1);
    container.setUser(
        ReportEtlContext.getInstance()
            .getReportEtlServiceConfig()
            .getMqconsumer()
            .get(ReportEtlConsts.ACTIVE_MQ_USERNAME)
            .toString());
    container.setPassword(
        ReportEtlContext.getInstance()
            .getReportEtlServiceConfig()
            .getMqconsumer()
            .get(ReportEtlConsts.ACTIVE_MQ_PASSWORD)
            .toString());
    container.setTransactionTimeout(
        Integer.parseInt(
            ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getMqconsumer()
                .get(ReportEtlConsts.CONSUMER_TIME_OUT)
                .toString()));
    container.setAtomikosConnectionFactoryBean(connFactory);
    container.setDestination(topic);
    container.setExceptionListener(
        e ->
            LOG.error(
                e.getMessage()
                    + " StackTrace: "
                    + Arrays.toString(e.getStackTrace())
                    + " linkedException: "
                    + (e.getLinkedException() != null ? e.getLinkedException().getMessage() : "")));
    return container;
  }

  private void listenTopic(String topicName) {
    try {
      if (connFactory == null) {
        connFactory = getConnectionFactory(brokerUrl);
        LOG.info("ActiveMq Consumer Started");
      }
      Topic topic = getTopic(topicName);

      MessageDrivenContainer container = createMessageDrivenContainer(connFactory, topic);
      if (container != null) {
        container.setMessageListener(new XaMessageListener(topicName));
        container.start();

        LOG.info("New topic container added : " + topicName);
        containers.add(container);
      } else {
        LOG.error("Message Driven Container not created for {}", topicName);
      }
    } catch (JMSException e) {
      LOG.error("listenTopic JMSException : " + e.getMessage());
    }
  }

  private void listenQueue(String queueName, Integer groupCount) throws JMSException {
    if (connFactory == null) {
      connFactory = getConnectionFactory(brokerUrl);
      LOG.info("ActiveMq Consumer Started");
    }
    for (int num = 1; num <= groupCount; num++) {
      ActiveMQQueue activeMQQueue = getQueue(queueName);

      MessageDrivenContainer container =
          createMessageDrivenContainerQueue(connFactory, activeMQQueue);
      container.setMessageListener(new XaMessageListener(queueName));
      container.start();
      LOG.info("New Queue container added : " + queueName + " -- " + num);
      containers.add(container);
    }
  }

  @Override
  public void start() throws Exception {
    try {
      Boolean isMysqlConnSuccess = startMySqlConnection();
      if (isMysqlConnSuccess) {
        startHibernateConnection();
        startActiveMqConnection();
      } else {
        LOG.error("CRITICAL Error: mysqlConnection not get succeeded, returned false");
      }
    } catch (Exception e) {
      LOG.error("XaAmqUtil Start Error :" + e.getMessage());
      throw e;
    }
  }

  private Boolean startMySqlConnection() {

    // Retry, if we have encountered exception in the initialize based on
    // the boolean flag variables.
    int hibernateTryCount = 0;
    while (true) {
      try {
        Thread.sleep(5000);

        if (!ReportEtlContext.isHibernateInitialized()) {
          try {
            LOG.info("Hibernate Retry Number :" + hibernateTryCount);
            //                        if (hibernateTryCount <
            // ReportEtlContext.HIBERNATE_RETRY_COUNT) {
            ReportEtlManaged.getInstance().startHibernate();
            /*} else {
                LOG.error("Hibernate could not be started!! ..EXITING APPLICATION..!!");
                LOG.error("..!!EXITING APPLICATION..!!");
                return false;
            }*/
          } catch (Exception e) {
            hibernateTryCount++;
            LOG.error("startMySqlConnection Error :" + e.getMessage(), e);
          }
        }
        if (ReportEtlContext.isHibernateInitialized()) {
          return true;
        }
      } catch (InterruptedException e) {
        LOG.error("startMySqlConnection InterruptedException Error :" + e.getMessage());
      }
    }
  }

  @Override
  public void stop() throws Exception {
    if (containers.size() > 0) {
      for (MessageDrivenContainer temp : containers) {
        if (temp != null && temp.getDestinationName() != null) {
          LOG.info(temp.getDestinationName() + "getting stopped");
          temp.stop();
        } else {
          LOG.error(temp.toString() + " having null , so not stopped");
        }
      }
    }
    connFactory.close();
    try {
      if (durableSubscriberCheck != null) {
        durableSubscriberCheck.closeConnection();
      }
    } catch (JMSException e) {
      LOG.error("XaAmqUtil Stop JmsException : " + e.getMessage());
    }

    LOG.info("ActiveMq Stopped");
    reportDataSource.close();
    reportSessionFactory.close();
    LOG.info("stopped Hibernate..!!");
  }

  private void startHibernateConnection() throws Exception {
    try {
      reportDataSource = createDataSource();

      File f =
          new File(
              ReportEtlContext.getInstance().getReportEtlServiceConfig().getHibernateConfigPath()
                  + "atomikos_hibernate.cfg.xml");
      if (f.exists()) {
        Configuration cfg = new Configuration().configure(f);
        cfg.setProperty(
            "hibernate.hbm2ddl.auto",
            ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getHibernateConfig()
                .getSchemaValidateOption());
        reportSessionFactory = cfg.buildSessionFactory();
      } else {
        // TODO throw error, don't start the application
        LOG.error("Hibernate Connection Error..!!");
      }
      LOG.info("Atomikos Hibernate Started Successfully");
      ReportEtlContext.setIsXaHibernateInitialized(true);
    } catch (Exception e) {
      LOG.error("startHibernateConnection Error :" + e.getMessage());
      throw e;
    }
  }

  private void startActiveMqConnection() throws Exception {
    if (connFactory == null) {
      connFactory = getConnectionFactory(brokerUrl);
      LOG.info("ActiveMq Consumer Started");
    }
    ReportEtlContext.setIsXaActiveMQInitialized(true);
    if (ReportEtlContext.isXaActiveMQInitialized()
        && ReportEtlContext.isXaHibernateInitialized()
        && ReportEtlContext.isHibernateInitialized()) {

      List<String> topics =
          ReportEtlContext.getInstance().getReportEtlServiceConfig().getMqconsumerTopics();

      if (topics != null && topics.size() > 0) {
        new Thread(
                new Runnable() {
                  private Boolean toContinue = false;
                  private String hearBeatTopicName =
                      (String)
                          ReportEtlContext.getInstance()
                              .getReportEtlServiceConfig()
                              .getMqconsumer()
                              .get(ReportEtlConsts.HEART_BEAT_TOPIC);

                  public void run() {
                    do {
                      try {
                        ReportEtlContext.setIsMaster(toContinue);
                        durableSubscriberCheck.createConnection(
                            (String)
                                ReportEtlContext.getInstance()
                                    .getReportEtlServiceConfig()
                                    .getMqconsumer()
                                    .get(ReportEtlConsts.ACTIVE_MQ_CLIENT_ID),
                            hearBeatTopicName,
                            hearBeatTopicName,
                            brokerUrl);
                        toContinue = true;
                        ReportEtlContext.setIsMaster(true);
                      } catch (InvalidClientIDException ex) {
                        LOG.error(ex.toString());
                        try {
                          durableSubscriberCheck.closeConnection();
                        } catch (JMSException e) {
                          LOG.error(ex.toString());
                        }
                      } catch (Exception ex) {
                        LOG.error(ex.toString());
                      }
                      if (toContinue) {
                        LOG.info(threadId + " got acquisition to consume topics");
                        consumeEachTopic(topics);
                        LOG.info("Listening ActiveMq Topics Started");
                        break;
                      } else {
                        LOG.info(threadId + " didn't got acquisition to consume topics");
                      }
                      try {
                        Thread.sleep(
                            Long.valueOf(
                                (String)
                                    ReportEtlContext.getInstance()
                                        .getReportEtlServiceConfig()
                                        .getMqconsumer()
                                        .get(ReportEtlConsts.SUBSCRIBER_RETRY_INTERVAL_MS)));
                      } catch (InterruptedException e) {
                        LOG.error(e.getMessage());
                      }
                    } while (true);
                  }
                })
            .start();
      } else {
        LOG.warn("No Topics listed to subscribe in ActiveMq");
      }

      HashMap<String, String> queues =
          ReportEtlContext.getInstance().getReportEtlServiceConfig().getMqConsumerQueues();

      HashMap<String, Integer> queuesCount =
          ReportEtlContext.getInstance().getReportEtlServiceConfig().getMqConsumerQueueCount();
      if (queues != null && queues.size() > 0) {

        for (Map.Entry<String, String> temp : queues.entrySet()) {
          try {
            if (queuesCount != null
                && queuesCount.size() > 0
                && queuesCount.get(temp.getKey()) != null
                && queuesCount.get(temp.getKey()) > 0) {
              listenQueue(temp.getValue(), queuesCount.get(temp.getKey()));
            } else {
              listenQueue(temp.getValue(), 1);
            }
            LOG.info("Queue Subscribed : " + temp.getValue());
          } catch (Exception e) {
            LOG.error("startHibernateConnection Error :" + e.getMessage());
          }
        }
        LOG.info("Started queues listening ActiveMq ..!!");
      } else {
        LOG.info("No queues listed to subscribe in ActiveMq");
      }
    }
  }

  private void consumeEachTopic(List<String> topics) {
    for (String topic : topics) {
      if (!topic.equalsIgnoreCase("empty")) {
        try {
          listenTopic(topic);
          LOG.info("Subscribed " + topic);
        } catch (Exception e) {
          LOG.error("Topic subscribing not happened for :" + topic);
          LOG.error(
              "ExecutionException in consumeEachTopic Error "
                  + e.getMessage()
                  + "Stack Trace: "
                  + Arrays.toString(e.getStackTrace()));
        }
      } else {
        LOG.warn("Topic ignored : " + topic);
      }
    }
    LOG.info("Started Topics listening ActiveMq ..!!");
  }

  public SessionFactory getSessionFactory() {
    try {
      /*
       * if (reportSessionFactory.isClosed()) { reportDataSource.close();
       * reportSessionFactory.close(); startHibernateConnection(); return
       * reportSessionFactory; } else {
       */
      return reportSessionFactory;
      // }
    } catch (Exception e) {
      LOG.error("XaAmqUtil getSessionFactory Error :" + e.toString());
      return null;
    }
  }
}
