package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public final class DataSyncMessageCount {

  /** The serviceName. */
  private String serviceName;
  /** Max Event Id */
  private long maxEventId;
  /** Topic List */
  private List<String> topicList;
  /** SCS Message Count */
  private long scsMessageCount;
  /** Report Message Count */
  private long reportMessageCount;
  /** @return the serviceName */
  public String getServiceName() {
    return serviceName;
  }
  /** @param serviceName the serviceName to set */
  public void setServiceName(String serviceName) {
    this.serviceName = serviceName;
  }
  /** @return the maxEventId */
  public long getMaxEventId() {
    return maxEventId;
  }
  /** @param maxEventId the maxEventId to set */
  public void setMaxEventId(long maxEventId) {
    this.maxEventId = maxEventId;
  }
  /** @return the topicList */
  public List<String> getTopicList() {
    return topicList;
  }
  /** @param topicList the topicList to set */
  public void setTopicList(List<String> topicList) {
    this.topicList = topicList;
  }
  /** @return the scsMessageCount */
  public long getScsMessageCount() {
    return scsMessageCount;
  }
  /** @param scsMessageCount the scsMessageCount to set */
  public void setScsMessageCount(long scsMessageCount) {
    this.scsMessageCount = scsMessageCount;
  }
  /** @return the reportMessageCount */
  public long getReportMessageCount() {
    return reportMessageCount;
  }
  /** @param reportMessageCount the reportMessageCount to set */
  public void setReportMessageCount(long reportMessageCount) {
    this.reportMessageCount = reportMessageCount;
  }
}
