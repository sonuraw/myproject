package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** The Class PlayerAddress. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PlayerAddress {

  /** The id. */
  private String id;

  /** The player id. */
  private Integer playerId;

  /** The type. */
  private String type;

  /** The co name. */
  private String coName;

  /** The house number. */
  private String houseNumber;

  /** The level. */
  private String level;

  /** The door. */
  private String door;

  /** The street. */
  private String street;

  /** The zip. */
  private String zip;

  /** The city. */
  private String city;

  /** The state. */
  private String state;

  /** The country. */
  private String country;

  /** The detail. */
  private String detail;

  /** The is validated. */
  private Boolean isValidated;

  /** The is verified. */
  private Boolean isVerified;

  /**
   * Gets the checks if is verified.
   *
   * @return the checks if is verified
   */
  public Boolean getIsVerified() {
    return isVerified;
  }

  /**
   * Sets the checks if is verified.
   *
   * @param isVerified the new checks if is verified
   */
  public void setIsVerified(Boolean isVerified) {
    this.isVerified = isVerified;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Sets the type.
   *
   * @param type the new type
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the co name.
   *
   * @return the co name
   */
  public String getCoName() {
    return coName;
  }

  /**
   * Sets the co name.
   *
   * @param coName the new co name
   */
  public void setCoName(String coName) {
    this.coName = coName;
  }

  /**
   * Gets the house number.
   *
   * @return the house number
   */
  public String getHouseNumber() {
    return houseNumber;
  }

  /**
   * Sets the house number.
   *
   * @param houseNumber the new house number
   */
  public void setHouseNumber(String houseNumber) {
    this.houseNumber = houseNumber;
  }

  /**
   * Gets the level.
   *
   * @return the level
   */
  public String getLevel() {
    return level;
  }

  /**
   * Sets the level.
   *
   * @param level the new level
   */
  public void setLevel(String level) {
    this.level = level;
  }

  /**
   * Gets the door.
   *
   * @return the door
   */
  public String getDoor() {
    return door;
  }

  /**
   * Sets the door.
   *
   * @param door the new door
   */
  public void setDoor(String door) {
    this.door = door;
  }

  /**
   * Gets the street.
   *
   * @return the street
   */
  public String getStreet() {
    return street;
  }

  /**
   * Sets the street.
   *
   * @param street the new street
   */
  public void setStreet(String street) {
    this.street = street;
  }

  /**
   * Gets the zip.
   *
   * @return the zip
   */
  public String getZip() {
    return zip;
  }

  /**
   * Sets the zip.
   *
   * @param zip the new zip
   */
  public void setZip(String zip) {
    this.zip = zip;
  }

  /**
   * Gets the city.
   *
   * @return the city
   */
  public String getCity() {
    return city;
  }

  /**
   * Sets the city.
   *
   * @param city the new city
   */
  public void setCity(String city) {
    this.city = city;
  }

  /**
   * Gets the state.
   *
   * @return the state
   */
  public String getState() {
    return state;
  }

  /**
   * Sets the state.
   *
   * @param state the new state
   */
  public void setState(String state) {
    this.state = state;
  }

  /**
   * Gets the country.
   *
   * @return the country
   */
  public String getCountry() {
    return country;
  }

  /**
   * Sets the country.
   *
   * @param country the new country
   */
  public void setCountry(String country) {
    this.country = country;
  }

  /**
   * Gets the detail.
   *
   * @return the detail
   */
  public String getDetail() {
    return detail;
  }

  /**
   * Sets the detail.
   *
   * @param detail the new detail
   */
  public void setDetail(String detail) {
    this.detail = detail;
  }

  /**
   * Gets the checks if is validated.
   *
   * @return the checks if is validated
   */
  public Boolean getIsValidated() {
    return isValidated;
  }

  /**
   * Sets the checks if is validated.
   *
   * @param isValidated the new checks if is validated
   */
  public void setIsValidated(Boolean isValidated) {
    this.isValidated = isValidated;
  }
}
