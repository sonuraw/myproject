package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public final class Links {

  private final String self;

  public Links() {
    this.self = null;
  }

  public Links(String self) {
    this.self = self;
  }

  @JsonProperty
  public String getSelf() {
    return self;
  }
}
