package com.sciplay.report.etl.Entities;

import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Type;

/**
 * The Class ErrorsLogEntity.
 *
 * @author salman
 */
@Entity
@Table(name = "EtlServiceErrorLog")
@DynamicUpdate
public class ErrorsLogEntity {

  /** The id. */
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "Id")
  private Integer id;

  /** The topic. */
  @Column(name = "Topic")
  private String topic;

  /** The type. */
  @Column(name = "Type")
  private String type;

  /** The retry count. */
  @Column(name = "RetryCount")
  private int retryCount;

  /** The error source data. */
  @Column(name = "ErrorSourceData")
  @Type(type = "text")
  private String errorSourceData;

  /** The error message. */
  @Column(name = "ErrorMessage")
  private String errorMessage;

  /** The correlation ID. */
  @Column(name = "CorrelationID")
  private String correlationID;

  /** The error stack trace. */
  @Column(name = "ErrorStackTrace")
  private String errorStackTrace;

  /** The updated date. */
  @Column(name = "UpdatedDate")
  private Date updatedDate;

  /** The processed status. */
  @Column(name = "ProcessedStatus")
  private String processedStatus = "Error";

  /** The ledger. */
  @Column(name = "Ledger")
  private String ledger;

  /** The ledger. */
  @Column(name = "Version")
  private String version;

  /** The is reprocessed. */
  @Column(name = "IsReprocessRequired")
  private Boolean isReprocessRequired;

  /** The updated date. */
  @Column(name = "TranCreatedDate")
  private Date tranCreatedDate;

  /** The updated date. */
  @Column(name = "TranUpdatedDate")
  private Date tranUpdatedDate;

  /** The updated date. */
  @Column(name = "TranApprovedDate")
  private Date tranApprovedDate;

  /** The updated date. */
  @Column(name = "TranGviUpdatedDate")
  private Date tranGviUpdatedDate;

  /** The updated date. */
  @Column(name = "TableName")
  private String tableName;

  /** Instantiates a new errors log entity. */
  public ErrorsLogEntity() {}

  /**
   * Instantiates a new errors log entity.
   *
   * @param topic the topic
   * @param errorSourceData the error source data
   * @param errorMessage the error message
   * @param errorStackTrace the error stack trace
   * @param correlationID the correlation ID
   * @param type the type
   * @param retryCount the retry count
   */
  public ErrorsLogEntity(
      String topic,
      String errorSourceData,
      String errorMessage,
      String errorStackTrace,
      String correlationID,
      String type,
      Integer retryCount,
      String ledger) {
    this.topic = topic;
    this.errorSourceData = errorSourceData;
    this.errorMessage = errorMessage;
    this.errorStackTrace = errorStackTrace;
    this.correlationID = correlationID;
    this.type = type;
    this.retryCount = Objects.isNull(retryCount) ? 0 : retryCount;
    this.ledger = ledger;
  }

  /**
   * Instantiates a new errors log entity.
   *
   * @param topic the topic
   * @param errorSourceData the error source data
   * @param errorMessage the error message
   * @param errorStackTrace the error stack trace
   * @param correlationID the correlation ID
   * @param type the type
   * @param isReprocessRequired the isReprocessRequired
   */
  public ErrorsLogEntity(
      String topic,
      String errorSourceData,
      String errorMessage,
      String errorStackTrace,
      String correlationID,
      String type,
      String ledger,
      Boolean isReprocessRequired) {
    this.topic = topic;
    this.errorSourceData = errorSourceData;
    this.errorMessage = errorMessage;
    this.errorStackTrace = errorStackTrace;
    this.correlationID = correlationID;
    this.type = type;
    this.ledger = ledger;
    this.isReprocessRequired = Objects.isNull(isReprocessRequired) ? false : isReprocessRequired;
  }

  public ErrorsLogEntity(
      String topic,
      String errorSourceData,
      String errorMessage,
      String errorStackTrace,
      String correlationID,
      String type,
      String ledger,
      Boolean isReprocessRequired,
      String processedStatus) {
    this.topic = topic;
    this.errorSourceData = errorSourceData;
    this.errorMessage = errorMessage;
    this.errorStackTrace = errorStackTrace;
    this.correlationID = correlationID;
    this.type = type;
    this.ledger = ledger;
    this.isReprocessRequired = Objects.isNull(isReprocessRequired) ? false : isReprocessRequired;
    this.processedStatus = processedStatus;
  }

  /**
   * Gets the ledger.
   *
   * @return the ledger
   */
  public String getLedger() {
    return ledger;
  }

  /**
   * Sets the ledger.
   *
   * @param ledger the new ledger
   */
  public void setLedger(String ledger) {
    this.ledger = ledger;
  }

  /**
   * Gets the topic.
   *
   * @return the topic
   */
  public String getTopic() {
    return topic;
  }

  /**
   * Sets the topic.
   *
   * @param topic the new topic
   */
  public void setTopic(String topic) {
    this.topic = topic;
  }

  /**
   * Gets the error source data.
   *
   * @return the error source data
   */
  public String getErrorSourceData() {
    return errorSourceData;
  }

  /**
   * Sets the error source data.
   *
   * @param errorSourceData the new error source data
   */
  public void setErrorSourceData(String errorSourceData) {
    this.errorSourceData = errorSourceData;
  }

  /**
   * Gets the error message.
   *
   * @return the error message
   */
  public String getErrorMessage() {
    return errorMessage;
  }

  /**
   * Sets the error message.
   *
   * @param errorMessage the new error message
   */
  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }

  /**
   * Gets the error stack trace.
   *
   * @return the error stack trace
   */
  public String getErrorStackTrace() {
    return errorStackTrace;
  }

  /**
   * Sets the error stack trace.
   *
   * @param errorStackTrace the new error stack trace
   */
  public void setErrorStackTrace(String errorStackTrace) {
    this.errorStackTrace = errorStackTrace;
  }

  /**
   * Gets the correlation ID.
   *
   * @return the correlationID
   */
  public String getCorrelationID() {
    return correlationID;
  }

  /**
   * Sets the correlation ID.
   *
   * @param correlationID the correlationID to set
   */
  public void setCorrelationID(String correlationID) {
    this.correlationID = correlationID;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public Integer getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id the id to set
   */
  public void setId(Integer id) {
    this.id = id;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Sets the type.
   *
   * @param type the type to set
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the retry count.
   *
   * @return the retryCount
   */
  public int getRetryCount() {
    return retryCount;
  }

  /**
   * Sets the retry count.
   *
   * @param retryCount the retryCount to set
   */
  public void setRetryCount(int retryCount) {
    this.retryCount = Objects.isNull(retryCount) ? 0 : retryCount;
  }

  /**
   * Gets the updated date.
   *
   * @return the updatedDate
   */
  public Date getUpdatedDate() {
    return updatedDate;
  }

  /**
   * Sets the updated date.
   *
   * @param updatedDate the updatedDate to set
   */
  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  /**
   * Gets the processed status.
   *
   * @return the processedStatus
   */
  public String getProcessedStatus() {
    return processedStatus;
  }

  /**
   * Sets the processed status.
   *
   * @param processedStatus the processedStatus to set
   */
  public void setProcessedStatus(String processedStatus) {
    this.processedStatus = processedStatus;
  }

  /** @return the version */
  public String getVersion() {
    return version;
  }

  /** @param version the version to set */
  public void setVersion(String version) {
    this.version = version;
  }

  /** @return the isReprocessRequired */
  public Boolean getIsReprocessRequired() {
    return isReprocessRequired;
  }

  /** @param isReprocessRequired the isReprocessRequired to set */
  public void setIsReprocessRequired(Boolean isReprocessRequired) {
    this.isReprocessRequired = Objects.isNull(isReprocessRequired) ? false : isReprocessRequired;
  }

  public Date getTranCreatedDate() {
    return tranCreatedDate;
  }

  public void setTranCreatedDate(Date tranCreatedDate) {
    this.tranCreatedDate = tranCreatedDate;
  }

  public Date getTranUpdatedDate() {
    return tranUpdatedDate;
  }

  public void setTranUpdatedDate(Date tranUpdatedDate) {
    this.tranUpdatedDate = tranUpdatedDate;
  }

  public Date getTranApprovedDate() {
    return tranApprovedDate;
  }

  public void setTranApprovedDate(Date tranApprovedDate) {
    this.tranApprovedDate = tranApprovedDate;
  }

  public Date getTranGviUpdatedDate() {
    return tranGviUpdatedDate;
  }

  public void setTranGviUpdatedDate(Date tranGviUpdatedDate) {
    this.tranGviUpdatedDate = tranGviUpdatedDate;
  }

  public String getTableName() {
    return tableName;
  }

  public void setTableName(String tableName) {
    this.tableName = tableName;
  }
}
