package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public final class DataSyncCountResponseData {

  private String type;
  private Integer count;
  private long totalAmount;
  private Integer reportCount;

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public Integer getCount() {
    return count;
  }

  public void setCount(Integer count) {
    this.count = count;
  }

  public long getTotalAmount() {
    return totalAmount;
  }

  public void setTotalAmount(long totalAmount) {
    this.totalAmount = totalAmount;
  }

  public Integer getReportCount() {
    return reportCount;
  }

  public void setReportCount(Integer reportCount) {
    this.reportCount = reportCount;
  }
}
