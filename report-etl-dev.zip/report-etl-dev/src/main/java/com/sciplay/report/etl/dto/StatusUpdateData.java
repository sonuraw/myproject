package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** The Class Data. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class StatusUpdateData {

  /** The type. */
  private Long id;

  /** The type. */
  private String status;

  /** The type. */
  private String previousStatus;

  private Long lastTransactionId;

  private String srcURL;

  private String channel;

  private String wagerSetNotifyWin;

  private String numberOfWagers;

  /** @return the id */
  public Long getId() {
    return id;
  }

  /** @param id the id to set */
  public void setId(Long id) {
    this.id = id;
  }

  /** @return the status */
  public String getStatus() {
    return status;
  }

  /** @param status the status to set */
  public void setStatus(String status) {
    this.status = status;
  }

  /** @return the previousStatus */
  public String getPreviousStatus() {
    if (previousStatus != null && previousStatus.equalsIgnoreCase("string")) {
      previousStatus = null;
    }
    return previousStatus;
  }

  /** @param previousStatus the previousStatus to set */
  public void setPreviousStatus(String previousStatus) {
    this.previousStatus = previousStatus;
  }

  public Long getLastTransactionId() {
    return lastTransactionId;
  }

  public void setLastTransactionId(Long lastTransactionId) {
    this.lastTransactionId = lastTransactionId;
  }

  public String getSrcURL() {
    return srcURL;
  }

  public void setSrcURL(String srcURL) {
    this.srcURL = srcURL;
  }

  public String getChannel() {
    return channel;
  }

  public void setChannel(String channel) {
    this.channel = channel;
  }

  public String getNumberOfWagers() {
    return numberOfWagers;
  }

  public void setNumberOfWagers(String numberOfWagers) {
    this.numberOfWagers = numberOfWagers;
  }

  public String getWagerSetNotifyWin() {
    return wagerSetNotifyWin;
  }

  public void setWagerSetNotifyWin(String wagerSetNotifyWin) {
    this.wagerSetNotifyWin = wagerSetNotifyWin;
  }
}
