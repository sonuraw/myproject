package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sciplay.report.etl.ReportEtlConsts;
import com.sciplay.report.etl.utils.ParamUtils;
import io.swagger.annotations.ApiModelProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public final class MetaResponse {

  /** Copyright. */
  @ApiModelProperty(required = true, value = "Copyright information")
  private String copyright = ReportEtlConsts.COPYRIGHT_TEMPLATE;

  /** creating time of this message. */
  @ApiModelProperty(required = true, value = "Created at timestamp")
  private String createdAt = ParamUtils.getCurrentTimestamp();

  /** Default constructor. */
  public MetaResponse() {}

  /** @return The copyright */
  public String getCopyright() {
    return copyright;
  }

  /** @param strCopyright The copyright */
  public void setCopyright(final String strCopyright) {
    this.copyright = strCopyright;
  }

  /** @return The createdAt */
  public String getCreatedAt() {
    return createdAt;
  }

  /** @param strCreationTime The createdAt */
  public void setCreatedAt(final String strCreationTime) {
    this.createdAt = strCreationTime;
  }
}
