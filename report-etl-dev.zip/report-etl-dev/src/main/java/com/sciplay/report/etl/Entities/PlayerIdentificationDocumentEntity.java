package com.sciplay.report.etl.Entities;

import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class IdentificationDocument. */
@Entity
@Table(name = "PlayerIdentificationDocument")
public class PlayerIdentificationDocumentEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The id. */
  @Id
  @Column(name = "Id")
  private String id;

  /** The player id. */
  private Integer playerId;

  /** The operator id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The type. */
  private String type;

  /** The number. */
  private String number;

  /** The issuer. */
  private String issuer;

  /** The expiration date. */
  private Date expirationDate;

  /** The author player id. */
  private Integer authorPlayerId;

  /** The author agent id. */
  private Integer authorAgentId;

  /** The author ip. */
  private String authorIp;

  /** The author session id. */
  private String authorSessionId;

  /** The created at. */
  private Date createdAt;

  /** The is validated. */
  private Boolean isValidated;

  private Date modifiedAt;

  /** The isDeleted. */
  @Column(name = "isDeleted")
  private Boolean isDeleted = false;

  /** Instantiates a new identification document. */
  public PlayerIdentificationDocumentEntity() {}

  /**
   * Instantiates a new identification document.
   *
   * @param id the id
   * @param playerId the player id
   * @param operatorId the operator id
   * @param type the type
   * @param number the number
   * @param issuer the issuer
   * @param expirationDate the expiration date
   * @param createdAt the created at
   */
  public PlayerIdentificationDocumentEntity(
      String id,
      Integer playerId,
      String operatorId,
      String type,
      String number,
      String issuer,
      Date expirationDate,
      Date createdAt,
      Date modifiedAt) {
    this.id = id;
    this.playerId = playerId;
    this.operatorId = operatorId;
    this.type = type;
    this.number = number;
    this.issuer = issuer;
    this.expirationDate = expirationDate;
    this.createdAt = createdAt;
    this.modifiedAt = modifiedAt;
  }

  /**
   * Instantiates a new identification document.
   *
   * @param id the id
   * @param playerId the player id
   * @param operatorId the operator id
   * @param type the type
   * @param number the number
   * @param issuer the issuer
   * @param expirationDate the expiration date
   * @param authorPlayerId the author player id
   * @param authorAgentId the author agent id
   * @param authorIp the author ip
   * @param authorSessionId the author session id
   * @param createdAt the created at
   */
  public PlayerIdentificationDocumentEntity(
      String id,
      Integer playerId,
      String operatorId,
      String type,
      String number,
      String issuer,
      Date expirationDate,
      Boolean isValidated,
      Integer authorPlayerId,
      Integer authorAgentId,
      String authorIp,
      String authorSessionId,
      Date createdAt,
      Date modifiedAt) {
    this.id = id;
    this.playerId = playerId;
    this.operatorId = operatorId;
    this.type = type;
    this.number = number;
    this.issuer = issuer;
    this.expirationDate = expirationDate;
    this.isValidated = Objects.isNull(isValidated) ? false : isValidated;
    this.authorPlayerId = Objects.isNull(authorPlayerId) ? 0 : authorPlayerId;
    this.authorAgentId = Objects.isNull(authorAgentId) ? 0 : authorAgentId;
    this.authorIp = authorIp;
    this.authorSessionId = authorSessionId;
    this.createdAt = createdAt;
    this.modifiedAt = modifiedAt;
  }

  public Date getModifiedAt() {
    return modifiedAt;
  }

  public void setModifiedAt(Date modifiedAt) {
    this.modifiedAt = modifiedAt;
  }

  /**
   * Gets the checks if is validated.
   *
   * @return the checks if is validated
   */
  public Boolean getIsValidated() {
    return isValidated;
  }

  /**
   * Sets the checks if is validated.
   *
   * @param isValidated the new checks if is validated
   */
  public void setIsValidated(Boolean isValidated) {
    this.isValidated = Objects.isNull(isValidated) ? false : isValidated;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public String getId() {
    return this.id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return this.playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return this.operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return this.type;
  }

  /**
   * Sets the type.
   *
   * @param type the new type
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the number.
   *
   * @return the number
   */
  public String getNumber() {
    return this.number;
  }

  /**
   * Sets the number.
   *
   * @param number the new number
   */
  public void setNumber(String number) {
    this.number = number;
  }

  /**
   * Gets the issuer.
   *
   * @return the issuer
   */
  public String getIssuer() {
    return this.issuer;
  }

  /**
   * Sets the issuer.
   *
   * @param issuer the new issuer
   */
  public void setIssuer(String issuer) {
    this.issuer = issuer;
  }

  /**
   * Gets the expiration date.
   *
   * @return the expiration date
   */
  public Date getExpirationDate() {
    return this.expirationDate;
  }

  /**
   * Sets the expiration date.
   *
   * @param expirationDate the new expiration date
   */
  public void setExpirationDate(Date expirationDate) {
    this.expirationDate = expirationDate;
  }

  /**
   * Gets the author player id.
   *
   * @return the author player id
   */
  public Integer getAuthorPlayerId() {
    return this.authorPlayerId;
  }

  /**
   * Sets the author player id.
   *
   * @param authorPlayerId the new author player id
   */
  public void setAuthorPlayerId(Integer authorPlayerId) {
    this.authorPlayerId = Objects.isNull(authorPlayerId) ? 0 : authorPlayerId;
  }

  /**
   * Gets the author agent id.
   *
   * @return the author agent id
   */
  public Integer getAuthorAgentId() {
    return this.authorAgentId;
  }

  /**
   * Sets the author agent id.
   *
   * @param authorAgentId the new author agent id
   */
  public void setAuthorAgentId(Integer authorAgentId) {
    this.authorAgentId = Objects.isNull(authorAgentId) ? 0 : authorAgentId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return this.authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return this.authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return this.createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  /** @return the isDeleted */
  public Boolean getIsDeleted() {
    return isDeleted;
  }

  /** @param isDeleted the isDeleted to set */
  public void setIsDeleted(Boolean isDeleted) {
    this.isDeleted = Objects.isNull(isDeleted) ? false : isDeleted;
  }
}
