package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Date;

/** The Class Identification. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Identification {

  /** The id. */
  private String id;

  /** The player id. */
  private Integer playerId;

  /** The type. */
  private String type;

  /** The number. */
  private String number;

  /** The issuer. */
  private String issuer;

  /** The expiration date. */
  private Date expirationDate;

  /** The is validated. */
  private Boolean isValidated;

  /**
   * Gets the id.
   *
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Sets the type.
   *
   * @param type the new type
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the number.
   *
   * @return the number
   */
  public String getNumber() {
    return number;
  }

  /**
   * Sets the number.
   *
   * @param number the new number
   */
  public void setNumber(String number) {
    this.number = number;
  }

  /**
   * Gets the issuer.
   *
   * @return the issuer
   */
  public String getIssuer() {
    return issuer;
  }

  /**
   * Sets the issuer.
   *
   * @param issuer the new issuer
   */
  public void setIssuer(String issuer) {
    this.issuer = issuer;
  }

  /**
   * Gets the expiration date.
   *
   * @return the expiration date
   */
  public Date getExpirationDate() {
    return expirationDate;
  }

  /**
   * Sets the expiration date.
   *
   * @param expirationDate the new expiration date
   */
  public void setExpirationDate(Date expirationDate) {
    this.expirationDate = expirationDate;
  }

  /**
   * Gets the checks if is validated.
   *
   * @return the checks if is validated
   */
  public Boolean getIsValidated() {
    return isValidated;
  }

  /**
   * Sets the checks if is validated.
   *
   * @param isValidated the new checks if is validated
   */
  public void setIsValidated(Boolean isValidated) {
    this.isValidated = isValidated;
  }
}
