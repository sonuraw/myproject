package com.sciplay.report.etl.dto.limits;

import java.util.List;

public class LimitScope {

  private List<String> games;

  private String operatorId;

  private Integer playerId;

  private String vertical;

  public String getVertical() {
    return this.vertical;
  }

  public void setVertical(String vertical) {
    this.vertical = vertical;
  }

  public List<String> getGames() {
    return this.games;
  }

  public void setGames(List<String> games) {
    this.games = games;
  }

  public String getOperatorId() {
    return this.operatorId;
  }

  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  public Integer getPlayerId() {
    return this.playerId;
  }

  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }
}
