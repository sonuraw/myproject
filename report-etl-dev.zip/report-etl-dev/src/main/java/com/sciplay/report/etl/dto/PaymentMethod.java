package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Date;

/** The Class PaymentMethod. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentMethod {

  /** The player id. */
  private Integer playerId;

  /** The type. */
  private String type;

  /** The holder. */
  private String holder;

  /** The bank name. */
  private String bankName;

  /** The account number. */
  private String accountNumber;

  /** The routing number. */
  private String routingNumber;

  /** The card number last four. */
  private String cardNumberLastFour;

  /** The expiration date. */
  private Date expirationDate;

  /** The token. */
  private String token;

  /** The is valid. */
  private Boolean isValid;

  /** The is Preferred. */
  private Boolean isPreferred;

  /** The card type. */
  private String cardType;

  /**
   * Gets the card type.
   *
   * @return the card type
   */
  public String getCardType() {
    return cardType;
  }

  /**
   * Sets the card type.
   *
   * @param cardType the new card type
   */
  public void setCardType(String cardType) {
    this.cardType = cardType;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Sets the type.
   *
   * @param type the new type
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the holder.
   *
   * @return the holder
   */
  public String getHolder() {
    return holder;
  }

  /**
   * Sets the holder.
   *
   * @param holder the new holder
   */
  public void setHolder(String holder) {
    this.holder = holder;
  }

  /**
   * Gets the bank name.
   *
   * @return the bank name
   */
  public String getBankName() {
    return bankName;
  }

  /**
   * Sets the bank name.
   *
   * @param bankName the new bank name
   */
  public void setBankName(String bankName) {
    this.bankName = bankName;
  }

  /**
   * Gets the account number.
   *
   * @return the account number
   */
  public String getAccountNumber() {
    return accountNumber;
  }

  /**
   * Sets the account number.
   *
   * @param accountNumber the new account number
   */
  public void setAccountNumber(String accountNumber) {
    this.accountNumber = accountNumber;
  }

  /**
   * Gets the routing number.
   *
   * @return the routing number
   */
  public String getRoutingNumber() {
    return routingNumber;
  }

  /**
   * Sets the routing number.
   *
   * @param routingNumber the new routing number
   */
  public void setRoutingNumber(String routingNumber) {
    this.routingNumber = routingNumber;
  }

  /**
   * Gets the card number last four.
   *
   * @return the card number last four
   */
  public String getCardNumberLastFour() {
    return cardNumberLastFour;
  }

  /**
   * Sets the card number last four.
   *
   * @param cardNumberLastFour the new card number last four
   */
  public void setCardNumberLastFour(String cardNumberLastFour) {
    this.cardNumberLastFour = cardNumberLastFour;
  }

  /**
   * Gets the expiration date.
   *
   * @return the expiration date
   */
  public Date getExpirationDate() {
    return expirationDate;
  }

  /**
   * Sets the expiration date.
   *
   * @param expirationDate the new expiration date
   */
  public void setExpirationDate(Date expirationDate) {
    this.expirationDate = expirationDate;
  }

  /**
   * Gets the token.
   *
   * @return the token
   */
  public String getToken() {
    return token;
  }

  /**
   * Sets the token.
   *
   * @param token the new token
   */
  public void setToken(String token) {
    this.token = token;
  }

  /**
   * Gets the checks if is valid.
   *
   * @return the checks if is valid
   */
  public Boolean getIsValid() {
    return isValid;
  }

  /**
   * Sets the checks if is valid.
   *
   * @param isValid the new checks if is valid
   */
  public void setIsValid(Boolean isValid) {
    this.isValid = isValid;
  }

  /** @return the isPreferred */
  public Boolean getIsPreferred() {
    return isPreferred;
  }

  /** @param isPreferred the isPreferred to set */
  public void setIsPreferred(Boolean isPreferred) {
    this.isPreferred = isPreferred;
  }
}
