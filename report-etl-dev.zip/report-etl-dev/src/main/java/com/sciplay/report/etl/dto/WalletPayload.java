package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sciplay.report.etl.exception.CustomException;
import java.util.Date;
import java.util.Objects;

/** The Class Attributes. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class WalletPayload {

  private Integer forceUpdatedBy;

  /** The game. */
  private Integer game;

  /** The group ID. */
  private String groupID;

  /** The src URL. */
  private String srcURL;

  /** The payment ID. */
  private String paymentID;

  /** The subtype. */
  private String subtype;

  /** The round ID. */
  private String roundID;

  /** The affiliate. */
  private String affiliate;

  /** The reason. */
  private String reason;

  /** The ref transaction id. */
  private String refTransactionId;

  /** The winning id. */
  private String winningId;

  /** The wager state. */
  private String wagerState;

  /** The winning state. */
  private String winningState;

  private String gviState;

  private String gviPreviousState;

  private Date gviStateUpdatedAt;

  /** The winning external created time. */
  private String winningExternalCreatedTime;

  /** The wager external id. */
  private String wagerExternalId;

  /** The wager set external id. */
  private String wagerSetExternalId;

  /** The wager external created time. */
  private String wagerExternalCreatedTime;

  /** The wager notify win. */
  private String wagerNotifyWin;

  /** The wager set external created time. */
  private String wagerSetExternalCreatedTime;

  /** The wager set notify win. */
  private String wagerSetNotifyWin;

  /** The wager brand. */
  private String wagerBrand;

  /** The number of wagers. */
  private String numberOfWagers;

  /** The set ID. */
  private String setID;

  /** The external id. */
  private String externalId;

  /** The previous status. */
  private String previousStatus;

  /** The external created at. */
  private String externalCreatedAt;

  /** The owner. */
  private String owner;

  /** The comment. */
  private String comment;

  /** The purchase order id. */
  private String purchaseOrderId;

  /** The wager type. */
  private String wagerType;

  /** The wager set type. */
  private String wagerSetType;

  private String cardType;

  private String cardNumberLastFour;

  private String wagerSetState;

  private String wagerSetBrand;

  /**
   * Gets the wager type.
   *
   * @return the wager type
   */
  public String getWagerType() {
    return wagerType;
  }

  /**
   * Sets the wager type.
   *
   * @param wagerType the new wager type
   */
  public void setWagerType(String wagerType) {
    this.wagerType = wagerType;
  }

  /**
   * Gets the wager set type.
   *
   * @return the wager set type
   */
  public String getWagerSetType() {
    return wagerSetType;
  }

  /**
   * Sets the wager set type.
   *
   * @param wagerSetType the new wager set type
   */
  public void setWagerSetType(String wagerSetType) {
    this.wagerSetType = wagerSetType;
  }

  /**
   * Gets the purchase order id.
   *
   * @return the purchase order id
   */
  public String getPurchaseOrderId() {
    return purchaseOrderId;
  }

  /**
   * Sets the purchase order id.
   *
   * @param purchaseOrderId the new purchase order id
   */
  public void setPurchaseOrderId(String purchaseOrderId) {
    this.purchaseOrderId = purchaseOrderId;
  }

  /**
   * Gets the group ID.
   *
   * @return the groupID
   */
  public long getGroupID() {
    if (Objects.equals(groupID, "") || groupID == null) {
      return Long.valueOf(Long.parseLong("0"));
    } else {
      return Long.valueOf(groupID);
    }
  }

  /**
   * Sets the group ID.
   *
   * @param groupID the groupID to set
   */
  public void setGroupID(String groupID) {
    this.groupID = groupID;
  }

  /**
   * Gets the src URL.
   *
   * @return the srcURL
   */
  public String getSrcURL() {
    return srcURL;
  }

  /**
   * Sets the src URL.
   *
   * @param srcURL the srcURL to set
   */
  public void setSrcURL(String srcURL) {
    this.srcURL = srcURL;
  }

  /**
   * Gets the payment ID.
   *
   * @return the paymentID
   */
  public String getPaymentID() {
    return paymentID;
  }

  /**
   * Sets the payment ID.
   *
   * @param paymentID the paymentID to set
   */
  public void setPaymentID(String paymentID) {
    this.paymentID = paymentID;
  }

  /**
   * Gets the affiliate.
   *
   * @return the affiliate
   */
  public String getAffiliate() {
    return affiliate;
  }

  /**
   * Sets the affiliate.
   *
   * @param affiliate the affiliate to set
   */
  public void setAffiliate(String affiliate) {
    this.affiliate = affiliate;
  }

  /**
   * Gets the subtype.
   *
   * @return the subtype
   */
  public String getSubtype() {
    return subtype;
  }

  /**
   * Sets the subtype.
   *
   * @param subtype the subtype to set
   */
  public void setSubtype(String subtype) {
    this.subtype = subtype;
  }

  /**
   * Gets the round ID.
   *
   * @return the roundID
   */
  public String getRoundID() {
    return roundID;
  }

  /**
   * Sets the round ID.
   *
   * @param roundID the roundID to set
   */
  public void setRoundID(String roundID) {
    this.roundID = roundID;
  }

  /**
   * Gets the reason.
   *
   * @return the reason
   */
  public String getReason() {
    return reason;
  }

  /**
   * Sets the reason.
   *
   * @param reason the reason to set
   */
  public void setReason(String reason) {
    this.reason = reason;
  }

  /**
   * Gets the ref transaction id.
   *
   * @return the refTransactionId
   */
  public String getRefTransactionId() {
    return refTransactionId;
  }

  /**
   * Sets the ref transaction id.
   *
   * @param refTransactionId the refTransactionId to set
   */
  public void setRefTransactionId(String refTransactionId) {
    this.refTransactionId = refTransactionId;
  }

  /**
   * Gets the winning id.
   *
   * @return the winningId
   */
  public long getWinningId() {
    if (Objects.equals(winningId, "") || winningId == null) {
      return Long.valueOf(Long.parseLong("0"));
    } else {
      return Long.valueOf(winningId);
    }
  }

  /**
   * Sets the winning id.
   *
   * @param winningId the winningId to set
   */
  public void setWinningId(String winningId) {
    this.winningId = winningId;
  }

  /**
   * Gets the wager state.
   *
   * @return the gviState
   */
  public String getGviState() {
    return gviState;
  }

  /**
   * Sets the wager state.
   *
   * @param gviState the gviState to set
   */
  public void setGviState(String gviState) {
    this.gviState = gviState;
  }

  /**
   * Gets the winning state.
   *
   * @return the winningState
   */
  public String getWinningState() {
    return winningState;
  }

  /**
   * Sets the winning state.
   *
   * @param winningState the winningState to set
   */
  public void setWinningState(String winningState) {
    this.winningState = winningState;
  }

  /**
   * Gets the winning external created time.
   *
   * @return the winningExternalCreatedTime
   */
  public String getWinningExternalCreatedTime() {
    return winningExternalCreatedTime;
  }

  /**
   * Sets the winning external created time.
   *
   * @param winningExternalCreatedTime the winningExternalCreatedTime to set
   */
  public void setWinningExternalCreatedTime(String winningExternalCreatedTime) {
    this.winningExternalCreatedTime = winningExternalCreatedTime;
  }

  /**
   * Gets the wager external id.
   *
   * @return the wagerExternalId
   */
  public String getWagerExternalId() {
    return wagerExternalId;
  }

  /**
   * Sets the wager external id.
   *
   * @param wagerExternalId the wagerExternalId to set
   */
  public void setWagerExternalId(String wagerExternalId) {
    this.wagerExternalId = wagerExternalId;
  }

  /**
   * Gets the wager external created time.
   *
   * @return the wagerExternalCreatedTime
   */
  public String getWagerExternalCreatedTime() {
    return wagerExternalCreatedTime;
  }

  /**
   * Sets the wager external created time.
   *
   * @param wagerExternalCreatedTime the wagerExternalCreatedTime to set
   */
  public void setWagerExternalCreatedTime(String wagerExternalCreatedTime) {
    this.wagerExternalCreatedTime = wagerExternalCreatedTime;
  }

  /**
   * Gets the wager notify win.
   *
   * @return the wagerNotifyWin
   */
  public String getWagerNotifyWin() {
    return wagerNotifyWin;
  }

  /**
   * Sets the wager notify win.
   *
   * @param wagerNotifyWin the wagerNotifyWin to set
   */
  public void setWagerNotifyWin(String wagerNotifyWin) {
    this.wagerNotifyWin = wagerNotifyWin;
  }

  /**
   * Gets the wager set external created time.
   *
   * @return the wagerSetExternalCreatedTime
   */
  public String getWagerSetExternalCreatedTime() {
    return wagerSetExternalCreatedTime;
  }

  /**
   * Sets the wager set external created time.
   *
   * @param wagerSetExternalCreatedTime the wagerSetExternalCreatedTime to set
   */
  public void setWagerSetExternalCreatedTime(String wagerSetExternalCreatedTime) {
    this.wagerSetExternalCreatedTime = wagerSetExternalCreatedTime;
  }

  /**
   * Gets the wager set notify win.
   *
   * @return the wagerSetNotifyWin
   */
  public String getWagerSetNotifyWin() {
    return wagerSetNotifyWin;
  }

  /**
   * Sets the wager set notify win.
   *
   * @param wagerSetNotifyWin the wagerSetNotifyWin to set
   */
  public void setWagerSetNotifyWin(String wagerSetNotifyWin) {
    this.wagerSetNotifyWin = wagerSetNotifyWin;
  }

  /**
   * Gets the wager brand.
   *
   * @return the wagerBrand
   */
  public String getWagerBrand() {
    return wagerBrand;
  }

  /**
   * Sets the wager brand.
   *
   * @param wagerBrand the wagerBrand to set
   */
  public void setWagerBrand(String wagerBrand) {
    this.wagerBrand = wagerBrand;
  }

  /**
   * Gets the number of wagers.
   *
   * @return the numberOfWagers
   */
  public String getNumberOfWagers() {
    return numberOfWagers;
  }

  /**
   * Sets the number of wagers.
   *
   * @param numberOfWagers the numberOfWagers to set
   */
  public void setNumberOfWagers(String numberOfWagers) {
    this.numberOfWagers = numberOfWagers;
  }

  /**
   * Gets the external id.
   *
   * @return the externalId
   */
  public String getExternalId() {
    return externalId;
  }

  /**
   * Sets the external id.
   *
   * @param externalId the externalId to set
   */
  public void setExternalId(String externalId) {
    this.externalId = externalId;
  }

  /**
   * Gets the sets the ID.
   *
   * @return the setID
   * @throws CustomException the custom exception
   */
  public long getSetID() throws CustomException {
    if (Objects.equals(setID, "") || setID == null) {
      return Long.valueOf(Long.parseLong("0"));
    } else {
      try {
        return Long.valueOf(setID);
      } catch (NumberFormatException ex) {
        throw new CustomException("Wallet setID field is not in expected data format");
      }
    }
  }

  /**
   * Sets the sets the ID.
   *
   * @param setID the setID to set
   */
  public void setSetID(String setID) {
    this.setID = setID;
  }

  /**
   * Gets the previous status.
   *
   * @return the previousStatus
   */
  public String getPreviousStatus() {
    return previousStatus;
  }

  /**
   * Sets the previous status.
   *
   * @param previousStatus the previousStatus to set
   */
  public void setPreviousStatus(String previousStatus) {
    this.previousStatus = previousStatus;
  }

  /**
   * Gets the external created at.
   *
   * @return the externalCreatedAt
   */
  public String getExternalCreatedAt() {
    return externalCreatedAt;
  }

  /**
   * Sets the external created at.
   *
   * @param externalCreatedAt the externalCreatedAt to set
   */
  public void setExternalCreatedAt(String externalCreatedAt) {
    this.externalCreatedAt = externalCreatedAt;
  }

  /**
   * Gets the owner.
   *
   * @return the owner
   */
  public String getOwner() {
    return owner;
  }

  /**
   * Sets the owner.
   *
   * @param owner the owner to set
   */
  public void setOwner(String owner) {
    this.owner = owner;
  }

  /**
   * Gets the comment.
   *
   * @return the comments
   */
  public String getComment() {
    return comment;
  }

  /**
   * Sets the comment.
   *
   * @param comment the new comment
   */
  public void setComment(String comment) {
    this.comment = comment;
  }

  /**
   * Gets the game.
   *
   * @return the game
   */
  public Integer getGame() {
    return game;
  }

  /**
   * Sets the game.
   *
   * @param game the new game
   */
  public void setGame(Integer game) {
    this.game = game;
  }

  /** @return the wagerSetExternalId */
  public String getWagerSetExternalId() {
    return wagerSetExternalId;
  }

  /** @param wagerSetExternalId the wagerSetExternalId to set */
  public void setWagerSetExternalId(String wagerSetExternalId) {
    this.wagerSetExternalId = wagerSetExternalId;
  }

  public Integer getForceUpdatedBy() {
    return forceUpdatedBy;
  }

  public void setForceUpdatedBy(Integer forceUpdatedBy) {
    this.forceUpdatedBy = forceUpdatedBy;
  }

  public String getCardType() {
    return cardType;
  }

  public void setCardType(String cardType) {
    this.cardType = cardType;
  }

  public String getCardNumberLastFour() {
    return cardNumberLastFour;
  }

  public void setCardNumberLastFour(String cardNumberLastFour) {
    this.cardNumberLastFour = cardNumberLastFour;
  }

  /** @return the wagerSetState */
  public String getWagerSetState() {
    return wagerSetState;
  }

  /** @param wagerSetState the wagerSetState to set */
  public void setWagerSetState(String wagerSetState) {
    this.wagerSetState = wagerSetState;
  }

  /** @return the wagerSetBrand */
  public String getWagerSetBrand() {
    return wagerSetBrand;
  }

  /** @param wagerSetBrand the wagerSetBrand to set */
  public void setWagerSetBrand(String wagerSetBrand) {
    this.wagerSetBrand = wagerSetBrand;
  }

  public String getGviPreviousState() {
    return gviPreviousState;
  }

  public void setGviPreviousState(String gviPreviousState) {
    this.gviPreviousState = gviPreviousState;
  }

  public Date getGviStateUpdatedAt() {
    return gviStateUpdatedAt;
  }

  public void setGviStateUpdatedAt(Date gviStateUpdatedAt) {
    this.gviStateUpdatedAt = gviStateUpdatedAt;
  }

  public String getWagerState() {
    return wagerState;
  }

  public void setWagerState(String wagerState) {
    this.wagerState = wagerState;
  }
}
