package com.sciplay.report.etl.dto;

import io.swagger.annotations.ApiModelProperty;

public class HealthCheckResponseAttributes {

  @ApiModelProperty(value = "Dependency status", required = true)
  private final boolean healthy;

  @ApiModelProperty(value = "Response message", required = true)
  private final String message;

  public HealthCheckResponseAttributes(boolean healthy, String message) {
    this.healthy = healthy;
    this.message = message;
  }

  /** @return the healthy */
  public boolean isHealthy() {
    return healthy;
  }

  /** @return the message */
  public String getMessage() {
    return message;
  }

  public enum TYPE {
    permanent,
    temporary
  }
}
