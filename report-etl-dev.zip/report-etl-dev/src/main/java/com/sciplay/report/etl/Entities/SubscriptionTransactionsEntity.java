package com.sciplay.report.etl.Entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Type;

/** The Class SubscriptionTransactionsId. */
@Entity
@Table(name = "SubscriptionTransactions")
@DynamicUpdate
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubscriptionTransactionsEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** Transaction Id. */
  @Id private long transactionId;

  /** The player id. */
  private Integer playerId;

  /** The operator id. */
  @Column(length = 3, columnDefinition = "CHAR")
  private String operatorId;

  /** The transaction date. */
  private Date transactionDate;

  /** The transaction type. */
  @Column(
      name = "TransactionType",
      columnDefinition =
          "enum('adjustment', 'credit', 'deposit', 'wager', 'win', 'debit', 'withdrawal')")
  private String transactionType;

  /** The subscription id. */
  private Long subscriptionId;

  /** The amount. */
  private Long amount;

  /** Player Balance Before a Transaction. */
  private Long balanceBefore;

  /** Player Balance After a Transaction. */
  private Long balanceAfter;

  /** The payment method. */
  private Long paymentMethodId;

  /** The status. */
  @Column(
      name = "Status",
      columnDefinition =
          "enum('pending', 'processing', 'accepted', 'rejected', 'abandoned', 'cancelled', "
              + "'completed', 'processed', 'STARTED', 'PLAYED', 'REFUNDED', 'ROLLEDBACK', 'CORRECTED')")
  @Id
  private String status;

  /** The author id. */
  private Integer authorId;

  /** The author ip. */
  private String authorIp;

  /** The author session id. */
  private String authorSessionId;

  /** The author type. */
  private String authorType;

  /** Win Id. */
  private Long winId;

  /** The bank name. */
  private String bankName;

  /** External Id. */
  private String externalId;

  /** Game Id. */
  private Integer gameId;

  /** Purchase Id. */
  private Long purchaseId;

  /** Subscription Numbers. */
  private String numbers;

  /** Card Type. */
  private String cardType;

  /** Account Type. */
  private String accountType;

  /** Card Number Last Four. */
  private String cardNumberLastFour;

  /** Account Number. */
  private String accountNumber;

  /** Channel. */
  private String channel;

  /** Currency. */
  private String currency;

  /** ExternalCreatedDate. */
  private Date externalCreatedDate;

  /** SubType. */
  private String subType;

  /** ExternalUrl. */
  private String externalUrl;

  /** The approved date. */
  private Date approvedDate;

  /** The approved by. */
  private String approvedBy;

  /** The updated date. */
  @Column(name = "UpdatedDate")
  private Date updatedDate;

  /** The external wager id. */
  private String externalWagerId;

  /** The is Nation Account. */
  private Boolean isNationalAccount;

  /** The is reprocessed. */
  private Boolean isReprocessed;

  /** The Reprocessed date. */
  private Date reprocessedDate;

  /** The wallet updated date. */
  private Date walletUpdatedDate;

  /** The game cycle id. */
  private String gameCycleId;

  /** The fee. */
  private Integer fee;

  /** The is approved. */
  private Boolean isApproved;

  /** The Player Card Type. */
  @Column(length = 1, columnDefinition = "CHAR")
  private String playerCardType;

  /** The linked transaction id. */
  private Long linkedTransactionId;

  /** The purchase status. */
  @Column(name = "PurchaseStatus", columnDefinition = "enum('Success', 'Failure', 'Unknown')")
  private String purchaseStatus;

  /** The Purchase order id. */
  private String purchaseOrderId;

  /** The wager set id. */
  private Long wagerSetId;
  /** Comment of the Transaction. */
  @Column(name = "Comment")
  @Type(type = "text")
  private String comment;
  /** The gvi previous state. */
  @Column(
      name = "GviPreviousState",
      columnDefinition =
          "enum('STARTED', 'PLAYED', 'REFUNDED', 'CANCELLED', 'ROLLEDBACK', 'CORRECTED', "
              + "'PENDING', 'PAID', 'CHECKED', 'ADJUSTED', 'CLAIMED')")
  private String gviPreviousState;
  /** The gvi state. */
  @Column(
      name = "GviState",
      columnDefinition =
          "enum('STARTED', 'PLAYED', 'REFUNDED', 'CANCELLED', 'ROLLEDBACK', 'CORRECTED', "
              + "'PENDING', 'PAID', 'CHECKED', 'ADJUSTED', 'CLAIMED')")
  private String gviState;
  /** The gvi state updated at. */
  private Date gviStateUpdatedAt;
  /** The event id. */
  private Long eventId;
  /** The event created at. */
  private Date eventCreatedAt;
  /** The Event Type. */
  private String eventType;
  /** The withdrawal processed date. */
  private Date withdrawalProcessedDate;

  /** Instantiates a new subscription transactions id. */
  public SubscriptionTransactionsEntity() {}

  /**
   * Gets the wager set id.
   *
   * @return the wager set id
   */
  public Long getWagerSetId() {
    return wagerSetId;
  }

  /**
   * Sets the wager set id.
   *
   * @param wagerSetId the new wager set id
   */
  public void setWagerSetId(Long wagerSetId) {
    if (wagerSetId == null) {
      wagerSetId = 0L;
    }
    this.wagerSetId = wagerSetId;
  }

  /**
   * Gets the purchase order id.
   *
   * @return the purchase order id
   */
  public String getPurchaseOrderId() {
    return purchaseOrderId;
  }

  /**
   * Sets the purchase order id.
   *
   * @param purchaseOrderId the new purchase order id
   */
  public void setPurchaseOrderId(String purchaseOrderId) {
    this.purchaseOrderId = purchaseOrderId;
  }

  /**
   * Gets the purchase status.
   *
   * @return the purchase status
   */
  public String getPurchaseStatus() {
    return purchaseStatus;
  }

  /**
   * Sets the purchase status.
   *
   * @param purchaseStatus the new purchase status
   */
  public void setPurchaseStatus(String purchaseStatus) {
    this.purchaseStatus = purchaseStatus;
  }

  /**
   * Gets the game cycle id.
   *
   * @return the game cycle id
   */
  public String getGameCycleId() {
    return gameCycleId;
  }

  /**
   * Sets the game cycle id.
   *
   * @param gameCycleId the new game cycle id
   */
  public void setGameCycleId(String gameCycleId) {
    this.gameCycleId = gameCycleId;
  }

  /**
   * Gets the fee.
   *
   * @return the fee
   */
  public Integer getFee() {
    return fee;
  }

  /**
   * Sets the fee.
   *
   * @param fee the new fee
   */
  public void setFee(Integer fee) {
    if (fee == null) {
      fee = 0;
    }
    this.fee = fee;
  }

  /**
   * Gets the wallet updated date.
   *
   * @return the wallet updated date
   */
  public Date getWalletUpdatedDate() {
    return walletUpdatedDate;
  }

  /**
   * Sets the wallet updated date.
   *
   * @param walletUpdatedDate the new wallet updated date
   */
  public void setWalletUpdatedDate(Date walletUpdatedDate) {
    this.walletUpdatedDate = walletUpdatedDate;
  }

  /**
   * Gets the gvi previous state.
   *
   * @return the gvi previous state
   */
  public String getGviPreviousState() {
    return gviPreviousState;
  }

  /**
   * Sets the gvi previous state.
   *
   * @param gviPreviousState the new gvi previous state
   */
  public void setGviPreviousState(String gviPreviousState) {
    this.gviPreviousState = gviPreviousState;
  }

  /**
   * Gets the gvi state.
   *
   * @return the gvi state
   */
  public String getGviState() {
    return gviState;
  }

  /**
   * Sets the gvi state.
   *
   * @param gviState the new gvi state
   */
  public void setGviState(String gviState) {
    this.gviState = gviState;
  }

  /**
   * Gets the gvi state updated at.
   *
   * @return the gvi state updated at
   */
  public Date getGviStateUpdatedAt() {
    return gviStateUpdatedAt;
  }

  /**
   * Sets the gvi state updated at.
   *
   * @param gviStateUpdatedAt the new gvi state updated at
   */
  public void setGviStateUpdatedAt(Date gviStateUpdatedAt) {
    this.gviStateUpdatedAt = gviStateUpdatedAt;
  }

  /**
   * Gets the event id.
   *
   * @return the event id
   */
  public Long getEventId() {
    return eventId;
  }

  /**
   * Sets the event id.
   *
   * @param eventId the new event id
   */
  public void setEventId(Long eventId) {
    if (eventId == null) {
      eventId = 0L;
    }
    this.eventId = eventId;
  }

  /**
   * Gets the event created at.
   *
   * @return the event created at
   */
  public Date getEventCreatedAt() {
    return eventCreatedAt;
  }

  /**
   * Sets the event created at.
   *
   * @param eventCreatedAt the new event created at
   */
  public void setEventCreatedAt(Date eventCreatedAt) {
    this.eventCreatedAt = eventCreatedAt;
  }

  /**
   * Gets the checks if is reprocessed.
   *
   * @return the checks if is reprocessed
   */
  public Boolean getIsReprocessed() {
    return isReprocessed;
  }

  /**
   * Sets the checks if is reprocessed.
   *
   * @param isReprocessed the new checks if is reprocessed
   */
  public void setIsReprocessed(Boolean isReprocessed) {
    if (isReprocessed == null) {
      isReprocessed = false;
    }
    this.isReprocessed = isReprocessed;
  }

  /**
   * Gets the reprocessed date.
   *
   * @return the reprocessed date
   */
  public Date getReprocessedDate() {
    return reprocessedDate;
  }

  /**
   * Sets the reprocessed date.
   *
   * @param reprocessedDate the new reprocessed date
   */
  public void setReprocessedDate(Date reprocessedDate) {
    this.reprocessedDate = reprocessedDate;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return this.playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return this.operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the transaction date.
   *
   * @return the transaction date
   */
  public Date getTransactionDate() {
    return this.transactionDate;
  }

  /**
   * Sets the transaction date.
   *
   * @param transactionDate the new transaction date
   */
  public void setTransactionDate(Date transactionDate) {
    this.transactionDate = transactionDate;
  }

  /**
   * Gets the transaction type.
   *
   * @return the transaction type
   */
  public String getTransactionType() {
    return this.transactionType;
  }

  /**
   * Sets the transaction type.
   *
   * @param transactionType the new transaction type
   */
  public void setTransactionType(String transactionType) {
    this.transactionType = transactionType;
  }

  /**
   * Gets the bank name.
   *
   * @return the bank name
   */
  public String getBankName() {
    return bankName;
  }

  /**
   * Sets the bank name.
   *
   * @param bankName the new bank name
   */
  public void setBankName(String bankName) {
    this.bankName = bankName;
  }

  /**
   * Gets the subscription id.
   *
   * @return the subscription id
   */
  public Long getSubscriptionId() {
    return this.subscriptionId;
  }

  /**
   * Sets the subscription id.
   *
   * @param subscriptionId the new subscription id
   */
  public void setSubscriptionId(Long subscriptionId) {
    this.subscriptionId = subscriptionId;
  }

  /**
   * Gets the amount.
   *
   * @return the amount
   */
  public Long getAmount() {
    return this.amount;
  }

  /**
   * Sets the amount.
   *
   * @param amount the new amount
   */
  public void setAmount(Long amount) {
    if (amount == null) {
      amount = 0L;
    }
    this.amount = amount;
  }

  /**
   * Gets the balance before.
   *
   * @return the balanceBefore
   */
  public Long getBalanceBefore() {
    return balanceBefore;
  }

  /**
   * Sets the balance before.
   *
   * @param balanceBefore the balanceBefore to set
   */
  public void setBalanceBefore(Long balanceBefore) {
    if (balanceBefore == null) {
      balanceBefore = 0L;
    }
    this.balanceBefore = balanceBefore;
  }

  /**
   * Gets the balance after.
   *
   * @return the balanceAfter
   */
  public Long getBalanceAfter() {
    return balanceAfter;
  }

  /**
   * Sets the balance after.
   *
   * @param balanceAfter the balanceAfter to set
   */
  public void setBalanceAfter(Long balanceAfter) {
    if (balanceAfter == null) {
      balanceAfter = 0L;
    }
    this.balanceAfter = balanceAfter;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public String getStatus() {
    return this.status;
  }

  /**
   * Sets the status.
   *
   * @param status the new status
   */
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * Gets the author id.
   *
   * @return the author id
   */
  public Integer getAuthorId() {
    return this.authorId;
  }

  /**
   * Sets the author id.
   *
   * @param authorId the new author id
   */
  public void setAuthorId(Integer authorId) {
    if (authorId == null) {
      authorId = 0;
    }
    this.authorId = authorId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return this.authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return this.authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the author type.
   *
   * @return the author type
   */
  public String getAuthorType() {
    return this.authorType;
  }

  /**
   * Sets the author type.
   *
   * @param authorType the new author type
   */
  public void setAuthorType(String authorType) {
    this.authorType = authorType;
  }

  /**
   * Gets the payment method id.
   *
   * @return the paymentMethodId
   */
  public Long getPaymentMethodId() {
    if (paymentMethodId == null || paymentMethodId == 0L) {
      return Long.parseLong("0");
    } else {
      return paymentMethodId;
    }
  }

  /**
   * Sets the payment method id.
   *
   * @param paymentMethodId the paymentMethodId to set
   */
  public void setPaymentMethodId(Long paymentMethodId) {
    if (paymentMethodId == null) {
      paymentMethodId = 0L;
    }
    this.paymentMethodId = paymentMethodId;
  }

  /**
   * Gets the transaction id.
   *
   * @return the transactionId
   */
  public long getTransactionId() {
    return transactionId;
  }

  /**
   * Sets the transaction id.
   *
   * @param transactionId the transactionId to set
   */
  public void setTransactionId(long transactionId) {
    this.transactionId = transactionId;
  }

  /**
   * Gets the game id.
   *
   * @return the gameId
   */
  public Integer getGameId() {
    return gameId;
  }

  /**
   * Sets the game id.
   *
   * @param gameId the gameId to set
   */
  public void setGameId(Integer gameId) {
    if (gameId == null) {
      gameId = 0;
    }
    this.gameId = gameId;
  }

  /**
   * Gets the external id.
   *
   * @return the externalId
   */
  public String getExternalId() {
    return externalId;
  }

  /**
   * Sets the external id.
   *
   * @param externalId the externalId to set
   */
  public void setExternalId(String externalId) {
    this.externalId = externalId;
  }

  /**
   * Gets the win id.
   *
   * @return the winId
   */
  public Long getWinId() {
    return winId;
  }

  /**
   * Sets the win id.
   *
   * @param winId the winId to set
   */
  public void setWinId(Long winId) {
    if (winId == null) {
      winId = 0L;
    }
    this.winId = winId;
  }

  /**
   * Gets the purchase id.
   *
   * @return the purchaseId
   */
  public Long getPurchaseId() {
    return purchaseId;
  }

  /**
   * Sets the purchase id.
   *
   * @param purchaseId the purchaseId to set
   */
  public void setPurchaseId(Long purchaseId) {
    if (purchaseId == null) {
      purchaseId = 0L;
    }
    this.purchaseId = purchaseId;
  }

  /**
   * Gets the numbers.
   *
   * @return the numbers
   */
  public String getNumbers() {
    return numbers;
  }

  /**
   * Sets the numbers.
   *
   * @param numbers the numbers to set
   */
  public void setNumbers(String numbers) {
    this.numbers = numbers;
  }

  /**
   * Gets the card type.
   *
   * @return the cardType
   */
  public String getCardType() {
    return cardType;
  }

  /**
   * Sets the card type.
   *
   * @param cardType the cardType to set
   */
  public void setCardType(String cardType) {
    this.cardType = cardType;
  }

  /**
   * Gets the account type.
   *
   * @return the accountType
   */
  public String getAccountType() {
    return accountType;
  }

  /**
   * Sets the account type.
   *
   * @param accountType the accountType to set
   */
  public void setAccountType(String accountType) {
    this.accountType = accountType;
  }

  /**
   * Gets the card number last four.
   *
   * @return the cardNumberLastFour
   */
  public String getCardNumberLastFour() {
    return cardNumberLastFour;
  }

  /**
   * Sets the card number last four.
   *
   * @param cardNumberLastFour the cardNumberLastFour to set
   */
  public void setCardNumberLastFour(String cardNumberLastFour) {
    this.cardNumberLastFour = cardNumberLastFour;
  }

  /**
   * Gets the account number.
   *
   * @return the accountNumber
   */
  public String getAccountNumber() {
    return accountNumber;
  }

  /**
   * Sets the account number.
   *
   * @param accountNumber the accountNumber to set
   */
  public void setAccountNumber(String accountNumber) {
    this.accountNumber = accountNumber;
  }

  /**
   * Gets the channel.
   *
   * @return the channel
   */
  public String getChannel() {
    return channel;
  }

  /**
   * Sets the channel.
   *
   * @param channel the channel to set
   */
  public void setChannel(String channel) {
    this.channel = channel;
  }

  /**
   * Gets the currency.
   *
   * @return the currency
   */
  public String getCurrency() {
    return currency;
  }

  /**
   * Sets the currency.
   *
   * @param currency the currency to set
   */
  public void setCurrency(String currency) {
    this.currency = currency;
  }

  /**
   * Gets the external created date.
   *
   * @return the externalCreatedDate
   */
  public Date getExternalCreatedDate() {
    return externalCreatedDate;
  }

  /**
   * Sets the external created date.
   *
   * @param externalCreatedDate the externalCreatedDate to set
   */
  public void setExternalCreatedDate(Date externalCreatedDate) {
    this.externalCreatedDate = externalCreatedDate;
  }

  /**
   * Gets the sub type.
   *
   * @return the subType
   */
  public String getSubType() {
    return subType;
  }

  /**
   * Sets the sub type.
   *
   * @param subType the subType to set
   */
  public void setSubType(String subType) {
    this.subType = subType;
  }

  /**
   * Gets the external url.
   *
   * @return the externalUrl
   */
  public String getExternalUrl() {
    return externalUrl;
  }

  /**
   * Sets the external url.
   *
   * @param externalUrl the externalUrl to set
   */
  public void setExternalUrl(String externalUrl) {
    this.externalUrl = externalUrl;
  }

  /**
   * Gets the approved date.
   *
   * @return the approvedDate
   */
  public Date getApprovedDate() {
    return approvedDate;
  }

  /**
   * Sets the approved date.
   *
   * @param approvedDate the approvedDate to set
   */
  public void setApprovedDate(Date approvedDate) {
    this.approvedDate = approvedDate;
  }

  /**
   * Gets the approved by.
   *
   * @return the approvedBy
   */
  public String getApprovedBy() {
    return approvedBy;
  }

  /**
   * Sets the approved by.
   *
   * @param approvedBy the approvedBy to set
   */
  public void setApprovedBy(String approvedBy) {
    this.approvedBy = approvedBy;
  }

  /**
   * Gets the updated date.
   *
   * @return the updatedDate
   */
  public Date getUpdatedDate() {
    return updatedDate;
  }

  /**
   * Sets the updated date.
   *
   * @param updatedDate the updatedDate to set
   */
  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  /**
   * Gets the external wager id.
   *
   * @return the externalWagerId
   */
  public String getExternalWagerId() {
    return externalWagerId;
  }

  /**
   * Sets the external wager id.
   *
   * @param externalWagerId the externalWagerId to set
   */
  public void setExternalWagerId(String externalWagerId) {
    this.externalWagerId = externalWagerId;
  }

  /**
   * Gets the checks if is national account.
   *
   * @return the isNationalAccount
   */
  public Boolean getIsNationalAccount() {
    return isNationalAccount;
  }

  /**
   * Sets the checks if is national account.
   *
   * @param isNationalAccount the isNationalAccount to set
   */
  public void setIsNationalAccount(Boolean isNationalAccount) {
    if (isNationalAccount == null) {
      isNationalAccount = false;
    }
    this.isNationalAccount = isNationalAccount;
  }

  /**
   * Gets the player card type.
   *
   * @return the playerCardType
   */
  public String getPlayerCardType() {
    return playerCardType;
  }

  /**
   * Sets the player card type.
   *
   * @param playerCardType the playerCardType to set
   */
  public void setPlayerCardType(String playerCardType) {
    this.playerCardType = playerCardType;
  }

  /**
   * Gets the linked transaction id.
   *
   * @return the linkedTransactionId
   */
  public Long getLinkedTransactionId() {
    return linkedTransactionId;
  }

  /**
   * Sets the linked transaction id.
   *
   * @param linkedTransactionId the linkedTransactionId to set
   */
  public void setLinkedTransactionId(Long linkedTransactionId) {
    if (linkedTransactionId == null) {
      linkedTransactionId = 0L;
    }
    this.linkedTransactionId = linkedTransactionId;
  }

  /**
   * Gets the event type.
   *
   * @return the eventType
   */
  public String getEventType() {
    return eventType;
  }

  /**
   * Sets the event type.
   *
   * @param eventType the eventType to set
   */
  public void setEventType(String eventType) {
    this.eventType = eventType;
  }

  /**
   * Gets the comment.
   *
   * @return the comment
   */
  public String getComment() {
    return comment;
  }

  /**
   * Sets the comment.
   *
   * @param comment the new comment
   */
  public void setComment(String comment) {
    this.comment = comment;
  }

  /**
   * Gets the withdrawal processed date.
   *
   * @return the withdrawalProcessedDate
   */
  public Date getWithdrawalProcessedDate() {
    return withdrawalProcessedDate;
  }

  /**
   * Sets the withdrawal processed date.
   *
   * @param withdrawalProcessedDate the withdrawalProcessedDate to set
   */
  public void setWithdrawalProcessedDate(Date withdrawalProcessedDate) {
    this.withdrawalProcessedDate = withdrawalProcessedDate;
  }

  /** @return the isApproved */
  public Boolean getIsApproved() {
    return isApproved;
  }

  /** @param isApproved the isApproved to set */
  public void setIsApproved(Boolean isApproved) {
    if (isApproved == null) {
      isApproved = false;
    }
    this.isApproved = isApproved;
  }
}
