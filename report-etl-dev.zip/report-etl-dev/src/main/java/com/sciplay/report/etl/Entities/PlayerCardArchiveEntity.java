package com.sciplay.report.etl.Entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class PlayerCardArchive. */
@Entity
@Table(name = "PlayerCardArchive")
public class PlayerCardArchiveEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The revision number. */
  @Id
  @Column(name = "RevisionNumber")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long revisionNumber;

  /** The revision date. */
  private Date revisionDate;

  /** The revision state. */
  private String revisionState;

  /** The id. */
  private String id;

  /** The player id. */
  @Column(name = "PlayerId")
  private Integer playerId;

  /** The operator id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The card number. */
  private String cardNumber;

  /** The reason. */
  private String reason;

  /** The author player id. */
  private Integer authorPlayerId;

  /** The author agent id. */
  private Integer authorAgentId;

  /** The author ip. */
  private String authorIp;

  /** The author session id. */
  private String authorSessionId;

  /** The printed date. */
  private Date printedDate;

  /** The expiration date. */
  private Date expirationDate;

  /** The cancel date. */
  private Date cancelDate;

  /** The created at. */
  private Date createdAt;

  /** The Type. */
  @Column(name = "Type")
  private String type;

  /** Instantiates a new player card archive. */
  public PlayerCardArchiveEntity() {}

  /**
   * Instantiates a new player card archive.
   *
   * @param revisionDate the revision date
   * @param revisionState the revision state
   * @param id the id
   * @param playerId the player id
   * @param operatorId the operator id
   * @param cardNumber the card number
   * @param expirationDate the expiration date
   * @param createdAt the created at
   */
  public PlayerCardArchiveEntity(
      Date revisionDate,
      String revisionState,
      String id,
      Integer playerId,
      String operatorId,
      String cardNumber,
      Date expirationDate,
      Date createdAt) {
    this.revisionDate = revisionDate;
    this.revisionState = revisionState;
    this.id = id;
    this.playerId = playerId;
    this.operatorId = operatorId;
    this.cardNumber = cardNumber;
    this.expirationDate = expirationDate;
    this.createdAt = createdAt;
  }

  /**
   * Instantiates a new player card archive.
   *
   * @param revisionDate the revision date
   * @param revisionState the revision state
   * @param id the id
   * @param playerId the player id
   * @param operatorId the operator id
   * @param cardNumber the card number
   * @param reason the reason
   * @param authorPlayerId the author player id
   * @param authorAgentId the author agent id
   * @param authorIp the author ip
   * @param authorSessionId the author session id
   * @param printedDate the printed date
   * @param expirationDate the expiration date
   * @param cancelDate the cancel date
   * @param createdAt the created at
   */
  public PlayerCardArchiveEntity(
      Date revisionDate,
      String revisionState,
      String id,
      Integer playerId,
      String operatorId,
      String cardNumber,
      String reason,
      Integer authorPlayerId,
      Integer authorAgentId,
      String authorIp,
      String authorSessionId,
      Date printedDate,
      Date expirationDate,
      Date cancelDate,
      Date createdAt,
      String type) {
    this.revisionDate = revisionDate;
    this.revisionState = revisionState;
    this.id = id;
    this.playerId = playerId;
    this.operatorId = operatorId;
    this.cardNumber = cardNumber;
    this.reason = reason;
    this.authorPlayerId = authorPlayerId;
    this.authorAgentId = authorAgentId;
    this.authorIp = authorIp;
    this.authorSessionId = authorSessionId;
    this.printedDate = printedDate;
    this.expirationDate = expirationDate;
    this.cancelDate = cancelDate;
    this.createdAt = createdAt;
    this.type = type;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Sets the type.
   *
   * @param type the new type
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the revision number.
   *
   * @return the revision number
   */
  public long getRevisionNumber() {
    return this.revisionNumber;
  }

  /**
   * Sets the revision number.
   *
   * @param revisionNumber the new revision number
   */
  public void setRevisionNumber(long revisionNumber) {
    this.revisionNumber = revisionNumber;
  }

  /**
   * Gets the revision date.
   *
   * @return the revision date
   */
  public Date getRevisionDate() {
    return this.revisionDate;
  }

  /**
   * Sets the revision date.
   *
   * @param revisionDate the new revision date
   */
  public void setRevisionDate(Date revisionDate) {
    this.revisionDate = revisionDate;
  }

  /**
   * Gets the revision state.
   *
   * @return the revision state
   */
  public String getRevisionState() {
    return this.revisionState;
  }

  /**
   * Sets the revision state.
   *
   * @param revisionState the new revision state
   */
  public void setRevisionState(String revisionState) {
    this.revisionState = revisionState;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public String getId() {
    return this.id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return this.playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return this.operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the card number.
   *
   * @return the card number
   */
  public String getCardNumber() {
    return this.cardNumber;
  }

  /**
   * Sets the card number.
   *
   * @param cardNumber the new card number
   */
  public void setCardNumber(String cardNumber) {
    this.cardNumber = cardNumber;
  }

  /**
   * Gets the reason.
   *
   * @return the reason
   */
  public String getReason() {
    return this.reason;
  }

  /**
   * Sets the reason.
   *
   * @param reason the new reason
   */
  public void setReason(String reason) {
    this.reason = reason;
  }

  /**
   * Gets the author player id.
   *
   * @return the author player id
   */
  public Integer getAuthorPlayerId() {
    return this.authorPlayerId;
  }

  /**
   * Sets the author player id.
   *
   * @param authorPlayerId the new author player id
   */
  public void setAuthorPlayerId(Integer authorPlayerId) {
    this.authorPlayerId = authorPlayerId;
  }

  /**
   * Gets the author agent id.
   *
   * @return the author agent id
   */
  public Integer getAuthorAgentId() {
    return this.authorAgentId;
  }

  /**
   * Sets the author agent id.
   *
   * @param authorAgentId the new author agent id
   */
  public void setAuthorAgentId(Integer authorAgentId) {
    this.authorAgentId = authorAgentId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return this.authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return this.authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the printed date.
   *
   * @return the printed date
   */
  public Date getPrintedDate() {
    return this.printedDate;
  }

  /**
   * Sets the printed date.
   *
   * @param printedDate the new printed date
   */
  public void setPrintedDate(Date printedDate) {
    this.printedDate = printedDate;
  }

  /**
   * Gets the expiration date.
   *
   * @return the expiration date
   */
  public Date getExpirationDate() {
    return this.expirationDate;
  }

  /**
   * Sets the expiration date.
   *
   * @param expirationDate the new expiration date
   */
  public void setExpirationDate(Date expirationDate) {
    this.expirationDate = expirationDate;
  }

  /**
   * Gets the cancel date.
   *
   * @return the cancel date
   */
  public Date getCancelDate() {
    return this.cancelDate;
  }

  /**
   * Sets the cancel date.
   *
   * @param cancelDate the new cancel date
   */
  public void setCancelDate(Date cancelDate) {
    this.cancelDate = cancelDate;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return this.createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }
}
