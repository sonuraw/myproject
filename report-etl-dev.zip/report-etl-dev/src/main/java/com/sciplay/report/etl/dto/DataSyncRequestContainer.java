package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class DataSyncRequestContainer {

  private String serviceName;
  private List<Integer> missingId;

  @JsonProperty("ServiceName")
  public String getServiceName() {
    return serviceName;
  }

  public void setServiceName(String serviceName) {
    this.serviceName = serviceName;
  }

  @JsonProperty("MissingId")
  public List<Integer> getMissingId() {
    return missingId;
  }

  public void setMissingId(List<Integer> missingId) {
    this.missingId = missingId;
  }
}
