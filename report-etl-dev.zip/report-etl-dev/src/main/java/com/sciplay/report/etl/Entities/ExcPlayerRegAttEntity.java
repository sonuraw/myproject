package com.sciplay.report.etl.Entities;

import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class ExcludedPlayerRegistrationAttemptEntity. */
@Entity
@Table(name = "ExcludedPlayerRegistrationAttempt")
public class ExcPlayerRegAttEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The id. */
  @Column(name = "Id")
  @Id
  private String id;

  /** The first name. */
  private String firstName;

  /** The last name. */
  private String lastName;

  /** The last operatorId. */
  @Id
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The identifications type. */
  private String identificationsType;

  /** The identification number. */
  private String identificationNumber;

  /** The expiration date. */
  private Date expirationDate;

  /** The author player id. */
  private Integer authorPlayerId;

  /** The author agent id. */
  private Integer authorAgentId;

  /** The author ip. */
  private String authorIp;

  /** The author session id. */
  private String authorSessionId;

  /** The created at. */
  private Date createdAt;

  /** Instantiates a new excluded player registration attempt entity. */
  public ExcPlayerRegAttEntity() {}

  /**
   * Instantiates a new excluded player registration attempt entity.
   *
   * @param id the id
   * @param firstName the first name
   * @param lastName the last name
   * @param identificationsType the identifications type
   * @param identificationNumber the identification number
   * @param expirationDate the expiration date
   * @param createdAt the created at
   */
  public ExcPlayerRegAttEntity(
      String id,
      String firstName,
      String lastName,
      String identificationsType,
      String identificationNumber,
      Date expirationDate,
      Date createdAt) {
    this.id = id;
    this.firstName = firstName;
    this.lastName = lastName;
    this.identificationsType = identificationsType;
    this.identificationNumber = identificationNumber;
    this.expirationDate = expirationDate;
    this.createdAt = createdAt;
  }

  /**
   * Instantiates a new excluded player registration attempt entity.
   *
   * @param id the id
   * @param firstName the first name
   * @param lastName the last name
   * @param identificationsType the identifications type
   * @param identificationNumber the identification number
   * @param expirationDate the expiration date
   * @param authorPlayerId the author player id
   * @param authorAgentId the author agent id
   * @param authorIp the author ip
   * @param authorSessionId the author session id
   * @param createdAt the created at
   */
  public ExcPlayerRegAttEntity(
      String id,
      String firstName,
      String lastName,
      String identificationsType,
      String identificationNumber,
      Date expirationDate,
      Integer authorPlayerId,
      Integer authorAgentId,
      String authorIp,
      String authorSessionId,
      Date createdAt) {
    this.id = id;
    this.firstName = firstName;
    this.lastName = lastName;
    this.identificationsType = identificationsType;
    this.identificationNumber = identificationNumber;
    this.expirationDate = expirationDate;
    this.authorPlayerId = Objects.isNull(authorPlayerId) ? 0 : authorPlayerId;
    this.authorAgentId = Objects.isNull(authorAgentId) ? 0 : authorAgentId;
    this.authorIp = authorIp;
    this.authorSessionId = authorSessionId;
    this.createdAt = createdAt;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public String getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Gets the first name.
   *
   * @return the first name
   */
  public String getFirstName() {
    return this.firstName;
  }

  /**
   * Sets the first name.
   *
   * @param firstName the new first name
   */
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  /**
   * Gets the last name.
   *
   * @return the last name
   */
  public String getLastName() {
    return this.lastName;
  }

  /**
   * Sets the last name.
   *
   * @param lastName the new last name
   */
  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  /**
   * Gets the identifications type.
   *
   * @return the identifications type
   */
  public String getIdentificationsType() {
    return this.identificationsType;
  }

  /**
   * Sets the identifications type.
   *
   * @param identificationsType the new identifications type
   */
  public void setIdentificationsType(String identificationsType) {
    this.identificationsType = identificationsType;
  }

  /**
   * Gets the identification number.
   *
   * @return the identification number
   */
  public String getIdentificationNumber() {
    return this.identificationNumber;
  }

  /**
   * Sets the identification number.
   *
   * @param identificationNumber the new identification number
   */
  public void setIdentificationNumber(String identificationNumber) {
    this.identificationNumber = identificationNumber;
  }

  /**
   * Gets the expiration date.
   *
   * @return the expiration date
   */
  public Date getExpirationDate() {
    return this.expirationDate;
  }

  /**
   * Sets the expiration date.
   *
   * @param expirationDate the new expiration date
   */
  public void setExpirationDate(Date expirationDate) {
    this.expirationDate = expirationDate;
  }

  /**
   * Gets the author player id.
   *
   * @return the author player id
   */
  public Integer getAuthorPlayerId() {
    return this.authorPlayerId;
  }

  /**
   * Sets the author player id.
   *
   * @param authorPlayerId the new author player id
   */
  public void setAuthorPlayerId(Integer authorPlayerId) {
    this.authorPlayerId = Objects.isNull(authorPlayerId) ? 0 : authorPlayerId;
  }

  /**
   * Gets the author agent id.
   *
   * @return the author agent id
   */
  public Integer getAuthorAgentId() {
    return this.authorAgentId;
  }

  /**
   * Sets the author agent id.
   *
   * @param authorAgentId the new author agent id
   */
  public void setAuthorAgentId(Integer authorAgentId) {
    this.authorAgentId = Objects.isNull(authorAgentId) ? 0 : authorAgentId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return this.authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return this.authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return this.createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  /** @return the operatorId */
  public String getOperatorId() {
    return operatorId;
  }

  /** @param operatorId the operatorId to set */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }
}
