package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

@Produces("application/json")
@Consumes("application/json")
@JsonIgnoreProperties(ignoreUnknown = true)
public final class SummaryResponse {

  /** The count. */
  private long count;
  /** The destinations. */
  private List<SummaryDestination> destinations;
  /** @return the count */
  public long getCount() {
    return count;
  }
  /** @param count the count to set */
  public void setCount(long count) {
    this.count = count;
  }
  /** @return the destinations */
  public List<SummaryDestination> getDestinations() {
    return destinations;
  }
  /** @param destinations the destinations to set */
  public void setDestinations(List<SummaryDestination> destinations) {
    this.destinations = destinations;
  }
}
