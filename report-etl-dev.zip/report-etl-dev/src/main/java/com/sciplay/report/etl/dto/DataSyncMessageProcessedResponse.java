package com.sciplay.report.etl.dto;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

@Produces("application/json")
@Consumes("application/json")
public final class DataSyncMessageProcessedResponse {

  /** The message. */
  private String message;
  /** The serviceName. */
  private String serviceName;

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  /** @return the serviceName */
  public String getServiceName() {
    return serviceName;
  }

  /** @param serviceName the serviceName to set */
  public void setServiceName(String serviceName) {
    this.serviceName = serviceName;
  }
}
