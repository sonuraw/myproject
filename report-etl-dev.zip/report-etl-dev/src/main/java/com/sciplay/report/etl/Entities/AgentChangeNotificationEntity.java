package com.sciplay.report.etl.Entities;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class AgentChangeNotificationEntity. */
@Entity
@Table(name = "AgentChangeNotification")
public class AgentChangeNotificationEntity implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The Correlation id. */
  @Id
  @Column(name = "CorrelationId")
  private String correlationId;

  /** The id. */
  @Id
  @Column(name = "Id")
  private int id;

  /** The agent id. */
  @Column(name = "AgentId")
  private Integer agentId;

  /** The change column name. */
  @Id
  @Column(name = "ChangeColumnName")
  private String changeColumnName;

  /** The old value. */
  @Column(name = "OldValue")
  private String oldValue;

  /** The new value. */
  @Column(name = "NewValue")
  private String newValue;

  /** The modified date. */
  @Column(name = "ModifiedDate")
  private Date modifiedDate;

  /** The modified by. */
  @Column(name = "ModifiedBy")
  private Integer modifiedBy;

  /** The session id. */
  @Column(name = "SessionId")
  private String sessionId;

  /** The ip address. */
  @Column(name = "IpAddress")
  private String ipAddress;

  /** The type of change. */
  @Column(name = "TypeOfChange", columnDefinition = "enum('credential','profile')")
  private String typeOfChange;

  public AgentChangeNotificationEntity() {}

  /**
   * Instantiates a new agent change notification entity.
   *
   * @param correlationId the Correlation Id
   * @param agentId the agent id
   * @param changeColumnName the change column name
   * @param oldValue the old value
   * @param newValue the new value
   * @param modifiedDate the modified date
   * @param modifiedBy the modified by
   * @param sessionId the session id
   * @param ipAddress the ip address
   * @param typeOfChange the type of change
   */
  public AgentChangeNotificationEntity(
      String correlationId,
      int id,
      Integer agentId,
      String changeColumnName,
      String oldValue,
      String newValue,
      Date modifiedDate,
      Integer modifiedBy,
      String sessionId,
      String ipAddress,
      String typeOfChange) {
    this.correlationId = correlationId;
    this.id = id;
    this.agentId = agentId;
    this.changeColumnName = changeColumnName;
    this.oldValue = oldValue;
    this.newValue = newValue;
    this.modifiedDate = modifiedDate;
    this.modifiedBy = Objects.isNull(modifiedBy) ? 0 : modifiedBy;
    this.sessionId = sessionId;
    this.ipAddress = ipAddress;
    this.typeOfChange = typeOfChange;
  }

  /**
   * Gets the correlation id.
   *
   * @return the correlation id
   */
  public String getCorrelationId() {
    return correlationId;
  }

  /**
   * Sets the correlation id.
   *
   * @param correlationId the new correlation id
   */
  public void setCorrelationId(String correlationId) {
    this.correlationId = correlationId;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public int getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(int id) {
    this.id = id;
  }

  /**
   * Gets the agent id.
   *
   * @return the agent id
   */
  public Integer getAgentId() {
    return agentId;
  }

  /**
   * Sets the agent id.
   *
   * @param agentId the new agent id
   */
  public void setAgentId(Integer agentId) {
    this.agentId = agentId;
  }

  /**
   * Gets the change column name.
   *
   * @return the change column name
   */
  public String getChangeColumnName() {
    return changeColumnName;
  }

  /**
   * Sets the change column name.
   *
   * @param changeColumnName the new change column name
   */
  public void setChangeColumnName(String changeColumnName) {
    this.changeColumnName = changeColumnName;
  }

  /**
   * Gets the old value.
   *
   * @return the old value
   */
  public String getOldValue() {
    return oldValue;
  }

  /**
   * Sets the old value.
   *
   * @param oldValue the new old value
   */
  public void setOldValue(String oldValue) {
    this.oldValue = oldValue;
  }

  /**
   * Gets the new value.
   *
   * @return the new value
   */
  public String getNewValue() {
    return newValue;
  }

  /**
   * Sets the new value.
   *
   * @param newValue the new new value
   */
  public void setNewValue(String newValue) {
    this.newValue = newValue;
  }

  /**
   * Gets the modified date.
   *
   * @return the modified date
   */
  public Date getModifiedDate() {
    return modifiedDate;
  }

  /**
   * Sets the modified date.
   *
   * @param modifiedDate the new modified date
   */
  public void setModifiedDate(Date modifiedDate) {
    this.modifiedDate = modifiedDate;
  }

  /**
   * Gets the modified by.
   *
   * @return the modified by
   */
  public Integer getModifiedBy() {
    return modifiedBy;
  }

  /**
   * Sets the modified by.
   *
   * @param modifiedBy the new modified by
   */
  public void setModifiedBy(Integer modifiedBy) {
    this.modifiedBy = Objects.isNull(modifiedBy) ? 0 : modifiedBy;
  }

  /**
   * Gets the session id.
   *
   * @return the session id
   */
  public String getSessionId() {
    return sessionId;
  }

  /**
   * Sets the session id.
   *
   * @param sessionId the new session id
   */
  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  /**
   * Gets the ip address.
   *
   * @return the ip address
   */
  public String getIpAddress() {
    return ipAddress;
  }

  /**
   * Sets the ip address.
   *
   * @param ipAddress the new ip address
   */
  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }

  /**
   * Gets the type of change.
   *
   * @return the type of change
   */
  public String getTypeOfChange() {
    return typeOfChange;
  }

  /**
   * Sets the type of change.
   *
   * @param typeOfChange the new type of change
   */
  public void setTypeOfChange(String typeOfChange) {
    this.typeOfChange = typeOfChange;
  }
}
