package com.sciplay.report.etl.dto.limits;

import com.sciplay.report.etl.dto.Links;

public class LimitCategoryData {

  private final String type;

  private final String id;

  private final LimitCategoryAttributes attributes;

  private final Links links;

  private final LimitMeta meta;

  public LimitCategoryData(
      String type, String id, LimitCategoryAttributes attributes, Links links, LimitMeta meta) {
    this.type = type;
    this.id = id;
    this.attributes = attributes;
    this.links = links;
    this.meta = meta;
  }

  public LimitCategoryData() {
    this.type = null;
    this.id = null;
    this.attributes = null;
    this.links = null;
    this.meta = null;
  }

  public String getType() {
    return type;
  }

  public String getId() {
    return id;
  }

  public LimitCategoryAttributes getAttributes() {
    return attributes;
  }

  public Links getLinks() {
    return links;
  }

  public LimitMeta getMeta() {
    return meta;
  }
}
