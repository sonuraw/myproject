package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class VersionResponse {

  private final String version;

  public VersionResponse(String version) {
    this.version = version;
  }

  @JsonProperty
  public String getVersion() {
    return version;
  }
}
