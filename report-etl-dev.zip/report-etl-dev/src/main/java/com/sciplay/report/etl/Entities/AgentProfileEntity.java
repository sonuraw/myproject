package com.sciplay.report.etl.Entities;

import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class AgentProfileEntity.
 *
 * @author salman
 */
@Entity
@Table(name = "AgentProfile")
public class AgentProfileEntity {

  /** The id. */
  @Id
  @Column(name = "Id")
  private Integer id;

  /** The user name. */
  @Column(name = "UserName")
  private String userName;

  /** The first name. */
  @Column(name = "FirstName")
  private String firstName;

  /** The last name. */
  @Column(name = "LastName")
  private String lastName;

  /** The email. */
  @Column(name = "Email")
  private String email;

  /** The locale. */
  @Column(name = "Locale")
  private String locale;

  /** The job title. */
  @Column(name = "jobTitle")
  private String jobTitle;

  /** The status. */
  @Column(name = "Status")
  private String status;

  /** The valid from. */
  @Column(name = "ValidFrom")
  private Date validFrom;

  /** The valid till. */
  @Column(name = "ValidTill")
  private Date validTill;

  /** The author id. */
  @Column(name = "AuthorId")
  private Integer authorId;

  /** The author ip. */
  @Column(name = "AuthorIp")
  private String authorIp;

  /** The author session id. */
  @Column(name = "AuthorSessionId")
  private String authorSessionId;

  /** The created at. */
  @Column(name = "CreatedAt")
  private Date createdAt;

  /** The last login. */
  @Column(name = "LastLogin")
  private Date lastLogin;

  /** The last password changed. */
  @Column(name = "LastPasswordChanged")
  private Date lastPasswordChanged;

  /** The last deactivated. */
  @Column(name = "LastDeactivated")
  private Date lastDeactivated;

  /** The Modified at. */
  private Date modifiedAt;

  /**
   * Gets the modified at.
   *
   * @return the modified at
   */
  public Date getModifiedAt() {
    return modifiedAt;
  }

  /**
   * Sets the modified at.
   *
   * @param modifiedAt the new modified at
   */
  public void setModifiedAt(Date modifiedAt) {
    this.modifiedAt = modifiedAt;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public Integer getId() {
    return id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(Integer id) {
    this.id = id;
  }

  /**
   * Gets the user name.
   *
   * @return the user name
   */
  public String getUserName() {
    return userName;
  }

  /**
   * Sets the user name.
   *
   * @param userName the new user name
   */
  public void setUserName(String userName) {
    this.userName = userName;
  }

  /**
   * Gets the first name.
   *
   * @return the first name
   */
  public String getFirstName() {
    return firstName;
  }

  /**
   * Sets the first name.
   *
   * @param firstName the new first name
   */
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  /**
   * Gets the last name.
   *
   * @return the last name
   */
  public String getLastName() {
    return lastName;
  }

  /**
   * Sets the last name.
   *
   * @param lastName the new last name
   */
  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  /**
   * Gets the email.
   *
   * @return the email
   */
  public String getEmail() {
    return email;
  }

  /**
   * Sets the email.
   *
   * @param email the new email
   */
  public void setEmail(String email) {
    this.email = email;
  }

  /**
   * Gets the locale.
   *
   * @return the locale
   */
  public String getLocale() {
    return locale;
  }

  /**
   * Sets the locale.
   *
   * @param locale the new locale
   */
  public void setLocale(String locale) {
    this.locale = locale;
  }

  /**
   * Gets the job title.
   *
   * @return the job title
   */
  public String getJobTitle() {
    return jobTitle;
  }

  /**
   * Sets the job title.
   *
   * @param jobTitle the new job title
   */
  public void setJobTitle(String jobTitle) {
    this.jobTitle = jobTitle;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public String getStatus() {
    return status;
  }

  /**
   * Sets the status.
   *
   * @param status the new status
   */
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * Gets the valid from.
   *
   * @return the valid from
   */
  public Date getValidFrom() {
    return validFrom;
  }

  /**
   * Sets the valid from.
   *
   * @param validFrom the new valid from
   */
  public void setValidFrom(Date validFrom) {
    this.validFrom = validFrom;
  }

  /**
   * Gets the valid till.
   *
   * @return the valid till
   */
  public Date getValidTill() {
    return validTill;
  }

  /**
   * Sets the valid till.
   *
   * @param validTill the new valid till
   */
  public void setValidTill(Date validTill) {
    this.validTill = validTill;
  }

  /**
   * Gets the author id.
   *
   * @return the author id
   */
  public Integer getAuthorId() {
    return authorId;
  }

  /**
   * Sets the author id.
   *
   * @param authorId the new author id
   */
  public void setAuthorId(Integer authorId) {
    this.authorId = Objects.isNull(authorId) ? 0 : authorId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  /**
   * Gets the last login.
   *
   * @return the last login
   */
  public Date getLastLogin() {
    return lastLogin;
  }

  /**
   * Sets the last login.
   *
   * @param lastLogin the new last login
   */
  public void setLastLogin(Date lastLogin) {
    this.lastLogin = lastLogin;
  }

  /**
   * Gets the last password changed.
   *
   * @return the last password changed
   */
  public Date getLastPasswordChanged() {
    return lastPasswordChanged;
  }

  /**
   * Sets the last password changed.
   *
   * @param lastPasswordChanged the new last password changed
   */
  public void setLastPasswordChanged(Date lastPasswordChanged) {
    this.lastPasswordChanged = lastPasswordChanged;
  }

  /**
   * Gets the last deactivated.
   *
   * @return the last deactivated
   */
  public Date getLastDeactivated() {
    return lastDeactivated;
  }

  /**
   * Sets the last deactivated.
   *
   * @param lastDeactivated the new last deactivated
   */
  public void setLastDeactivated(Date lastDeactivated) {
    this.lastDeactivated = lastDeactivated;
  }
}
