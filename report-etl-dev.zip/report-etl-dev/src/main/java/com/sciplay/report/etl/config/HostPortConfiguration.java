package com.sciplay.report.etl.config;

import javax.validation.constraints.NotNull;
import org.hibernate.validator.constraints.NotEmpty;

/** Represents all external systems configured by host:port pairs. */
public class HostPortConfiguration {
  @NotEmpty private String host;

  @NotNull private Integer port;

  HostPortConfiguration() {}

  public HostPortConfiguration(String host, Integer port) {
    this.host = host;
    this.port = port;
  }

  public String getHost() {
    return host;
  }

  public Integer getPort() {
    return port;
  }

  @Override
  public String toString() {
    return host + ":" + port;
  }
}
