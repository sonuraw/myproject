package com.sciplay.report.etl.Entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class SubscriptionScheduleEntity. */
@Entity
@Table(name = "SubscriptionSchedule")
public class SubscriptionScheduleEntity implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The Year. */
  @Id
  @Column(name = "Year")
  private int year;

  /** The Operator id. */
  @Id
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The Created at. */
  @Column(name = "CreatedAt")
  private Date createdAt;

  /** The Correlation id. */
  @Column(name = "CorrelationId")
  private String correlationId;

  /** The Is deleted. */
  private Boolean isDeleted = false;

  /** The author id. */
  private Integer authorId;

  /** The author ip. */
  private String authorIp;

  /** The author session id. */
  private String authorSessionId;

  /** The author type. */
  private String authorType;

  /** The Modified at. */
  private Date modifiedAt;

  /**
   * Gets the modified at.
   *
   * @return the modified at
   */
  public Date getModifiedAt() {
    return modifiedAt;
  }

  /**
   * Sets the modified at.
   *
   * @param modifiedAt the new modified at
   */
  public void setModifiedAt(Date modifiedAt) {
    this.modifiedAt = modifiedAt;
  }

  /**
   * Gets the author id.
   *
   * @return the author id
   */
  public Integer getAuthorId() {
    return authorId;
  }

  /**
   * Sets the author id.
   *
   * @param authorId the new author id
   */
  public void setAuthorId(Integer authorId) {
    if (authorId == null) {
      authorId = 0;
    }
    this.authorId = authorId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the author type.
   *
   * @return the author type
   */
  public String getAuthorType() {
    return authorType;
  }

  /**
   * Sets the author type.
   *
   * @param authorType the new author type
   */
  public void setAuthorType(String authorType) {
    this.authorType = authorType;
  }

  /**
   * Gets the checks if is deleted.
   *
   * @return the checks if is deleted
   */
  public Boolean getIsDeleted() {
    return isDeleted;
  }

  /**
   * Sets the checks if is deleted.
   *
   * @param isDeleted the new checks if is deleted
   */
  public void setIsDeleted(Boolean isDeleted) {
    if (isDeleted == null) {
      isDeleted = false;
    }
    this.isDeleted = isDeleted;
  }

  /**
   * Gets the year.
   *
   * @return the year
   */
  public int getYear() {
    return year;
  }

  /**
   * Sets the year.
   *
   * @param year the new year
   */
  public void setYear(int year) {
    this.year = year;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  /**
   * Gets the correlation id.
   *
   * @return the correlation id
   */
  public String getCorrelationId() {
    return correlationId;
  }

  /**
   * Sets the correlation id.
   *
   * @param correlationId the new correlation id
   */
  public void setCorrelationId(String correlationId) {
    this.correlationId = correlationId;
  }
}
