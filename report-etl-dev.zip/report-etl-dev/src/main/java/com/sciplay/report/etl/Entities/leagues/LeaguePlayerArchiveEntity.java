package com.sciplay.report.etl.Entities.leagues;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

/**
 * The Class LeaguePlayerArchiveEntity.
 *
 * @author salman
 */
@Entity
@Table(name = "LeaguePlayerArchive")
public class LeaguePlayerArchiveEntity {

  /** The revision number. */
  @javax.persistence.Id
  @Column(name = "RevisionNumber")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long revisionNumber;

  /** The revision date. */
  @Column(name = "RevisionDate")
  private Date revisionDate;

  /** The revision state. */
  @Column(name = "RevisionState")
  private String revisionState;

  /** The player id. */
  @Column(name = "PlayerId")
  private Integer playerId;

  /** The league id. */
  @Column(name = "LeagueId")
  private String leagueId;

  /** The operator id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The status. */
  @Column(
      name = "Status",
      columnDefinition = "enum('ACTIVE','JOINED','LEFT','REMOVED','A','J','L','R')")
  private String status;

  /** The author id. */
  @Column(name = "AuthorId")
  private Integer authorId;

  /** The author ip. */
  @Column(name = "AuthorIp")
  private String authorIp;

  /** The author session id. */
  @Column(name = "AuthorSessionId")
  private String authorSessionId;

  /** The created at. */
  @Column(name = "CreatedAt")
  private Date createdAt;

  /** Instantiates a new league player archive entity. */
  public LeaguePlayerArchiveEntity() {}

  /**
   * Instantiates a new league player archive entity.
   *
   * @param leaguePlayerEntity the league player entity
   */
  public LeaguePlayerArchiveEntity(LeaguePlayerEntity leaguePlayerEntity, String revisionState) {
    this.playerId = leaguePlayerEntity.getPlayerId();
    this.leagueId = leaguePlayerEntity.getLeagueId();
    this.operatorId = leaguePlayerEntity.getOperatorId();
    this.status = leaguePlayerEntity.getStatus();
    this.authorId = leaguePlayerEntity.getAuthorId();
    this.authorIp = leaguePlayerEntity.getAuthorIp();
    this.authorSessionId = leaguePlayerEntity.getAuthorSessionId();
    this.createdAt = leaguePlayerEntity.getCreatedAt();
    this.revisionDate = leaguePlayerEntity.getUpdatedAt();
    this.revisionState = revisionState;
  }

  /**
   * Gets the revision number.
   *
   * @return the revision number
   */
  public long getRevisionNumber() {
    return revisionNumber;
  }

  /**
   * Sets the revision number.
   *
   * @param revisionNumber the new revision number
   */
  public void setRevisionNumber(long revisionNumber) {
    this.revisionNumber = revisionNumber;
  }

  /**
   * Gets the revision date.
   *
   * @return the revision date
   */
  public Date getRevisionDate() {
    return revisionDate;
  }

  /**
   * Sets the revision date.
   *
   * @param revisionDate the new revision date
   */
  public void setRevisionDate(Date revisionDate) {
    this.revisionDate = revisionDate;
  }

  /**
   * Gets the revision state.
   *
   * @return the revision state
   */
  public String getRevisionState() {
    return revisionState;
  }

  /**
   * Sets the revision state.
   *
   * @param revisionState the new revision state
   */
  public void setRevisionState(String revisionState) {
    this.revisionState = revisionState;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the league id.
   *
   * @return the league id
   */
  public String getLeagueId() {
    return leagueId;
  }

  /**
   * Sets the league id.
   *
   * @param leagueId the new league id
   */
  public void setLeagueId(String leagueId) {
    this.leagueId = leagueId;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public String getStatus() {
    return status;
  }

  /**
   * Sets the status.
   *
   * @param status the new status
   */
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * Gets the author id.
   *
   * @return the author id
   */
  public Integer getAuthorId() {
    return authorId;
  }

  /**
   * Sets the author id.
   *
   * @param authorId the new author id
   */
  public void setAuthorId(Integer authorId) {
    this.authorId = authorId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }
}
