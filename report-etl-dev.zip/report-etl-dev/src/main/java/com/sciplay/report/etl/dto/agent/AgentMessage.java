package com.sciplay.report.etl.dto.agent;

import com.sciplay.report.etl.ReportEtlContext;
import java.io.IOException;

/** @author salman */
public class AgentMessage {

  private AgentMeta meta;

  private AgentData data;

  public AgentMeta getMeta() {
    return meta;
  }

  public void setMeta(AgentMeta meta) {
    this.meta = meta;
  }

  public AgentData getData() {
    return data;
  }

  public void setData(AgentData data) {
    this.data = data;
  }

  public String getJsonString() throws IOException {
    return ReportEtlContext.getInstance().getObjectMapper().writeValueAsString(this);
  }
}
