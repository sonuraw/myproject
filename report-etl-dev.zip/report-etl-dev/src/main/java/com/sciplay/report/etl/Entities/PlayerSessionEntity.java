package com.sciplay.report.etl.Entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class PlayerSessionId. */
@Entity
@Table(name = "PlayerSession")
public class PlayerSessionEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The session id. */
  @Id
  @Column(name = "SessionId")
  private String sessionId;

  /** The player id. */
  private Integer playerId;

  /** The ip address. */
  private String ipAddress;

  /** The customer id. */
  @Column(length = 3, columnDefinition = "CHAR")
  private String operatorId;

  /** The type. */
  private String type;

  /** The correlation id. */
  private String correlationId;

  /** The start time. */
  private Date startTime;

  /** The last activity. */
  private Date lastActivity;

  /** The end time. */
  @Column(name = "EndTime")
  private Date endTime;

  /** The end reason. */
  private String endReason;

  /** The realmoney balance before. */
  // @Column(name = "RealmoneyBalanceBefore", nullable = true)
  private Long realMoneyBalanceBefore;

  /** The real money balance after. */
  // @Column(name = "RealMoneyBalanceAfter", nullable = true)
  private Long realMoneyBalanceAfter;

  /** The game platform. */
  private String gamePlatform;

  /** The transaction type. */
  private String transactionType;

  /** The money type. */
  private String moneyType;

  /** The website. */
  private String website;

  /** The status. */
  private String status;

  /** The nem id. */
  private String nemId;

  /** The balance before. */
  private Long balanceBefore;

  /** The balance after. */
  private Long balanceAfter;

  /** The info. */
  private String info;

  /** The last activity. */
  private Date realMoneyBalanceAfterUpdatedDate;

  /** The last activity. */
  private Date realmoneyBalanceBeforeUpdatedDate;

  /** The Modified at. */
  private Date modifiedAt;

  /** The Username. */
  private String username;

  /** The channel. */
  private String channel;

  /** Instantiates a new player session id. */
  public PlayerSessionEntity() {}

  /**
   * Instantiates a new player session id.
   *
   * @param sessionId the session id
   * @param playerId the player id
   * @param ipAddress the ip address
   * @param operatorId the operatorId id
   * @param type the type
   * @param correlationId the correlation id
   * @param startTime the start time
   * @param lastActivity the last activity
   * @param endTime the end time
   * @param endReason the end reason
   * @param realMoneyBalanceBefore the realmoney balance before
   * @param realMoneyBalanceAfter the real money balance after
   * @param gamePlatform the game platform
   * @param transactionType the transaction type
   * @param moneyType the money type
   * @param website the website
   * @param status the status
   * @param nemId the nem id
   * @param balanceBefore the balance before
   * @param balanceAfter the balance after
   * @param info the info
   * @param realMoneyBalanceAfterUpdatedDate the real money balance after updated date
   * @param realmoneyBalanceBeforeUpdatedDate the realmoney balance before updated date
   * @param modifiedAt the modified at
   */
  public PlayerSessionEntity(
      String sessionId,
      Integer playerId,
      String ipAddress,
      String operatorId,
      String type,
      String correlationId,
      Date startTime,
      Date lastActivity,
      Date endTime,
      String endReason,
      Long realMoneyBalanceBefore,
      Long realMoneyBalanceAfter,
      String gamePlatform,
      String transactionType,
      String moneyType,
      String website,
      String status,
      String nemId,
      Long balanceBefore,
      Long balanceAfter,
      String info,
      Date realMoneyBalanceAfterUpdatedDate,
      Date realmoneyBalanceBeforeUpdatedDate,
      Date modifiedAt) {
    this.sessionId = sessionId;
    this.playerId = playerId;
    this.ipAddress = ipAddress;
    this.operatorId = operatorId;
    this.type = type;
    this.correlationId = correlationId;
    this.startTime = startTime;
    this.lastActivity = lastActivity;
    this.endTime = endTime;
    this.endReason = endReason;
    this.realMoneyBalanceBefore = realMoneyBalanceBefore;
    this.realMoneyBalanceAfter = realMoneyBalanceAfter;
    this.gamePlatform = gamePlatform;
    this.transactionType = transactionType;
    this.moneyType = moneyType;
    this.website = website;
    this.status = status;
    this.nemId = nemId;
    this.balanceBefore = balanceBefore;
    this.balanceAfter = balanceAfter;
    this.info = info;
    this.realMoneyBalanceAfterUpdatedDate = realMoneyBalanceAfterUpdatedDate;
    this.realmoneyBalanceBeforeUpdatedDate = realmoneyBalanceBeforeUpdatedDate;
    this.modifiedAt = modifiedAt;
  }

  /**
   * Gets the username.
   *
   * @return the username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Sets the username.
   *
   * @param username the new username
   */
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   * Gets the realmoney balance before updated date.
   *
   * @return the realmoney balance before updated date
   */
  public Date getRealmoneyBalanceBeforeUpdatedDate() {
    return realmoneyBalanceBeforeUpdatedDate;
  }

  /**
   * Sets the realmoney balance before updated date.
   *
   * @param realmoneyBalanceBeforeUpdatedDate the new realmoney balance before updated date
   */
  public void setRealmoneyBalanceBeforeUpdatedDate(Date realmoneyBalanceBeforeUpdatedDate) {
    this.realmoneyBalanceBeforeUpdatedDate = realmoneyBalanceBeforeUpdatedDate;
  }

  /**
   * Gets the modified at.
   *
   * @return the modified at
   */
  public Date getModifiedAt() {
    return modifiedAt;
  }

  /**
   * Sets the modified at.
   *
   * @param modifiedAt the new modified at
   */
  public void setModifiedAt(Date modifiedAt) {
    this.modifiedAt = modifiedAt;
  }

  /**
   * Gets the session id.
   *
   * @return the session id
   */
  public String getSessionId() {
    return this.sessionId;
  }

  /**
   * Sets the session id.
   *
   * @param sessionId the new session id
   */
  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return this.playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    if (playerId == null) {
      playerId = 0;
    }
    this.playerId = playerId;
  }

  /**
   * Gets the ip address.
   *
   * @return the ip address
   */
  public String getIpAddress() {
    return this.ipAddress;
  }

  /**
   * Sets the ip address.
   *
   * @param ipAddress the new ip address
   */
  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }

  /**
   * Gets the customer id.
   *
   * @return the customer id
   */
  public String getOperatorId() {
    return this.operatorId;
  }

  /**
   * Sets the customer id.
   *
   * @param operatorId the new customer id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return this.type;
  }

  /**
   * Sets the type.
   *
   * @param type the new type
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the correlation id.
   *
   * @return the correlation id
   */
  public String getCorrelationId() {
    return this.correlationId;
  }

  /**
   * Sets the correlation id.
   *
   * @param correlationId the new correlation id
   */
  public void setCorrelationId(String correlationId) {
    this.correlationId = correlationId;
  }

  /**
   * Gets the start time.
   *
   * @return the start time
   */
  public Date getStartTime() {
    return this.startTime;
  }

  /**
   * Sets the start time.
   *
   * @param startTime the new start time
   */
  public void setStartTime(Date startTime) {
    this.startTime = startTime;
  }

  /**
   * Gets the last activity.
   *
   * @return the last activity
   */
  public Date getLastActivity() {
    return this.lastActivity;
  }

  /**
   * Sets the last activity.
   *
   * @param lastActivity the new last activity
   */
  public void setLastActivity(Date lastActivity) {
    this.lastActivity = lastActivity;
  }

  /**
   * Gets the end time.
   *
   * @return the end time
   */
  public Date getEndTime() {
    return this.endTime;
  }

  /**
   * Sets the end time.
   *
   * @param endTime the new end time
   */
  public void setEndTime(Date endTime) {
    this.endTime = endTime;
  }

  /**
   * Gets the end reason.
   *
   * @return the end reason
   */
  public String getEndReason() {
    return this.endReason;
  }

  /**
   * Sets the end reason.
   *
   * @param endReason the new end reason
   */
  public void setEndReason(String endReason) {
    this.endReason = endReason;
  }

  /**
   * Gets the realmoney balance before.
   *
   * @return the realmoney balance before
   */
  public Long getRealMoneyBalanceBefore() {
    return this.realMoneyBalanceBefore;
  }

  /**
   * Sets the realmoney balance before.
   *
   * @param realMoneyBalanceBefore the new realmoney balance before
   */
  public void setRealMoneyBalanceBefore(Long realMoneyBalanceBefore) {
    if (realMoneyBalanceBefore == null) {
      realMoneyBalanceBefore = 0L;
    }
    this.realMoneyBalanceBefore = realMoneyBalanceBefore;
  }

  /**
   * Gets the real money balance after.
   *
   * @return the real money balance after
   */
  public Long getRealMoneyBalanceAfter() {
    return this.realMoneyBalanceAfter;
  }

  /**
   * Sets the real money balance after.
   *
   * @param realMoneyBalanceAfter the new real money balance after
   */
  public void setRealMoneyBalanceAfter(Long realMoneyBalanceAfter) {
    if (realMoneyBalanceAfter == null) {
      realMoneyBalanceAfter = 0L;
    }
    this.realMoneyBalanceAfter = realMoneyBalanceAfter;
  }

  /**
   * Gets the game platform.
   *
   * @return the game platform
   */
  public String getGamePlatform() {
    return this.gamePlatform;
  }

  /**
   * Sets the game platform.
   *
   * @param gamePlatform the new game platform
   */
  public void setGamePlatform(String gamePlatform) {
    this.gamePlatform = gamePlatform;
  }

  /**
   * Gets the transaction type.
   *
   * @return the transaction type
   */
  public String getTransactionType() {
    return this.transactionType;
  }

  /**
   * Sets the transaction type.
   *
   * @param transactionType the new transaction type
   */
  public void setTransactionType(String transactionType) {
    this.transactionType = transactionType;
  }

  /**
   * Gets the money type.
   *
   * @return the money type
   */
  public String getMoneyType() {
    return this.moneyType;
  }

  /**
   * Sets the money type.
   *
   * @param moneyType the new money type
   */
  public void setMoneyType(String moneyType) {
    this.moneyType = moneyType;
  }

  /**
   * Gets the website.
   *
   * @return the website
   */
  public String getWebsite() {
    return this.website;
  }

  /**
   * Sets the website.
   *
   * @param website the new website
   */
  public void setWebsite(String website) {
    this.website = website;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public String getStatus() {
    return this.status;
  }

  /**
   * Sets the status.
   *
   * @param status the new status
   */
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * Gets the nem id.
   *
   * @return the nem id
   */
  public String getNemId() {
    return this.nemId;
  }

  /**
   * Sets the nem id.
   *
   * @param nemId the new nem id
   */
  public void setNemId(String nemId) {
    this.nemId = nemId;
  }

  /**
   * Gets the balance before.
   *
   * @return the balance before
   */
  public Long getBalanceBefore() {
    return this.balanceBefore;
  }

  /**
   * Sets the balance before.
   *
   * @param balanceBefore the new balance before
   */
  public void setBalanceBefore(Long balanceBefore) {
    if (balanceBefore == null) {
      balanceBefore = 0L;
    }
    this.balanceBefore = balanceBefore;
  }

  /**
   * Gets the balance after.
   *
   * @return the balance after
   */
  public Long getBalanceAfter() {
    return this.balanceAfter;
  }

  /**
   * Sets the balance after.
   *
   * @param balanceAfter the new balance after
   */
  public void setBalanceAfter(Long balanceAfter) {
    if (balanceAfter == null) {
      balanceAfter = 0L;
    }
    this.balanceAfter = balanceAfter;
  }

  /**
   * Gets the info.
   *
   * @return the info
   */
  public String getInfo() {
    return this.info;
  }

  /**
   * Sets the info.
   *
   * @param info the new info
   */
  public void setInfo(String info) {
    this.info = info;
  }

  /**
   * Gets the end time.
   *
   * @return the end time
   */
  public Date getRealMoneyBalanceAfterUpdatedDate() {
    return this.realMoneyBalanceAfterUpdatedDate;
  }

  /**
   * Sets the end time.
   *
   * @param realMoneyBalanceAfterUpdatedDate the new real money balance after updated date
   */
  public void setRealMoneyBalanceAfterUpdatedDate(Date realMoneyBalanceAfterUpdatedDate) {
    this.realMoneyBalanceAfterUpdatedDate = realMoneyBalanceAfterUpdatedDate;
  }

  /**
   * Gets the end time.
   *
   * @return the end time
   */
  public Date getRealMoneyBalanceBeforeUpdatedDate() {
    return this.realmoneyBalanceBeforeUpdatedDate;
  }

  /**
   * Sets the end time.
   *
   * @param realmoneyBalanceBeforeUpdatedDate the new real money balance before updated date
   */
  public void setRealMoneyBalanceBeforeUpdatedDate(Date realmoneyBalanceBeforeUpdatedDate) {
    this.realmoneyBalanceBeforeUpdatedDate = realmoneyBalanceBeforeUpdatedDate;
  }

  public String getChannel() {
    return channel;
  }

  public void setChannel(String channel) {
    this.channel = channel;
  }
}
