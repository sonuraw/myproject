package com.sciplay.report.etl.dto.limits;

/** @author salman */
public class ExpectedSpendingMessage {

  private String correlationId;
  private String walletID;
  private String limitId;
  private String operator;
  private String createdAt;
  private long transactionAmount;
  private String duration;

  public ExpectedSpendingMessage(
      String correlationId, String operator, String walletID, String createdAt) {
    this.correlationId = correlationId;
    this.walletID = walletID;
    this.operator = operator;
    this.createdAt = createdAt;
  }

  public ExpectedSpendingMessage() {}

  public String getCorrelationId() {
    return correlationId;
  }

  public void setCorrelationId(String correlationId) {
    this.correlationId = correlationId;
  }

  public String getWalletID() {
    return walletID;
  }

  public void setWalletID(String walletID) {
    this.walletID = walletID;
  }

  public String getLimitId() {
    return limitId;
  }

  public void setLimitId(String limitId) {
    this.limitId = limitId;
  }

  public String getOperator() {
    return operator;
  }

  public void setOperator(String operator) {
    this.operator = operator;
  }

  public String getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }

  public long getTransactionAmount() {
    return transactionAmount;
  }

  public void setTransactionAmount(long transactionAmount) {
    this.transactionAmount = transactionAmount;
  }

  public String getDuration() {
    return duration;
  }

  public void setDuration(String duration) {
    this.duration = duration;
  }
}
