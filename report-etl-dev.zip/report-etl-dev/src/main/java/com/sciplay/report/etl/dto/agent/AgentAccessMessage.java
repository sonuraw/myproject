package com.sciplay.report.etl.dto.agent;

import com.sciplay.report.etl.ReportEtlContext;
import java.io.IOException;

/** @author salman */
public class AgentAccessMessage {

  private AgentMeta meta;

  private AgentAccessData data;

  public AgentMeta getMeta() {
    return meta;
  }

  public void setMeta(AgentMeta meta) {
    this.meta = meta;
  }

  public AgentAccessData getData() {
    return data;
  }

  public void setData(AgentAccessData data) {
    this.data = data;
  }

  public String getJsonString() throws IOException {
    return ReportEtlContext.getInstance().getObjectMapper().writeValueAsString(this);
  }
}
