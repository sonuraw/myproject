package com.sciplay.report.etl.Entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class SubscriptionGamesEntity. */
@Entity
@Table(name = "SubscriptionGamesArchive")
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubscriptionGamesArchiveEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The revision number. */
  @Column(name = "RevisionNumber")
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long revisionNumber;

  /** The revision date. */
  private Date revisionDate;

  /** The revision state. */
  private String revisionState;

  /** The Draw game template id. */
  private String drawGameTemplateId;

  /** The Subscription id. */
  private Long subscriptionId;

  /** The Game id. */
  private Integer gameId;

  /** The Game name. */
  private String gameName;

  /** The No of tickets. */
  private Integer noOfTickets;

  /** The Is random. */
  private String playMethod;

  /** The Cost per draw. */
  private Integer costPerDraw;

  /** The Partner id. */
  private String partnerId;

  /** The Add on trigger value. */
  private Long addOnTriggerValue;

  /** The Version id. */
  private int versionId;

  /** The Parent draw game template id. */
  private String parentDrawGameTemplateId;

  /** The next draw start date. */
  private Date nextDrawStartDate;

  /** The next draw end date. */
  private Date nextDrawEndDate;

  /** Instantiates a new subscription games entity. */
  public SubscriptionGamesArchiveEntity() {}

  /**
   * Instantiates a new subscription games archive entity.
   *
   * @param revisionDate the revision date
   * @param revisionState the revision state
   * @param drawGameTemplateId the draw game template id
   * @param subscriptionId the subscription id
   * @param gameId the game id
   * @param gameName the game name
   * @param noOfTickets the no of tickets
   * @param playMethod the play method
   * @param costPerDraw the cost per draw
   */
  public SubscriptionGamesArchiveEntity(
      Date revisionDate,
      String revisionState,
      String drawGameTemplateId,
      Long subscriptionId,
      Integer gameId,
      String gameName,
      Integer noOfTickets,
      String playMethod,
      Integer costPerDraw) {
    this.revisionDate = revisionDate;
    this.revisionState = revisionState;
    this.drawGameTemplateId = drawGameTemplateId;
    this.subscriptionId = subscriptionId;
    this.gameId = gameId;
    this.gameName = gameName;
    this.noOfTickets = noOfTickets;
    this.playMethod = playMethod;
    this.costPerDraw = costPerDraw;
    this.costPerDraw = costPerDraw;
  }

  /**
   * Gets the serialversionuid.
   *
   * @return the serialversionuid
   */
  public static long getSerialversionuid() {
    return serialVersionUID;
  }

  /**
   * Gets the next draw start date.
   *
   * @return the next draw start date
   */
  public Date getNextDrawStartDate() {
    return nextDrawStartDate;
  }

  /**
   * Sets the next draw start date.
   *
   * @param nextDrawStartDate the new next draw start date
   */
  public void setNextDrawStartDate(Date nextDrawStartDate) {
    this.nextDrawStartDate = nextDrawStartDate;
  }

  /**
   * Gets the next draw end date.
   *
   * @return the next draw end date
   */
  public Date getNextDrawEndDate() {
    return nextDrawEndDate;
  }

  /**
   * Sets the next draw end date.
   *
   * @param nextDrawEndDate the new next draw end date
   */
  public void setNextDrawEndDate(Date nextDrawEndDate) {
    this.nextDrawEndDate = nextDrawEndDate;
  }

  /**
   * Gets the parent draw game template id.
   *
   * @return the parent draw game template id
   */
  public String getParentDrawGameTemplateId() {
    return parentDrawGameTemplateId;
  }

  /**
   * Sets the parent draw game template id.
   *
   * @param parentDrawGameTemplateId the new parent draw game template id
   */
  public void setParentDrawGameTemplateId(String pParentDrawGameTemplateId) {
    parentDrawGameTemplateId = pParentDrawGameTemplateId;
  }

  /**
   * Gets the version id.
   *
   * @return the version id
   */
  public int getVersionId() {
    return versionId;
  }

  /**
   * Sets the version id.
   *
   * @param versionId the new version id
   */
  public void setVersionId(int versionId) {
    this.versionId = versionId;
  }

  /**
   * Gets the partner id.
   *
   * @return the partner id
   */
  public String getPartnerId() {
    return partnerId;
  }

  /**
   * Sets the partner id.
   *
   * @param partnerId the new partner id
   */
  public void setPartnerId(String partnerId) {
    this.partnerId = partnerId;
  }

  /**
   * Gets the adds the on trigger value.
   *
   * @return the adds the on trigger value
   */
  public Long getAddOnTriggerValue() {
    return addOnTriggerValue;
  }

  /**
   * Sets the adds the on trigger value.
   *
   * @param addOnTriggerValue the new adds the on trigger value
   */
  public void setAddOnTriggerValue(Long addOnTriggerValue) {
    this.addOnTriggerValue = addOnTriggerValue;
  }

  /**
   * Gets the revision number.
   *
   * @return the revision number
   */
  public long getRevisionNumber() {
    return revisionNumber;
  }

  /**
   * Sets the revision number.
   *
   * @param revisionNumber the new revision number
   */
  public void setRevisionNumber(long revisionNumber) {
    this.revisionNumber = revisionNumber;
  }

  /**
   * Gets the revision date.
   *
   * @return the revision date
   */
  public Date getRevisionDate() {
    return revisionDate;
  }

  /**
   * Sets the revision date.
   *
   * @param revisionDate the new revision date
   */
  public void setRevisionDate(Date revisionDate) {
    this.revisionDate = revisionDate;
  }

  /**
   * Gets the revision state.
   *
   * @return the revision state
   */
  public String getRevisionState() {
    return revisionState;
  }

  /**
   * Sets the revision state.
   *
   * @param revisionState the new revision state
   */
  public void setRevisionState(String revisionState) {
    this.revisionState = revisionState;
  }

  /**
   * Gets the draw game template id.
   *
   * @return the draw game template id
   */
  public String getDrawGameTemplateId() {
    return drawGameTemplateId;
  }

  /**
   * Sets the draw game template id.
   *
   * @param drawGameTemplateId the new draw game template id
   */
  public void setDrawGameTemplateId(String drawGameTemplateId) {
    this.drawGameTemplateId = drawGameTemplateId;
  }

  /**
   * Gets the subscription id.
   *
   * @return the subscription id
   */
  public Long getSubscriptionId() {
    return subscriptionId;
  }

  /**
   * Sets the subscription id.
   *
   * @param subscriptionId the new subscription id
   */
  public void setSubscriptionId(Long subscriptionId) {
    this.subscriptionId = subscriptionId;
  }

  /**
   * Gets the game id.
   *
   * @return the game id
   */
  public Integer getGameId() {
    return gameId;
  }

  /**
   * Sets the game id.
   *
   * @param gameId the new game id
   */
  public void setGameId(Integer gameId) {
    this.gameId = gameId;
  }

  /**
   * Gets the game name.
   *
   * @return the game name
   */
  public String getGameName() {
    return gameName;
  }

  /**
   * Sets the game name.
   *
   * @param gameName the new game name
   */
  public void setGameName(String gameName) {
    this.gameName = gameName;
  }

  /**
   * Gets the no of tickets.
   *
   * @return the no of tickets
   */
  public Integer getNoOfTickets() {
    return noOfTickets;
  }

  /**
   * Sets the no of tickets.
   *
   * @param noOfTickets the new no of tickets
   */
  public void setNoOfTickets(Integer noOfTickets) {
    this.noOfTickets = noOfTickets;
  }

  /**
   * Gets the checks if is random.
   *
   * @return the checks if is random
   */
  public String getPlayMethod() {
    return playMethod;
  }

  /**
   * Sets the checks if is random.
   *
   * @param playMethod the new play method
   */
  public void setPlayMethod(String playMethod) {
    this.playMethod = playMethod;
  }

  /**
   * Gets the cost per draw.
   *
   * @return the cost per draw
   */
  public Integer getCostPerDraw() {
    return costPerDraw;
  }

  /**
   * Sets the cost per draw.
   *
   * @param costPerDraw the new cost per draw
   */
  public void setCostPerDraw(Integer costPerDraw) {
    this.costPerDraw = costPerDraw;
  }
}
