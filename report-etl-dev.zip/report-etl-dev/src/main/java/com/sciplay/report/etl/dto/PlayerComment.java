package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** The Class PlayerComment. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PlayerComment {

  /** The player id. */
  private Integer playerId;

  /** The type. */
  private String type;

  /** The comment. */
  private String comment;

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the type.
   *
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * Sets the type.
   *
   * @param type the new type
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * Gets the comment.
   *
   * @return the comment
   */
  public String getComment() {
    return comment;
  }

  /**
   * Sets the comment.
   *
   * @param comment the new comment
   */
  public void setComment(String comment) {
    this.comment = comment;
  }
}
