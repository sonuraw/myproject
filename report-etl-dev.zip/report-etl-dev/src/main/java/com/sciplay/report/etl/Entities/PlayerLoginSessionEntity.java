package com.sciplay.report.etl.Entities;

import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class PlayerLoginSession. */
@Entity
@Table(name = "PlayerLoginSession")
public class PlayerLoginSessionEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The revision number. */
  @Column(name = "RevisionNumber")
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long revisionNumber;

  /** The revision date. */
  private Date revisionDate;

  /** The id. */
  private String id;

  /** The event type. */
  private String eventType;

  /** The player id. */
  private Integer playerId;

  /** The operator id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The is secured login. */
  private Boolean isSecuredLogin;

  /** The username. */
  private String username;

  /** The ip. */
  private String ip;

  /** The reason. */
  private String reason;

  /** The created at. */
  private Date createdAt;

  /** The nem id. */
  private String nemId;

  /** The channel. */
  private String channel;

  /** Instantiates a new player login session. */
  public PlayerLoginSessionEntity() {}

  /**
   * Instantiates a new player login session.
   *
   * @param id the id
   * @param eventType the event type
   * @param playerId the player id
   * @param operatorId the operator id
   * @param ip the ip
   * @param createdAt the created at
   */
  public PlayerLoginSessionEntity(
      String id, String eventType, Integer playerId, String operatorId, String ip, Date createdAt) {
    this.id = id;
    this.eventType = eventType;
    this.playerId = Objects.isNull(playerId) ? 0 : playerId;
    this.operatorId = operatorId;
    this.ip = ip;
    this.createdAt = createdAt;
  }

  /**
   * Instantiates a new player login session.
   *
   * @param id the id
   * @param eventType the event type
   * @param playerId the player id
   * @param operatorId the operator id
   * @param isSecuredLogin the is secured login
   * @param username the username
   * @param ip the ip
   * @param reason the reason
   * @param createdAt the created at
   */
  public PlayerLoginSessionEntity(
      Date revisionDate,
      String id,
      String eventType,
      Integer playerId,
      String operatorId,
      Boolean isSecuredLogin,
      String username,
      String ip,
      String reason,
      Date createdAt,
      String nemId) {
    this.id = id;
    this.eventType = eventType;
    this.playerId = Objects.isNull(playerId) ? 0 : playerId;
    this.operatorId = operatorId;
    this.isSecuredLogin = isSecuredLogin;
    this.username = username;
    this.ip = ip;
    this.reason = reason;
    this.createdAt = createdAt;
    this.revisionDate = revisionDate;
    this.nemId = nemId;
  }

  /**
   * Gets the nem id.
   *
   * @return the nem id
   */
  public String getNemId() {
    return this.nemId;
  }

  /**
   * Sets the nem id.
   *
   * @param nemId the new nem id
   */
  public void setNemId(String nemId) {
    this.nemId = nemId;
  }

  /**
   * Gets the revision number.
   *
   * @return the revision number
   */
  public long getRevisionNumber() {
    return revisionNumber;
  }

  /**
   * Sets the revision number.
   *
   * @param revisionNumber the new revision number
   */
  public void setRevisionNumber(long revisionNumber) {
    this.revisionNumber = revisionNumber;
  }

  /**
   * Gets the revision date.
   *
   * @return the revision date
   */
  public Date getRevisionDate() {
    return revisionDate;
  }

  /**
   * Sets the revision date.
   *
   * @param revisionDate the new revision date
   */
  public void setRevisionDate(Date revisionDate) {
    this.revisionDate = revisionDate;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public String getId() {
    return this.id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Gets the event type.
   *
   * @return the event type
   */
  public String getEventType() {
    return this.eventType;
  }

  /**
   * Sets the event type.
   *
   * @param eventType the new event type
   */
  public void setEventType(String eventType) {
    this.eventType = eventType;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return this.playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = Objects.isNull(playerId) ? 0 : playerId;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return this.operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the checks if is secured login.
   *
   * @return the checks if is secured login
   */
  public Boolean getIsSecuredLogin() {
    return this.isSecuredLogin;
  }

  /**
   * Sets the checks if is secured login.
   *
   * @param isSecuredLogin the new checks if is secured login
   */
  public void setIsSecuredLogin(Boolean isSecuredLogin) {
    this.isSecuredLogin = isSecuredLogin;
  }

  /**
   * Gets the username.
   *
   * @return the username
   */
  public String getUsername() {
    return this.username;
  }

  /**
   * Sets the username.
   *
   * @param username the new username
   */
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   * Gets the ip.
   *
   * @return the ip
   */
  public String getIp() {
    return this.ip;
  }

  /**
   * Sets the ip.
   *
   * @param ip the new ip
   */
  public void setIp(String ip) {
    this.ip = ip;
  }

  /**
   * Gets the reason.
   *
   * @return the reason
   */
  public String getReason() {
    return this.reason;
  }

  /**
   * Sets the reason.
   *
   * @param reason the new reason
   */
  public void setReason(String reason) {
    this.reason = reason;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return this.createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  public String getChannel() {
    return channel;
  }

  public void setChannel(String channel) {
    this.channel = channel;
  }
}
