package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** The Class Author. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PlayerPreference {

  private String defaultWinningsAccount;

  public String getDefaultWinningsAccount() {
    return defaultWinningsAccount;
  }

  public void setDefaultWinningsAccount(String defaultWinningsAccount) {
    this.defaultWinningsAccount = defaultWinningsAccount;
  }
}
