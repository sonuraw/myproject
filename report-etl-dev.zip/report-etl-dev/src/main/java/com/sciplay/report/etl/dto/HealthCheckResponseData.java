package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public final class HealthCheckResponseData {

  private final HealthCheckResponseAttributes mysql;

  private final HealthCheckResponseAttributes activeMq;

  private final HealthCheckResponseAttributes etlServiceErrorLogHealth;

  private final HealthCheckResponseAttributes eventDispatcherMissingStoreHealth;

  private final HealthCheckResponseAttributes jmsTopicIndexHealth;

  public HealthCheckResponseData(
      HealthCheckResponseAttributes mysql,
      HealthCheckResponseAttributes activeMq,
      HealthCheckResponseAttributes etlServiceErrorLogHealth,
      HealthCheckResponseAttributes eventDispatcherMissingStoreHealth,
      HealthCheckResponseAttributes jmsTopicIndexHealth) {
    this.mysql = mysql;
    this.activeMq = activeMq;
    this.etlServiceErrorLogHealth = etlServiceErrorLogHealth;
    this.eventDispatcherMissingStoreHealth = eventDispatcherMissingStoreHealth;
    this.jmsTopicIndexHealth = jmsTopicIndexHealth;
  }

  @JsonProperty
  public HealthCheckResponseAttributes getMysql() {
    return mysql;
  }

  public HealthCheckResponseAttributes getActiveMq() {
    return activeMq;
  }

  public HealthCheckResponseAttributes getEtlServiceErrorLogHealth() {
    return etlServiceErrorLogHealth;
  }

  public HealthCheckResponseAttributes getEventDispatcherMissingStoreHealth() {
    return eventDispatcherMissingStoreHealth;
  }

  public HealthCheckResponseAttributes getJmsTopicIndexHealth() {
    return jmsTopicIndexHealth;
  }
}
