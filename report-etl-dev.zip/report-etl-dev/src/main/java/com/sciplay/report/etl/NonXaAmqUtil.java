package com.sciplay.report.etl;

import com.sciplay.report.etl.consumer.DurableSubscriberCheck;
import com.sciplay.report.etl.consumer.NonXaMessageListener;
import io.dropwizard.lifecycle.Managed;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.jms.Connection;
import javax.jms.InvalidClientIDException;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.Topic;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.RedeliveryPolicy;
import org.apache.activemq.command.ActiveMQQueue;
import org.apache.activemq.command.ActiveMQTopic;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NonXaAmqUtil implements Managed {

  private static final Logger LOG = LoggerFactory.getLogger(NonXaAmqUtil.class);

  private static NonXaAmqUtil instance = new NonXaAmqUtil();

  private static ActiveMQConnectionFactory connectionFactory;
  private static String brokerUrl =
      ReportEtlContext.getInstance().getReportEtlServiceConfig().getAMQFailoverUrl();
  private static String threadId = UUID.randomUUID().toString();

  private DurableSubscriberCheck durableSubscriberCheck = new DurableSubscriberCheck();

  public static NonXaAmqUtil getInstance() {
    return instance;
  }

  private static Topic getTopic(String topicName) {
    ActiveMQTopic topic = new ActiveMQTopic();
    topic.setPhysicalName(topicName);
    return topic;
  }

  private static ActiveMQQueue getQueue(String qName) {
    ActiveMQQueue topic = new ActiveMQQueue();
    topic.setPhysicalName(
        qName
            + "?consumer.prefetchSize="
            + ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getMqconsumer()
                .get(ReportEtlConsts.PREFETCH_LIMIT)
                .toString());
    return topic;
  }

  @Override
  public void start() throws Exception {
    /*

     have 50 messages in queue , process in debug, stop for 15th message in onMessage and start
     and see the count and data ,

     select the rollback kind of messages and see the redeliveries in jmsMessageDetails
     and error log saving in error-log tables
    */

    Boolean isMysqlConnSuccess = startMySqlConnection();
    try {
      if (isMysqlConnSuccess) {
        setAmqConnectionFactory();
        startActiveMqConnection();
      } else {
        LOG.error("CRITICAL Error: mysqlConnection not get succeeded, returned false");
      }
    } catch (Exception e) {
      LOG.error("NonXaAmqUtil Start Error :" + e.getMessage());
      throw e;
    }
  }

  @Override
  public void stop() throws Exception {
    // TODO stop the consumers and connection on shutting down
    /*if (containers.size() > 0) {
        for (MessageDrivenContainer temp : containers) {
            if (temp != null && temp.getDestinationName() != null) {
                LOG.info(temp.getDestinationName() + "getting stopped");
                temp.stop();
            } else {
                LOG.error(temp.toString() + " having null , so not stopped");
            }
        }
    }*/
    try {
      if (durableSubscriberCheck != null) {
        durableSubscriberCheck.closeConnection();
      }
    } catch (JMSException e) {
      LOG.error("NonXaAmqUtil Stop JmsException : " + e.getMessage());
    }

    LOG.info("ActiveMq Stopped");
    LOG.info("stopped Hibernate..!!");
  }

  private Boolean startMySqlConnection() {

    // Retry, if we have encountered exception in the initialize based on
    // the boolean flag variables.
    int hibernateTryCount = 0;
    while (true) {
      try {
        Thread.sleep(5000);
        if (!ReportEtlContext.isHibernateInitialized()) {
          try {
            LOG.info("Hibernate Retry Number :" + hibernateTryCount);
            ReportEtlManaged.getInstance().startHibernate();
          } catch (Exception e) {
            hibernateTryCount++;
            LOG.error("startMySqlConnection Error :" + e.getMessage(), e);
          }
        }
        if (ReportEtlContext.isHibernateInitialized()) {
          return true;
        }
      } catch (InterruptedException e) {
        LOG.error("startMySqlConnection InterruptedException Error :" + e.getMessage());
      }
    }
  }

  private void consumeEachTopic(List<String> topics) {
    for (String topic : topics) {
      if (!topic.equalsIgnoreCase("empty")) {
        try {
          listenQueueBasedOnJDBC(topic, 1, false);
          LOG.info("Subscribed " + topic);
        } catch (Exception e) {
          LOG.error("Topic subscribing not happened for :" + topic);
          LOG.error(
              "ExecutionException in consumeEachTopic Error "
                  + e.getMessage()
                  + "Stack Trace: "
                  + Arrays.toString(e.getStackTrace()));
        }
      } else {
        LOG.warn("Topic ignored : " + topic);
      }
    }
    LOG.info("Started Topics listening ActiveMq ..!!");
  }

  private void startActiveMqConnection() throws Exception {
    if (ReportEtlContext.isActiveMQInitialized() && ReportEtlContext.isHibernateInitialized()) {

      List<String> topics =
          ReportEtlContext.getInstance().getReportEtlServiceConfig().getMqconsumerTopics();

      if (topics != null && topics.size() > 0) {
        new Thread(
                new Runnable() {
                  private Boolean toContinue = false;
                  private String hearBeatTopicName =
                      (String)
                          ReportEtlContext.getInstance()
                              .getReportEtlServiceConfig()
                              .getMqconsumer()
                              .get(ReportEtlConsts.HEART_BEAT_TOPIC);

                  public void run() {
                    do {
                      try {
                        ReportEtlContext.setIsMaster(toContinue);
                        durableSubscriberCheck.createConnection(
                            (String)
                                ReportEtlContext.getInstance()
                                    .getReportEtlServiceConfig()
                                    .getMqconsumer()
                                    .get(ReportEtlConsts.ACTIVE_MQ_CLIENT_ID),
                            hearBeatTopicName,
                            hearBeatTopicName,
                            brokerUrl);
                        toContinue = true;
                        ReportEtlContext.setIsMaster(toContinue);
                      } catch (InvalidClientIDException ex) {
                        LOG.error(ex.toString());
                        try {
                          durableSubscriberCheck.closeConnection();
                        } catch (JMSException e) {
                          LOG.error(ex.toString());
                        }
                      } catch (Exception ex) {
                        LOG.error(ex.toString());
                      }
                      if (toContinue) {
                        LOG.info(threadId + " got acquisition to consume topics");
                        consumeEachTopic(topics);
                        LOG.info("Listening ActiveMq Topics Started");
                        break;
                      } else {
                        LOG.info(threadId + " didn't got acquisition to consume topics");
                      }
                      try {
                        Thread.sleep(
                            Long.valueOf(
                                (String)
                                    ReportEtlContext.getInstance()
                                        .getReportEtlServiceConfig()
                                        .getMqconsumer()
                                        .get(ReportEtlConsts.SUBSCRIBER_RETRY_INTERVAL_MS)));
                      } catch (InterruptedException e) {
                        LOG.error(e.getMessage());
                      }
                    } while (true);
                  }
                })
            .start();
      } else {
        LOG.warn("No Topics listed to subscribe in ActiveMq");
      }

      HashMap<String, String> queues =
          ReportEtlContext.getInstance().getReportEtlServiceConfig().getMqConsumerQueues();

      HashMap<String, Integer> queuesCount =
          ReportEtlContext.getInstance().getReportEtlServiceConfig().getMqConsumerQueueCount();
      if (queues != null && queues.size() > 0) {
        for (Map.Entry<String, String> temp : queues.entrySet()) {
          try {
            if (queuesCount != null
                && queuesCount.size() > 0
                && queuesCount.get(temp.getKey()) != null
                && queuesCount.get(temp.getKey()) > 0) {
              listenQueueBasedOnJDBC(temp.getValue(), queuesCount.get(temp.getKey()), true);
            } else {
              listenQueueBasedOnJDBC(temp.getValue(), 1, true);
            }
            LOG.info("Queue Subscribed : " + temp.getValue());
          } catch (Exception e) {
            LOG.error("startHibernateConnection Error :" + e.getMessage());
          }
        }
        LOG.info("Started queues listening ActiveMq ..!!");
      } else {
        LOG.info("No queues listed to subscribe in ActiveMq");
      }
    }
  }

  private void setAmqConnectionFactory() {
    try {
      if (connectionFactory == null) {
        connectionFactory = new ActiveMQConnectionFactory(brokerUrl);
        RedeliveryPolicy policy = new RedeliveryPolicy();
        policy.setInitialRedeliveryDelay(0);
        policy.setRedeliveryDelay(0); // TODO from config
        policy.setUseExponentialBackOff(false);
        policy.setMaximumRedeliveries(
            ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getAllowedJMXDeliveryCount()); // TODO from config
        connectionFactory.setRedeliveryPolicy(policy);
        ReportEtlContext.setIsActiveMQInitialized(true);
      }
      // TODO retry the connection on error
    } catch (Exception ex) {
      LOG.error(
          "setAmqConnectionFactory error: "
              + ex.getMessage()
              + " Stack: "
              + Arrays.toString(ex.getStackTrace()));
      throw ex;
    }
  }

  private void listenQueueBasedOnJDBC(String destName, Integer groupCount, Boolean isQueue)
      throws JMSException {
    Connection connection =
        connectionFactory.createConnection(
            ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getMqconsumer()
                .get(ReportEtlConsts.ACTIVE_MQ_USERNAME)
                .toString(),
            ReportEtlContext.getInstance()
                .getReportEtlServiceConfig()
                .getMqconsumer()
                .get(ReportEtlConsts.ACTIVE_MQ_PASSWORD)
                .toString());

    if (!isQueue) {
      connection.setClientID(
          ReportEtlContext.getInstance()
                  .getReportEtlServiceConfig()
                  .getMqconsumer()
                  .get(ReportEtlConsts.ACTIVE_MQ_CLIENT_ID)
              + ":"
              + destName);
    }

    Session session = connection.createSession(false, Session.CLIENT_ACKNOWLEDGE);
    // transacted session will allow redelivery multiple sessions

    for (int playerId = 1; playerId <= groupCount; playerId++) {
      MessageConsumer consumer;
      if (isQueue) {
        ActiveMQQueue queue = getQueue(destName);
        consumer = session.createConsumer(queue);
      } else {
        Topic topic = getTopic(destName);
        consumer = session.createDurableSubscriber(topic, destName + "-0");
        // zero is added to retain both the XA And NonXA ids
      }
      consumer.setMessageListener(new NonXaMessageListener(destName, session));
      connection.start(); // TODO single connection ?? why multiple ??
      LOG.info("New Queue/Topic container added : " + destName + " -- " + playerId);
    }
  }
}
