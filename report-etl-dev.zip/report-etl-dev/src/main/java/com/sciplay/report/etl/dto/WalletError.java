package com.sciplay.report.etl.dto;

import java.util.List;

public class WalletError {

  private Meta meta;
  private List<ErrorDetail> errors;

  public WalletError() {}

  public Meta getMeta() {
    return meta;
  }

  public void setMeta(Meta meta) {
    this.meta = meta;
  }

  public List<ErrorDetail> getErrors() {
    return errors;
  }

  public void setErrors(List<ErrorDetail> errors) {
    this.errors = errors;
  }
}
