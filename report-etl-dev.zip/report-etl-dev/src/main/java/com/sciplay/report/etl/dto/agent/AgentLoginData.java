package com.sciplay.report.etl.dto.agent;

/** @author salman */
public class AgentLoginData {

  private String type;

  private String id;

  private AgentAttributes attributes;

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public AgentAttributes getAttributes() {
    return attributes;
  }

  public void setAttributes(AgentAttributes attributes) {
    this.attributes = attributes;
  }
}
