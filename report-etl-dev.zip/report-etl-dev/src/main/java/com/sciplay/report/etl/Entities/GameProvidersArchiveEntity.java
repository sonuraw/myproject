package com.sciplay.report.etl.Entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** Entity class for GameProvidersArchive. */
@Entity
@Table(name = "GameProvidersArchive")
public class GameProvidersArchiveEntity {

  /** The revision number. */
  @Id
  @Column(name = "RevisionNumber")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long revisionNumber;

  /** The revision date. */
  private Date revisionDate;

  /** The revision state. */
  private String revisionState;

  /** The id. */
  private String id;

  /** The operator id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The name. */
  private String name;

  /** The author id. */
  private Integer authorId;

  /** The author ip. */
  private String authorIp;

  /** The author session id. */
  private String authorSessionId;

  /** The created at. */
  private Date createdAt;

  /** The Domain. */
  private String domain;

  /** The backoffice url template. */
  private String backofficeUrlTemplate;

  /** Instantiates a new game providers archive entity. */
  public GameProvidersArchiveEntity() {}

  /**
   * Instantiates a new game providers archive entity.
   *
   * @param revisionDate the revision date
   * @param revisionState the revision state
   * @param id the id
   * @param operatorId the operator id
   * @param name the name
   * @param createdAt the created at
   */
  public GameProvidersArchiveEntity(
      Date revisionDate,
      String revisionState,
      String id,
      String operatorId,
      String name,
      Date createdAt) {
    this.revisionDate = revisionDate;
    this.revisionState = revisionState;
    this.id = id;
    this.operatorId = operatorId;
    this.name = name;
    this.createdAt = createdAt;
  }

  /**
   * Instantiates a new game providers archive entity.
   *
   * @param revisionState the revision state
   * @param id the id
   * @param operatorId the operator id
   * @param name the name
   * @param authorId the author id
   * @param authorIp the author ip
   * @param authorSessionId the author session id
   * @param createdAt the created at
   * @param domain the domain
   */
  public GameProvidersArchiveEntity(
      String revisionState,
      String id,
      String operatorId,
      String name,
      Integer authorId,
      String authorIp,
      String authorSessionId,
      Date createdAt,
      String domain,
      String backofficeUrlTemplate,
      Date revisionDate) {
    this.revisionState = revisionState;
    this.id = id;
    this.operatorId = operatorId;
    this.name = name;
    this.authorId = authorId;
    this.authorIp = authorIp;
    this.authorSessionId = authorSessionId;
    this.createdAt = createdAt;
    this.domain = domain;
    this.backofficeUrlTemplate = backofficeUrlTemplate;
    this.revisionDate = revisionDate;
  }

  /**
   * Gets the backoffice url template.
   *
   * @return the backoffice url template
   */
  public String getBackofficeUrlTemplate() {
    return backofficeUrlTemplate;
  }

  /**
   * Sets the backoffice url template.
   *
   * @param backofficeUrlTemplate the new backoffice url template
   */
  public void setBackofficeUrlTemplate(String backofficeUrlTemplate) {
    this.backofficeUrlTemplate = backofficeUrlTemplate;
  }

  /**
   * Gets the domain.
   *
   * @return the domain
   */
  public String getDomain() {
    return domain;
  }

  /**
   * Sets the domain.
   *
   * @param domain the new domain
   */
  public void setDomain(String domain) {
    this.domain = domain;
  }

  /**
   * Gets the revision number.
   *
   * @return the revision number
   */
  public long getRevisionNumber() {
    return this.revisionNumber;
  }

  /**
   * Sets the revision number.
   *
   * @param revisionNumber the new revision number
   */
  public void setRevisionNumber(long revisionNumber) {
    this.revisionNumber = revisionNumber;
  }

  /**
   * Gets the revision date.
   *
   * @return the revision date
   */
  public Date getRevisionDate() {
    return this.revisionDate;
  }

  /**
   * Sets the revision date.
   *
   * @param revisionDate the new revision date
   */
  public void setRevisionDate(Date revisionDate) {
    this.revisionDate = revisionDate;
  }

  /**
   * Gets the revision state.
   *
   * @return the revision state
   */
  public String getRevisionState() {
    return this.revisionState;
  }

  /**
   * Sets the revision state.
   *
   * @param revisionState the new revision state
   */
  public void setRevisionState(String revisionState) {
    this.revisionState = revisionState;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public String getId() {
    return this.id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return this.operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the name.
   *
   * @return the name
   */
  public String getName() {
    return this.name;
  }

  /**
   * Sets the name.
   *
   * @param name the new name
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Gets the author id.
   *
   * @return the author id
   */
  public Integer getAuthorId() {
    return this.authorId;
  }

  /**
   * Sets the author id.
   *
   * @param authorId the new author id
   */
  public void setAuthorId(Integer authorId) {
    this.authorId = authorId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return this.authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return this.authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return this.createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }
}
