package com.sciplay.report.etl.Entities;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "ThirdPartyError")
public class ThirdPartyErrorsEntity {

  /** The Id. */
  @Id private String id;
  /** The Type. */
  private String type;
  /** The CreatedDate. */
  private Date createdDate;
  /** The PartnerId. */
  private String partnerId;
  /** The Error. */
  @Type(type = "text")
  private String error;

  public ThirdPartyErrorsEntity() {}

  /** @return the id */
  public String getId() {
    return id;
  }

  /** @param id the id to set */
  public void setId(String id) {
    this.id = id;
  }

  /** @return the type */
  public String getType() {
    return type;
  }

  /** @param type the type to set */
  public void setType(String type) {
    this.type = type;
  }

  /** @return the createdDate */
  public Date getCreatedDate() {
    return createdDate;
  }

  /** @param createdDate the createdDate to set */
  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  /** @return the partnerId */
  public String getPartnerId() {
    return partnerId;
  }

  /** @param partnerId the partnerId to set */
  public void setPartnerId(String partnerId) {
    this.partnerId = partnerId;
  }

  /** @return the error */
  public String getError() {
    return error;
  }

  /** @param error the error to set */
  public void setError(String error) {
    this.error = error;
  }
}
