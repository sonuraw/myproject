package com.sciplay.report.etl.Entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Type;

/**
 * The Class ErrorsLogEntity.
 *
 * @author salman
 */
@Entity
@Table(name = "WinningError")
@DynamicUpdate
public class WinningErrorEntity {

  /** The id. */
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "Id")
  private Integer id;

  private long winningId;
  private String state;
  private String prevState;

  @Column(name = "operatorId", columnDefinition = "char(3)")
  private String operatorId;

  private Date createdDateTime;

  private String processedStatus;

  @Column(name = "json")
  @Type(type = "text")
  private String json;

  private int retryCount;
  private String correlationId;

  public WinningErrorEntity() {}

  public WinningErrorEntity(
      long winningId,
      String state,
      String prevState,
      String operatorId,
      Date createdDateTime,
      String processedStatus,
      String json,
      String correlationId) {
    this.retryCount = 0;
    this.winningId = winningId;
    this.state = state;
    this.prevState = prevState;
    this.operatorId = operatorId;
    this.createdDateTime = createdDateTime;
    this.processedStatus = processedStatus;
    this.json = json;
    this.correlationId = correlationId;
  }

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public String getPrevState() {
    return prevState;
  }

  public void setPrevState(String prevState) {
    this.prevState = prevState;
  }

  public String getOperatorId() {
    return operatorId;
  }

  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  public Date getCreatedDateTime() {
    return createdDateTime;
  }

  public void setCreatedDateTime(Date createdDateTime) {
    this.createdDateTime = createdDateTime;
  }

  public String getProcessedStatus() {
    return processedStatus;
  }

  public void setProcessedStatus(String processedStatus) {
    this.processedStatus = processedStatus;
  }

  public String getJson() {
    return json;
  }

  public void setJson(String json) {
    this.json = json;
  }

  public int getRetryCount() {
    return retryCount;
  }

  public void setRetryCount(int retryCount) {
    this.retryCount = retryCount;
  }

  public String getCorrelationId() {
    return correlationId;
  }

  public void setCorrelationId(String correlationId) {
    this.correlationId = correlationId;
  }

  public long getWinningId() {
    return winningId;
  }

  public void setWinningId(long winningId) {
    this.winningId = winningId;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }
}
