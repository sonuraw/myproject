package com.sciplay.report.etl.Entities;

import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.DynamicUpdate;

/**
 * The Class JmsMessageDetailsEntity.
 *
 * @author Ananth
 */
@Entity
@Table(name = "JmsMessageDetails")
@DynamicUpdate
public class JmsMessageDetailsEntity {

  /** The id. */
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "Id")
  private Long id;

  /** The agent Jms Message Id. */
  @Column(name = "JmsMessageId")
  private String jmsMessageId;

  /** The Topic. */
  @Column(name = "Topic")
  private String topic;

  /** The Type. */
  @Column(name = "Type")
  private String type;

  /** The RetryCount. */
  @Column(name = "RetryCount")
  private Integer retryCount;

  /** The Creation Date. */
  @Column(name = "CreationDate")
  private Date creationDate;

  /** The Updated Date. */
  @Column(name = "UpdatedDate")
  private Date updatedDate;

  @Column(name = "GapTime")
  private long gapTime;

  @Column(name = "ProcessTime")
  private long processTime;

  @Column(name = "DelayTime")
  private long delayTime;

  @Column(name = "ThreadId")
  private String threadId;

  @Column(name = "xaTranId")
  private String xaTranId;

  @Column(name = "eventId")
  private long eventId;

  /**
   * @param jmsMessageId
   * @param topic
   * @param type
   * @param retryCount
   * @param creationDate
   * @param updatedDate - for storage issue, updated Date value will be null only , since it is only
   *     insert-table
   * @param gapTime
   */
  public JmsMessageDetailsEntity(
      String jmsMessageId,
      String topic,
      String type,
      Integer retryCount,
      Date creationDate,
      Date updatedDate,
      Long gapTime,
      Long processTime,
      Long delayTime,
      String threadId,
      String xaTranId,
      Long eventId) {
    this.jmsMessageId = jmsMessageId;
    this.topic = topic;
    this.type = type;
    this.retryCount = Objects.isNull(retryCount) ? 0 : retryCount;
    this.creationDate = creationDate;
    this.updatedDate = updatedDate;
    this.gapTime = Objects.isNull(gapTime) ? 0L : gapTime;
    this.processTime = Objects.isNull(processTime) ? 0L : processTime;
    this.delayTime = Objects.isNull(delayTime) ? 0L : delayTime;
    this.threadId = threadId;
    this.xaTranId = xaTranId;
    this.eventId = Objects.isNull(eventId) ? 0L : eventId;
  }

  /** Instantiates a new agent country list entity. */
  public JmsMessageDetailsEntity() {}

  /** @return the id */
  public Long getId() {
    return id;
  }

  /** @param id the id to set */
  public void setId(Long id) {
    this.id = id;
  }

  /** @return the jmsMessageId */
  public String getJmsMessageId() {
    return jmsMessageId;
  }

  /** @param jmsMessageId the jmsMessageId to set */
  public void setJmsMessageId(String jmsMessageId) {
    this.jmsMessageId = jmsMessageId;
  }

  /** @return the topic */
  public String getTopic() {
    return topic;
  }

  /** @param topic the topic to set */
  public void setTopic(String topic) {
    this.topic = topic;
  }

  /** @return the type */
  public String getType() {
    return type;
  }

  /** @param type the type to set */
  public void setType(String type) {
    this.type = type;
  }

  /** @return the retryCount */
  public Integer getRetryCount() {
    return retryCount;
  }

  /** @param retryCount the retryCount to set */
  public void setRetryCount(Integer retryCount) {
    this.retryCount = Objects.isNull(retryCount) ? 0 : retryCount;
  }

  /** @return the creationDate */
  public Date getCreationDate() {
    return creationDate;
  }

  /** @param creationDate the creationDate to set */
  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  /** @return the updatedDate */
  public Date getUpdatedDate() {
    return updatedDate;
  }

  /** @param updatedDate the updatedDate to set */
  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  public long getGapTime() {
    return gapTime;
  }

  public void setGapTime(Long gapTime) {
    this.gapTime = Objects.isNull(gapTime) ? 0L : gapTime;
  }

  public long getProcessTime() {
    return processTime;
  }

  public void setProcessTime(Long processTime) {
    this.processTime = Objects.isNull(processTime) ? 0L : processTime;
  }

  public long getDelayTime() {
    return delayTime;
  }

  public void setDelayTime(Long delayTime) {
    this.delayTime = Objects.isNull(delayTime) ? 0L : delayTime;
  }

  public String getThreadId() {
    return threadId;
  }

  public void setThreadId(String threadId) {
    this.threadId = threadId;
  }

  public String getXATranId() {
    return xaTranId;
  }

  public void setXATranId(String xaTranId) {
    this.xaTranId = xaTranId;
  }

  public long getEventId() {
    return eventId;
  }

  public void setEventId(Long eventId) {
    this.eventId = Objects.isNull(eventId) ? 0L : eventId;
  }
}
