package com.sciplay.report.etl.consumer;

import com.codahale.metrics.health.HealthCheck;
import com.sciplay.report.etl.ReportEtlConsts;
import com.sciplay.report.etl.ReportEtlContext;
import javax.jms.DeliveryMode;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TemporaryQueue;
import javax.jms.TextMessage;
import org.apache.activemq.ActiveMQXAConnectionFactory;

public class ActiveMqHealthCheck extends HealthCheck {
  private ActiveMQXAConnectionFactory connectionFactory;
  private long millisecondsToWait;

  public ActiveMqHealthCheck() {
    this.connectionFactory =
        new ActiveMQXAConnectionFactory(
            ReportEtlContext.getInstance().getReportEtlServiceConfig().getAMQFailoverUrl()
                + "&"
                + ReportEtlContext.getInstance()
                    .getReportEtlServiceConfig()
                    .getMqconsumer()
                    .getProperty("healthCheckUriQueryParam"));
    this.connectionFactory.setUserName(
        ReportEtlContext.getInstance()
            .getReportEtlServiceConfig()
            .getMqconsumer()
            .get(ReportEtlConsts.ACTIVE_MQ_USERNAME)
            .toString());
    this.connectionFactory.setPassword(
        ReportEtlContext.getInstance()
            .getReportEtlServiceConfig()
            .getMqconsumer()
            .get(ReportEtlConsts.ACTIVE_MQ_PASSWORD)
            .toString());
    this.millisecondsToWait = 3000;
  }

  @Override
  protected Result check() throws Exception {
    javax.jms.Connection connection = connectionFactory.createConnection();
    connection.start();
    try {
      Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
      try {
        TemporaryQueue tempQueue = session.createTemporaryQueue();
        try {
          MessageProducer producer = session.createProducer(tempQueue);
          MessageConsumer consumer = session.createConsumer(tempQueue);
          try {
            producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
            final String messageText = "Test message-" + System.currentTimeMillis();
            producer.send(tempQueue, session.createTextMessage(messageText));
            TextMessage receivedMessage = (TextMessage) consumer.receive(millisecondsToWait);
            // Make sure we received the correct message
            if (receivedMessage != null && messageText.equals(receivedMessage.getText())) {
              return Result.healthy();
            } else {
              return Result.unhealthy(
                  "Did not receive testMessage via tempQueue in "
                      + millisecondsToWait
                      + " milliseconds");
            }
          } finally {
            swallowException(() -> consumer.close());
            swallowException(() -> producer.close());
          }
        } finally {
          swallowException(() -> tempQueue.delete());
        }
      } finally {
        swallowException(() -> session.close());
      }
    } finally {
      swallowException(() -> connection.close());
    }
  }

  public Result getCheck() throws Exception {
    return check();
  }

  protected void swallowException(DoCleanup doCleanup) throws Exception {
    try {
      doCleanup.doCleanup();
    } catch (Exception e) {
      throw e;
    }
  }

  protected interface DoCleanup {
    void doCleanup() throws Exception;
  }
}
