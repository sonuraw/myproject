package com.sciplay.report.etl.Entities;

import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/** Entity class for Games. */
@Entity
@Table(name = "Games")
public class GamesEntity {

  /** The id. */
  @Id
  @Column(name = "Id")
  private Integer id;

  /** The operator id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The external game id. */
  private String externalGameId;

  /** The game type id. */
  private Integer gameTypeId;

  /** The game provider id. */
  private String gameProviderId;

  /** The sub category id. */
  private Integer subCategoryId;

  /** The name. */
  private String name;

  /** The theoretical payout percentage. */
  private int theoreticalPayoutPercentage;

  /** The tax percentage. */
  private int taxPercentage;

  /** The channel. */
  private String channel;

  /** The payload. */
  private String payload;

  /** The comment. */
  private String comment;

  /** The notify. */
  @Column(nullable = false)
  private Boolean notify;

  /** The status. */
  @Column(nullable = false)
  private Boolean status;

  /** The author id. */
  private Integer authorId;

  /** The author ip. */
  private String authorIp;

  /** The author session id. */
  private String authorSessionId;

  /** The created at. */
  private Date createdAt;

  /** The payout. */
  private String payout;

  /** The subscriptionAvailable. */
  private Boolean subscriptionAvailable;

  /** true if deleted */
  private Boolean isDeleted = false;

  /** The Modified at. */
  private Date modifiedAt;

  /** The LastActivityDate at. */
  private Date lastActivityDate;

  /** Instantiates a new games entity. */
  public GamesEntity() {}

  /**
   * Instantiates a new games entity.
   *
   * @param id the id
   * @param operatorId the operator id
   * @param externalGameId the external game id
   * @param gameTypeId the game type id
   * @param gameProviderId the game provider id
   * @param subCategoryId the sub category id
   * @param name the name
   * @param theoreticalPayoutPercentage the theoretical payout percentage
   * @param taxPercentage the tax percentage
   * @param channel the channel
   * @param createdAt the created at
   */
  public GamesEntity(
      Integer id,
      String operatorId,
      String externalGameId,
      Integer gameTypeId,
      String gameProviderId,
      Integer subCategoryId,
      String name,
      int theoreticalPayoutPercentage,
      int taxPercentage,
      String channel,
      Date createdAt,
      Date modifiedAt,
      Date lastActivityDate) {
    this.id = id;
    this.operatorId = operatorId;
    this.externalGameId = externalGameId;
    this.gameTypeId = gameTypeId;
    this.gameProviderId = gameProviderId;
    this.subCategoryId = subCategoryId;
    this.name = name;
    this.theoreticalPayoutPercentage = theoreticalPayoutPercentage;
    this.taxPercentage = taxPercentage;
    this.channel = channel;
    this.createdAt = createdAt;
    this.modifiedAt = modifiedAt;
    this.lastActivityDate = lastActivityDate;
  }

  /**
   * Instantiates a new games entity.
   *
   * @param id the id
   * @param operatorId the operator id
   * @param externalGameId the external game id
   * @param gameTypeId the game type id
   * @param gameProviderId the game provider id
   * @param subCategoryId the sub category id
   * @param name the name
   * @param theoreticalPayoutPercentage the theoretical payout percentage
   * @param taxPercentage the tax percentage
   * @param channel the channel
   * @param payload the payload
   * @param comment the comment
   * @param notify the notify
   * @param status the status
   * @param authorId the author id
   * @param authorIp the author ip
   * @param authorSessionId the author session id
   * @param createdAt the created at
   * @param payout the payout
   * @param subscriptionAvailable the subscription available
   */
  public GamesEntity(
      Integer id,
      String operatorId,
      String externalGameId,
      Integer gameTypeId,
      String gameProviderId,
      Integer subCategoryId,
      String name,
      int theoreticalPayoutPercentage,
      int taxPercentage,
      String channel,
      String payload,
      String comment,
      Boolean notify,
      Boolean status,
      Integer authorId,
      String authorIp,
      String authorSessionId,
      Date createdAt,
      String payout,
      Boolean subscriptionAvailable,
      Date modifiedAt,
      Date lastActivityDate,
      Boolean isDeleted) {
    this.id = id;
    this.operatorId = operatorId;
    this.externalGameId = externalGameId;
    this.gameTypeId = gameTypeId;
    this.gameProviderId = gameProviderId;
    this.subCategoryId = subCategoryId;
    this.name = name;
    this.theoreticalPayoutPercentage = theoreticalPayoutPercentage;
    this.taxPercentage = taxPercentage;
    this.channel = channel;
    this.payload = payload;
    this.comment = comment;
    this.notify = notify;
    this.status = status;
    this.authorId = Objects.isNull(authorId) ? 0 : authorId;
    this.authorIp = authorIp;
    this.authorSessionId = authorSessionId;
    this.createdAt = createdAt;
    this.payout = payout;
    this.subscriptionAvailable =
        Objects.isNull(subscriptionAvailable) ? false : subscriptionAvailable;
    this.modifiedAt = modifiedAt;
    this.lastActivityDate = lastActivityDate;
    this.isDeleted = isDeleted;
  }

  /**
   * Gets the modified at.
   *
   * @return the modified at
   */
  public Date getModifiedAt() {
    return modifiedAt;
  }

  /**
   * Sets the modified at.
   *
   * @param modifiedAt the new modified at
   */
  public void setModifiedAt(Date modifiedAt) {
    this.modifiedAt = modifiedAt;
  }

  /**
   * Gets the payout.
   *
   * @return the payout
   */
  public String getPayout() {
    return payout;
  }

  /**
   * Sets the payout.
   *
   * @param payout the new payout
   */
  public void setPayout(String payout) {
    this.payout = payout;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public Integer getId() {
    return this.id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(Integer id) {
    this.id = id;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return this.operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the external game id.
   *
   * @return the external game id
   */
  public String getExternalGameId() {
    return this.externalGameId;
  }

  /**
   * Sets the external game id.
   *
   * @param externalGameId the new external game id
   */
  public void setExternalGameId(String externalGameId) {
    this.externalGameId = externalGameId;
  }

  /**
   * Gets the game type id.
   *
   * @return the game type id
   */
  public Integer getGameTypeId() {
    return this.gameTypeId;
  }

  /**
   * Sets the game type id.
   *
   * @param gameTypeId the new game type id
   */
  public void setGameTypeId(Integer gameTypeId) {
    this.gameTypeId = gameTypeId;
  }

  /**
   * Gets the game provider id.
   *
   * @return the game provider id
   */
  public String getGameProviderId() {
    return this.gameProviderId;
  }

  /**
   * Sets the game provider id.
   *
   * @param gameProviderId the new game provider id
   */
  public void setGameProviderId(String gameProviderId) {
    this.gameProviderId = gameProviderId;
  }

  /**
   * Gets the sub category id.
   *
   * @return the sub category id
   */
  public Integer getSubCategoryId() {
    return this.subCategoryId;
  }

  /**
   * Sets the sub category id.
   *
   * @param subCategoryId the new sub category id
   */
  public void setSubCategoryId(Integer subCategoryId) {
    this.subCategoryId = subCategoryId;
  }

  /**
   * Gets the name.
   *
   * @return the name
   */
  public String getName() {
    return this.name;
  }

  /**
   * Sets the name.
   *
   * @param name the new name
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Gets the theoretical payout percentage.
   *
   * @return the theoretical payout percentage
   */
  public int getTheoreticalPayoutPercentage() {
    return this.theoreticalPayoutPercentage;
  }

  /**
   * Sets the theoretical payout percentage.
   *
   * @param theoreticalPayoutPercentage the new theoretical payout percentage
   */
  public void setTheoreticalPayoutPercentage(int theoreticalPayoutPercentage) {
    this.theoreticalPayoutPercentage = theoreticalPayoutPercentage;
  }

  /**
   * Gets the tax percentage.
   *
   * @return the tax percentage
   */
  public int getTaxPercentage() {
    return this.taxPercentage;
  }

  /**
   * Sets the tax percentage.
   *
   * @param taxPercentage the new tax percentage
   */
  public void setTaxPercentage(int taxPercentage) {
    this.taxPercentage = taxPercentage;
  }

  /**
   * Gets the channel.
   *
   * @return the channel
   */
  public String getChannel() {
    return this.channel;
  }

  /**
   * Sets the channel.
   *
   * @param channel the new channel
   */
  public void setChannel(String channel) {
    this.channel = channel;
  }

  /**
   * Gets the payload.
   *
   * @return the payload
   */
  public String getPayload() {
    return this.payload;
  }

  /**
   * Sets the payload.
   *
   * @param payload the new payload
   */
  public void setPayload(String payload) {
    this.payload = payload;
  }

  /**
   * Gets the comment.
   *
   * @return the comment
   */
  public String getComment() {
    return this.comment;
  }

  /**
   * Sets the comment.
   *
   * @param comment the new comment
   */
  public void setComment(String comment) {
    this.comment = comment;
  }

  /**
   * Gets the notify.
   *
   * @return the notify
   */
  public Boolean getNotify() {
    return this.notify;
  }

  /**
   * Sets the notify.
   *
   * @param notify the new notify
   */
  public void setNotify(Boolean notify) {
    this.notify = notify;
  }

  /**
   * Gets the status.
   *
   * @return the status
   */
  public Boolean getStatus() {
    return this.status;
  }

  /**
   * Sets the status.
   *
   * @param status the new status
   */
  public void setStatus(Boolean status) {
    this.status = status;
  }

  /**
   * Gets the author id.
   *
   * @return the author id
   */
  public Integer getAuthorId() {
    return this.authorId;
  }

  /**
   * Sets the author id.
   *
   * @param authorId the new author id
   */
  public void setAuthorId(Integer authorId) {
    this.authorId = Objects.isNull(authorId) ? 0 : authorId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return this.authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return this.authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return this.createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  /**
   * Gets the subscriptionAvailable.
   *
   * @return the subscriptionAvailable
   */
  public Boolean getSubscriptionAvailable() {
    return subscriptionAvailable;
  }

  /**
   * Sets the subscriptionAvailable.
   *
   * @param subscriptionAvailable the new subscription available
   */
  public void setSubscriptionAvailable(Boolean subscriptionAvailable) {
    this.subscriptionAvailable =
        Objects.isNull(subscriptionAvailable) ? false : subscriptionAvailable;
  }

  public Boolean getDeleted() {
    return isDeleted;
  }

  public void setDeleted(Boolean deleted) {
    isDeleted = deleted;
  }

  /** @return the lastActivityDate */
  public Date getLastActivityDate() {
    return lastActivityDate;
  }

  /** @param lastActivityDate the lastActivityDate to set */
  public void setLastActivityDate(Date lastActivityDate) {
    this.lastActivityDate = lastActivityDate;
  }
}
