package com.sciplay.report.etl.Entities;

import java.util.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Entity
@Table(name = "PlayerAppliedLimit")
@JsonIgnoreProperties(ignoreUnknown = true)
public class PlayerAppliedLimitEntity {

  @Id
  @Column(name = "LimitId")
  private String limitId;

  private String limitType;
  private String scopeType;

  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  private Integer playerId;
  private String categoryId;
  private String extent;
  private long value;
  private Date creationDate;
  private Date appliedFrom;
  private Date appliedTill;
  private String eventType;
  private Date modifiedAt;
  private String categoryType;
  private Integer author;
  private String authorType;

  @Column(name = "LastDateExceeded")
  private Date lastDateExceeded;

  @Column(name = "NumberOfTimesExceeded")
  private Integer numberOfTimesExceeded;

  public PlayerAppliedLimitEntity() {}

  public PlayerAppliedLimitEntity(
      String limitId,
      String limitType,
      String scopeType,
      String operatorId,
      Integer playerId,
      String categoryId,
      String extent,
      long value,
      Date creationDate,
      Date appliedFrom,
      Date appliedTill,
      String eventType,
      Date modifiedAt,
      String categoryType) {
    this.limitId = limitId;
    this.limitType = limitType;
    this.scopeType = scopeType;
    this.operatorId = operatorId;
    this.playerId = Objects.isNull(playerId) ? 0 : playerId;
    this.categoryId = categoryId;
    this.extent = extent;
    this.value = Objects.isNull(value) ? 0L : value;
    this.creationDate = creationDate;
    this.appliedFrom = appliedFrom;
    this.appliedTill = appliedTill;
    this.eventType = eventType;
    this.modifiedAt = modifiedAt;
    this.categoryType = categoryType;
  }

  public Date getModifiedAt() {
    return modifiedAt;
  }

  public void setModifiedAt(Date modifiedAt) {
    this.modifiedAt = modifiedAt;
  }

  public String getLimitId() {
    return this.limitId;
  }

  public void setLimitId(String limitId) {
    this.limitId = limitId;
  }

  public String getLimitType() {
    return this.limitType;
  }

  public void setLimitType(String limitType) {
    this.limitType = limitType;
  }

  public String getScopeType() {
    return this.scopeType;
  }

  public void setScopeType(String scopeType) {
    this.scopeType = scopeType;
  }

  public String getOperatorId() {
    return this.operatorId;
  }

  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  public Integer getPlayerId() {
    return this.playerId;
  }

  public void setPlayerId(Integer playerId) {
    this.playerId = Objects.isNull(playerId) ? 0 : playerId;
  }

  public String getCategoryId() {
    return this.categoryId;
  }

  public void setCategoryId(String categoryId) {
    this.categoryId = categoryId;
  }

  public String getExtent() {
    return this.extent;
  }

  public void setExtent(String extent) {
    this.extent = extent;
  }

  public long getValue() {
    return this.value;
  }

  public void setValue(long value) {
    this.value = Objects.isNull(value) ? 0L : value;
  }

  public Date getCreationDate() {
    return this.creationDate;
  }

  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  public Date getAppliedFrom() {
    return this.appliedFrom;
  }

  public void setAppliedFrom(Date appliedFrom) {
    this.appliedFrom = appliedFrom;
  }

  public Date getAppliedTill() {
    return this.appliedTill;
  }

  public void setAppliedTill(Date appliedTill) {
    this.appliedTill = appliedTill;
  }

  public String getEventType() {
    return this.eventType;
  }

  public void setEventType(String eventType) {
    this.eventType = eventType;
  }

  public String getCategoryType() {
    return categoryType;
  }

  public void setCategoryType(String categoryType) {
    this.categoryType = categoryType;
  }

  /** @return the author */
  public Integer getAuthor() {
    return author;
  }

  /** @param author the author to set */
  public void setAuthor(Integer author) {
    this.author = Objects.isNull(author) ? 0 : author;
  }

  /** @return the authorType */
  public String getAuthorType() {
    return authorType;
  }

  /** @param authorType the authorType to set */
  public void setAuthorType(String authorType) {
    this.authorType = authorType;
  }

  public Date getLastDateExceeded() {
    return lastDateExceeded;
  }

  public void setLastDateExceeded(Date lastDateExceeded) {
    this.lastDateExceeded = lastDateExceeded;
  }

  public Integer getNumberOfTimesExceeded() {
    return numberOfTimesExceeded;
  }

  public void setNumberOfTimesExceeded(Integer numberOfTimesExceeded) {
    this.numberOfTimesExceeded = numberOfTimesExceeded;
  }
}
