package com.sciplay.report.etl.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** The Class PlayerAffiliate. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PlayerAffiliate {

  /** The player id. */
  private Integer playerId;

  /** The payload. */
  private String payload;

  /** The partner. */
  private String partner;

  /** The campaign. */
  private String campaign;

  /** The description. */
  private String description;

  /**
   * Gets the description.
   *
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Sets the description.
   *
   * @param description the new description
   */
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the partner.
   *
   * @return the partner
   */
  public String getPartner() {
    return partner;
  }

  /**
   * Sets the partner.
   *
   * @param partner the new partner
   */
  public void setPartner(String partner) {
    this.partner = partner;
  }

  /**
   * Gets the campaign.
   *
   * @return the campaign
   */
  public String getCampaign() {
    return campaign;
  }

  /**
   * Sets the campaign.
   *
   * @param campaign the new campaign
   */
  public void setCampaign(String campaign) {
    this.campaign = campaign;
  }

  /**
   * Gets the payload.
   *
   * @return the payload
   */
  public String getPayload() {
    return payload;
  }

  /**
   * Sets the payload.
   *
   * @param payload the new payload
   */
  public void setPayload(String payload) {
    this.payload = payload;
  }
}
