package com.sciplay.report.etl.config;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.dropwizard.Configuration;
import io.federecio.dropwizard.swagger.SwaggerBundleConfiguration;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * The Class ApplicationConfiguration.
 *
 * @author salman
 */
public class ApplicationConfiguration extends Configuration {

  /** The swagger bundle configuration. */
  @JsonProperty("swagger")
  private SwaggerBundleConfiguration swaggerBundleConfiguration;

  /** The mqconsumer. */
  private Properties mqconsumer = new Properties();
  /** The hibernate config path. */
  @NotEmpty private String hibernateConfigPath;
  /** The service id. */
  private String serviceId;

  private String hostname;

  /** The date format ISO. */
  private String dateFormatISO;
  /** The date format. */
  private String dateFormat;

  private Boolean reportEtlJobsHealthMonitoring;

  private List<String> concurrenceCronTopics;

  private Boolean isAmqXAConnectionMode;

  /** The subscription service games url. */
  private String subscriptionServiceGamesUrl;

  /** The subscription service game schedule url. */
  private String subscriptionServiceGameScheduleUrl;

  /** The game manager Destination. */
  private List<String> gameManagerDestination;
  /** The exclusion Destination. */
  private List<String> exclusionDestination;
  /** The limit Destination. */
  private List<String> limitDestination;
  /** The agent Destination. */
  private List<String> agentDestination;
  /** The player Destination. */
  private List<String> playerDestination;
  /** The session Destination. */
  private List<String> sessionDestination;
  /** The team Destination. */
  private List<String> teamDestination;
  /** The league Destination. */
  private List<String> leagueDestination;
  /** The expected spending Destination. */
  private List<String> expectedSpendingDestination;
  /** The access log Destination. */
  private List<String> accessLogDestination;
  /** The player card Destination. */
  private List<String> playerCardDestination;
  /** The Third Party Errors Destination. */
  private List<String> thirdPartyErrorsDestination;
  /** The iHub alert Destination. */
  private List<String> ihubAlertsDestination;
  /** The Dynamic Ledger Creation Destination. */
  private List<String> ledgerDestination;

  private List<String> gviDestination;

  private String deleteProfileTopics;

  /** The ledger topics. */
  private List<String> walletTransactionDestination;
  /** The gvi topics. */
  private List<String> gviStatusUpdateTypes;
  /** The new subscription created topic. */
  private List<String> subscriptionDestination;

  private List<String> notificationBrokerErrorDestination;
  /** The purchase send topic. */
  private List<String> subsPurchaseDestination;

  /** The mqconsumer topics. */
  private List<String> mqconsumerTopics;

  /** The mq consumer queues. */
  private HashMap<String, String> mqConsumerQueues;

  private HashMap<String, Integer> mqConsumerQueueCount;

  /** The gvi wager from wager set. */
  private String gviWagerFromWagerSet;

  /** The system agent id. */
  private Integer systemAgentId;

  /** The upam gvi wager create. */
  private String gviWagerCreateType;

  /** The upam gvi wager set create. */
  private String gviWagerSetCreateType;

  private String timeZone;

  private HashMap<String, List<String>> eventDispatcherTopics;

  private List<String> batchLogDestination;

  /** The Available Data Sync Endpoint. */
  private HashMap<String, String> eventDispatcherEndPoints;

  /** The reprocess Batch Size. */
  private Integer dataReconcileBatchSize;

  /** The Max EventId Time Interval. */
  private Integer maxEventIdTimeInterval;

  private Boolean missingEventsToBeProcessedByService;

  private Integer errorProcessingBatchLimit;

  private Integer errorProcessingBatchPauseSecs;
  /** The hibernate config. */
  private HibernateConfig hibernateConfig;
  private FlywayConfiguration flyway;
  /** The subscriptions game schedule deleted. */
  private String jwtToken;
  /** The allowed JMX delivery count. */
  private Integer allowedJMXDeliveryCount;
  private Integer maxRetryCount;
  private Integer maxRetryCountForConcurrence;
  private Integer maxWaitTimeForConcurrence;
  private Integer allowedErrorCount;
  /** Instantiates a new application configuration. */
  public ApplicationConfiguration() {}

  /**
   * Gets the subscription api topic.
   *
   * @return the subscription api topic
   */
  public List<String> getSubscriptionDestination() {
    return subscriptionDestination;
  }

  /**
   * Sets the subscription api topic.
   *
   * @param subscriptionDestination the new subscription api topic
   */
  public void setSubscriptionDestination(List<String> subscriptionDestination) {
    this.subscriptionDestination = subscriptionDestination;
  }

  /**
   * Gets the upam gvi wager create.
   *
   * @return the upam gvi wager create
   */
  public String getGviWagerCreateType() {
    return gviWagerCreateType;
  }

  /**
   * Sets the upam gvi wager create.
   *
   * @param gviWagerCreateType the new upam gvi wager create
   */
  public void setGviWagerCreateType(String gviWagerCreateType) {
    this.gviWagerCreateType = gviWagerCreateType;
  }

  /**
   * Gets the upam gvi wager set create.
   *
   * @return the upam gvi wager set create
   */
  public String getGviWagerSetCreateType() {
    return gviWagerSetCreateType;
  }

  /**
   * Sets the upam gvi wager set create.
   *
   * @param gviWagerSetCreateType the new upam gvi wager set create
   */
  public void setGviWagerSetCreateType(String gviWagerSetCreateType) {
    this.gviWagerSetCreateType = gviWagerSetCreateType;
  }

  /**
   * Gets the purchase send topic.
   *
   * @return the purchase send topic
   */
  public List<String> getSubsPurchaseDestination() {
    return subsPurchaseDestination;
  }

  /**
   * Sets the purchase send topic.
   *
   * @param subsPurchaseDestination the new purchase send topic
   */
  public void setSubsPurchaseDestination(List<String> subsPurchaseDestination) {
    this.subsPurchaseDestination = subsPurchaseDestination;
  }

  /**
   * Gets the hibernate config path.
   *
   * @return the hibernate config path
   */
  public String getHibernateConfigPath() {
    return hibernateConfigPath;
  }

  /**
   * Sets the hibernate config path.
   *
   * @param hibernateConfigPath the new hibernate config path
   */
  public void setHibernateConfigPath(String hibernateConfigPath) {
    this.hibernateConfigPath = hibernateConfigPath;
  }

  /**
   * Gets the service id.
   *
   * @return the service id
   */
  public String getServiceId() {
    return serviceId;
  }

  /**
   * Sets the service id.
   *
   * @param serviceId the new service id
   */
  public void setServiceId(String serviceId) {
    this.serviceId = serviceId;
  }

  /**
   * Gets the date format ISO.
   *
   * @return the date format ISO
   */
  public String getDateFormatISO() {
    return dateFormatISO;
  }

  /**
   * Sets the date format ISO.
   *
   * @param dateFormatISO the new date format ISO
   */
  public void setDateFormatISO(String dateFormatISO) {
    this.dateFormatISO = dateFormatISO;
  }

  /**
   * Gets the date format.
   *
   * @return the date format
   */
  public String getDateFormat() {
    return dateFormat;
  }

  /**
   * Sets the date format.
   *
   * @param dateFormat the new date format
   */
  public void setDateFormat(String dateFormat) {
    this.dateFormat = dateFormat;
  }

  /**
   * Gets the ledger topics.
   *
   * @return the ledger topics
   */
  public List<String> getWalletTransactionDestination() {
    return walletTransactionDestination;
  }

  /**
   * Sets the ledger topics.
   *
   * @param walletTransactionDestination the new ledger topics
   */
  public void setWalletTransactionDestination(List<String> walletTransactionDestination) {
    this.walletTransactionDestination = walletTransactionDestination;
  }

  /**
   * Gets the gvi topics.
   *
   * @return the gviStatusUpdateTypes
   */
  public List<String> getGviStatusUpdateTypes() {
    return gviStatusUpdateTypes;
  }

  /**
   * Sets the gvi topics.
   *
   * @param gviStatusUpdateTypes the gviStatusUpdateTypes to set
   */
  public void setGviStatusUpdateTypes(List<String> gviStatusUpdateTypes) {
    this.gviStatusUpdateTypes = gviStatusUpdateTypes;
  }

  /**
   * Gets the mqconsumer.
   *
   * @return the mqconsumer
   */
  public Properties getMqconsumer() {
    return mqconsumer;
  }

  /**
   * Sets the mqconsumer.
   *
   * @param mqconsumer the new mqconsumer
   */
  public void setMqconsumer(Properties mqconsumer) {
    this.mqconsumer = mqconsumer;
  }

  /**
   * Gets the jwt token.
   *
   * @return the authToken
   */
  public String getJwtToken() {
    return jwtToken;
  }

  /**
   * Sets the jwt token.
   *
   * @param jwtToken the new jwt token
   */
  public void setJwtToken(String jwtToken) {
    this.jwtToken = jwtToken;
  }

  /**
   * Gets the hibernate config.
   *
   * @return the hibernate config
   */
  public HibernateConfig getHibernateConfig() {
    return hibernateConfig;
  }

  /**
   * Sets the hibernate config.
   *
   * @param hibernateConfig the hibernate config
   */
  public void setHibernateConfig(HibernateConfig hibernateConfig) {
    this.hibernateConfig = hibernateConfig;
  }

  /**
   * Gets the swagger bundle configuration.
   *
   * @return the swaggerBundleConfiguration
   */
  public SwaggerBundleConfiguration getSwaggerBundleConfiguration() {
    return swaggerBundleConfiguration;
  }

  /*
   * The swagger bundle configuration.
   */

  /**
   * Sets the swagger bundle configuration.
   *
   * @param swaggerBundleConfiguration the swaggerBundleConfiguration to set
   */
  public void setSwaggerBundleConfiguration(SwaggerBundleConfiguration swaggerBundleConfiguration) {
    this.swaggerBundleConfiguration = swaggerBundleConfiguration;
  }

  /**
   * Gets the mqconsumer topics.
   *
   * @return the mqconsumer topics
   */
  public List<String> getMqconsumerTopics() {
    return mqconsumerTopics;
  }

  /**
   * Sets the mqconsumer topics.
   *
   * @param mqconsumerTopics the new mqconsumer topics
   */
  public void setMqconsumerTopics(List<String> mqconsumerTopics) {
    this.mqconsumerTopics = mqconsumerTopics;
  }

  /**
   * The subscription service games url.
   *
   * @return the subscription service games url
   */
  public String getSubscriptionServiceGamesUrl() {
    return subscriptionServiceGamesUrl;
  }

  /**
   * Sets the subscription service games url.
   *
   * @param subscriptionServiceGamesUrl the new subscription service games url
   */
  public void setSubscriptionServiceGamesUrl(String subscriptionServiceGamesUrl) {
    this.subscriptionServiceGamesUrl = subscriptionServiceGamesUrl;
  }

  /**
   * Sets the subscription service games url.
   *
   * @param subscriptionServiceGamesUrl the new subscription service games url
   */
  public void setSubscriptionServiceUrl(String subscriptionServiceGamesUrl) {
    this.subscriptionServiceGamesUrl = subscriptionServiceGamesUrl;
  }

  /**
   * The subscription service game schedule url.
   *
   * @return the subscription service game schedule url
   */
  public String getSubscriptionServiceGameScheduleUrl() {
    return subscriptionServiceGameScheduleUrl;
  }

  /**
   * Sets the subscription service game schedule url.
   *
   * @param subscriptionServiceGameScheduleUrl the new subscription service game schedule url
   */
  public void setSubscriptionServiceGameScheduleUrl(String subscriptionServiceGameScheduleUrl) {
    this.subscriptionServiceGameScheduleUrl = subscriptionServiceGameScheduleUrl;
  }

  /**
   * Gets the gvi wager from wager set.
   *
   * @return the gvi wager from wager set
   */
  public String getGviWagerFromWagerSet() {
    return gviWagerFromWagerSet;
  }

  /**
   * Sets the gvi wager from wager set.
   *
   * @param gviWagerFromWagerSet the new gvi wager from wager set
   */
  public void setGviWagerFromWagerSet(String gviWagerFromWagerSet) {
    this.gviWagerFromWagerSet = gviWagerFromWagerSet;
  }

  /**
   * Gets the allowed JMX delivery count.
   *
   * @return the allowed JMX delivery count
   */
  public Integer getAllowedJMXDeliveryCount() {
    return allowedJMXDeliveryCount;
  }

  /**
   * Sets the allowed JMX delivery count.
   *
   * @param allowedJMXDeliveryCount the new allowed JMX delivery count
   */
  public void setAllowedJMXDeliveryCount(Integer allowedJMXDeliveryCount) {
    this.allowedJMXDeliveryCount = allowedJMXDeliveryCount;
  }

  /**
   * Gets the system agent id.
   *
   * @return the system agent id
   */
  public Integer getSystemAgentId() {
    return systemAgentId;
  }

  /**
   * Sets the system agent id.
   *
   * @param systemAgentId the new system agent id
   */
  public void setSystemAgentId(Integer systemAgentId) {
    this.systemAgentId = systemAgentId;
  }

  /**
   * Gets the mq consumer queues.
   *
   * @return the mq consumer queues
   */
  public HashMap<String, String> getMqConsumerQueues() {
    return mqConsumerQueues;
  }

  /**
   * Sets the mq consumer queues.
   *
   * @param mqConsumerQueues the mq consumer queues
   */
  public void setMqConsumerQueues(HashMap<String, String> mqConsumerQueues) {
    this.mqConsumerQueues = mqConsumerQueues;
  }

  public HashMap<String, Integer> getMqConsumerQueueCount() {
    return mqConsumerQueueCount;
  }

  public void setMqConsumerQueueCount(HashMap<String, Integer> mqConsumerQueueCount) {
    this.mqConsumerQueueCount = mqConsumerQueueCount;
  }

  public String getAMQFailoverUrl() {
    return "failover:("
        + Arrays.stream(mqconsumer.getProperty("hosts").split(","))
            .map(h -> "tcp://" + h + ":" + mqconsumer.getProperty("port"))
            .collect(Collectors.joining(","))
        + ")"
        + mqconsumer.getProperty("uriQueryParam");
  }

  public String getHostname() {
    return hostname;
  }

  public void setHostname(String hostname) {
    this.hostname = hostname;
  }

  /** @return the dataReconcileBatchSize */
  public Integer getDataReconcileBatchSize() {
    return dataReconcileBatchSize;
  }

  /** @param dataReconcileBatchSize the dataReconcileBatchSize to set */
  public void setDataReconcileBatchSize(Integer dataReconcileBatchSize) {
    this.dataReconcileBatchSize = dataReconcileBatchSize;
  }

  /** @return the maxEventIdTimeInterval */
  public Integer getMaxEventIdTimeInterval() {
    return maxEventIdTimeInterval;
  }

  /** @param maxEventIdTimeInterval the maxEventIdTimeInterval to set */
  public void setMaxEventIdTimeInterval(Integer maxEventIdTimeInterval) {
    this.maxEventIdTimeInterval = maxEventIdTimeInterval;
  }

  public Integer getMaxRetryCount() {
    return maxRetryCount;
  }

  public void setMaxRetryCount(Integer maxRetryCount) {
    this.maxRetryCount = maxRetryCount;
  }

  public Integer getMaxRetryCountForConcurrence() {
    return maxRetryCountForConcurrence;
  }

  public void setMaxRetryCountForConcurrence(Integer maxRetryCountForConcurrence) {
    this.maxRetryCountForConcurrence = maxRetryCountForConcurrence;
  }

  public Integer getMaxWaitTimeForConcurrence() {
    return maxWaitTimeForConcurrence;
  }

  public void setMaxWaitTimeForConcurrence(Integer maxWaitTimeForConcurrence) {
    this.maxWaitTimeForConcurrence = maxWaitTimeForConcurrence;
  }

  public Integer getErrorProcessingBatchLimit() {
    return errorProcessingBatchLimit;
  }

  public void setErrorProcessingBatchLimit(Integer errorProcessingBatchLimit) {
    this.errorProcessingBatchLimit = errorProcessingBatchLimit;
  }

  public Integer getErrorProcessingBatchPauseSecs() {
    return errorProcessingBatchPauseSecs;
  }

  public void setErrorProcessingBatchPauseSecs(Integer errorProcessingBatchPauseSecs) {
    this.errorProcessingBatchPauseSecs = errorProcessingBatchPauseSecs;
  }

  public List<String> getNotificationBrokerErrorDestination() {
    return notificationBrokerErrorDestination;
  }

  public void setNotificationBrokerErrorDestination(
      List<String> notificationBrokerErrorDestination) {
    this.notificationBrokerErrorDestination = notificationBrokerErrorDestination;
  }

  public Boolean getReportEtlJobsHealthMonitoring() {
    return reportEtlJobsHealthMonitoring;
  }

  public void setReportEtlJobsHealthMonitoring(Boolean reportEtlJobsHealthMonitoring) {
    this.reportEtlJobsHealthMonitoring = reportEtlJobsHealthMonitoring;
  }

  public Boolean getAmqXAConnectionMode() {
    return isAmqXAConnectionMode;
  }

  public void setAmqXAConnectionMode(Boolean amqXAConnectionMode) {
    this.isAmqXAConnectionMode = amqXAConnectionMode;
  }

  public String getDeleteProfileTopics() {
    return deleteProfileTopics;
  }

  public void setDeleteProfileTopics(String deleteProfileTopics) {
    this.deleteProfileTopics = deleteProfileTopics;
  }

  public Integer getAllowedErrorCount() {
    return allowedErrorCount;
  }

  public void setAllowedErrorCount(Integer allowedErrorCount) {
    this.allowedErrorCount = allowedErrorCount;
  }

  public List<String> getBatchLogDestination() {
    return batchLogDestination;
  }

  public void setBatchLogDestination(List<String> batchLogDestination) {
    this.batchLogDestination = batchLogDestination;
  }

  public String getTimeZone() {
    return timeZone;
  }

  public void setTimeZone(String timeZone) {
    this.timeZone = timeZone;
  }

  public HashMap<String, List<String>> getEventDispatcherTopics() {
    return eventDispatcherTopics;
  }

  public void setEventDispatcherTopics(HashMap<String, List<String>> eventDispatcherTopics) {
    this.eventDispatcherTopics = eventDispatcherTopics;
  }

  public HashMap<String, String> getEventDispatcherEndPoints() {
    return eventDispatcherEndPoints;
  }

  public void setEventDispatcherEndPoints(HashMap<String, String> eventDispatcherEndPoints) {
    this.eventDispatcherEndPoints = eventDispatcherEndPoints;
  }

  public Boolean getMissingEventsToBeProcessedByService() {
    return missingEventsToBeProcessedByService;
  }

  public void setMissingEventsToBeProcessedByService(Boolean missingEventsToBeProcessedByService) {
    this.missingEventsToBeProcessedByService = missingEventsToBeProcessedByService;
  }

  /** @return the gameManagerDestination */
  public List<String> getGameManagerDestination() {
    return gameManagerDestination;
  }

  /** @param gameManagerDestination the gameManagerDestination to set */
  public void setGameManagerDestination(List<String> gameManagerDestination) {
    this.gameManagerDestination = gameManagerDestination;
  }

  /** @return the exclusionDestination */
  public List<String> getExclusionDestination() {
    return exclusionDestination;
  }

  /** @param exclusionDestination the exclusionDestination to set */
  public void setExclusionDestination(List<String> exclusionDestination) {
    this.exclusionDestination = exclusionDestination;
  }

  /** @return the limitDestination */
  public List<String> getLimitDestination() {
    return limitDestination;
  }

  /** @param limitDestination the limitDestination to set */
  public void setLimitDestination(List<String> limitDestination) {
    this.limitDestination = limitDestination;
  }

  /** @return the agentDestination */
  public List<String> getAgentDestination() {
    return agentDestination;
  }

  /** @param agentDestination the agentDestination to set */
  public void setAgentDestination(List<String> agentDestination) {
    this.agentDestination = agentDestination;
  }

  /** @return the playerDestination */
  public List<String> getPlayerDestination() {
    return playerDestination;
  }

  /** @param playerDestination the playerDestination to set */
  public void setPlayerDestination(List<String> playerDestination) {
    this.playerDestination = playerDestination;
  }

  /** @return the sessionDestination */
  public List<String> getSessionDestination() {
    return sessionDestination;
  }

  /** @param sessionDestination the sessionDestination to set */
  public void setSessionDestination(List<String> sessionDestination) {
    this.sessionDestination = sessionDestination;
  }

  /** @return the teamDestination */
  public List<String> getTeamDestination() {
    return teamDestination;
  }

  /** @param teamDestination the teamDestination to set */
  public void setTeamDestination(List<String> teamDestination) {
    this.teamDestination = teamDestination;
  }

  /** @return the leagueDestination */
  public List<String> getLeagueDestination() {
    return leagueDestination;
  }

  /** @param leagueDestination the leagueDestination to set */
  public void setLeagueDestination(List<String> leagueDestination) {
    this.leagueDestination = leagueDestination;
  }
  /** @return the expectedSpendingDestination */
  public List<String> getExpectedSpendingDestination() {
    return expectedSpendingDestination;
  }

  /** @param expectedSpendingDestination the expectedSpendingDestination to set */
  public void setExpectedSpendingDestination(List<String> expectedSpendingDestination) {
    this.expectedSpendingDestination = expectedSpendingDestination;
  }

  /** @return the accessLogDestination */
  public List<String> getAccessLogDestination() {
    return accessLogDestination;
  }

  /** @param accessLogDestination the accessLogDestination to set */
  public void setAccessLogDestination(List<String> accessLogDestination) {
    this.accessLogDestination = accessLogDestination;
  }

  /** @return the playerCardDestination */
  public List<String> getPlayerCardDestination() {
    return playerCardDestination;
  }

  /** @param playerCardDestination the playerCardDestination to set */
  public void setPlayerCardDestination(List<String> playerCardDestination) {
    this.playerCardDestination = playerCardDestination;
  }

  /** @return the thirdPartyErrorsDestination */
  public List<String> getThirdPartyErrorsDestination() {
    return thirdPartyErrorsDestination;
  }

  /** @param thirdPartyErrorsDestination the thirdPartyErrorsDestination to set */
  public void setThirdPartyErrorsDestination(List<String> thirdPartyErrorsDestination) {
    this.thirdPartyErrorsDestination = thirdPartyErrorsDestination;
  }

  /** @return the ihubAlertsDestination */
  public List<String> getIhubAlertsDestination() {
    return ihubAlertsDestination;
  }

  /** @param ihubAlertsDestination the ihubAlertsDestination to set */
  public void setIhubAlertsDestination(List<String> ihubAlertsDestination) {
    this.ihubAlertsDestination = ihubAlertsDestination;
  }

  /** @return the ledgerDestination */
  public List<String> getLedgerDestination() {
    return ledgerDestination;
  }

  /** @param ledgerDestination the ledgerDestination to set */
  public void setLedgerDestination(List<String> ledgerDestination) {
    this.ledgerDestination = ledgerDestination;
  }

  public List<String> getGviDestination() {
    return gviDestination;
  }

  public void setGviDestination(List<String> gviDestination) {
    this.gviDestination = gviDestination;
  }

  public FlywayConfiguration getFlyway() {
    return flyway;
  }

  public void setFlyway(FlywayConfiguration flyway) {
    this.flyway = flyway;
  }

  public List<String> getConcurrenceCronTopics() {
    return concurrenceCronTopics;
  }

  public void setConcurrenceCronTopics(List<String> concurrenceCronTopics) {
    this.concurrenceCronTopics = concurrenceCronTopics;
  }
}
