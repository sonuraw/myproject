package com.sciplay.report.etl.dto.agent;

/** @author salman */
public class AgentMeta {

  private String createdAt;

  private String correlationId;

  private AgentAuthor author;

  private String operatorId;

  public String getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }

  public String getCorrelationId() {
    return correlationId;
  }

  public void setCorrelationId(String correlationId) {
    this.correlationId = correlationId;
  }

  public AgentAuthor getAuthor() {
    return author;
  }

  public void setAuthor(AgentAuthor author) {
    this.author = author;
  }

  public String getOperatorId() {
    return operatorId;
  }

  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }
}
