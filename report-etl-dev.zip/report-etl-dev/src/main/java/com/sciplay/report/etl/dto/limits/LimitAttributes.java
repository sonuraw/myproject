package com.sciplay.report.etl.dto.limits;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
class LimitAttributes {

  private String category;

  private String period;

  private String status;

  private int value;

  private LimitScope scope;

  private String payload;

  private Date createdAt;

  private Date plannedAt;

  private String plannedStatus;

  private Date appliedFrom;

  private Date appliedUntil;

  public Date getAppliedUntil() {
    return this.appliedUntil;
  }

  public void setAppliedUntil(Date appliedUntil) {
    this.appliedUntil = appliedUntil;
  }

  public String getCategory() {
    return this.category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public String getPeriod() {
    return this.period;
  }

  public void setPeriod(String period) {
    this.period = period;
  }

  public String getStatus() {
    return this.status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public int getValue() {
    return this.value;
  }

  public void setValue(int value) {
    this.value = value;
  }

  public LimitScope getScope() {
    return this.scope;
  }

  public void setScope(LimitScope scope) {
    this.scope = scope;
  }

  public String getPayload() {
    return this.payload;
  }

  public void setPayload(String payload) {
    this.payload = payload;
  }

  public Date getCreatedAt() {
    return this.createdAt;
  }

  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  public Date getPlannedAt() {
    return plannedAt;
  }

  public void setPlannedAt(Date plannedAt) {
    this.plannedAt = plannedAt;
  }

  public String getPlannedStatus() {
    return plannedStatus;
  }

  public void setPlannedStatus(String plannedStatus) {
    this.plannedStatus = plannedStatus;
  }

  public Date getAppliedFrom() {
    return appliedFrom;
  }

  public void setAppliedFrom(Date appliedFrom) {
    this.appliedFrom = appliedFrom;
  }
}
