package com.sciplay.report.etl.Entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/** The Class PaymentMethodArchive. */
@Entity
@Table(name = "PlayerPaymentMethodArchive")
public class PlayerPaymentMethodArchiveEntity implements java.io.Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1L;

  /** The revision number. */
  @Id
  @Column(name = "RevisionNumber")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long revisionNumber;

  /** The revision date. */
  private Date revisionDate;

  /** The revision state. */
  private String revisionState;

  /** The id. */
  private Integer id;

  /** The player id. */
  private Integer playerId;

  /** The operator id. */
  @Column(name = "OperatorId", columnDefinition = "char(3)")
  private String operatorId;

  /** The payment method type. */
  private String paymentMethodType;

  /** The holder. */
  private String holder;

  /** The bank name. */
  private String bankName;

  /** The account number. */
  private String accountNumber;

  /** The routing number. */
  private String routingNumber;

  /** The card number last four. */
  private String cardNumberLastFour;

  /** The expiration date. */
  private Date expirationDate;

  /** The token. */
  private String token;

  /** The is valid. */
  private Boolean isValid;

  /** The author player id. */
  private Integer authorPlayerId;

  /** The author agent id. */
  private Integer authorAgentId;

  /** The author ip. */
  private String authorIp;

  /** The author session id. */
  private String authorSessionId;

  /** The created at. */
  private Date createdAt;

  /** The card type. */
  private String cardType;

  /** The is NationAccount. */
  private Boolean isNationalAccount;

  /** The is Preferred. */
  @Column(name = "IsPreferred")
  private Boolean isPreferred = false;

  /** Instantiates a new payment method archive. */
  public PlayerPaymentMethodArchiveEntity() {}

  /**
   * Instantiates a new payment method archive.
   *
   * @param revisionDate the revision date
   * @param revisionState the revision state
   * @param id the id
   * @param createdAt the created at
   */
  public PlayerPaymentMethodArchiveEntity(
      Date revisionDate, String revisionState, Integer id, Date createdAt) {
    this.revisionDate = revisionDate;
    this.revisionState = revisionState;
    this.id = id;
    this.createdAt = createdAt;
  }

  /**
   * Instantiates a new payment method archive.
   *
   * @param revisionDate the revision date
   * @param revisionState the revision state
   * @param id the id
   * @param playerId the player id
   * @param operatorId the operator id
   * @param paymentMethodType the payment method type
   * @param holder the holder
   * @param bankName the bank name
   * @param accountNumber the account number
   * @param routingNumber the routing number
   * @param cardNumberLastFour the card number last four
   * @param expirationDate the expiration date
   * @param token the token
   * @param isValid the is valid
   * @param authorPlayerId the author player id
   * @param authorAgentId the author agent id
   * @param authorIp the author ip
   * @param authorSessionId the author session id
   * @param createdAt the created at
   */
  public PlayerPaymentMethodArchiveEntity(
      Date revisionDate,
      String revisionState,
      Integer id,
      Integer playerId,
      String operatorId,
      String paymentMethodType,
      String holder,
      String bankName,
      String accountNumber,
      String routingNumber,
      String cardNumberLastFour,
      Date expirationDate,
      String token,
      Boolean isValid,
      Integer authorPlayerId,
      Integer authorAgentId,
      String authorIp,
      String authorSessionId,
      Date createdAt,
      String cardType,
      Boolean isNationalAccount) {
    this.revisionDate = revisionDate;
    this.revisionState = revisionState;
    this.id = id;
    this.playerId = playerId;
    this.operatorId = operatorId;
    this.paymentMethodType = paymentMethodType;
    this.holder = holder;
    this.bankName = bankName;
    this.accountNumber = accountNumber;
    this.routingNumber = routingNumber;
    this.cardNumberLastFour = cardNumberLastFour;
    this.expirationDate = expirationDate;
    this.token = token;
    this.isValid = isValid;
    this.authorPlayerId = authorPlayerId;
    this.authorAgentId = authorAgentId;
    this.authorIp = authorIp;
    this.authorSessionId = authorSessionId;
    this.createdAt = createdAt;
    this.cardType = cardType;
    this.isNationalAccount = isNationalAccount;
  }

  @Override
  public String toString() {
    return "PlayerPaymentMethodArchiveEntity{"
        + "revisionState='"
        + revisionState
        + '\''
        + ", id="
        + id
        + ", playerId="
        + playerId
        + ", operatorId='"
        + operatorId
        + '\''
        + ", paymentMethodType='"
        + paymentMethodType
        + '\''
        + ", holder='"
        + holder
        + '\''
        + ", bankName='"
        + bankName
        + '\''
        + ", accountNumber='"
        + accountNumber
        + '\''
        + ", routingNumber='"
        + routingNumber
        + '\''
        + ", cardNumberLastFour='"
        + cardNumberLastFour
        + '\''
        + ", expirationDate="
        + expirationDate
        + ", token='"
        + token
        + '\''
        + ", isValid="
        + isValid
        + ", authorPlayerId="
        + authorPlayerId
        + ", authorAgentId="
        + authorAgentId
        + ", authorIp='"
        + authorIp
        + '\''
        + ", authorSessionId='"
        + authorSessionId
        + '\''
        + ", createdAt="
        + createdAt
        + ", cardType='"
        + cardType
        + '\''
        + ", isNationalAccount="
        + isNationalAccount
        + ", isPreferred="
        + isPreferred
        + '}';
  }

  /**
   * Gets the revision number.
   *
   * @return the revision number
   */
  public long getRevisionNumber() {
    return this.revisionNumber;
  }

  /**
   * Sets the revision number.
   *
   * @param revisionNumber the new revision number
   */
  public void setRevisionNumber(long revisionNumber) {
    this.revisionNumber = revisionNumber;
  }

  /**
   * Gets the revision date.
   *
   * @return the revision date
   */
  public Date getRevisionDate() {
    return this.revisionDate;
  }

  /**
   * Sets the revision date.
   *
   * @param revisionDate the new revision date
   */
  public void setRevisionDate(Date revisionDate) {
    this.revisionDate = revisionDate;
  }

  /**
   * Gets the revision state.
   *
   * @return the revision state
   */
  public String getRevisionState() {
    return this.revisionState;
  }

  /**
   * Sets the revision state.
   *
   * @param revisionState the new revision state
   */
  public void setRevisionState(String revisionState) {
    this.revisionState = revisionState;
  }

  /**
   * Gets the id.
   *
   * @return the id
   */
  public Integer getId() {
    return this.id;
  }

  /**
   * Sets the id.
   *
   * @param id the new id
   */
  public void setId(Integer id) {
    this.id = id;
  }

  /**
   * Gets the player id.
   *
   * @return the player id
   */
  public Integer getPlayerId() {
    return this.playerId;
  }

  /**
   * Sets the player id.
   *
   * @param playerId the new player id
   */
  public void setPlayerId(Integer playerId) {
    this.playerId = playerId;
  }

  /**
   * Gets the operator id.
   *
   * @return the operator id
   */
  public String getOperatorId() {
    return this.operatorId;
  }

  /**
   * Sets the operator id.
   *
   * @param operatorId the new operator id
   */
  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  /**
   * Gets the payment method type.
   *
   * @return the payment method type
   */
  public String getPaymentMethodType() {
    return this.paymentMethodType;
  }

  /**
   * Sets the payment method type.
   *
   * @param paymentMethodType the new payment method type
   */
  public void setPaymentMethodType(String paymentMethodType) {
    this.paymentMethodType = paymentMethodType;
  }

  /**
   * Gets the holder.
   *
   * @return the holder
   */
  public String getHolder() {
    return this.holder;
  }

  /**
   * Sets the holder.
   *
   * @param holder the new holder
   */
  public void setHolder(String holder) {
    this.holder = holder;
  }

  /**
   * Gets the bank name.
   *
   * @return the bank name
   */
  public String getBankName() {
    return this.bankName;
  }

  /**
   * Sets the bank name.
   *
   * @param bankName the new bank name
   */
  public void setBankName(String bankName) {
    this.bankName = bankName;
  }

  /**
   * Gets the account number.
   *
   * @return the account number
   */
  public String getAccountNumber() {
    return this.accountNumber;
  }

  /**
   * Sets the account number.
   *
   * @param accountNumber the new account number
   */
  public void setAccountNumber(String accountNumber) {
    this.accountNumber = accountNumber;
  }

  /**
   * Gets the routing number.
   *
   * @return the routing number
   */
  public String getRoutingNumber() {
    return this.routingNumber;
  }

  /**
   * Sets the routing number.
   *
   * @param routingNumber the new routing number
   */
  public void setRoutingNumber(String routingNumber) {
    this.routingNumber = routingNumber;
  }

  /**
   * Gets the card number last four.
   *
   * @return the card number last four
   */
  public String getCardNumberLastFour() {
    return this.cardNumberLastFour;
  }

  /**
   * Sets the card number last four.
   *
   * @param cardNumberLastFour the new card number last four
   */
  public void setCardNumberLastFour(String cardNumberLastFour) {
    this.cardNumberLastFour = cardNumberLastFour;
  }

  /**
   * Gets the expiration date.
   *
   * @return the expiration date
   */
  public Date getExpirationDate() {
    return this.expirationDate;
  }

  /**
   * Sets the expiration date.
   *
   * @param expirationDate the new expiration date
   */
  public void setExpirationDate(Date expirationDate) {
    this.expirationDate = expirationDate;
  }

  /**
   * Gets the token.
   *
   * @return the token
   */
  public String getToken() {
    return this.token;
  }

  /**
   * Sets the token.
   *
   * @param token the new token
   */
  public void setToken(String token) {
    this.token = token;
  }

  /**
   * Gets the checks if is valid.
   *
   * @return the checks if is valid
   */
  public Boolean getIsValid() {
    return this.isValid;
  }

  /**
   * Sets the checks if is valid.
   *
   * @param isValid the new checks if is valid
   */
  public void setIsValid(Boolean isValid) {
    this.isValid = isValid;
  }

  /**
   * Gets the author player id.
   *
   * @return the author player id
   */
  public Integer getAuthorPlayerId() {
    return this.authorPlayerId;
  }

  /**
   * Sets the author player id.
   *
   * @param authorPlayerId the new author player id
   */
  public void setAuthorPlayerId(Integer authorPlayerId) {
    this.authorPlayerId = authorPlayerId;
  }

  /**
   * Gets the author agent id.
   *
   * @return the author agent id
   */
  public Integer getAuthorAgentId() {
    return this.authorAgentId;
  }

  /**
   * Sets the author agent id.
   *
   * @param authorAgentId the new author agent id
   */
  public void setAuthorAgentId(Integer authorAgentId) {
    this.authorAgentId = authorAgentId;
  }

  /**
   * Gets the author ip.
   *
   * @return the author ip
   */
  public String getAuthorIp() {
    return this.authorIp;
  }

  /**
   * Sets the author ip.
   *
   * @param authorIp the new author ip
   */
  public void setAuthorIp(String authorIp) {
    this.authorIp = authorIp;
  }

  /**
   * Gets the author session id.
   *
   * @return the author session id
   */
  public String getAuthorSessionId() {
    return this.authorSessionId;
  }

  /**
   * Sets the author session id.
   *
   * @param authorSessionId the new author session id
   */
  public void setAuthorSessionId(String authorSessionId) {
    this.authorSessionId = authorSessionId;
  }

  /**
   * Gets the created at.
   *
   * @return the created at
   */
  public Date getCreatedAt() {
    return this.createdAt;
  }

  /**
   * Sets the created at.
   *
   * @param createdAt the new created at
   */
  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  /**
   * Gets the cardType.
   *
   * @return the cardType
   */
  public String getCardType() {
    return this.cardType;
  }

  /** Sets the cardType. */
  public void setCardType(String cardType) {
    this.cardType = cardType;
  }

  /** @return the isNationalAccount */
  public Boolean getIsNationalAccount() {
    return isNationalAccount;
  }

  /** @param isNationalAccount the isNationalAccount to set */
  public void setIsNationalAccount(Boolean isNationalAccount) {
    this.isNationalAccount = isNationalAccount;
  }

  /** @return the isPreferred */
  public Boolean getIsPreferred() {
    return isPreferred;
  }

  /** @param isPreferred the isPreferred to set */
  public void setIsPreferred(Boolean isPreferred) {
    this.isPreferred = isPreferred;
  }
}
