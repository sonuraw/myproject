package migration;

import CustomClasses.Encryption;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;

public class PlayerAddress {
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;
    private String selectStmt = "SELECT Id,street FROM PlayerAddress"; //TODO
    private String updateStmt = "Update PlayerAddress Set Street= ? Where Id = ?;"; //TODO

    public PlayerAddress(Connection conn) {
        connection = conn;
    }

    public void readData() throws Exception {
        try {
            preparedStatement = connection.prepareStatement(selectStmt);
            System.out.println(new Date().toString() + "Selecting For " + Thread.currentThread().getStackTrace()[1]
                    .getClassName());
            resultSet = preparedStatement.executeQuery();
            preparedStatement = connection.prepareStatement(updateStmt);
            System.out.println(
                    new Date().toString() + "Targeting For next 100 in : " + Thread.currentThread().getStackTrace()[1]
                            .getClassName());
            updateResultSet(resultSet);
            System.out.println(
                    new Date().toString() + " Over for, " + Thread.currentThread().getStackTrace()[1].getClassName());
        } finally {
            close();
        }
    }

    private void updateResultSet(ResultSet resultSet) throws Exception {
        System.out.println(
                new Date().toString() + "Updating For " + Thread.currentThread().getStackTrace()[1].getClassName());
        int i = 0, totalCount = 0;
        while (resultSet.next()) {
            if (i == 100) {
                i = 0;
                totalCount += 100;
                System.out.println(new Date().toString() + "Batching For " + Thread.currentThread().getStackTrace()[1]
                        .getClassName());
                preparedStatement.executeBatch();
                System.out.println(new Date().toString() + "Committing For " + Thread.currentThread().getStackTrace()[1]
                        .getClassName() + "Total Count Committed :" + totalCount);
                connection.commit();
                preparedStatement = connection.prepareStatement(updateStmt);
                System.out.println(new Date().toString() + "Targeting For next 100 in : " + Thread.currentThread()
                        .getStackTrace()[1].getClassName());
            }
            try {
                preparedStatement.setString(1,
                        Encryption.encrypt(resultSet.getString(PlayerAddressColumns.street.toString()))); // TODO
                preparedStatement.setString(2, resultSet.getString(PlayerAddressColumns.Id.toString()));
                preparedStatement.addBatch();
                i++;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void close() {
        try {
            if (resultSet != null)
                resultSet.close();
            if (statement != null)
                statement.close();
            if (preparedStatement != null)
                preparedStatement.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    enum PlayerAddressColumns {
        street, Id
    }

    enum CountData {
        count
    }
}
