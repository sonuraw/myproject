package db.migration;

import migration.*;
import org.flywaydb.core.api.migration.jdbc.JdbcMigration;

import java.sql.Connection;
import java.util.Date;

/**
 * Created by 105450 on 2/22/2017.
 */

public class V1_4_6__base implements JdbcMigration {
    private static Connection conn;

    public void migrate(Connection connection) throws Exception {
        try {
            conn = connection;

            PlayerProfile();
            PlayerProfileArchive();
            PlayerAddress();
            PlayerAddressArchive();
            PlayerPhone();
            PlayerPhoneArchive();
            PlayerIdentificationDocument();
            PlayerIdentificationDocumentArchive();
            PlayerPaymentMethod();
            PlayerPaymentMethodArchive();
            AgentProfile();
            AgentProfileArchive();
            PlayerTransaction();
            PlayerTransactionDetails();
            PlayerHistory();
            AgentChangeNotification();

        } finally {
            System.out.printf("Migration done in V1_4.6");
        }

    }

    public static void PlayerProfile() {
        PlayerProfile pp = new PlayerProfile(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public static void PlayerProfileArchive() {
        PlayerProfileArchive pp = new PlayerProfileArchive(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public static void PlayerAddress() {
        PlayerAddress pp = new PlayerAddress(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public static void PlayerAddressArchive() {
        PlayerAddressArchive pp = new PlayerAddressArchive(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public static void PlayerPhone() {
        PlayerPhone pp = new PlayerPhone(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public static void PlayerPhoneArchive() {
        PlayerPhoneArchive pp = new PlayerPhoneArchive(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public static void PlayerIdentificationDocument() {
        PlayerIdentificationDocument pp = new PlayerIdentificationDocument(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public static void PlayerIdentificationDocumentArchive() {
        PlayerIdentificationDocumentArchive pp = new PlayerIdentificationDocumentArchive(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public static void PlayerPaymentMethod() {
        PlayerPaymentMethod pp = new PlayerPaymentMethod(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public static void PlayerPaymentMethodArchive() {
        PlayerPaymentMethodArchive pp = new PlayerPaymentMethodArchive(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public static void AgentProfile() {
        AgentProfile pp = new AgentProfile(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public static void AgentProfileArchive() {
        AgentProfileArchive pp = new AgentProfileArchive(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public static void PlayerTransaction() {
        PlayerTransaction pp = new PlayerTransaction(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public static void PlayerTransactionDetails() {
        PlayerTransactionDetails pp = new PlayerTransactionDetails(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public static void PlayerHistory() {
        PlayerHistory pp = new PlayerHistory(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public static void AgentChangeNotification() {
        AgentChangeNotification pp = new AgentChangeNotification(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

}