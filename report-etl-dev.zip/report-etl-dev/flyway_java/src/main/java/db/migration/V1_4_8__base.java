package db.migration;

import migration.PlayerProfile_3;
import migration.PlayerProfileArchive_3;
import migration.PlayerHistory_3;
import org.flywaydb.core.api.migration.jdbc.JdbcMigration;

import java.util.Date;

import java.sql.Connection;

/**
 * Created by 105450 on 2/22/2017.
 */

public class V1_4_8__base implements JdbcMigration {
    private static Connection conn;

    public void migrate(Connection connection) throws Exception {
        try {
            conn = connection;
            PlayerProfile_3();
            PlayerProfileArchive_3();
            PlayerHistory_3();
        } finally {
            System.out.printf("Migration done in V1_4.8");
        }

    }

    public static void PlayerProfile_3() {
        PlayerProfile_3 pp = new PlayerProfile_3(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public static void PlayerProfileArchive_3() {
        PlayerProfileArchive_3 pp = new PlayerProfileArchive_3(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public static void PlayerHistory_3() {
        PlayerHistory_3 pp = new PlayerHistory_3(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

}