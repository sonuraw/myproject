package db.migration;

import migration.*;
import org.flywaydb.core.api.migration.jdbc.JdbcMigration;

import java.sql.Connection;
import java.util.Date;

/**
 * Created by 105450 on 2/22/2017.
 */

public class V1_4_7__base implements JdbcMigration {
    private static Connection conn;

    public void migrate(Connection connection) throws Exception {
        try {
            conn = connection;
            PlayerHistory_2();
            AgentChangeNotification_2();

        } finally {
            System.out.printf("Migration done in V1_4.7");
        }

    }

    public static void PlayerHistory_2() {
        PlayerHistory_2 pp = new PlayerHistory_2(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public static void AgentChangeNotification_2() {
        AgentChangeNotification_2 pp = new AgentChangeNotification_2(conn);
        try {
            pp.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

}