package db.migration;

import migration.*;
import org.flywaydb.core.api.migration.jdbc.JdbcMigration;

import java.util.Date;

import java.sql.Connection;

/**
 * Created by Kaliyappan on 11-Oct-2017.
 */

public class V1_30_0__PlayerAddress_Detail implements JdbcMigration {
    private static Connection conn;

    public void migrate(Connection connection) throws Exception {
        try {
            conn = connection;
            PlayerAddress_Detail();
            PlayerAddressArchive_Detail();
        } finally {
            System.out.printf("Migration done in V1_30.0");
        }

    }

    public static void PlayerAddress_Detail() {
        PlayerAddress_Detail pad = new PlayerAddress_Detail(conn);
        try {
            pad.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }

    public static void PlayerAddressArchive_Detail() {
        PlayerAddressArchive_Detail pad = new PlayerAddressArchive_Detail(conn);
        try {
            pad.readData();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(
                    new Date().toString() + "Over " + Thread.currentThread().getStackTrace()[1].getMethodName());
        }
    }
}