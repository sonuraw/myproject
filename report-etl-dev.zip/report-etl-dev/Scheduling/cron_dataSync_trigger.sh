#!/bin/bash
if pidof -x "cron_dataSync.sh" > /dev/null; then
    echo "$(date) cron_dataSync is already running. Exiting.."
    echo "$(date) cron_dataSync already running" >> /u01/report-etl-service/Scheduling/cron_dataSync_trigger.log
    exit 0
else
    echo "$(date) cron_dataSync not running. Starting now.."
    echo "$(date) cron_dataSync not running. Starting now.." >> /u01/report-etl-service/Scheduling/cron_dataSync_trigger.log
    echo "$(date) Process cron_dataSync has started"
    /u01/report-etl-service/Scheduling/cron_dataSync.sh >> /u01/report-etl-service/Scheduling/cron_dataSync.log
    echo "$(date) Process cron_dataSync_trigger has ended"
    exit 0
fi

