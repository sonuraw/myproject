#!/bin/bash
echo "$(date) Process cron_reProcessAll has started"
curl -X GET --header 'Accept: application/vnd.api+json' 'http://127.0.0.1:11005/processAllErrors'
echo "$(date) Process cron_reProcessAll has ended"
