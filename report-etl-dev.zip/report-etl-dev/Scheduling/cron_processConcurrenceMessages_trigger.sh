#!/bin/bash
if pidof -x "cron_processConcurrenceMessages.sh" > /dev/null; then
    echo "$(date) cron_processConcurrenceMessages is already running. Exiting.."
    echo "$(date) cron_processConcurrenceMessages already running" >> /u01/report-etl-service/Scheduling/cron_processConcurrenceMessages_trigger.log
    exit 0
else
    echo "$(date) cron_processConcurrenceMessages not running. Starting now.."
    echo "$(date) cron_processConcurrenceMessages not running. Starting now.." >> /u01/report-etl-service/Scheduling/cron_processConcurrenceMessages_trigger.log
    echo "$(date) Process processConcurrenceMessagesTrigger has started"
    /u01/report-etl-service/Scheduling/cron_processConcurrenceMessages.sh >> /u01/report-etl-service/Scheduling/cron_processConcurrenceMessages.log
    echo "$(date) Process processConcurrenceMessagesTrigger has ended"
    exit 0
fi

