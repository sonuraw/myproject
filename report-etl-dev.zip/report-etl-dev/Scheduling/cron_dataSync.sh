#!/bin/bash
echo "$(date) Process dataSync has started"
curl -X GET --header 'Accept: application/vnd.api+json' 'http://127.0.0.1:11005/dataSync/processAllMessage'
echo "$(date) Process dataSync has ended"
