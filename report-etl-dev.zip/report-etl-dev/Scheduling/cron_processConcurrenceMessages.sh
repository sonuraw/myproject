#!/bin/bash
echo "$(date) Process processConcurrenceMessages has started"
curl -X GET --header 'Accept: application/vnd.api+json' 'http://127.0.0.1:11005/processConcurrenceMessages'
echo "$(date) Process processConcurrenceMessages has ended"
