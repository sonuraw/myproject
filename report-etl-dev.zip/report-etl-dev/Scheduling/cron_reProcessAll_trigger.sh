#!/bin/bash
if pidof -x "cron_reProcessAll.sh" > /dev/null; then
    echo "$(date) cron_reProcessAll is already running. Exiting.."
    echo "$(date) cron_reProcessAll already running" >> /u01/report-etl-service/Scheduling/cron_reProcessAll_trigger.log
    exit 0
else
    echo "$(date) cron_reProcessAll not running. Starting now.."
    echo "$(date) cron_reProcessAll not running. Starting now.." >> /u01/report-etl-service/Scheduling/cron_reProcessAll_trigger.log
    echo "$(date) Process cron_reProcessAll has started"
    /u01/report-etl-service/Scheduling/cron_reProcessAll.sh >> /u01/report-etl-service/Scheduling/cron_reProcessAll.log
    echo "$(date) Process cron_reProcessAll has ended"
    exit 0
fi
