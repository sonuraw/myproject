Report-etl-service-errors health api
==========================================

#### report-etl-service-errors health api details

EndPoint Details (Prod)
```curl
http://10.75.101.200:11005/health?expand=true
```
Response Json : 
- Success
```json
{
    "healthy": true,
    "dependencies": {
        "mysql": {
            "healthy": true,
            "message": "Mysql Connection success"
        },
        "activeMq": {
            "healthy": true,
            "message": "ActiveMq Connection Success"
        },
        "etlServiceErrorLogHealth": {
            "healthy": true,
            "message": "EtlServiceErrorLog Okay"
        },
        "eventDispatcherMissingStoreHealth": {
            "healthy": true,
            "message": "EventDispatcherMissingStore Okay"
        },
        "jmsTopicIndexHealth": {
            "healthy": true,
            "message": "DataSync Okay"
        }
    }
}
```

report-etl-service-errors health api is based on two different scenarios of EtlServiceErrorLog Table.
1) the max number configured for the error re processing is 50 (configured in DDC env MAX_RETRY_COUNT_PROCESSING_ERROR).
So if any records with the error count > 50 , then the health api will be false.
```roomsql
Select Count(1) FROM EtlServiceErrorLog Where ProcessedStatus = 'Error' And RetryCount > 50;
-- if the count > 0 means, dev team needs to address this issue
```

```curl
http://10.75.101.200:11005/health?expand=true&job=etlServiceErrorLog
```
- Error Response
```json
{
    "healthy": false,
    "dependencies": {
        "mysql": {
            "healthy": true,
            "message": "Mysql Connection success"
        },
        "activeMq": {
            "healthy": true,
            "message": "ActiveMq Connection Success"
        },
        "etlServiceErrorLogHealth": {
            "healthy": false,
            "message": "EtlServiceErrorLog is having long pending error records"
        }
    }
}
```

2) if no of error records growing beyond un-acceptable value (configured in DDC env ALLOWED_ERROR_RECORD_COUNT), then the api will return false 500 error
```roomsql
Select Count(1) FROM EtlServiceErrorLog Where ProcessedStatus = 'Error';
-- if above ALLOWED_ERROR_RECORD_COUNT, then api health will be false
```

```curl
http://10.75.101.200:11005/health?expand=true&job=etlServiceErrorLog
```
- Error Response
```json
{
    "healthy": false,
    "dependencies": {
        "mysql": {
            "healthy": true,
            "message": "Mysql Connection success"
        },
        "activeMq": {
            "healthy": true,
            "message": "ActiveMq Connection Success"
        },
        "etlServiceErrorLogHealth": {
            "healthy": false,
            "message": "EtlServiceErrorLog is having {XX} error records, which is greater than allowed error counts"
        }
    }
}
```


in some cases, error count growth is quite natural.
Example: 
    Subscription queues are consumed, but the related transaction queues are not consumed still. so the subs events will be saved as error and will go for retry in the cron (10 min once)
Normally these errors should be processed with the 10 - 15 retries . If it goes beyond that, and also the error count is above 2 times of allowed means, serious bug. call dev team to address this.

Some exceptions like 
- Delay Exception
- Custom Exception
- Suppress Exception

If the errors belongs to above categories and the total count in these errors are under 2 times of allowed count, we can wait until it reaches the retry count of 50,
```roomsql
Select Count(1) FROM EtlServiceErrorLog Where ProcessedStatus = 'Error' AND RetryCount > 2
                AND 
                (
                ErrorStackTrace like '%Suppress%' OR
                ErrorStackTrace like '%Delay%' OR 
                ErrorStackTrace like '%Custom%')Order BY Id ASC
-- if above 2*ALLOWED_ERROR_RECORD_COUNT - call dev
```  
the thing is not too many (not above 2*allowed), only the same error rows still going for re process, no new accumulation of error rows is totally fine.

