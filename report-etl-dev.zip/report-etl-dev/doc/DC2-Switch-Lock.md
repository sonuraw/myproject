# Queries to get the mysql locking query threadid and killing the same

The following queries were used to detect the locking mysql thread id and killed , which was giving problem ion the time of DC2 Switch , which caused no  further CRUD operation allowed in report.PlayerBalance table


```sql
Select * FROM information_schema.PROCESSLIST Where info is not null Order BY Time DESC;
XA recover;
SHOW OPEN TABLES FROM report WHERE In_use > 0;
SHOW ENGINE INNODB STATUS;
Select * FROM INFORMATION_SCHEMA.INNODB_LOCKS; 

Select Id, p.*, t.* FROM INFORMATION_SCHEMA.INNODB_TRX t JOIN INFORMATION_SCHEMA.PROCESSLIST p
 ON ( p.ID = t.TRX_MYSQL_THREAD_ID )
 LEFT JOIN INFORMATION_SCHEMA.INNODB_LOCK_WAITS ot
 ON ( ot.BLOCKING_TRX_ID = t.TRX_id )
 Order BY TIME DESC;
```
