Dockers Build Guide
------------------

This service is packed and running as a docker container. Here we going to see few configuration and steps to build docker image for Report ETL Service. Before run the jenkins jobs we need to do few things, which are listed below.
        
Steps to do before run Jenkins Job:
-----------------------------------

**Update user_guide .md**

Path: report-service/doc/user_guide.md

Description: This file contains the details which will help user to execute or test the released tasks. Like configuration, manual changes before start test, etc.. to test released task or functionality of current release. This file will update only for some special cases.

**Update changes .md**

Path: report-service/doc/changes.md

Description: Update the changes made for the current release. For Example, If you fix any issue that must be updated here with short description of issue of rally ticket ID. Create new ticket if there is no rally ticket.

**Update ReleaseNotes .md**

Path: report-service/doc/ReleaseNotes.md

Description: This will contain the detailed information of current release. All the information that must be communicate with QA should be updated here.
    	
**Parameters**

There are two common parameters to make a docker build which are branch and tag.

	1.Branch - Name of the branch in git Repository to build docker image.
	2.Tag - This will be the docker image tag name.

**Dockers Build Script**

This script will create a tag with given tag parameter and pushed to git repository, If suppose tag is already exist then delete old tag and create a new one with same name. If branch and tag name are same then tag creation will not happen. After tag creation completed the image will build with tag name and default image with name "dev".
	    
## dockerBuild .sh file

	echo "Git Fetch All"
	#Git Fetch All
	git fetch --all

	echo "Git Check out branch: ${BUILD_BRANCH}"
	#Checkout to requested branch
	git checkout ${BUILD_BRANCH}

	echo "Git Pull branch: ${BUILD_BRANCH}"
	#pull the branch to get updated code
	git pull origin ${BUILD_BRANCH}

	if [ ${BUILD_BRANCH} != ${BUILD_TAG} ]; then
		echo "Check tag(${BUILD_TAG}) Exist"
		#Check If tag is exists
		if git rev-parse -q --verify "refs/tags/${BUILD_TAG}" >/dev/null; then
			echo "Tag(${BUILD_TAG}) Found"
			git tag -d ${BUILD_TAG}
			echo "Delete Tag(${BUILD_TAG})"
			#Delete Tag
			git push origin :refs/tags/${BUILD_TAG}    	
		fi

		echo "Create Tag(${BUILD_TAG})"
		#Create Tag
		git tag ${BUILD_TAG}

		echo "Push Tag(${BUILD_TAG})"
		#Push Tag
		git push origin tag ${BUILD_TAG}

	fi




	echo "the docker tag to be built is: ${BUILD_TAG}"

	# Build the Docker container for this project
	docker build --rm --force-rm -t report-etl-service:${BUILD_TAG} .

	# Tag the images with 'project version' and 'latest-dev'
	docker tag -f report-etl-service:${BUILD_TAG} $DOCKER_REGISTRY/platform/report-etl-service:${BUILD_TAG}
	docker tag -f report-etl-service:${BUILD_TAG} $DOCKER_REGISTRY/platform/report-etl-service:dev

	# Push the previously tagged images into the corporate Docker registry
	docker push $DOCKER_REGISTRY/platform/report-etl-service:${BUILD_TAG}
	docker push $DOCKER_REGISTRY/platform/report-etl-service:dev
	    
**Jenkins Job URL**

    http://jenkins.sg-platform-vpc.wms.com/job/report-etl-service/

Run the job by clicking left menu "Build with parameter".
