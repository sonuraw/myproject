## Batch execution

The report services are able to report about other services batch job executions, based on events published by these services: the jobs executions are then made available from the backoffice.
Services must publish events according to the specifications below.


### Events

* destination type: queue
* data/attributes/correlationId is used as an identifier for job executions.
 
#### Job starts

```json
{
  "meta": {
    "service": "wallet",
    "createdAt": "2019-10-16T07:03:23.009Z"
  },
  "data": {
    "type": "batch-execution",
    "attributes": {
      "correlationId": "fb8b0874-8db7-4f50-bc8b-b7d41dd39319",
      "batchGroupId": "scheduler-transactions-purge",
      "status": "in_progress",
      "startDate": "2019-10-16T07:03:23.009Z",
      "nextRunDate": "2019-10-17T07:03:23.000Z"
    }
  }
}
```

#### Job update

```json
{
  "meta": {
    "service": "wallet",
    "createdAt": "2019-10-16T07:04:09.613Z"
  },
  "data": {
    "type": "batch-execution",
    "attributes": {
      "correlationId": "fb8b0874-8db7-4f50-bc8b-b7d41dd39319",
      "batchGroupId": "scheduler-transactions-purge",
      "status": "success",
      "endDate": "2019-10-16T07:04:09.613Z",
      "result": {
        "message": ""
      }
    }
  }
}
```


#### Event attributes details

  * meta:
    - service:  event producer service name -- mandatory
    - createdAt: UTC create timestamp -- 
  * data:
    - type: batch-execution (static value) -- optional
    - attributes: 
      * correlationId: unique identifier UUID for each of the batch log executions -- mandatory 
      * batchGroupId: scheduler group name - ex: Journal Job log  -- mandatory
      * batchId: individual sub jobs in it - Player affiliation , Team, Leagues -- optional
      * status: status tracking of the job ENUM("in_progress","success","error", "not_ready", "incomplete") -- mandatory 
      * startDate: start dateTime in UTC  -- optional 
      * endDate: end dateTime in UTC -- optional
      * nextRunDate: next run dateTime of the job in UTC -- optional  
      * result:  -- optional
        - numberOfSuccess: if the jobs has many child executions, no of success in that can be tracked here
        - numberOfFailure: if the jobs has many child executions, no of failure in that can be tracked here
        - message: custom message by the batch executor - just a plain string 
    


#### Full json example

```json
{
  "meta": {
    "service": "string",
    "createdAt": "2019-06-27T08:05:28.218Z"
  },
  "data": {
    "type": "batch-execution",
    "attributes": {
      "correlationId": "",
      "batchGroupId": "string",
      "batchId": "string",
      "status": "string",
      "startDate": "2019-06-27T08:05:28.218Z",
      "endDate": "2019-06-27T08:05:28.218Z",
      "nextRunDate": "2019-06-27T08:05:28.218Z",
      "result": {
        "numberOfSuccess": 0,
        "numberOfFailure": 0,
        "message": "text"
      }
    }
  }
}
```

### Storage in reports

  * table: batch_log
  * table unique columns: 
    - id, run_date 
      * id - auto increment column
      * run_date - CEST timezone value of start date (for partition purpose)
    - correlationId
      * set by the producer service - create and update is based on this field

