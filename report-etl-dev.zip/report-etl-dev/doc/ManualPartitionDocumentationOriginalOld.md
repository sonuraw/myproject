

#### MANUAL PARTITION SCHEDULE

**Reports requires partitions to be created manually by operations based on the schedule described below**

**DAY WISE PARTIONED TABLES**

For the day wise tables mentioned
in table below : 

Maximum partition is created till
2099-01-01

Reorganization is done till
2019-01-02

**SCHEDULE :**

|    TableName                      |    reorganizePartition                                                    |    reorganizePartition - Example                                                                           |    ManualPartitionDeletionSP                                                        |    ManualPartitionDeletionSP  -   Example                                                                        |
|-----------------------------------|---------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------|
|    GameStatsPlayerByDate          |    Run on 1st of every 2 months with date 3   months from current date    |    On 1st of Jan 2019, execute    CALL   reorganizePartition('GameStatsPlayerByDate','2019-03-01');        |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL   ManualPartitionDeletionSP('GameStatsPlayerByDate','2018-06-31');              |
|        TransactionDailyBalance    |    Run on 1st of every 2 months with date 3   months from current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('TransactionDailyBalance ','2019-03-01');       |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('TransactionDailyBalance   ','2018-06-31');           |
|    TransactionEndOfDayBalance     |    Run on 1st of every 2 months with date 3   months from current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('TransactionEndOfDayBalance','2019-03-01');     |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('TransactionEndOfDayBalance   ','2018-06-31');        |
|    TransactionSummary             |    Run on 1st of every 2 months with date 3   months from current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('TransactionSummary','2019-03-01');             |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('TransactionSummary','2018-06-31');                   |
|    SubscriptionBalance            |    Run on 1st of every 2 months with date 3   months from current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('SubscriptionBalance','2019-03-01');            |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('SubscriptionBalance','2018-06-31');                  |
|    AgentAccessHistory             |    Run on 1st of every 2 months with date 3   months from current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('AgentAccessHistory','2019-03-01');             |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('AgentAccessHistory','2018-06-31');                   |
|    TransactionBalance             |    Run on 1st of every 2 months with date 3   months from current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('TransactionBalance','2019-03-01');             |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('TransactionBalance','2018-06-31');                   |
|    TransformationLog              |    Run on 1st of every 2 months with date 3   months from current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('TransformationLog','2019-03-01');              |    Run on 1st of every month with first   date of last month from current date      |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('TransformationLog','2018-12-31');                    |
|    Errors                         |    Run on 1st of every 2 months with date 3   months from current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('Errors','2019-03-01');                         |    Run on 1st of every month with first   date of last month from current date      |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('Errors','2018-12-31');                               |
|                                   |    Run on 1st of every 2 months with date 3   months from current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('JmsMessageDetails','2019-03-01');              |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('JmsMessageDetails','2018-06-31');                    |
|    JmsMessageDetails              |    Run on 1st of every 2 months with date 3   months from current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('JmsMessageDetails','2019-03-01');              |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('JmsMessageDetails','2018-06-31');                    |
|                                   |                                                                           |                                                                                                            |                                                                                     |                                                                                                                  |
|                                   |                                                                           |                                                                                                            |                                                                                     |                                                                                                                  |
|                                   |                                                                           |                                                                                                            |                                                                                     |                                                                                                                  |

**Note : If ManualPartitionDeletionSP is not called within the mentioned duration above, then automated event takes up the drop partition with double the retention
period for the table and starts dropping the partition which is twice as old as
retention period.**

To find retention period of any
table use the below query :

**_SELECT RetentionPeriod FROM
PurgeRetention WHERE TableName=’&lt;Required TableName&gt;’;_**


**_ _**


**WEEK WISE PARTIONED TABLES**

For the tables mentioned in below
table : 

Maximum partition is created till
2099-01-01

Reorganization is done till
2019-01-07

**Schedule :**

|    TableName                |    reorganizePartition                                                    |    reorganizePartition - Example                                                                         |    ManualPartitionDeletionSP                                                        |    ManualPartitionDeletionSP  -   Example                                                                |
|-----------------------------|---------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------|
|    GameStatsPlayerByWeek    |    Run on 1st of every 2 months with date 3   months from current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('GameStatsPlayerByWeek','2019-03-01');        |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('GameStatsPlayerByWeek','2018-06-31');        |
|        NetLossByWeek        |    Run on 1st of every 2 months with date 3   months from current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('NetLossByWeek'','2019-03-01');               |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('NetLossByWeek','2018-06-31');                |

**Note : If ManualPartitionDeletionSP is not called within the mentioned duration above, then automated event takes up the drop partition with double the retention
period for the table and starts dropping the partition which is twice as old as
retention period.**

To find retention period of any table use the below query :

**_SELECT RetentionPeriod FROM
PurgeRetention WHERE TableName=’&lt;Required TableName&gt;’;_**



**_ _**


**MONTH WISE PARTIONED TABLES**

For tables mentioned in the below
table : 

Maximum partition is created till
2099-01-01

Reorganization is done till
2019-01-01 

**Schedule :**

|    TableName                          |    reorganizePartition                                                    |    reorganizePartition - Example                                                                                   |    ManualPartitionDeletionSP                                                        |    ManualPartitionDeletionSP  -   Example                                                                          |
|---------------------------------------|---------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------|
|    GameStatsPlayerByMonth             |    Run on 1st of every 3 months with date 6   months from current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('GameStatsPlayerByMonth','2019-06-01');                 |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('GameStatsPlayerByMonth','2018-06-31');                 |
|    NetLossByMonth                     |    Run on 1st of every 3 months with date 6   months from current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('NetLossByMonth','2019-06-01');                         |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('NetLossByMonth','2018-06-31');                         |
|    GameStatsPlayerDefaultByMonth      |    Run on 1st of every 3 months with date 6   months from current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('GameStatsPlayerDefaultByMonth','2019-06-01');          |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('GameStatsPlayerDefaultByMonth','2018-06-31');          |
|    GameStatsPlayerMoneyTypeByMonth    |    Run on 1st of every 3 months with date 6 months from   current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('GameStatsPlayerMoneyTypeByMonth','2019-06-01');        |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('GameStatsPlayerMoneyTypeByMonth','2018-06-31');        |
|    PlayerTransaction                  |    Run on 1st of every 3 months with date 6 months from   current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('PlayerTransaction','2019-06-01');                      |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('PlayerTransaction','2018-06-31');                      |
|    PlayerTransactionDetails           |    Run on 1st of every 3 months with date 6 months from   current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('PlayerTransactionDetails','2019-06-01');               |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('PlayerTransactionDetails','2018-06-31');               |
|        Wager                          |    Run on 1st of every 3 months with date 6 months from   current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('Wager','2019-06-01');                                  |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('Wager','2018-06-31');                                  |
|    WagerArchive                       |    Run on 1st of every 3 months with date 6 months from   current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('WagerArchive','2019-06-01');                           |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('WagerArchive','2018-06-31');                           |
|    Winning                            |    Run on 1st of every 3 months with date 6 months from   current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('Winning','2019-06-01');                                |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('Winning','2018-06-31');                                |
|    WinningArchive                     |    Run on 1st of every 3 months with date 6 months from   current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('WinningArchive','2019-06-01');                         |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('WinningArchive','2018-06-31');                         |
|    WagerSet                           |    Run on 1st of every 3 months with date 6 months from   current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('WagerSet','2019-06-01');                               |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('WagerSet','2018-06-31');                               |
|    WagerSetArchive                    |    Run on 1st of every 3 months with date 6 months from   current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('WagerSetArchive','2019-06-01');                        |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('WagerSetArchive','2018-06-31');                        |
|    SubscriptionTransactions           |    Run on 1st of every 3 months with date 6 months from current   date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('SubscriptionTransactions','2019-06-01');               |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('SubscriptionTransactions','2018-06-31');               |
|    SubscriptionTransactionsArchive    |    Run on 1st of every 3 months with date 6 months from   current date    |    On 1st of Jan 2019, execute    CALL reorganizePartition('SubscriptionTransactionsArchive','2019-06-01');        |    Run on 1st of every month with first   date of last 6 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('SubscriptionTransactionsArchive','2018-06-31');        |

**Note : If ManualPartitionDeletionSP is not called within the mentioned duration above, then automated event takes up the drop partition with double the retention
period for the table and starts dropping the partition which is twice as old as
retention period.**

To find retention period of any table use the below query :

**_SELECT RetentionPeriod FROM
PurgeRetention WHERE TableName=’&lt;Required TableName&gt;’;_**


**_ _**


**QUARTER WISE PARTIONED TABLES**

For tables mentioned in the below
table : 

Maximum partition is created till
2099-01-01

Reorganization is done till 2019-01-04

**Schedule :**

|    TableName                            |    reorganizePartition                                                                                            |    reorganizePartition - Example                                                                                     |    ManualPartitionDeletionSP                                                                                                 |    ManualPartitionDeletionSP  -   Example                                                                            |
|-----------------------------------------|-------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------|
|    GameStatsPlayerByQuarter             |    Run on 1st of every 3 months(i.e, on   3rd,6th,9th and 12th month) with date 9 months from current date        |    On 1st of Jan 2019, execute    CALL reorganizePartition('GameStatsPlayerByQuarter','2019-09-01');                 |    Run on 1st of every 3 months(i.e, on   3rd,6th,9th and 12th month) with first date of last 7 month from   current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('GameStatsPlayerByQuarter','2018-05-31');                 |
|    NetLossByQuarterYear                 |    Run on 1st of every 3 months(i.e, on   3rd,6th,9th and 12th month) with date 9 months from current date        |    On 1st of Jan 2019, execute    CALL reorganizePartition('NetLossByQuarterYear','2019-09-01');                     |    Run on 1st of every 3 months(i.e, on   3rd,6th,9th and 12th month) with first date of last 7 month from   current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('NetLossByQuarterYear','2018-05-31');                     |
|    GameStatsPlayerDefaultByQuarter      |    Run on 1st of every 3 months(i.e, on   3rd,6th,9th and 12th month) with date 9 months from current date        |    On 1st of Jan 2019, execute    CALL reorganizePartition('GameStatsPlayerDefaultByQuarter','2019-09-01');          |    Run on 1st of every 3 months(i.e, on   3rd,6th,9th and 12th month) with first date of last 7 month from   current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('GameStatsPlayerDefaultByQuarter','2018-05-31');          |
|    GameStatsPlayerMoneyTypeByQuarter    |    Run on 1st of every 3 months(i.e, on   3rd,6th,9th and 12th month) with date 9 months from current date        |    On 1st of Jan 2019, execute    CALL reorganizePartition('GameStatsPlayerMoneyTypeByQuarter','2019-09-01');        |    Run on 1st of every 3 months(i.e, on   3rd,6th,9th and 12th month) with first date of last 7 month from   current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('GameStatsPlayerMoneyTypeByQuarter','2018-05-31');        |

**Note : If
ManualPartitionDeletionSP is not called within the mentioned duration above, then
automated event takes up the drop partition with double the retention period
for the table and starts dropping the partition which is twice as old as
retention period.**

To find retention period of any
table use the below query :

**_SELECT RetentionPeriod FROM
PurgeRetention WHERE TableName=’&lt;Required TableName&gt;’;_**


**_ _**


**HALF YEAR WISE PARTIONED TABLES  **

For tables mentioned in the below
table : 

Maximum partition is created till
2099-01-01

Reorganization is done till
2019-01-07

**Schedule :**

|    TableName                             |    reorganizePartition                                                                                       |    reorganizePartition - Example                                                                                      |    ManualPartitionDeletionSP                                                                                        |    ManualPartitionDeletionSP  -   Example                                                                             |
|------------------------------------------|--------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------|
|    GameStatsPlayerByHalfYear             |    Run on 1st of every 6th month (i.e, on   6th and 12th month) with date 18 months from current date        |    On 1st of Jan 2019, execute    CALL reorganizePartition('GameStatsPlayerByHalfYear','2020-06-01');                 |    Run on 1st of every 3 months(i.e, on 6th   and 12th month) with first date of last 19 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('GameStatsPlayerByHalfYear','2017-05-31');                 |
|    NetLossByHalfYear                     |    Run on 1st of every 6th month (i.e, on   6th and 12th month) with date 18 months from current date        |    On 1st of Jan 2019, execute    CALL reorganizePartition('NetLossByHalfYear','2020-06-01');                         |    Run on 1st of every 3 months(i.e, on 6th   and 12th month) with first date of last 19 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('NetLossByHalfYear','2017-05-31');                         |
|    GameStatsPlayerDefaultByHalfYear      |    Run on 1st of every 6th month (i.e, on   6th and 12th month) with date 18 months from current date        |    On 1st of Jan 2019, execute    CALL reorganizePartition('GameStatsPlayerDefaultByHalfYear','2020-06-01');          |    Run on 1st of every 3 months(i.e, on 6th   and 12th month) with first date of last 19 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('GameStatsPlayerDefaultByHalfYear','2017-05-31');          |
|    GameStatsPlayerMoneyTypeByHalfYear    |    Run on 1st of every 6th month (i.e, on   6th and 12th month) with date 18 months from current date        |    On 1st of Jan 2019, execute    CALL reorganizePartition('GameStatsPlayerMoneyTypeByHalfYear','2020-06-01');        |    Run on 1st of every 3 months(i.e, on 6th   and 12th month) with first date of last 19 month from current date    |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('GameStatsPlayerMoneyTypeByHalfYear','2017-05-31');        |

**Note : If ManualPartitionDeletionSP is not called within the mentioned duration above, then automated event takes up the drop partition with double the retention
period for the table and starts dropping the partition which is twice as old as
retention period.**

To find retention period of any table use the below query :

**_SELECT RetentionPeriod FROM PurgeRetention WHERE TableName=’&lt;Required TableName&gt;’;_**


**_ _**


**YEAR WISE PARTIONED TABLES**

For the tables mentioned in the
below table : 

Maximum partition is created till
2099-01-01

Reorganization is done till
2020-01-01

**Schedule**

|    TableName                         |    reorganizePartition                                                                       |    reorganizePartition - Example                                                                                  |    ManualPartitionDeletionSP                                                                            |    ManualPartitionDeletionSP  -   Example                                                                         |
|--------------------------------------|----------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------|
|    GameStatsPlayerByYear             |    Run on 1st January every year with date   January 1st of 2 years from current date        |    On 1st of Jan 2019, execute    CALL reorganizePartition('GameStatsPlayerByYear','2021-01-01');                 |    Run on 1st January every year with date   December 1st of previous 3rd year from current date        |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('GameStatsPlayerByYear','2016-12-31');                 |
|    NetLossByYear                     |    Run on 1st January every year with date   January 1st of 2 years from current date        |    On 1st of Jan 2019, execute    CALL reorganizePartition('NetLossByYear','2021-01-01');                         |    Run on 1st January every year with date   December 1st of previous 3rd year from current date        |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('NetLossByYear','2016-12-31');                         |
|    GameStatsPlayerDefaultByYear      |    Run on 1st January every year with date   January 1st of 2 years from current date        |    On 1st of Jan 2019, execute    CALL reorganizePartition('GameStatsPlayerDefaultByYear','2021-01-01');          |    Run on 1st January every year with date   December 1st of previous 3rd year from current date        |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('GameStatsPlayerDefaultByYear','2016-12-31');          |
|    GameStatsPlayerMoneyTypeByYear    |    Run on 1st January every year with date   January 1st of 2 years from current date        |    On 1st of Jan 2019, execute    CALL reorganizePartition('GameStatsPlayerMoneyTypeByYear','2021-01-01');        |    Run on 1st January every year with date December   1st of previous 3rd year from current date        |    On 1st of Jan, execute   CALL ManualPartitionDeletionSP('GameStatsPlayerMoneyTypeByYear','2016-12-31');        |

**Note : If ManualPartitionDeletionSP is not called within the mentioned duration above, then partitions won’t be deleted automatically.**

**_ _**

**_ _**

#### MANUAL PARTITION


This document gives an insight into the manual partition
scripts and the way to create maximum partition, reorganise the partitions
within the maximum date and manual deletion of the partition.

Stored procedure to create partition for a far future date : **maximumPartition**

   This SP is used to create a single partition for the given date. It is preferable to create a partition with a far future date to avoid any data losses and for easier
reorganisation of partition.

Stored procedure to reorganise the partition : **reorganizePartition**

  This SP is used to reorganise the partition till the provided date. The date provided should be lesser that maximum date provided in maximumPartition call for the corresponding table and greater than the current date. 

Stored procedure to delete the partitions : **ManualPartitionDeletionSP**

This SP is used to drop the partitions before the given date. **_Dropping the partition will also delete the data for all the dates
equal to and before the given date, so please be sure before calling this SP
with a date._**

**_ _**

Below is the partition interval wise division of the tables
along with the call to each of the above SP :

**DAY WISE PARTIONED TABLES **

**Table : GameStatsPlayerByDate**

For adding maximum partition :  CALL maximumPartition('GameStatsPlayerByDate','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('GameStatsPlayerByDate','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : CALL
ManualPartitionDeletionSP('GameStatsPlayerByDate','&lt;Date in YYYY-MM-DD
format&gt;');

**Table : TransactionDailyBalance**

For adding maximum partition :  CALL maximumPartition('TransactionDailyBalance','&lt;Date in YYYY-MM-DD
format&gt;');

For reorganising the partition :
CALL reorganizePartition('TransactionDailyBalance','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : CALL ManualPartitionDeletionSP('TransactionDailyBalance','&lt;Date in YYYY-MM-DD
format&gt;');

**Table : TransactionEndOfDayBalance**

For adding maximum partition :  CALL
maximumPartition('TransactionEndOfDayBalance','&lt;Date in YYYY-MM-DD
format&gt;');

For reorganising the partition :
CALL reorganizePartition('TransactionEndOfDayBalance','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : CALL ManualPartitionDeletionSP('TransactionEndOfDayBalance','&lt;Date
in YYYY-MM-DD format&gt;');

**Table : TransactionSummary**

For adding maximum partition :  CALL
maximumPartition('TransactionSummary','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('TransactionSummary','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : CALL
ManualPartitionDeletionSP('TransactionSummary','&lt;Date in YYYY-MM-DD
format&gt;');

**Table : SubscriptionBalance**

For adding maximum partition :  CALL maximumPartition('SubscriptionBalance','&lt;Date
in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('SubscriptionBalance','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : CALL
ManualPartitionDeletionSP('SubscriptionBalance','&lt;Date in YYYY-MM-DD
format&gt;');

**Table : AgentAccessHistory**

For adding maximum partition :  CALL
maximumPartition('AgentAccessHistory','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('AgentAccessHistory','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : CALL
ManualPartitionDeletionSP('AgentAccessHistory','&lt;Date in YYYY-MM-DD
format&gt;');

**Table : TransactionBalance**

For adding maximum partition :  CALL
maximumPartition('TransactionBalance','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('TransactionBalance','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : CALL
ManualPartitionDeletionSP('TransactionBalance','&lt;Date in YYYY-MM-DD
format&gt;');

**Table : TransformationLog**

For adding maximum partition :  CALL maximumPartition('TransformationLog','&lt;Date
in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('TransformationLog','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : CALL
ManualPartitionDeletionSP('TransformationLog','&lt;Date in YYYY-MM-DD
format&gt;');

**Table : Errors**

For adding maximum partition :  CALL maximumPartition('Errors','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('Errors','&lt;Date in YYYY-MM-DD format&gt;');

For dropping partition : CALL
ManualPartitionDeletionSP('Errors','&lt;Date in YYYY-MM-DD format&gt;');

**Table : JmsMessageDetails**

For adding maximum partition :  CALL maximumPartition('JmsMessageDetails','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('JmsMessageDetails','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : CALL
ManualPartitionDeletionSP('JmsMessageDetails','&lt;Date in YYYY-MM-DD
format&gt;');

**To test the above tables partition calls working, follow below steps :**

After CALL maximumPartition,

Execute : **_select
information_schema.partitions from information_schema.partitions where
Table_name=’TableName’ order by PARTITION_ORDINAL_POSITION DESC;_**

You should be able to find **TableNameYYYYMMDD **of the given date for
a particular table.

For example : If you have executed
**_CALL maximumPartition('GameStatsPlayerByDate','2040-01-01'); _**

Then on execution of **_select
PARTITION_NAME from information_schema.partitions where table_name='GameStatsPlayerByDate'
order by PARTITION_ORDINAL_POSITION DESC; _**you should be able to find **GameStatsPlayerByDate20400101**

If partition for given date is
already present, then you will get an error saying “PARTITION FOR TABLE
GameStatsPlayerByDate IS ALREADY AVAILABLE TILL 2040-01-01. PLEASE TRY WITH A
GREATER DATE.”


After CALL reorganizePartition 

Execute : **_select
PARTITION_NAME from information_schema.partitions where
Table_name=’TableName’ order by PARTITION_ORDINAL_POSITION DESC;_**

You should be able to find **TableNameYYYYMMDD **of one day greater
than the given date for a particular table.

For example : If you have executed
 **CALL
reorganizePartition('GameStatsPlayerByDate','2019-01-01');**

Then on execution of **_select
PARTITION_NAME from information_schema.partitions where table_name='GameStatsPlayerByDate'
order by PARTITION_ORDINAL_POSITION DESC; _**you should be able to find **GameStatsPlayerByDate20190102 **

 

If partition's already available you
will get list of partitions that is already present example “PARTITION FOR
TABLE - GameStatsPlayerByDate , DATE - 2019-01-02 IS ALREADY PRESENT, SKIPPING
THIS PARTITION.”


![Partition Image 1](manualPartitionImages/1.png)



Before : CALL ManualPartitionDeletionSP

Execute : **_select
PARTITION_NAME from information_schema.partitions where
Table_name=’TableName’ order by PARTITION_ORDINAL_POSITION DESC;_**

Note the PARTITION_NAME until
which you want the partition to be retained.

For example if you want to retain
data from 2018-09-01, then you will have to execute 

**CALL ManualPartitionDeletionSP('GameStatsPlayerByDate','2018-08-31');**

**Please note : This will drop all the partitions on or before 2018-08-31.**

**_ _**

**WEEK WISE PARTIONED TABLES **

**Table : GameStatsPlayerByWeek**

For adding maximum partition :  CALL maximumPartition('GameStatsPlayerByWeek','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('GameStatsPlayerByWeek','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : CALL
ManualPartitionDeletionSP('GameStatsPlayerByWeek','&lt;Date in YYYY-MM-DD
format&gt;');

**Table : NetLossByWeek**

For adding maximum partition :  CALL
maximumPartition('NetLossByWeek','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('NetLossByWeek','&lt;Date in YYYY-MM-DD format&gt;');

For dropping partition : CALL ManualPartitionDeletionSP('NetLossByWeek','&lt;Date
in YYYY-MM-DD format&gt;');

**To test the above tables partition calls working, follow below steps :**

After CALL maximumPartition,

Execute : **_select
PARTITION_NAME from information_schema.partitions where
Table_name=’TableName’ order by PARTITION_ORDINAL_POSITION DESC;_**

You should be able to find **TableNameYYYYMMDD **of the given date for
a particular table. In case of weekly tables, the YYYYMMDD above will be
monday’s date of the week in which the given date is present.

For example : If you have executed
**_CALL
maximumPartition('_****_GameStatsPlayerByWeek','2040-01-01'); _**

Then on execution of **_select
PARTITION_NAME from information_schema.partitions where table_name='GameStatsPlayerByWeek'
order by PARTITION_ORDINAL_POSITION DESC; _**you should be able to find **GameStatsPlayerByWeek20391226**

If partition for given date is already present, then you will get an error saying “PARTITION FOR TABLE GameStatsPlayerByWeek IS ALREADY AVAILABLE TILL 2040-01-01. PLEASE TRY WITH A GREATER DATE.”

After CALL reorganizePartition 

Execute : **_select
PARTITION_NAME from information_schema.partitions where
Table_name=’TableName’ order by PARTITION_ORDINAL_POSITION DESC;_**

You should be able to find **TableNameYYYYMMDD **of one week greater
than the given date for a particular table.

For example : If you have executed
**CALL reorganizePartition('GameStatsPlayerByWeek','2019-01-01');**

Then on execution of **_select
PARTITION_NAME from information_schema.partitions where table_name='GameStatsPlayerByWeek'
order by PARTITION_ORDINAL_POSITION DESC; _**you should be able to find **GameStatsPlayerByWeek20190107**


If partition’s already available
you will get list of partitions that is already present example “PARTITION FOR
TABLE – GameStatsPlayerByWeek, DATE - 2019-01-02 IS ALREADY PRESENT, SKIPPING THIS PARTITION.”

![Partition Image 2](manualPartitionImages/2.png)

Before : CALL ManualPartitionDeletionSP

Execute : **_select
PARTITION_NAME from information_schema.partitions where
Table_name=’TableName’ order by PARTITION_ORDINAL_POSITION DESC;_**

Note the PARTITION_NAME until which you want the partition to be retained.

For example if you want to retain data till the week of date 2018-09-01, then you will have to execute 

**CALL ManualPartitionDeletionSP('GameStatsPlayerByWeek ','Between 2018-08-20
to '2018-08-26');**

**Please note : This will drop all the partitions on or before week 2018-08-20.**

**_ _**

**MONTH WISE PARTIONED TABLES **

**Table : GameStatsPlayerByMonth**

For adding maximum partition :  
CALL maximumPartition('GameStatsPlayerByMonth','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('GameStatsPlayerByMonth','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('GameStatsPlayerByMonth','&lt;Date
in YYYY-MM-DD format&gt;');

**Table : NetLossByMonth**

For adding maximum partition :
CALL maximumPartition('NetLossByMonth','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('NetLossByMonth','&lt;Date in YYYY-MM-DD format&gt;');

For dropping partition :
CALL ManualPartitionDeletionSP('NetLossByMonth','&lt;Date in YYYY-MM-DD
format&gt;');

**Table : GameStatsPlayerDefaultByMonth**

For adding maximum partition :  
CALL maximumPartition('GameStatsPlayerDefaultByMonth','&lt;Date
in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('GameStatsPlayerDefaultByMonth','&lt;Date in
YYYY-MM-DD format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('GameStatsPlayerDefaultByMonth','&lt;Date in
YYYY-MM-DD format&gt;');

**Table : GameStatsPlayerMoneyTypeByMonth**

For adding maximum partition :
CALL maximumPartition('GameStatsPlayerMoneyTypeByMonth','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('GameStatsPlayerMoneyTypeByMonth','&lt;Date in
YYYY-MM-DD format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('GameStatsPlayerMoneyTypeByMonth','&lt;Date in
YYYY-MM-DD format&gt;');

**Table : PlayerTransaction**

For adding maximum partition :
CALL maximumPartition('PlayerTransaction','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('PlayerTransaction','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('PlayerTransaction','&lt;Date in YYYY-MM-DD
format&gt;');

**Table : PlayerTransactionDetails**

For adding maximum partition :
CALL maximumPartition('PlayerTransactionDetails','&lt;Date in YYYY-MM-DD
format&gt;');

For reorganising the partition :
CALL reorganizePartition('PlayerTransactionDetails','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('PlayerTransactionDetails','&lt;Date in YYYY-MM-DD
format&gt;');

**Table : Wager**

For adding maximum partition :
CALL maximumPartition('Wager','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('Wager','&lt;Date in YYYY-MM-DD format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('Wager','&lt;Date in YYYY-MM-DD format&gt;');

**Table : WagerArchive**

For adding maximum partition :
CALL maximumPartition('WagerArchive','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('WagerArchive','&lt;Date in YYYY-MM-DD format&gt;');

For dropping partition : CALL
ManualPartitionDeletionSP('WagerArchive','&lt;Date in YYYY-MM-DD format&gt;');

**Table : Winning**

For adding maximum partition :
CALL maximumPartition('Winning','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('Winning','&lt;Date in YYYY-MM-DD format&gt;');

For dropping partition : CALL
ManualPartitionDeletionSP('Winning','&lt;Date in YYYY-MM-DD format&gt;');

**Table : WinningArchive**

For adding maximum partition :
CALL maximumPartition('WinningArchive','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('WinningArchive','&lt;Date in YYYY-MM-DD format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('WinningArchive','&lt;Date in YYYY-MM-DD
format&gt;');

**Table : WagerSet**

For adding maximum partition :
CALL maximumPartition('WagerSet','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('WagerSet','&lt;Date in YYYY-MM-DD format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('WagerSet','&lt;Date in YYYY-MM-DD format&gt;');

**Table : WagerSetArchive**

For adding maximum partition :
CALL  maximumPartition('WagerSetArchive','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('WagerSetArchive','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('WagerSetArchive','&lt;Date
in YYYY-MM-DD format&gt;');

**Table : SubscriptionTransactions**

For adding maximum partition : 
CALL maximumPartition('SubscriptionTransactions','&lt;Date in YYYY-MM-DD
format&gt;');

For reorganising the partition : 
CALL reorganizePartition('SubscriptionTransactions','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('SubscriptionTransactions','&lt;Date in YYYY-MM-DD
format&gt;');

**Table : SubscriptionTransactionsArchive**

For adding maximum partition :
CALL maximumPartition('SubscriptionTransactionsArchive','&lt;Date in YYYY-MM-DD
format&gt;');

For reorganising the partition :
CALL reorganizePartition('SubscriptionTransactionsArchive','&lt;Date in
YYYY-MM-DD format&gt;');

For dropping partition : CALL ManualPartitionDeletionSP('SubscriptionTransactionsArchive','&lt;Date
in YYYY-MM-DD format&gt;');

**To test the above tables partition calls working, follow below steps :**

After CALL maximumPartition,

Execute : **_select
PARTITION_NAME from information_schema.partitions where
Table_name=’TableName’ order by PARTITION_ORDINAL_POSITION DESC;_**

You should be able to find **TableNameYYYYMM **of the given date for a
particular table.

For example : If you have executed
**_CALL
maximumPartition('GameStatsPlayerByMonth','2040-01-01'); _**

Then on execution of **_select
PARTITION_NAME from information_schema.partitions where table_name='GameStatsPlayerByMonth'
order by PARTITION_ORDINAL_POSITION DESC; _**you should be able to find **GameStatsPlayerByMonth204001**

If partition for given date is already
present, then you will get an error saying “PARTITION FOR TABLE GameStatsPlayerByMonth
IS ALREADY AVAILABLE TILL 2040-01-01. PLEASE TRY WITH A GREATER DATE.”

After CALL reorganizePartition 

Execute : **_select
PARTITION_NAME from information_schema.partitions where
Table_name=’TableName’ order by PARTITION_ORDINAL_POSITION DESC;_**

In case of normal tables, you should be able to find **TableNameYYYYMM **of
the given date for a particular table.

Incase of TransactionTables ie., for tables 'PlayerTransactionDetails','PlayerTransaction',
'Wager','WagerArchive', 'Winning','WinningArchive','WagerSet','WagerSetArchive',
'SubscriptionTransactions','SubscriptionTransactionsArchive'. You should be able to find **TableNameYYYYMM ** of one month greater than the given date for a particular table.
 

For example : 

For normal summary table :

If you have executed  **CALL reorganizePartition('GameStatsPlayerByMonth','2019-01-01');**

Then on execution of **_select
* from PARTITION_NAME where table_name='_****_GameStatsPlayerByMonth'
order by PARTITION_ORDINAL_POSITION DESC; _**you should be able to find **GameStatsPlayerByMonth201901**

If partition's already available you will get list of partitions that is already present example “PARTITION FOR TABLE – GameStatsPlayerByMonth, DATE - 201901 IS ALREADY PRESENT, SKIPPING THIS PARTITION.”

![Partition Image 3](manualPartitionImages/3.png)

For transaction table :

If you have executed  **CALL reorganizePartition('PlayerTransaction','2019-01-01');**

Then on execution of **_select
PARTITION_NAME from information_schema.partitions where table_name='_****_PlayerTransaction'
order by PARTITION_ORDINAL_POSITION DESC; _**you should be able to find **_PlayerTransaction_
201902**

If partition’s already available you will get list of partitions that is already present example “PARTITION FOR TABLE – PlayerTransaction, DATE - 2019-01-02 IS ALREADY PRESENT, SKIPPING THIS PARTITION.”

![Partition Image 4](manualPartitionImages/4.png)

Before : CALL ManualPartitionDeletionSP

Execute : **_select
PARTITION_NAME from information_schema.partitions where
Table_name=’TableName’ order by PARTITION_ORDINAL_POSITION DESC;_**

Note the PARTITION_NAME until which you want the partition to be retained.

For example if you want to retain data till the week of date 2018-09-01, then you will have to execute 

**CALL ManualPartitionDeletionSP(' GameStatsPlayerByMonth', '2018-08-30
&lt;Any date of August 2018&gt;');           **

**Please note : This
will drop all the partitions on or before week 2018-08-01.**

**_ _**

**QUARTER WISE PARTIONED TABLES **

**Table : GameStatsPlayerByQuarter**

For adding maximum partition :
CALL maximumPartition('GameStatsPlayerByQuarter','&lt;Date in YYYY-MM-DD
format&gt;');

For reorganising the partition :
CALL reorganizePartition('GameStatsPlayerByQuarter','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('GameStatsPlayerByQuarter','&lt;Date in YYYY-MM-DD
format&gt;');

**Table : NetLossByQuarterYear**

For adding maximum partition :
CALL maximumPartition('NetLossByQuarterYear','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('NetLossByQuarterYear','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('NetLossByQuarterYear','&lt;Date in YYYY-MM-DD
format&gt;');

**Table : GameStatsPlayerDefaultByQuarter**

For adding maximum partition :  
CALL maximumPartition('GameStatsPlayerDefaultByQuarter','&lt;Date in YYYY-MM-DD
format&gt;');

For reorganising the partition :
CALL reorganizePartition('GameStatsPlayerDefaultByQuarter','&lt;Date in
YYYY-MM-DD format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('GameStatsPlayerDefaultByQuarter','&lt;Date in
YYYY-MM-DD format&gt;');

**Table : GameStatsPlayerMoneyTypeByQuarter**

For adding maximum partition :  
CALL maximumPartition('GameStatsPlayerMoneyTypeByQuarter','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('GameStatsPlayerMoneyTypeByQuarter','&lt;Date in
YYYY-MM-DD format&gt;');

For dropping partition : CALL
ManualPartitionDeletionSP('GameStatsPlayerMoneyTypeByQuarter','&lt;Date in
YYYY-MM-DD format&gt;');

**To test the above tables partition calls working, follow below steps :**

After CALL maximumPartition,

Execute : **_select PARTITION_NAME
from information_schema.partitions where Table_name=’TableName’ order by
PARTITION_ORDINAL_POSITION DESC;_**

You should be able to find **TableNameYYYYMM **of the given date for a
particular table i.e, MM of start month of given quarter.

For example : If you have executed
**_CALL maximumPartition('GameStatsPlayerByQuarter','2040-01-01'); _**

Then on execution of **_select
PARTITION_NAME from information_schema.partitions where table_name='GameStatsPlayerByQuarter'
order by PARTITION_ORDINAL_POSITION DESC; _**you should be able to find **GameStatsPlayerByQuarter204001**

If partition for given date is already present, then you will get an error saying “PARTITION FOR TABLE GameStatsPlayerByQuarter IS ALREADY AVAILABLE TILL 2040-01-01. PLEASE TRY WITH A GREATER DATE.”

After CALL reorganizePartition 

Execute : **_select PARTITION_NAME from information_schema.partitions where
Table_name=’TableName’ order by PARTITION_ORDINAL_POSITION DESC;_**

You should be able to find **TableNameYYYYMM **of one quarter greater
than the given date for a particular table. i.e, MM of start month of next
quarter of given date.

For example : If you have executed
 **CALL reorganizePartition('GameStatsPlayerByQuarter','2019-01-01');**

Then on execution of **_select
PARTITION_NAME from information_schema.partitions where table_name='GameStatsPlayerByQuarter'
order by PARTITION_ORDINAL_POSITION DESC; _**you should be able to find **GameStatsPlayerByQuarter201904 **

If partition’s already available
you will get list of partitions that is already present example “PARTITION FOR
TABLE - GameStatsPlayerByQuarter , DATE - 201904 IS ALREADY PRESENT, SKIPPING
THIS PARTITION.”

![Partition Image 5](manualPartitionImages/5.png)  

Before : CALL
ManualPartitionDeletionSP

Execute : **_select
PARTITION_NAME from information_schema.partitions where
Table_name=’TableName’ order by PARTITION_ORDINAL_POSITION DESC;_**

Note the PARTITION_NAME until which you want the partition to be retained.

For example if you want to retain data from 2018-07-01, then you will have to execute 

**CALL ManualPartitionDeletionSP('GameStatsPlayerByQuarter','2018-05-30&lt;Any
date from quarter before 2018-07-01&gt;');**

**Please note : This will drop all the partitions before 2018-07-01.**

**_ _**
 
**HALF YEAR WISE PARTIONED TABLES **

**Table : GameStatsPlayerByHalfYear**

For adding maximum partition :
CALL maximumPartition('GameStatsPlayerByHalfYear','&lt;Date in YYYY-MM-DD
format&gt;');

For reorganising the partition :
CALL reorganizePartition('GameStatsPlayerByHalfYear','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('GameStatsPlayerByHalfYear','&lt;Date in YYYY-MM-DD
format&gt;');

**Table : NetLossByHalfYear**

For adding maximum partition : 
CALL maximumPartition('NetLossByHalfYear','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('NetLossByHalfYear','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('NetLossByHalfYear','&lt;Date in YYYY-MM-DD
format&gt;');

**Table : GameStatsPlayerDefaultByHalfYear**

For adding maximum partition :
CALL maximumPartition('GameStatsPlayerDefaultByHalfYear','&lt;Date in YYYY-MM-DD
format&gt;');

For reorganising the partition :
CALL reorganizePartition('GameStatsPlayerDefaultByHalfYear','&lt;Date in
YYYY-MM-DD format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('GameStatsPlayerDefaultByHalfYear','&lt;Date in
YYYY-MM-DD format&gt;');

**Table : GameStatsPlayerMoneyTypeByHalfYear**

For adding maximum partition :
CALL maximumPartition('GameStatsPlayerMoneyTypeByHalfYear','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('GameStatsPlayerMoneyTypeByHalfYear','&lt;Date in
YYYY-MM-DD format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('GameStatsPlayerMoneyTypeByHalfYear','&lt;Date in
YYYY-MM-DD format&gt;');

**To test the above tables partition calls working, follow below steps :**

After CALL maximumPartition,

Execute : **_select PARTITION_NAME
from information_schema.partitions where Table_name=’TableName’ order by
PARTITION_ORDINAL_POSITION DESC;_**

You should be able to find **TableNameYYYYMM **of the given date for a
particular table i.e, MM of start month of given half year.

For example : If you have executed
**_CALL maximumPartition('GameStatsPlayerByHalfYear','2040-01-01'); _**

Then on execution of **_select PARTITION_NAME from information_schema.partitions where table_name='GameStatsPlayerByHalfYear'
order by PARTITION_ORDINAL_POSITION DESC; _**you should be able to find **GameStatsPlayerByHalfYear204001**

If partition for given date is
already present, then you will get an error saying “PARTITION FOR TABLE GameStatsPlayerByHalfYear IS ALREADY AVAILABLE TILL 2040-01-01. PLEASE TRY WITH A GREATER DATE.”

After CALL reorganizePartition 

Execute : **_select PARTITION_NAME from information_schema.partitions where
Table_name=’TableName’ order by PARTITION_ORDINAL_POSITION DESC;_**

You should be able to find **TableNameYYYYMM **of one quarter greater than
the given date for a particular table. i.e, MM of start month of next half year
of given date.

For example : If you have executed
 **CALL reorganizePartition('GameStatsPlayerByHalfYear','2019-01-01');**

Then on execution of **_select PARTITION_NAME from information_schema.partitions where table_name='GameStatsPlayerByHalfYear'
order by PARTITION_ORDINAL_POSITION DESC; _**you should be able to find **GameStatsPlayerByHalfYear201907**

If partition’s already available
you will get list of partitions that is already present example “PARTITION FOR
TABLE - GameStatsPlayerByHalfYear , DATE - 201907 IS ALREADY PRESENT, SKIPPING
THIS PARTITION.”

![Partition Image 6](manualPartitionImages/6.png)

Before : CALL
ManualPartitionDeletionSP

Execute : **_select
PARTITION_NAME from information_schema.partitions where
Table_name=’TableName’ order by PARTITION_ORDINAL_POSITION DESC;_**

Note the PARTITION_NAME until which you want the partition to be retained.

For example if you want to retain data from 2018-07-01, then you will have to execute 

**CALL ManualPartitionDeletionSP('GameStatsPlayerByHalfYear','2018-05-30&lt;Any date from half yearbefore 2018-07-01&gt;');**

**Please note : This will drop all the partitions before 2018-07-01.**

**_ _**

**YEAR WISE PARTIONED TABLES **

**Table : GameStatsPlayerByYear**

For adding maximum partition :  
CALL maximumPartition('GameStatsPlayerByYear','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition : 
CALL reorganizePartition('GameStatsPlayerByYear','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('GameStatsPlayerByYear','&lt;Date in YYYY-MM-DD
format&gt;');

**Table : NetLossByYear**

For adding maximum partition :
CALL maximumPartition('NetLossByYear','&lt;Date in YYYY-MM-DD format&gt;');

For reorganising the partition :
CALL reorganizePartition('NetLossByYear','&lt;Date in YYYY-MM-DD format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('NetLossByYear','&lt;Date in YYYY-MM-DD format&gt;');

**Table : GameStatsPlayerDefaultByYear**

For adding maximum partition : 
CALL maximumPartition('GameStatsPlayerDefaultByYear','&lt;Date in YYYY-MM-DD
format&gt;');

For reorganising the partition : 
CALL reorganizePartition('GameStatsPlayerDefaultByYear','&lt;Date in YYYY-MM-DD
format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('GameStatsPlayerDefaultByYear','&lt;Date in YYYY-MM-DD format&gt;');

**Table : GameStatsPlayerMoneyTypeByYear**

For adding maximum partition :
CALL maximumPartition('GameStatsPlayerMoneyTypeByYear','&lt;Date in YYYY-MM-DD
format&gt;');

For reorganising the partition :
CALL reorganizePartition('GameStatsPlayerMoneyTypeByYear','&lt;Date in
YYYY-MM-DD format&gt;');

For dropping partition : 
CALL ManualPartitionDeletionSP('GameStatsPlayerMoneyTypeByYear','&lt;Date in
YYYY-MM-DD format&gt;');

**To test the above tables partition calls working, follow below steps :**

After CALL maximumPartition,

Execute : **_select PARTITION_NAME from information_schema.partitions where
Table_name=’TableName’ order by PARTITION_ORDINAL_POSITION DESC;_**

You should be able to find **TableNameYYYY **of the given date for a
particular table.

For example : If you have executed
**_CALL maximumPartition('_****_GameStatsPlayerByYear','2040-01-01'); _**

Then on execution of **_select
PARTITION_NAME from information_schema.partitions where table_name='GameStatsPlayerByYear'
order by PARTITION_ORDINAL_POSITION DESC; _**you should be able to find **GameStatsPlayerByYear2040**

If partition for given date is already present, then you will get an error saying “PARTITION FOR TABLE GameStatsPlayerByYear IS ALREADY AVAILABLE TILL 2040-01-01. PLEASE TRY WITH A GREATER DATE.”

After CALL reorganizePartition 

Execute : **_select PARTITION_NAME from information_schema.partitions where
Table_name=’TableName’ order by PARTITION_ORDINAL_POSITION DESC;_**

You should be able to find **TableNameYYYY **of the given date for a
particular table.

For example : If you have executed
 **CALL reorganizePartition('****GameStatsPlayerByYear','2019-01-01');**

Then on execution of **_select PARTITION_NAME from information_schema.partitions where table_name='GameStatsPlayerByYear'
order by PARTITION_ORDINAL_POSITION DESC; _**you should be able to find **GameStatsPlayerByYear2019**

If partition’s already available
you will get list of partitions that is already present example “PARTITION FOR
TABLE - GameStatsPlayerByYear , DATE - 2019 IS ALREADY PRESENT, SKIPPING THIS
PARTITION.”

![Partition Image 7](manualPartitionImages/7.png)

Before : CALL ManualPartitionDeletionSP

Execute : **_select PARTITION_NAME from information_schema.partitions where
Table_name=’TableName’ order by PARTITION_ORDINAL_POSITION DESC;_**

Note the PARTITION_NAME until which you want the partition to be retained.

For example if you want to retain data from 2018-01-01, then you will have to execute 

**CALL ManualPartitionDeletionSP('GameStatsPlayerByYear','2017-05-30&lt;Any
date from year before 2018-01-01&gt;');**

**Please note : This will drop all the partitions before 2018-01-01.**

**_ _**
