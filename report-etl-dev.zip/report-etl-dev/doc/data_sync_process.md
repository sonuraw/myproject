Data Sync Processing in Report-etl
==========================================

#### Check the data sync job is running or not 
 ```roomsql
Select * FROM report.JmsTopicIndex;
```
Cron Job status is maintained in JmsTopicIndex table 
For each service, there will be row with the max event id compared last and jon ran date against it
The row, with the topic - 'cronStatus', denotes the cron running status, if it is 1, then the cron is running now, 
    if zero, not running now, last ran date can be seen in updatedDate field
       
#### Check any missed event identified by the cron job
```roomsql
Select * FROM EventDispatcherMissingStore;
``` 
If any rows returned in the above query, then those events are not processed in report-etl and those needs to be processes manually .
The list will return the event id's with the service name against it.

#### Are they really missed out !
To find, are they really missed in report-etl process
```roomsql
Select * FROM report.JmsMessageDetails Where EventId In () AND Topic In ('transaction-dli-report', 'transaction-dlo-report');
```
If the above query returns the zero results, it means that you have to process the events, following the steps bellow. 
If the records are there, you can just remove the records from the EventDispatcherMissingStore table.

#### Eager to See what type of events are those?
use the below query to see the event json before processing in report-etl 
```roomsql
Select * from transactions.events Where Id In ();
```

#### To process the missing events 
We can process the events one by one service . not altogether we cant process.
So, if we need to process the wallet events  , use the below query as it is.
```roomsql
SET SESSION GROUP_CONCAT_MAX_LEN=330000009999;
Select group_concat(CONCAT('"', EventId, '"')) FROM EventDispatcherMissingStore Where ServiceName = 'wallet' Order By EventId ASC;
```

The result, we should use in the below curl call of report-etl
On posting this call, the events json will be fetched from respective service events and will be stored in report.EtlServiceErrorLog table and from there it will get process in the reProcessErrorLog cron job (currently it is scheduled as 10 min once).

```bash
curl -X POST --header 'Content-Type: application/vnd.api+json' --header 'Accept: application/json' -d '{ \ 
"eventIdList": [ \ 
"1100" \ 
], \ 
"serviceName": "wallet" \ 
}' 'http://localhost:11005/dataSync/processMessages/wallet'
```

The same api can be accessed in report-etl swagger too - 
```bash
http://localhost:11005/documentation#!/Data32Sync/processMessages
```

* use the service name in the url param , as well as in the post body correctly - should be same (wallet in this case)
* eventid array list should be used within the post.body.eventIdList array holder in the format as returned in the sql query.
* Hit the Api only once for one set of event ids, dont trigger multiple times with the same events, may result in data collapse.  




To make sure, the api call was succeeded , use the below query .

```roomsql
Select E.* FROM report.EtlServiceErrorLog E inner join JmsMessageDetails J
ON E.CorrelationID = J.JmsMessageId AND J.Topic = E.Topic
Where J.Topic In ('transaction-dli-report', 'transaction-dlo-report') AND J.EventID in (<events identified in Store table>);
```
topic names in (IN Cndn) should be based on events topic name .(can get from Select * from transactions.events Where Id In () -- in wallet case). 
