# Report ETL Service change log

- [2.27.0](release-notes/2.x/2.27.0.md)
- [2.26.3](release-notes/2.x/2.26.3.md)
- [2.26.2](release-notes/2.x/2.26.2.md)
- [2.26.1](release-notes/2.x/2.26.1.md)
- [2.26.0](release-notes/2.x/2.26.0.md)
- [2.25.0](release-notes/2.x/2.25.0.md)
- [2.24.0](release-notes/2.x/2.24.0.md)

### 2.23.0 / 2019-10-15
* DSPAM-26769 - Report-etl - Expected end date should be null if not provided (no more default based on wager creation date) 
* DSPAM-26698 - Wallet - Payment method events invalid date format (report-etl support) 
* DSPAM-25579 - Delay when bets is shown in active games - rebalancing required after deployments

### 2.22.1 / 2019-10-01
* DSPAM-26624 - T20-MySQL8 - Transaction Aggregation(Wager AGG) Job got failed 

### 2.22.0 / 2019-09-27
* DSPAM-26335 - report-service - stored procedure change - mysql 8 compartablity

### 2.21.1 / 2019-09-26
* DSPAM-26575 - T20-CR129-Wager Expected_End_Date Storing As Null

### 2.21.0 / 2019-09-23
* DSPAM-26450 - CR129: Report Service Jasper and SP changes 

### 2.20.1 / 2019-09-17
* DSPAM-26499 - Null pointer Exception in Processing Subs Template Archive

### 2.20.0 / 2019-09-16
* DSPAM-26449 - CR129: Additional Fields for Gaming History (report-etl changes)
* DSPAM-26404 - Process the eventDispatcher missing events directly into Report DB

### 2.19.2 / 2019-09-05
* DSPAM-26333 - BO-batchlog scheduled reports are not working
* DSPAM-26312 - T20_BO-limit report is not genarating- Mysql 8
* DSPAM-26348 - Null pointer Exception - SubscriptionUpdate

### 2.19.1 / 2019-08-28
* DSPAM-26269 - upam-etl: health page is not working due to transformation name change in Transaction Aggregation Job - SP
* DSPAM-26290 - UPAM_TeamsAndLeagues_Purpose is displayed as 'Competition' on Report database - Teams table

### 2.19.0 / 2019-08-23
* DSPAM-26222 - PlayTogether : Report-ETL & DWH side changes
* DSPAM-26239 - PFI -get player transactions is not working
* DSPAM-26165 - BO- UI- Create a new report batch logs (link to the jasper report)

### 2.18.0 / 2019-08-14
* DSPAM-26164 - Build a Jasper report for batch log

### 2.17.0 / 2019-08-05
* DSPAM-26145 - PlayerTransaction_stage table - Implement the functionality to delete the partition automatically

### 2.16.0 / 2019-08-05
* DSPAM-25809 - Report-Etl Consumption of new topic (queue:batch-execution)
* DSPAM-26012 - UPAM_Subscription_Incorrect Next Funding date shown on Back Office for Bank + Gap Funded subscriptions
* DSPAM-26038 - T20-mysql8:upam-etl-WS Report health is failing
* DSPAM-26064 - Global session and player session reports should allow searching for unsuccessful logins

### 2.15.0 / 2019-07-18
- DSPAM-21221 - upam-etl : Batch Log for Summary Job - LiveDataCronTrigger.sh - cron
- DSPAM-21209 - upam-etl : Batch Log for Genesys Job - GenesysEtl.sh - cron
- DSPAM-21203 - upam-etl : Batch Log for  WS Report Reconcile - WithdrawalSummaryReconciliationCheck.sh -  cron

### 2.14.1 / 2019-07-15
* DSPAM-25871 - Nagios alert implementation if etl-error log tables starts growing and crosses the threshold

### 2.14.0 / 2019-07-11
* DSPAM-25789 - Subcription BO - FAILURE status remains on NONE
* DSPAM-25842 - Reports : SubscriptionTransactions : PurchaseStatus filter for value 'None' not working

### 2.13.0 / 2019-07-01
* DSPAM-25774 - Self-exclusion report - ended exclusions
* DSPAM-25750 - Several Service Alerts Problem - reports processing stopped

### 2.12.0 / 2019-06-24
* DSPAM-25750 - CLONE - Suspension report not working

### 2.11.1 / 2019-06-18
* DSPAM-25712 - player-login-failed not saving the reason value in report DB

### 2.11.0 / 2019-06-17
* DSPAM-25701 - Failed login report contains timeout and manual logouts. should contains "errors" only

### 2.10.1 / 2019-06-12
* DSPAM-25661 - Global Transaction History timeout
* DSPAM-25253 - CR123: CSR service related to transaction Data (CSR - Retrieve total deposit / wager / win on a given period (including count of deposits)

### 2.10.0 / 2019-06-10
* DSPAM-25588 - Social network with id {} not found
* DSPAM-25574 - UPAM_Subscription_Next Funding date on BO reports is incorrect for a gap funded subscription which is kept on on-hold

### 2.9.1 / 2019-05-29
* DSPAM-25542 - delete-profile should be based on player topic in case of report-etl (TermsAndCondAckEntity)

### 2.9.0 / 2019-05-27
* DSPAM-25111 - Wallet - add meta and data fields in events - update transaction-dl(i|o)-report & CreatedLedger consumers
* DSPAM-25542 - delete-profile should be based on player topic in case of report-etl 

### 2.8.0 / 2019-05-14
* DSPAM-25456 - WagerSet Based Wager throws Constraint Violation Exception 

### 2.7.1 / 2019-05-09
* DSPAM-25435 - SuppressException listed should not be reprocessed in ETLServiceErrorLog (report-etl)
* DSPAM-25436 - CR73b- violates GTID consistency - SP fixes

### 2.7.0 / 2019-05-06
* DSPAM-23719 - Reports - delete all data and propagate the deletion to datawarehouse
* DSPAM-22819 - CR73b: Aggregate consecutive transactions per game session

### 2.6.1 / 2019-04-25
* DSPAM-24616 - Add purge feature on player_card, withdraw, withdraw_requestId, ThirdPartyError
* DSPAM-25349 - Handle the duplicate processing of same deposit events (non-XA)

### 2.6.0 / 2019-04-23
* DSPAM-25284 - Report ETL change for Total Cost Per Week calculation for "Game Id 80 All or Nothing" like "Game Id 13 Keno"
* DSPAM-24807 - Add the service name as user agent when sending requests to other services

### 2.5.0 / 2019-04-17
* DSPAM-25238 - Invalid PFI API request returns actual data
* DSPAM-24528 - XA removal in Report-ETL service (Support both XA & Non-XA)

### 2.4.0 / 2019-04-08
* DSPAM-24999 - EtlServiceErrorLog / EventDispatcherMissingStore - Alert Implementation
* DSPAM-25152 - PAM Subscription: Possible visual error in "Next funding date" 

### 2.3.0 / 2019-03-29
* DSPAM-24584 - Upgrade to MySQL 8 - compatibility with 5.7 AND 8 (Report-etl)
* DSPAM-25110 - Remove the wallet's health endpoint & other related dependencies in report-etl service

### 2.2.0 / 2019-03-18
* DSPAM-25022 - UPAM_Subscription_Subscriptions modified by agent are shown as Player
* DSPAM-25025 - ETLServiceError log - Null pointer Exception - Subscription Report queue
* DSPAM-25023 - CreatedAt is wrongfully changed with updates (PlayerProfile)
* DSPAM-25036 - Performance Impact on CRUD Operations in JMSMessageDetails table on AMQ subscribe

### 2.1.0 / 2019-03-18
* DSPAM-24938 - Reports timeouts when frontend tries to find if any withdrawal is pending

### 2.0.0 / 2019-03-11
* DSPAM-24906 - Purge Retention for Txn related report tables should be > 2 years
* DSPAM-24914 - Chronological order on account history is wrong

### 1.99.0 / 2019-03-04
* DSPAM-24325 - CR110: Exclusions -Restrictions History Log

### 1.98.0 / 2019-02-25
* DSPAM-24743 - PlayerAddress Update Event Issue


### 1.97.3 / 2019-02-20
* DSPAM-24724 - De-Queuing the notification-broker-errors by storing it in Report DB
* DSPAM-24721 - Missing records in Player.Profile

### 1.97.2 / 2019-02-18
* DSPAM-24706 - Null Pointer Exception in ProcessZeroWagers

### 1.97.1 / 2019-02-13
* DSPAM-24667 - Start date, draw date, wrong in Subscription view

### 1.97.0 / 2019-02-11
* DSPAM-24402 - Delay when purchasing number games coupons for multiple weeks - gap in event id - data sync enabled
* DSPAM-24460 - Document to detect the dead lock - observed on DC2 Switch
* DSPAM-24482 - Status update issue in gvi
* DSPAM-22905 - Standardize accesslog formats

### 1.96.0 / 2019-02-05
* DSPAM-24491 - Town 36 - Missing transactions in PAM / report etl dup entries
* DSPAM-24302 - Method - This specific method is not represented as a value in the dropdown "Method"
* DSPAM-24500 - DWH Pentaho Job - Disabled then Health API status should show "true"

### 1.95.1 / 2019-02-04
* DSPAM-24486 - UPAM-Etl health issue for ExcludedPlayerRegistrationAttempt
* DSPAM-24182 - Subscription template payment method edit triggering- Back office version history showing the tickets count and amount wrong.
* DSPAM-24462 - New closed reason to consider: inactive

### 1.95.0 / 2019-01-28
* DSPAM-24205 - CR105: New Payment option Mobile Pay and DKK app
* DSPAM-24182 - Subscription template payment method edit triggering- Back office version history showing the tickets count and amount wrong.
* DSPAM-24335 - Report-ETL report.EtlServiceErrorLog table add partition and auto deletion of partition 

### 1.94.0 / 2019-01-09
* DSPAM-24028 - Reports: In SQL queries chanage find_in_set to OR condition for better performance 
* DSPAM-24168 - Data truncation: Incorrect date value: '20192019-01-08' for column 'DateLimitExceeded 

### 1.93.0 / 2019-01-03
* DSPAM-23621 - WS report - Alert Implementation (Reconcilation amount with bank file, Bank service down)

### 1.92.1 / 2018-12-28
* DSPAM-24078 - Handle Constraint Violation Exception for Zero Wager Creation  (Handle Wager - Cancelled Scenario)

### 1.92.0 / 2018-12-27
* DSPAM-24020 - Negative Balances - It is not the latest transaction being shown 
* DSPAM-24023 - Delay in active MQ transaction related queues 
* DSPAM-24078 - Handle Constraint Violation Exception for Zero Wager Creation 

### 1.91.0 / 2018-12-17
* DSPAM-23782 - No values in PaymentMehodId in subscription.SubscriptionItem
* DSPAM-23993 - CLONE - PlayerId/Username Search text box is not working in efficient mode( in DB username having numeric values)- ALL Reports

### 1.90.0 / 2018-12-10
* DSPAM-22991 - CR-89(4/4): TS report - New shortcode - Send a message when a new shortcode is created
* DSPAM-23729 - PlayerId/Username Search text box is not working in efficient mode( in DB username having numeric values)
* DSPAM-23717 - ExpectedSpendLimit table growth
* DSPAM-23736 - Game Cycles Pending/Voids timeouts often

### 1.89.1 / 2018-12-05
* DSPAM-22066 - TSR - Remarks Update
* DSPAM-23782 - No values in PaymentMehodId in subscription.SubscriptionItem

### 1.89.0 / 2018-12-03
* DSPAM-23674 - Removed self-exclusions are still shown as active in the report
* DSPAM-23606 - Game Channel "INTERNAL" Is Not Displayed In BO (Instead of "INTERNAL" another Channel is Displayed)
* DSPAM-23625 - Events Data Sync should be able to run with proper index / control to check if any missed records without processing 
* DSPAM-23678 - Report ETL Start Up Order should be Mysql Connection / Atomikos Mysql / Atomikos AMQ

### 1.88.1 / 2018-11-28
* DSPAM-23651 - Pentaho - TSR/GS reconciliation - Implement the month range validation check and alert

### 1.88.0 / 2018-11-26
* DSPAM-23600 - Units Cancelled Won is miss matching Due to missing of "INTERNAL" Game channel
* DSPAM-23320 - Pentaho - Game Stats By Player Job - Optimization & Improvements
* DSPAM-23496 - TSR reconciliation failure alert - considers yesterday's end of day balance matches today's start day balance
* DSPAM-23536 - Implement the TS and GS Reconcile Alert -  for each day of job running

### 1.87.0 / 2018-11-19
* DSPAM-23384 - Report: Expected Spend Limit report timedout in Prod.
* DSPAM-23446 - JmsMessageDetails Purge Retention changes & Archive table needs to be purged only after exported to DWH 

### 1.86.2 / 2018-11-15
* DSPAM-22855 - Missing creditcardtype in player.PaymentMethod (creationDate fix)

### 1.86.1 / 2018-11-14
* DSPAM-22855 - Missing creditcardtype in player.PaymentMethod (missing entry in Archive table - fix) - (handle the delete event)

### 1.86.0 / 2018-11-13
* DSPAM-23160 - Registry Comparison issues (Change level type from int to varchar in report db (PlayerAddress and PlayerAddressArchive))
* DSPAM-23441 - Handle Constraint Violation Exception for Zero Wager Creation

### 1.85.0 / 2018-11-12
* DSPAM-23305 - Negative balances - Disappear from the list when write off but still negative balance
* DSPAM-21225 - Amendment of subscription should not affect Next Draw Date
* DSPAM-23379 - Game Cycles Pending/Voids timeouts often
* DSPAM-21223 - StartDate missing in subscription.Subscription
* DSPAM-22453 - Missing few information in WagerSet Message

### 1.84.1 / 2018-11-08
* DSPAM-23327 - RevisionNumber should be bigint in report DB

### 1.84.0 / 2018-11-05
* DSPAM-23208 - Report ETL side changes

### 1.83.2 / 2018-10-31
* DSPAM-23144 - WS reports - Sometimes missing few transactions due to 1sec different in creation date
* DSPAM-22855 - Missing creditcardtype in player.PaymentMethod (missing entry in Archive table - fix)
* DSPAM-23115 - Report ETL listen the AMQ message  will get the entire list of instance and calculate the dates

### 1.83.1 / 2018-10-30
* DSPAM-21809 - Merge gvi topics related to wager-set/wager/winning into a single queue (Json mapping exception handled)

### 1.83.0 / 2018-10-29
* DSPAM-23039 - Payment method info is not available in transaction tables for the new deposits creating  (depends on wallet release)
* DSPAM-23061 - Config based ProcessedEtlErrorLog entry and Reprocess the Error Messages based on config RetryCount (2 min cron should be handled differently)
* DSPAM-23074 - Negative Balances - There are some with positive balance
* DSPAM-23124 - PAM 19.5.0: Not able to generate report on External Game Wallet -  status: 500
* DSPAM-22649 - CLONE - Not possible to make Analysis report - timeout

### 1.82.0 / 2018-10-22
* DSPAM-22870 - House Number should support letters
* DSPAM-22936 - Pentaho: NetLoss related jobs performance improvements(add indexes)
* DSPAM-22926 - Revisiondate is less than CreatedAt


### 1.81.0 / 2018-10-15
* DSPAM-22605 - WS report - Forced accepted/forced rejected (depends on wallet new release)
* DSPAM-22677 - Report-Etl not getting reconnect after disconnects from AMQ in T20 / T23 (Caused due to OOM Error)
* DSPAM-22885 - Method (creditcard type) is not translated correct into TS(shortcode)

### 1.80.1 / 2018-10-09
* DSPAM-22785 - UPAM_Subscription_Unable to sort through the available filters on Subscription Transactions page

### 1.80.0 / 2018-10-08
* DSPAM-22065 - Data sync missing some events to process
* DSPAM-22667 - Subscriptions - BO - Comment for cancelled wallet transaction is not displayed under subscription transaction report - Town 20

### 1.79.2 / 2018-10-04
* DSPAM-22065 - Data sync missing some events to process
* DSPAM-22336 - Reports: All reports should allow to download all data while using Export (options if there is no explicit DefaultRecordCount opted by Agent )

### 1.79.1 / 2018-10-03
* DSPAM-22336 - Reports: All reports should allow to download all data while using Export (options if there is no explicit DefaultRecordCount opted by Agent )

### 1.79.0 / 2018-09-28
* DSPAM-22446 - Limit Details are not in Sync in Report SCS
* DSPAM-22519 - Null pointer Exception on Cancelling the Credit-Refund Transaction
* DSPAM-22454 - Wager Set External Id stored as null in report DB whereas having some value in GVI
* DSPAM-22441 - Created Date is greater than Updated Date for Wager and Win Records.
* DSPAM-22376 - Analyse and update the fix

### 1.78.1 / 2018-09-25
* DSPAM-22336 - Reports: All reports should allow to download all data while using Export (options if there is no explicit DefaultRecordCount opted by Agent )
* DSPAM-22099 - New Partition Changes

### 1.78.0 / 2018-09-24
* DSPAM-22224 - Report-etl - Do not log expected errors as errors (messages going into reprocessing)
* DSPAM-22312 - ETL Changes to consume from SubscriptionAPI.queue (subTask of etl changes - DSPAM-22311) 
* DSPAM-22244 - Handle the withdrawal abandoned  (second time -with no balance change) scenario in Report ETL 

### 1.77.0 / 2018-09-17
* DSPAM-22160 - ETL Service Reprocess Concurrent Error and ReProcess Improvement

### 1.76.3 / 2018-09-07
* DSPAM-22042 - Cancelled Winning Transaction is not reflecting in Report BO, appearing still as accepted
* DSPAM-21966 - Wager issue Analysis

### 1.76.2 / 2018-09-06
* DSPAM-21955 - Missing UpdatedAt column for multiple tabels
* DSPAM-21761 - UPAM_Subscription_Add on Subscriptions are displayed as add_on - false in BO
* DSPAM-21851 - [T27] AuthorPlayerId and AuthorAgentId both contain values at the same time in player.Card
* DSPAM-21849 - [T27] AuthorPlayerId and AuthorAgentId both contain values at the same time in player.Affiliation
* DSPAM-21859 - [T27] EventType contains values not allowed in player.Profile
* DSPAM-21857 - [T27] EventType contains values not allowed in player.PaymentMethod
* DSPAM-21854 - [T27] EventType contains values not allowed in player.Comments
* DSPAM-21846 - [T27] EventType contains values not allowed in player.Address
* DSPAM-21850 - [T27] EventType contains values not allowed in player.Affiliation
* DSPAM-21855 - [T27] EventType contains values not allowed in player.Identification

### 1.76.0 / 2018-09-03
* Duplicate Constraint Violation Exception (Purchase-send.queue topic messages)(DSPAM-21930)
* Temporary solution to consume all the pending messages in upam_gvi_winning_status_update(DSPAM-21923)
* Queue Consumer Support for gvi SCS
* try / catch block added for JSONParse Exception

### 1.75.6 / 2018-08-31
* Fee value issue fix in PlayerTranEntity

### 1.75.5 / 2018-08-30
* Purchase-send Queue Concurrency error - reprocessing separated from ProcessAllErrors (DSPAM-21618)
* Added the options to process the error on topic based 
* Suppressing the Winning's exists status matched with the incoming status

### 1.75.2 / 2018-08-28
* Added the logs to identify the Subscription Purchase State Update Issue (DSPAM-21618)

### 1.75.1 / 2018-08-27
* Move the Report ETL related crpon to Report ETL Service (DSPAM-21762)
* Back Office is not updating parts of the subscription information (DSPAM-21618)

### 1.74.9 / 2018-08-23
* Slow consuming of upam_gvi_wager_create messages in Report ETL (DSPAM-21759)
* Adding proper logs to identify processed evenId through data sync (DSPAM-21767)

### 1.74.0 / 2018-08-21
* Release version update

### 1.73.5 / 2018-08-21
* Fix for session leak
* Update to fix gvi state update issue

### 1.73.4 / 2018-08-20
* DSPAM-21374 - Implement data reconciliation / sync process in reports
* Jms topic index column changed to big int 20
* Track table changes column value
* Log addition changes

### 1.73.3 / 2018-08-19
* DSPAM-21374 - Implement data reconciliation / sync process in reports

### 1.73.2 / 2018-08-17
* DSPAM-21374 - Implement data reconciliation / sync process in reports

### 1.73.1 / 2018-08-17
* DSPAM-21374 - Implement data reconciliation / sync process in reports

### 1.73.0 / 2018-08-14
* DSPAM-21374 - Implement data reconciliation / sync process in reports

### 1.72.1 / 2018-08-10
* DE10017 - SessionId & Currency Information missing in the report for wagers created with wager-set
* DE9907 (TA21285) - TS at T22 for both DLI and DLO don't reconciliate - ETL Service Error Log changes
* DE10018 - Update accepted/rejected deposit with previous status abandoned
* DE9827 (TA21287)- Remove the sourceId & correlationId in the log format in etl service
* DE9917 - Financial/GTHD/Subtype - drop down

### 1.72.0 / 2018-08-06
* DE9963 - Game Stats: Type of funds: What is External?
* Active MQ Health check - max Connection Attempts added
* DE9877 - Implement data reconciliation / sync process in reports
* DE9575 - Playercard - Fill out Game cycle_id for automatic credit of the  (subtype=retailer payment)
* DE9847 - Offline credit "retailer-payment" have game cycle id = 0
* DE9908 - The difference at TS "Reconcile Diff Amount" is not shown at the report Player Reconcile Report
* DE9979 - DWH :  Add script to add of new transformation into JournalJobLog Table

### 1.71.1 / 2018-08-03
* DE9833 - Financial reports - TS and game stats - Implementing alerts when the reports is not reconciliating og been fully updated
* DE9959 - Player Card Winnings - Payout - Report is empty

### 1.71.0 / 2018-08-01
* DE9827 (TA21045) - Cleanup logs - report-etl-log format change

### 1.70.0 / 2018-07-27
* DE9871 - PAM 18.2.0 Profile: Country column is empty on Session tab
* US6851 - SQL injection prevention in Store Procedure

### 1.69.1 / 2018-07-24
* US6849 - [Unfinished] [Continued] Reports Analysis and Verification, Improvements

### 1.69.0 / 2018-07-23
* DE9783 - Split transactions queues into DLI and DLO

### 1.68.2 / 2018-07-19
* US6817 - [Continued] [Continued] ETL Job Running status / Summary reports data availability display in Back office

### 1.68.1 / 2018-07-17
* DE9780 - Undo the Jms Message Details index & Add the TransactionType / Subtype missing entries
* DE9581 - T23: ExternalCreationDate and ExternalCreationDateUTC milliseconds are truncated after updates in ga.Wager
* DE6192 - PAMGVI-50 - Third Party errors emails are not delivered (3rd party CPR)

### 1.68.0 / 2018-07-16
* DE9780 - Transaction manager identifier collides between services in town27
* DE9581 - T23: ExternalCreationDate and ExternalCreationDateUTC milliseconds are truncated after updates in ga.Wager
* US6830 - [Unfinished] Monitor and analyse issues in cucumber beta
* US6703 - [Continued] Create data sync scripts for all tables in report DB

### 1.67.1 / 2018-07-13
* DE9765 - Use AMQ_HOSTS env variable - to get the amq hosts ip address
* DE9743 - SubTransactions - Deposit Null pointer Exception
* DE9769 - Track the eventId for wallet message in ETL JmsMessageDetails table

### 1.67.0 / 2018-07-09
* US6807 - Monitoring ETLServiceErrorLog in Iteration 27
* DE9489 - T23: Duplicate rows in ga.Wager
* DE9407 - SUBSCRIPTION BO: In the Subscriptions Transactions Failure list amount is displayed incorrect
* DE9347 - Handle activemq slave in the application

### 1.66.1 / 2018-07-06
* DE9699 - Financials/TS report - Removing/adding credit/debit shortcodes (subtypes) + adjustment

### 1.66.0 / 2018-07-02
* DE9600 - Include the subscription ledger true or false in the all wallet transactions message  subscription:true / false
* US6791 - ETL Service Message Consumer Logging Improvements
* DE9650 - Getting Message is too old for GVI status update for win
* US6797 - [Unfinished] Meter results and fixes of All reports on Town27
* US6799 - [Unfinished] Revised logic for reprocess date
* DE9561 - Game Manager DB  and Report DB sync
* DE9581 - T23: ExternalCreationDate and ExternalCreationDateUTC milliseconds are truncated after updates in ga.Wager 

### 1.65.1 / 2018-06-28
* DE9571 - Remove the MYSQL_POOL_SIZE env value from ddc as well as in Report ETL Code Usage
* DE9561 - Game Manager DB  and Report DB sync
* DE9561 - T23: Value in ga.WagerSet is not equal to Amount in account.Transaction
* DE9596 - Undo the exclusion-events-json.topic queue re-direction in Exclusion as well as in ETL
* TA20530 - Config level changes to support VitualTopic and testing the same - Report ETL Service

### 1.65.0 / 2018-06-25
* DE9550 - Missing jta prop "force_shutdown_on_vm_exit"
* US6750 - Hibernate Performance Analyse & Code Changes in Report ETL Service
* DE9486 - UPAM_Subscription_New version history is not created, every time when a change is made to a template from Subscription API
* DE9212 - Subscriptions: Funding event must not create new revision under Version Details
* DE9147 - Subscriptions:Subscriptions created with Credit Card is Displayed as Bank Account in BO

### 1.64.0 / 2018-06-18
* DE9371 - UPAM_Subscription_Changing Payment Method from Bank1 - Bank 2 archives current and creates new template. But the new template not displayed on BO
* DE9312 - Capture CostPerDraw from SubscriptionGames table
* DE9293 - Subscriptions - BO - Updating subscription resets the "CreatedBy" field in players subscription report
* DE9213 - Subscriptions: Erroneous revision under Version Details
* DE9120 - Not possible to identify players with NemID validation
* US6700 - Add new  channel column in [player].[LoginSession]
* US6624 - Extend Cukes test for the missing scenarios
* DE9261 - T23: CreatedAt larger than UpdatedAt in ga.WagerSet

### 1.63.0 / 2018-06-11
* DE9294 - T23: PlayerId in account.Transaction is missing a match in player.Profile
* DE9200 - Subscription - Report - Status didn't update in BO after M603 execution
* DE7862 - T23: WagerIds in ga.Wager missing matching key in account.Transaction

### 1.62.1 / 2018-06-08
* DE9270 - T23: PaymentMethodId in account.Transaction has no matching key in player.PaymentMethod
* DE9262 - T23: NumberOfTransactions in ga.WagerSet does not reflect number of Wagers in a WagerSet
* DE9254 - T23: CreatedAt larger than GETDATE() in player.PaymentMethod
* DE9251 - T23: EventType value in player.PaymentMethod is not allowed
* DE9269 - T23: CreatedAt is larger than UpdatedAt in ga.Winning
* DE9267 - T23: EventType value in ga.Winning is not allowed
* DE9263 - T23: Value in ga.WagerSet is not equal to Amount in account.Transaction
* DE9261 - T23: CreatedAt larger than UpdatedAt in ga.WagerSet
* DE9239 - T23: AuthorAgentId in player.Address is missing a matching key in agent.Profile
* DE9191 - T23: Issue with BalanceAfter in account.Transaction

### 1.62.0 / 2018-06-04
* US6566 - Performance run of ETL - XA Rollback Options
* DE9106 - Subscriptions: Winnings sent to selected as National Account number is Displayed as credit card in BO
* DE9083 - Reports - not returning data
* DE9062 - UPAM_Subscription_Town 21_Purchase status - success is appearing for all Win Transactions (Town 21)
* DE8738 - T23: SubscriptionIds from subscription.SubscriptionItem missing in subscription.Subscription
* DE8662 - T23: WinningsSentTo in subscription.Subscription is missing key in player.PaymentMethod
* DE8481 - Subscriptions: All purchase attempts must be shown in Back Office
* DE8185 - BO - Player's Subscription & Global Subscriptions - Winnings Sent to with bankAccount - National number does not show in Information Icon (i)
* DE7972 - Start date for subscriptions
* DE9202 - ETL Service Error log producing lot of MessageConsumerSession: Error ending thread tx association

### 1.61.0 / 2018-05-30
* DE8870 - Security - SQL injection vulnerabilities
* DE9112 - Player Card Winnings Payout : Show only processing transactions game

### 1.61.0 / 2018-05-28
* US6566 - Atomikos module change to get the MYSQL XA Tran Id (TA19600)
* DE9062 - UPAM_Subscription_Town 21_Purchase status - success is appearing for all Win Transactions (Town 21)
* US6636 - Monitor EtlServiceErrorLog table for new issues
* DE8481 - Subscriptions: All purchase attempts must be shown in Back Office
* DE8185 - BO - Player's Subscription & Global Subscriptions - Winnings Sent to with bankAccount - National number does not show in Information Icon (i)

### 1.60.1 / 2018-05-22
* DE8997 - Amount should be shown in opposite sign while cancel or reject the transaction

### 1.60.0 / 2018-05-21
* DE8961 - Logging: avoid constant logging about WARN: Establishing SSL connection without server's identity verification is not recommended
* US6625 - Improvements Transaction Summary Report and ETL Service Logs
* DE8997 - Amount should be shown in opposite sign while cancel or reject the transaction

### 1.59.1 / 2018-05-18
* DE8993 - Linked Transaction Id Overflow Issue

### 1.59.0 / 2018-05-15
* DE8902 - Report ETL java.lang.IllegalStateException: This method needs a transaction for the calling thread and none exists.
* DE8849 - Java AMQ Consumer service does the duplicate attempt to subscribe the topic which is already subscribed in case of redis data loss (heartbeat key)
* DE8894 - Add data.failureReason and move data.attributes.purchasedGameDetails.resultCode to data.resultCode
* DE8878 - UPAM_Subscription_Subscription available in Template Table In SubscriptionDB is not available in BO (Town21)
* DE8843 - UPAM_Subscription_Newly created Subscriptions are not reflecting in BO
* DE8825 - KPS/Town27 LZ: data appears to be delayed for 3-4 days
* DE8806 - T24 - Subscription 517297 in report db don't have the correct games on each transactions
* DE8481 - Subscriptions: All purchase attempts must be shown in Back Office
* DE8791 - Monitor EtlServiceErrorLog Table And Issue Fixes

### 1.58.0 / 2018-05-07
* DE8780 - Financials/Transaction Summary - Dublicate shortcodes
* US6609 - JMeter results and fixes of All reports on Town27

### 1.57.2 / 2018-05-04
* DE8796 - java.lang.NullPointerException for Subscription Purchase

### 1.57.1 / 2018-05-03
* DE8670 - Deposits - Missing "Method" (type of creditcard)
* DE8590 - GVSPOT- 10 Town 2x - Smart Quick Pick bets for lower than requested ticket cost, should display actual ticket cost in Spilhistorik
* DE8744 - UPAM_Subscription_End date is not populated for few of the Cancelled / Archived Subscriptions
* DE8738 - T23: SubscriptionIds from subscription.SubscriptionItem missing in subscription.Subscription
* DE8730 - Financials - Mass adjustment - Report at Wallet differs from GTHD
* DE8751 - EtlServiceErrorLog Table Issues

### 1.57.0 / 2018-04-30
* DE8614 - GVSPOT- 12 Town 2x - Spilhistorik doesn't display correct values after over_under file is run
* DE8606 - GVOBET-41 DAN-154718 - Wrong winnings in the spilhistorik page after resettlement
* DE8082 - Incorrect values in "CreatedAt" column in LZ.AccountTransaction
* DE8480 - T23: CreatedAt larger than UpdatedAt in account.Transaction
* DE8485 - T23: SubscriptionIds from subscription.SubscriptionItem missing in subscription.Subscription
* DE8583 - EtlServiceErrorLog Table Issues
* DE7274 - Winning rollback on oddset has no effect on game history
* US6463 - Remove RG-nginx from the ddc repo + remove RESPONSIBLE_GAMING_ENDPOINT variable
* DE8628 - Date with feature and too old values in transaction related tables
* DE8573 - T27 - BO Reports not returning results
* DE8560 - GVSPOT-9 Dantoto (Sportech) wins are displayed five days later in UPAM
* US6516 - ErrorLog table and Reprocess improvements
* DE8082 - Incorrect values in "CreatedAt" column in LZ.AccountTransaction


### 1.56.1 / 2018-04-25
* DE8390 - PAM 14.4.1.: Reporting | Differences between Transaction summary and transaction history
* DE8621 - Report ETL Service - PurchaseStatus not updated in SubscriptionTransactionsArchive table

### 1.56.0 / 2018-04-23
* DE8529 - Payout method missing when set to NemKonto
* DE8481 - Subscriptions: All purchase attempts must be shown in Back Office
* DE8507 - EtlServiceErrorLog Table Issues
* DE8487 - Double winnings on ticket in UPAM
* DE8480 - T23: CreatedAt larger than UpdatedAt in account.Transaction
* DE8418 - T23: Duplicate rows in account.Transaction
* DE8390 - PAM 14.4.1.: Reporting | Differences between Transaction summary and transaction history
* DE8082 - Incorrect values in "CreatedAt" column in LZ.AccountTransaction
* DE7862 - T23: None og the Id's in the ga.wager table for PlayerId 1128140 has corresponding WagerId's in the account.Transaction table on TOWN23

### 1.55.2 / 2018-04-19
* DE8480 - T23: CreatedAt larger than UpdatedAt in account.Transaction

### 1.55.1 / 2018-04-17
* DE8476 - Town27 - RevisionDate with default value not working
* DE8492 - DWH - Creation Date is greater than Updated Date in transaction table

### 1.55.0 / 2018-04-16
* DE8409 - Report Manager - GET /health - not healthy
* DE8394 - Not updating updateDate field in transaction table
* DE8378 - T23: Duplicate rows in player.PaymentMethod
* US6521 - Store jmsMessageId in all snapshot and archive table in Report DB
* DE8286 - Validation/Report-ETL service/more than one service instance for HA

### 1.54.1-rc.1 / 2018-04-12
* DE8394 - Not updating updateDate field in transaction table

### 1.54.0-rc.1 / 2018-04-09
* DE8284 - 14.2.0 PAM Town 23: Not all players exist in the genesys export file
* DE8277 - EtlServiceErrorLog Table Issues
* DE7270 - Subscriptions: Purchase state "Failure" in db
* DE7048 - UPAM, settings, view button  ETL Source Data
* DE6149 - Financials - Negative balances

### 1.53.0-rc.1 / 2018-04-03
* DE8248 - UPAM_Player has two identifications in DB, but API is showing one
* DE8233 - EtlServiceErrorLog Table Issues
* DE8171 - Profile history - Comment is not shown
* DE8104 - Player Affiliation  - Update message is coming earlier

### 1.52.1-rc.1 / 2018-03-28
* US6541 - ETL-Service Config Changes to support the wallet queue jmsgroup id support

### 1.52.0-rc.1 / 2018-03-26
* DE8226 - BO: Player's Transactions / Global Transaction History -- Deposit transaction with Type of Funds being Subscription -- Transactions are in wrong order
* DE8205 - EtlServiceErrorLog Table Issues
* DE8188 - UPAM_Subscription_Purchase Status is missing for few Purchase transactions in Player and Global Subscription Transactions Report (Town 21)
* DE8179 - UPAM_Subscription_Accepted Purchase transactions are not reflecting in Global / Player Subscription Transactions page
* DE8149 - EtlServiceErrorLog Table Issues
* US6530 - [Unfinished] ErrorLog table and Reprocess improvements
* DE8177 - DWH: Update UPAM Journal Schema to manage the EventType on transaction table

### 1.51.1-rc.1 / 2018-03-22
* DE8177 - DWH: Update UPAM Journal Schema to manage the EventType on transaction table
* DE8149 - EtlServiceErrorLog Table Issues
* DE8179 - UPAM_Subscription_Accepted Purchase transactions are not reflecting in Global / Player Subscription Transactions page

### 1.51.0-rc.1 / 2018-03-19
* US6508 - Win and Game related information needs to be sent in withdrawal transaction from payout service and the same needs to be saved in java ETL
* DE8126 - External ID is missing
* DE7989 - Transaction is missing
* DE7955 - Subscriptions - Gap purchased template shows gapPurchase=false in BO
* DE7935 - Missing data under subscription - Transactions history
* DE7926 - Subscriptions - Gap funded ledger is not returned in GET /players/{playerId}/transactions response
* DE7824 - Missing sub type in negative balance report
* DE7696 - EtlServiceErrorLog table issue fix
* DE8035 - T27 Hung Transformations
* DE7943 - PAM 13.0.42.: Affiliate | REG_1 - Report - Subscription informations not stored in PlayerProfile
* DE8034 - DWH: we are not sending the updates on transaction


### 1.50.1-rc.1 / 2018-03-14
* DE7926 - Subscriptions - Gap funded ledger is not returned in GET /players/{playerId}/transactions response
* DE7696 - EtlServiceErrorLog table issue fix

### 1.50.0-rc.1 / 2018-03-12
* DE7941 - UPAM_Subscriptions_Purchase status should be blank for all other transaction types except Wager
* DE6901 - Subscriptions: Hold function has stopped working (again)
* US6499 - ActiveMq group Consumer implementation for parallel processing of same topic messages
* DE7775 - UPAM_Subscriptions_Payout withdrawal for Subscription winnings did not happen for Subscriptions with winnings sent to as Bank Account

### 1.49.0-rc.1 / 2018-03-05
* DE7824 - Missing sub type in negative balance report
* DE7788 - 13.0.37 PAM Town 22: in PAM on the Players/Search player and the Players / Players report tab the player’s status doesn’t the same
* DE7663 - Global Transaction. CouponId is missing on multiweek wagers.
* DE7514 - DAN-148970 - Spilhistorik page for settled slave pool bets
* DE7471 - DAN-148637 - Subscription bets isn't present in the Spilhistorik list
* DE6934 - Subscriptions -BO - Failed purchase returned as Accepted in Player Subscription Transactions
* DE7695 - Different transaction status between wallet and pfi
* US6471 - 2.9.27 - it is to track offline win payouts by game (linked to withdrawal submitted to bank).  it is ideal to build a new report similar to withdrawal summary report date filter support with game level offline withdrawal summary

### 1.48.0-rc.1 / 2018-02-26
* DE7696 - EtlServiceErrorLog table issue fix
* DE7690 - DAN-149668 - Spilhistorik shows the freebet amount instead of the amount paid when a bet is placed with a freebet
* DE7515 - DAN-148969 - Spilhistorik page for settled master pool bets

### 1.47.0-rc.1 / 2018-02-20
* DE7653 - Report ETL Service Health Api Throwing Error when the dependent api is not reachable / not correct
* DE7619 - Difference between winning amount in UPAM versus Openbet.
* DE7606 - EtlServiceErrorLog table issue fix
* DE7582 - Subscriptions: New subscription is not shown in UPAM (DE7333 reopened)
* DE7569 - IU-10304 - FE - Played Keno game is still under active games.
* DE7389 - Definition of "Game Name" in the header of Global Transaction History/Record count - Game master data issue?
* DE6149 - Financials - Negative balances

### 1.46.1-rc.1 / 2018-02-14
* DE7563 - PAM 13.0.35.: Affiliate | DLI - Sales0 report wrong

### 1.46.0-rc.1 / 2018-02-12
* DE7499 - UPAM_Subscriptions_Subscription Game schedules and Transactions History is blank in Subscription details for pop up from both Global Subscription and Subscription Transactions page
* DE7479 - EtlServiceErrorLog table issue fix
* DE7367 - Subscriptions - BO - When Payment Method is changed from BS to CC, the PBS nbr is not reset in BO

### 1.45.0-rc.1 / 2018-02-06
* DE7441 - Change SubscriptionId from Varchar to bigint(20)
* DE7412 - Remove TransactionType from primary key in PlayerTransaction and SubscriptionTransactions tables
* DE7385 - UPAM_Subscriptions_Newly created subscriptions are not reflecting in Town 21 environment
* DE7372 - UPAM_Subscriptions_Next draw date is missing for many subscriptions in Town 20
* DE7048 - UPAM, settings, view button  ETL Source Data
* DE6956 - Subscriptions - BO -  Gap Funded template has "Send Notification" button enabled
* DE7407 - Env based logging level in Report SCS

### 1.44.0-rc.1 / 2018-01-30
* DE7354 - Subscriptions: Subscription deposits are missing on player transaction history tab
* DE7333 - Subscriptions: New subscription is not shown in UPAM (DE4428 reopened)
* DE7227 - Reports System - Post /players - can't use player id in the payload - DATA-NOT-FOUND

### 1.43.1-rc.1 / 2018-01-25
* DE7223 - Optimizing SELECT query for TransactionDailyBalance

### 1.43.0-rc.1 / 2018-01-23
* DE7259 - DWH - Add onHoldUntil column in the subscription table
* DE7225 - Etl Service Error Logs
* DE5616 - Reports - Player Change By Agent - Log Value Correction
* DE6956 - Subscriptions - BO -  Gap Funded template has "Send Notification" button enabled
* DE7194 - PAM 13.0.27: Subscriptions | Wrong amount at failing deposit
* DE7128 - Subscriptions: Subscription disappears when cancelled by BetalingsService
* DE6956 - Subscriptions - BO -  Gap Funded template has "Send Notification" button enabled
* DE7114 - TSR. Transactions from 3. jan is not in report.
* DE7048 - UPAM, settings, view button  ETL Source Data
* DE7225 - Etl Service Error Logs 
* DE7181 - Reports-System - POST /upload returns HTTP 500 Internal Server Error
* DE6813 - PAM 13.0.20.: Profile | Session tab is empty in PAM
* DE6951 - PAM 13.0.21.: DWH | empty table player.LogoutSession
* DE7176 - Error Logged in EtlServiceErrorLog
* DE7166 - reportSystem - getPlayersPlayerIdWagerStatistics - 500 server error

### 1.42.0-rc.1 / 2018-01-15
* DE7194 - PAM 13.0.27: Subscriptions | Wrong amount at failing deposit
* DE7128 - Subscriptions: Subscription disappears when cancelled by BetalingsService
* DE6956 - Subscriptions - BO -  Gap Funded template has "Send Notification" button enabled

### 1.41.0-rc.1 / 2018-01-09
* DE6957 - UPAM_Subscriptions_Total Purchase and Total Won are not reflecting in Subscriptions page in Town 21
* DE6149 - Financials - Negative balances
* DE5865 - Financial and Analysis reports don't reconciliate

### 1.40.1-rc.1 / 2018-01-05
* DE7122 - TransactionSummary functional fixes

### 1.40.0-rc.1 / 2018-01-03
* DE6786 - Offline transactions in wallet with sub-type and transaction summary reporting to show this at sub-type level
* DE6928 - Withdrawals - add subtype
* DE6957 - UPAM_Subscriptions_Total Purchase and Total Won are not reflecting in Subscriptions page in Town 21
* DE6755 - Adjustment sub-types in transaction history to match with adjustment back office screen options.

### 1.39.2-rc.1 / 2017-12-22
* DE7061 - External Game Wallet - Basic report service fix
* DE7062 - Netloss - Datatype change for netloss percentage

### 1.39.1-rc.1 / 2017-12-21
* DE6897 - Java ETL hibernate select/update with where conditions and map with expected index and testing that also if possible.

### 1.39.0-rc.1 / 2017-12-19
* DE6572 - Transaction Summary Report_Functional issues
* DE6793 - Reports - remove kafka env vars & code, including ddc repo
* DE6878 - PlayerId, OperatorId, GameId, PaymentMethodId,AgentId, AuthorId, etc (Universal reference Columns)  Data Type - Check and modify the all the tables
* DE6892 - 13.0.21 PAM Town 22: in PAM I added my email address to get an excel report file in Email Report window, but I don’t get an email
* DE6715 - back office - nothing logged in profile history tab
* DE6405 - Reports: Player Change By Agent - Report Log - Data Display Issue
* DE6901 - Subscriptions: Hold function has stopped working (again)
* DE6895 - Subscriptions- Player data not added to playerProfile table results in subscriptions not returned in report
* DE6885 - Subscriptions: UPAM client is not up-to-date with UPAM DB
* DE6872 - Player Reactivation - investigate current behaviour
* DE6826 - Reports_Negative Balance Report_The column called 'comments' is displaying in the exported files
* DE6825 - Reports_Negative Balance Report_Adjustment comments in receipt
* DE6813 - PAM 13.0.20.: Profile | Session tab is empty in PAM
* DE6755 - Adjustment sub-types in transaction history to match with adjustment back office screen options.
* DE6678 - Subscriptions - BO - Player registered with ROFUS - Templates are not archived in BO
* DE6557 - Subscriptions - BO - ModifiedBy under version Details
* DE5616 - Reports - Player Change By Agent - Log Value Correction

### 1.38.2-rc.1 / 2017-12-13
* DE6860 - Transaction Summary Report - Player Based - Performance issues

### 1.38.1-rc.1 / 2017-12-12
* DE6697 - External Game Wallet - Dynamic query condition and Dynamic Sorting

### 1.38.0-rc.1 / 2017-12-11
* DE5777 - Subscriptions - Credit card funding failures not returned in Subscriptions Transaction report
* DE6633 - Subscriptions - BO - Newly created subscriptions doesnt show in Report
* DE6517 - Report-SCS ReportETLErrorLog reprocessing setup using cron
* DE6710 - Remove the 'Type' Column in Wager / Archive tables if not used any where in the functional level

### 1.37.0-rc.1 / 2017-12-04
* DE6402 - Report DB - Winning / Winning Archive tables missing player records
* DE6672 - Town20 issue after deploy Iteration47 patch release

### 1.36.2-rc.1 / 2017-12-01
* DE6647 - Stored Procedure Issue for agnet/player/game IDs conversion from varchar to Int

### 1.36.1-rc.1 / 2017-11-30
* DE6459 - AgentId/PlayerId/GameId Column datatype changes to int from varchar in report SCS
* DE3448 - PAM 9.4.3.: Financial / Transaction Summary does not show correct figures
* DE6541 - DB - General Defect to Remove Future Dates in DB

### 1.36.0-rc.1 / 2017-11-27
* DE6467 - Add missing fields WalletUpdatedDate, GviPreviousState, GviState, GviStateUpdatedAt, EventId, EventCreatedAt in SubscriptionTransactions table and corresponding ETL changes
* DE6413 - Subscriptions: Trigger value is not shown in version track for Jackpot subscription
* DE6370 - Subscriptions-BO- Winnings generated for a subscriptions is not showing up on transaction report
* DE6369 - Subscriptions - BO - Wager details are not returned in player's transaction
* DE6334 - Report SCS - EtlErrorLog improvements
* DE6402 - Report DB - Winning / Winning Archive tables missing player records
* DE6322 - PAM 13.0.15.: Reporting | Responsible gaming / Limit report is empty
* DE6121 - Reports - 1 or no wager appears in transaction history when Posting 2 wagers
* DE6065 - Player's Transaction History / Global Transaction History -- National Number showing in Method; should be "bankAccount - National number"
* DE5928 - 13.0.4 PAM Town 22: the Responsible gaming tab / Expected spend report does not show the search’s result
* DE5826 - Transaction Summary Report. Wagers and wins  are not in report
* DE5206 - GET /players/{playerId}/transactions count doesn't match backoffice reports


### 1.35.0-rc.1 / 2017-11-21
* DE6352 - PAM 13.0.15: Subscription | Cannot be canceled
* DE6262 - Reports: Agent Credentials - Agent Access Listing - Website List Issue
* DE5865 - Financial and Analysis reports don't reconciliate
* DE6395 - ActiveMq Health Api correction to use the unique XA resource name in report ETL Service
* DE6380 - Error Log Entry should be always one based on n+1 jmsRedeliveryCount
* DE6090 - ETLServiceErrorLog - Error Messages

### 1.34.3-rc.1 / 2017-11-20
* DE6291 - Migration script issue

### 1.34.2-rc.1 / 2017-11-16
* DE6302 - ETL Error :- could NOT resolve property: OperatorId of: com.sciplay.report.etl.Entities.Exclusion.SelfExclusionEntity
* DE6305 - Exclsuion Msg Process in ETL :- java.lang.NullPointerException at ReportEtlExclusionProcessor.java:103
* DE6308 - Analyse ETL ErrorLog table and apply fix

### 1.34.1-rc.1 / 2017-11-15
* DE6291 - Migration script issue

### 1.34.0-rc.1 / 2017-11-14
* DE6250 - UPAM_Transactions_Player Transaction History details are not getting reflected in UPAM BO
* DE6225 - Correct ETL code from SQL update to Entity update to fix partial commit
* DE6161 - Accepted Wager still showing as Pending in BO.
* DE6043 - Cancelling a Wager/Win through Financials->Wallet changes Wagers Status but creates another transaction for Win
* DE5826 - Transaction Summary Report. Wagers and wins  are not in report
* DE6099 - Back Office - Transaction Status missing - BR259 requirement
* DE5917 - PFI API: Fetch single game history details. Missing response information.
* DE5914 - PFI API: Fetch player game history. Missing information in response.
* DE5069 - Exclusion DB not loading into Report DB - exclusions added via RG Swagger
* US6288 - PlayerTransaction, SubscriptionTransaction, PlayerTransactionDetails, SubscriptionTransactionArchive, Wager, Win
* DE3469 - Reports / Back Office - Transaction History does not show Session ID when using Player Token for any GVI transactions.
* DE5988 - PAM 13.0.7.: Reporting | The free game is not listed on Transactions History page on Player level

### 1.33.0-rc.1 / 2017-11-06
* DE6122 - ETL should store Agent Name in Player Profile table
* DE6053 - Player's Transactions History / Global Transactions History -- Wagers and Wins Transactions not showing properly
* DE5878 - Report- Transaction History Summary Report- The accepted transaction should display below the cancelled transaction
* DE5616 - Reports - Player Change By Agent - Log Value Correction

### 1.32.0-rc.1 / 2017-10-30
* DE5938 - PAM 13.0.4.: DWH | duplicate entry in [player].[Phone] table
* DE5915 - UPAM_Subscriptions_Subscription Transaction Report_Rounds and Unit Wagers are 0 in Subscription Charge Collection Report
* DE5900 - Financials -> Global Transaction Summary / Player's Transaction History - Pending Adjustment / Approved Date
* DE5993 - Report-ETlService - Remove checks for duplicate handling

### 1.31.0-rc.1 / 2017-10-24
* DE5978 - Include OperatorId in primary key for GameProviders table
* DE5900 - Financials -> Global Transaction Summary / Player's Transaction History - Pending Adjustment / Approved Date
* DE5749 - EventTypes does not match UPAMJournalSchema allowed values
* DE5466 - UPAM_Subscriptions_Initiated By is blank for all transaction entries of Subscription Transaction Reports
* DE5320 - Global Transaction History. Balances on Offline does not match
* DE5963 - Include ActiveMq in /health of Report-Etl-Service & Poison message Handling in Report ETL
* DE5889 - Analysis -> Game Stats BY Player -> Wager Doubled Up
* DE5778 - Game History report gives out doubled values for wagers
* DE5847 - Wallet - Cancelled deposit has the same date as the original deposit date and appears before in the report.
* DE5895 - Reports - Handle wallet CORRECTED status

### 1.30.1-rc.1 / 2017-10-19
* DE5922 - Transaction summary ETL to handle proper indexes and query plan

### 1.30.0-rc.1 / 2017-10-16
* DE5516 - 12.4.0 PAM Back office: Game Categories/sports filter don't show result
* DE5479 - Financials -> Global Transactions History - Method is not populating properly
* DE5427 - BR259 - Back Office - Transaction History - data under Method comes back as ****
* DE5745 - Increase length of Period  field in Restriction tables
* DE5734 - Session.flush should happen only if any transactions happened, getting error "no transactions to flush" on session.flush
* DE5594 - PAM 12.5.1.: DWH | Teams and Leagues table were not updated from 14/09/2017
* DE5504 - Report ETL: log delay in seconds between the event date and the processing time
* DE5314 - PAM 12.2.2. Player | Wagering Preference is wrong (more than 100%)
* DE5578 - DWH - Event Type differences
* DE5540 - Report - Negative balance report does not show write off details
* DE5406 - UI: Agent Change Notification - Log Details Display Issue
* DE5297 - Subscription Transactions Report : Funding deposits are not appearing in Subscription Transactions Report.
* DE5285 - Subscriptions - Support for Failed Transactions

### 1.29.0-rc.1 / 2017-10-10
* DE5027 - No comma separation in CSV reports
* DE5314 - PAM 12.2.2. Player | Wagering Preference is wrong (more than 100%)
* DE5357 - ETLServiceErrorLog - Error Messages
* DE5616 - Reports - Player Change By Agent - Log Value Correction
* DE5647 - Game Stat and Transaction Summary Issue due to data in wager and playertransaction table
* DE5206 - GET /players/{playerId}/transactions count doesn't match backoffice reports
* DE5692 - Report - Data is not being populated in NegativeBalance table

### 1.28.0-rc.1 / 2017-10-06
* DE5437 - Reports - transaction comment does not appear in reports
* DE5540 - Report - Negative balance report does not show write off details
* DE5511 - Subscriptions - Town20 - Version details doesnt return any details
* DE5510 - Subscriptions-Town20-Subscription put on hold doesnt reflect the status in BO

### 1.27.0-rc.1 / 2017-10-03
* DE5549 - PAM 12.4.0: Subscription | Purchase Declines and Add-on Purchase Notifications are not able to be set
* DE5276 - PAM12.1.2 Game Stats And Game Player stats calculation issues
* DE3232 - Winnings with WagerId's that does not exist in Wager in LZ_PAM Town21
* DE5452 - Report - PlayerBalance table receives previous balance instead of current balance
* DE5320 - Global Transaction History. Balances on Offline does not match

### 1.26.1-rc.1 / 2017-09-26
* DE5503 - Report ETL Service Migration Script Issue

### 1.26.0-rc.1 / 2017-09-25
* US5413 - Report ETL stopped in town21 - Analyse kbana and fix it in report ETL
* DE5387 - Player Transaction report should show pending adjustments
* DE5369 - Report ETL - Debit added from a patched Winning is not being inserted in report.PlayerTransaction table
* DE5377 - UPAM_Subscriptions_End date does not populate for Canceled Subscriptions

### 1.25.0-rc.1 / 2017-09-18
* US6224 - ActiveMQ Integration Testing
* DE3874 - Deposits are rejected because of innacurate deposit responsible gaming counter

### 1.24.0-rc.1 / 2017-09-11
* DE4634 - Subscriptions - Subscription Transactions - "External Trans Id" not being populated when doing a credit
* DE5279 - Subscription Game Schedule Schema Changes and Entity Changes

### 1.22.0-rc.1 / 2017-08-28
* US6154 - ActiveMQ Report-ETL JTA implementation
* DE5088 - Transaction History Details_The 'External Trans Id' is not displaying for the agent transaction
* DE3567 - Status of a deposit cancelled from DIBS shows up as refund.
* DE4537 - Subscriptions - Funding Notification button should be disabled when subscription is in Funding cycle

### 1.21.0-rc.1 / 2017-08-21
* DE4101 - New transactions and winning all with WinId = 0 on LZ_PAM on Town21
* DE5109 - Reports-Transaction History -Wager and Win transaction directly moves to processed status and the Reserved Trans Id is Null
* DE4723 - Transaction issues throughout the system

### 1.20.1-rc.1 / 2017-08-17
* DE2893 - UPAM Transaction lists error

### 1.20.0-rc.1 / 2017-08-11
* DE4711 - BO UPAM - Player Profile Preferred Game is populated with Profile DB not Report DB
* DE4709 - BO UPAM - Player Profile Default Winning account populated with Profile DB not Report DB
* DE3500 - 9.4.3 PAM Financials / Deposits: There Is Only One Searchable Transaction ID
* US6011 - UPAM DW ETL service error response schema changes
* DE4914 - Add ModifiedBy to Primary Key List in PlayerHistory Table
* DE4537 - Subscriptions - Funding Notification button should be disabled when subscription is in Funding cycle
* DE4469 - Internal server error when creating Jackpot subscription with Add-on trigger value > 21,474,836.47
* US6117 - Reports ETL - update for new wallet
* DE4452 - Report-Global Session-The 'Real Money Balance Before and after does'nt match with the wallet Real money

### 1.19.0-rc.1 / 2017-07-31
* DE4788 - The amount on Wager from OB is not correct in 'Financia - Transaction Summary Report
* DE4711 - BO UPAM - Player Profile Preferred Game is populated with Profile DB not Report DB
* DE4709 - BO UPAM - Player Profile Default Winning account populated with Profile DB not Report DB
* DE4706 - UPAM - Total purchase price for a subscription is only the price for one row - and not for all rows included in the system
* DE4790 - Cucumber Tests for Report ETL Service
* DE3993 - DWH Reports > SelfExclusion 1 record for split player
* DE4787 - In 'Player - Transaction History Details' the winnings/balance are not shown in correct order
* DE4538 - Reports / DWH - Add&Remove League Player, Team Player display in BO from T&L db, not reports db
* DE4732 - Player Profile - Posting a player card returns 500 error

### 1.18.0-rc.1 / 2017-07-24
* DE4743 - Reports: Game Stats - No Record with Game Type for disabled Games
* DE4711 - BO UPAM - Player Profile Preferred Game is populated with Profile DB not Report DB
* DE4710 - BO UPAM - Player Profile Security Question populated with Profile DB not Report DB
* DE4709 - BO UPAM - Player Profile Default Winning account populated with Profile DB not Report DB
* DE4673 - Cucumber Tests for Report ETL Service
* DE4707 - UPAM Journal Schema 7.6 Report DB EventType differences
* DE4685 - Subscriptions- BO - Missing PBS Agreement number from Version Details

### 1.17.0-rc.1 / 2017-07-17
* DE4611 - Id missing in TeamPlayerArchive
* DE4609 - Update/delete queries cannot be typed in Self Exclusion
* DE4591 - Cucumber Tests for Report ETL Service
* DE3620 - Reports: Failed Login Attempt - Player Details aren’t recorded.
* DE3518 - PAM 9.4.3: DWH | Missing record from [Player].[Identification] table
* DE4653 - Reports:  Log for reports not Created - Self Exclusion
* US6009 - Report ETL Service error response schema changes

### 1.16.0-rc.1 / 2017-07-10
* DE4452 - Report-Global Session-The 'Real Money Balance Before and after does'nt match with the wallet Real money
* DE4325 - On Transaction History report 'External Game Id' on Safari and Golden Pyramid from Cego is 'OB_TIPS12
* DE4299 - Change From Start to End of Day' in the financials/transactionSummaryReport are not correct
* DE4543 - PFI: responsible gaming no values
* DE4466 - Capture BackendTransactionId and Joker informations in game purchase
* DE4423 - Cucumber Tests for Report ETL Service
* DE4356 - Subscriptions: Subscription information no longer available after updating subscription Template from swagger.
* DE4297 - PAM 9.10.1 Not every data update in General tab is presented in Progile History
* DE4109 - Subscriptions - BO - Comment section on information popup

### 1.15.1-rc.1 / 2017-07-04
* DE4509 - Update release versions in API

### 1.15.0-rc.1 / 2017-07-03
* DE4472 - Change root health based on all internal dependent services status
* DE4465 - Subscription cancel not working
* DE3635 - Reports: Limit Type column value other than expected-spending is not recorded.
* DE4373 - Subscriptions: Back Office: Bank Account missing from Winning Sent To in Subscription Details
* DE4481 - Subscription Games List Sync Issue

### 1.14.1-rc.1 / 2017-06-29
* DE4446 - Change Id field column size from 36 to 100 in PlayerLoginSession and PlayerLogOutSession
* DE4447 - Add AcknowledgementType as primary key in PlayerTermsAndConditionsAcknowledgement

### 1.14.0-rc.1 / 2017-06-27
* US5976 - Reports - add a /version route in each container
* US5977 - Reports - add a /health route per container
* DE4278 - Reports SCS all services disable file logging based on logback configuration.
* DE4356 - Subscriptions: Subscription information no longer available after updating subscription Template from swagger.
* DE4330 - Report ETL Service - Make all code run in a single session and test
* DE4358 - 'WagerSetId' in Wager table of reportdb is showing out of range error

### 1.13.1-rc.1 / 2017-06-21
* DE4312 - QA Environment-player registration error for Global session and profile history reports
* DE4334 - Report ETL Service not picking up Kafka messages

### 1.13.0-rc.1 / 2017-06-19
* DE4188 - Error Log Improvements
* DE4102 - PAM 9.8.1: DWH | Wrong transaction data ga.wager (offline channel wager)
* DE3233 - Account.Transaction's where WinId and WagerId refers to wins and wagers that do not exist in LZ_PAM Tows21
* DE4120 - 9.8.1 PAM SSO Login Notification Does Not Work Properly - Session report
* DE4121 - 9.8.1 PAM Profile History is not updated with some kind of data
* DE4138 - PAM 9.8.1: DWH | Differences betweeen DWL tables and UpamJournalSchema_7.3 LOV (List of values)
* DE4196 - Compare and update report DB with MsSql DB

### 1.12.1-rc.1 / 2017-06-12
* DE4045 - subscription template PlayType field rename

### 1.12.0-rc.1 / 2017-06-09
* DE4132 - Subscriptions- Cancelling Subscription updated created Date to Cancelled Date
* DE4073 - Blocked subscription players not working fine in the report
* DE4066 - Subscriptions BO- Version Details popup
* DE3469 - Reports / Back Office - Transaction History returning Session ID when using System Token
* DE3461 - PAM 9.4.3: DWH | Duplicated entry in [account].[transaction]
* DE4081 - Capture additional information into Subscription Transaction table
* DE4155 - Change column to not null to match with DW database
* DE4075 - Find Data Sync issues and diff's for Report Etl tables

### 1.11.1-rc.1 / 2017-06-08
* DE3635 - Reports: Limit Type column value other than expected-spending is not recorded.

### 1.11.0-rc.1 / 2017-06-02
* DE4017 - Move Mysql migration script from upam ETL to Report ETL project
* DE4016 - IpAddress field in PlayerTransaction and PlayerTransactionDetails table as nullable
* DE3943 - Subscriptions -- Credit card payments shall include order number (generated by Subscription Service Engine) and transaction number.
* DE3291 - UPAM BO Analysis – Game/Player Stats -> Information does not match Games tab information
* DE3962 - Find Data Sync issues and diff's for Report Etl tables

### 1.10.0-rc.1 / 2017-05-26
* DE3958: Create a ETL to store third party errors
* DE3921: update SQL schema to fix player affiliation update
* DE3916: Error log table issue fix
* DE3500: 9.4.3 PAM Financials / Deposits: There Is Only One Searchable Transaction ID
* DE3899: Create a report for third party errors
* DE3923: Fix Data Sync issues in error log table
* DE3917: 9.6.3 PAM / Global Transaction History: Missing Usernames
* DE3901: Fix issues in error log table
* DE3857: Update NemId in PlayerSession and PlayerLoginSession
* DE3620: Reports: Failed Login Attempt - Player Details aren’t recorded.
* DE3103: CS69 - DS Data Warehouse
* DE3746: Missing Brand data in ga.Wager in LZ_PAM Town21
* DE3491: DWH GVI / API Swagger  Brand field contents only displays in GVI db

### 1.9.1-rc.1 / 2017-05-22
* DE3803: Make sure only deposit limit are sent to the wallet
* DE3916: Error log table issue fix
* DE3857: Update NemId in PlayerSession and PlayerLoginSession
* DE3828: Report Data Service: Getting 500 internal server error for playerSubscriptions getAggregations
* DE3620: Reports: Failed Login Attempt - Player Details aren’t recorded.

### 1.9.0-rc.1 / 2017-05-17
* DE3804: Update PBS Agreement Number in Subscription table
* DE3659: Subscriptions to use same session for create, update and delete
* DE3786: Subscription - Unable to put Subscription on hold from BO
* DE3756: UPAM BO - playerSubscription -> OnHold Subscription becomes Archived after On Hold Wait Days.
* DE3807: Subscriptions - BO - Unable to Reactivate a cancelled subscription
* DE3695: PAM 9.5.5: Subscription | Missing record from Subscription table
* DE3776: Error log table entry having two entry for same error

### 1.8.2-rc.1 / 2017-05-12
* DE3598: Subscription History ETl Update to store Version ID
* DE2905: Agent Login History Report-The AgentId and username is not getting recorded for the 'Login attempt failure' status
* DE3694: Logging is not working properly in ETL service
* DE3602: Getting Error while commit rollback in Report ETL service
* DE3344: RG-SCS Exclusion and Validation service DDC configuration refactoring
* DE3404: Responsible Gaming: Global Deposit Limits are not preventing deposits above the limit.

### 1.8.1-rc.1 / 2017-05-03
* DE3602: Getting Error while commit rollback in Report ETL service
* DE3591: Reports ETL > has been stopped/issue

### 1.8.0-rc.1 / 2017-04-28
* DE3516: Change datatype for two game fields
* DE3517: PAM 9.4.3: DWH | [Player].[Card] table is not updated
* DE3518: PAM 9.4.3: DWH | Missing record from [Player].[Identification] table
* DE3516: Change datatype for two game fields
* DE3517: PAM 9.4.3: DWH | [Player].[Card] table is not updated
* DE3518: PAM 9.4.3: DWH | Missing record from [Player].[Identification] table
* DE3453: DWH: Winning Tables have no time stamp
* DE3383: PAM 9.4.3 Missing DLI/DLO values from LOV, Responsible Gaming / Net Losses
* DE2843: UPAM>  Responsible Gaming > Net Loss Report no Loss concept / players ID link returns search screen

### 1.7.1-rc.1 / 2017-04-24
* DE3345: ReportEtlService - EtlErrorLog table error fixes April B
* DE3404: Responsible Gaming: Deposit Limits are not preventing deposits above the limit.
* DE3444: Report-SCS Transaction History doesn't showing DIBS txn id
* DE3450: DWH - Reports - handle card type field
* DE3445: /players/1007/gameHistory/ WagerStatus returns "-"
* DE3469: Reports / Back Office - Transaction History returning Session ID when using System Token
* DE3448: PAM 9.4.3.: Financial / Transaction Summary does not show correct figures
* DE3438: Getting same correlation id for credentials-added and credentials-removed

### 1.7.0-rc.1 / 2017-04-18
* DE3242: DWH - MYSQL report.Winning table does not have DLI or DLO records
* DE3229: GameId, ExternalCreationDate is coming null in WagerArchive table
* DE3206: Subscription.Subscription.EventType - does not match definition in LZ_PAM Town21
* DE3135: NULL value is coming for Ip in PlayerLoginSession table and Brand in WagerSetArchive table
* DE3036: EventType is wrong in ga.Wager table: always wager instead of wager-update and wager-create
* DE3295: Remove Game related fields except game id from player transaction table
* DE3056: Report-ETL-Service Manual Error Log table processing

### 1.6.3-rc.1 / 2017-04-11
* DE3286: Subscription ETL Change for Payment Methods
* DE3216: Subscription Edit History ETL
* US5803: Update schema to add the "type" field to player card events
* US5804: Handle type in etl

### 1.6.2-rc.1 / 2017-04-07
* DE3247: Analyse and fix issue on player, subscription transactions
* DE3235: Analyse and fix issue on wager, win, adjustment, player registration transactions
* DE2893: UPAM Transaction lists error
* DE3140: UPAM BO Subscription->Subscription Transaction report is empty after transactions performed

### 1.6.1-rc.1 / 2017-04-05
* DE3203: Analyse and fix error in EtlServiceErrorLog table
* DE3202: Player Balance not sync with wallet balance while adding negative transaction
* DE3140: UPAM BO Subscription->Subscription Transaction report is empty after transactions performed
* DE3192: Accepting Withdrawal not capturing Agent Id and also Approved Date in player Transaction table
* DE2893: UPAM Transaction lists error
* DE3196: Fix the defects in error log table
* DE3193: DELETE Subscriptions, SubscriptionsArchive, SubscriptionTransactions, SubscriptionTransactionsArchive WHERE PlayerId not equals 924

### 1.6.0-rc.1 / 2017-03-31
* DE3092: Annex 2.9.7 - Report example - Reports to the operations if side games have not been played during last 5 hours' is missing
* DE2918: Report: Player Change by Agent - 'Secret Question "What's my secret code" doesn’t get logged.
* DE2880: In PDF design issues :  amount and String columns are merging together
* DE3010: Save deleting processed transaction for wager and win
* DE3038: Several rows without difference for the same wager
* DE3117: Store domain in GameProviders table
* DE3094: Remove Duplicate Dao Implementations like GameDaoImpl, GamesDaoImpl
* DE3055: Show "System" in report, when author id is available as "System" in exclusion, locked closed, game restriction.
* DE2917: Reports: Player Change By Agent: Player Profile Update, DOB display format issue

### 1.5.1-rc.1 / 2017-03-24
* DE2918: Report: Player Change by Agent - 'Secret Question "What's my secret code" doesn’t get logged.
* DE3010: Save deleting processed transaction for wager and win
* DE3023: period and appliedUntill field should be null when exclusionType is permanent
* US5761: Avoid duplicate data in report DB by adding ModifiedAt field in missing tables and corresponding ETL changes
* US5760: Data migration for Subscription Schema Changes
* DE2835: PlayerID should not be primary key in player related tables.

### 1.5.0-rc.1 / 2017-03-16
* DE2899: Instead of updating subscription transaction insert as new record like player transaction
* US5719: Update report service report auto generation to support defining dataset field column width on contract json to generate Reports
* DE2838: BO balance and report database PlayerBalance table balance are not in sync while adding adjustment in negative.
* DE2803: Transaction History: "Balance Before" and "Balance After" values are incorrect for cancelled Adjustments
* US5577: [Continued] Report-Etl-Service Enhancements (Authentication based session Id)
* DE2762: Record getting updated instead of insert while wallet changes happen.
* DE2791: Before and after balance are not displayed in subscription transaction report
* DE2911: ETL changes to store rejected negative transaction and approve deposit need to insert new row with new transaction type
* DE2938: Report ETL comes with null for Few Columns in Archive Tables
* DE2831: Negative balance write-off is not happening
* US5716: Create script to remove duplicate records in all primary key modified tables
* US5688: Report-ETL-Service Subscription New ETL activities and enhacements


### 1.4.1-rc.1 / 2017-03-09
* DE2838 - BO balance and report database PlayerBalance table balance are not in sync while adding adjustment in negative.
* DE2762 - Record getting updated instead of insert while wallet changes happen.
* DE2791 - Before and after balance are not displayed in subscription transaction report
* DE2768 - PAM 9.0.2: player profile changes are not logged in the history

### 1.4.0-rc.1 / 2017-03-01
* DE2740 - GET /players/{playerId}/wallet/responsibleGaming respond with wrong values
* DE2732 - Event type error while adding wagreset
* US5603 - Reports SCS database all datetime fields to store the data at milliseconds precision
* US5590 - Get Sample kafka message for all the topics in Report ETL service
* US5678 - [Unfinished] Report-Etl-Service Enhancements
* US4808 - Report-ETL-Service changes for Subscription Transactions
* US5417 - MySQL Schema/ETL to take care of Operator Id in all transactions.
* US5420 - Report Data Service operator handling.
* DE2711 - Deposit inserted two time instead of update
* US5607 - Report ETL service code refactor
* US5603 - Reports SCS database all datetime fields to store the data at milliseconds precision
* US5602 - Handle null pointer exception due to Kafka / DB sync issue
* US5590 - Get Sample kafka message for all the topics in Report ETL service
* US5408 - Exclusion Operator Id (DLI DLO Split) Changes
* DE2765 - Player changes are not showing in Player Profile History report


### 1.3.4-rc.1 / 2017-02-16
* US5494 - "Report-Etl-Service Unique Key Handling for Pending tables"
* US5572 - "Report-Etl-Service Store subscription purchase schedule data"
* US4998 - "[Continued] [Unfinished] [Continued] ETL Test Issues"
* US5363 - "Report-Etl-Service Excluded player registration attempt ETL development"
* US5472 - "Viewing Subscription Details Report ETL"
* US1854 - "R150 - The PAM Solution shall enable the Danske Spil Finance employee to uniquely identify the manual corrections that were done as a write off."
* US5539 - "Birthdate column as default null in both Player Profile and Player Profile Archive"
* US5534 - "Update ETL According to Wallet Kafka Message - ExternalId filed value mapping to new filed reservedTransactionId"
* US5496 - "Report-ETL-Service ETL entity updates refactor"
* US5268 - "Report-Etl-Service ETL for ledger type to be stored"
* DE2584 - "Player Balance report not working when "Show Combined Total For All Ledgers" check box checked"
* DE2438 - "While edit Agent  First name / Last name, not inserting current agentId  into modifiedBy column in the AgentChangeNotification table."
* DE2442 - "Player Payment method is not added in Report DB"
* DE2447 - "Divide by 10000 error in transaction history on fee column"

### 1.3.0-rc.1 / 2017-01-18
* US5049: Unique key validation to be added to all the vulnerable report tables continued

### 1.2.0-rc.4 / 2017-01-09
* DE2442: Player Payment method is not added in Report DB
* DE2438: While edit Agent  First name / Last name, not inserting current agentId  into modifiedBy column in the AgentChangeNotification table.

### 1.2.0-rc.2 / 2016-12-29
* US5044: Report-Etl-Service support for Wager/Win/WagerSet/Subscription reporting
* US4635: Ledger ETL/Reports (Withdrawal, etc), issue fixes
* US4633: GVI ETL/Reports pending integration tasks

### 1.1.0-rc.4 / 2016-12-21
* DE2392: Deposit and Withdrawal process are not get update in report DB
* TA10030: Exception issue in adjustment job while accessing cause of exception where no causes in exception
* TA10007: To handle special character in jenkins parameter values

### 1.1.0-rc.3 / 2016-12-20
* US5037: Update Limit topic as LIMIT-2.0.3

### 1.1.0-rc.2 / 2016-12-19
* US5025: Limit report issue fix after dev image build
* US5024: Introduce new field into player transaction table to track wallet changes
* US5026: Handling multiple negative balance issue

### 1.2.0-rc.1 / 2016-12-16
* ETL development for deposit approved and reject flow
* Subscription update in Player Profile Table

### 1.1.0-rc.1 / 2016-12-02
* Balance Before and Balance After addition for Player Session With ETL
* ETL Test Issues and Fixes Completed
* Reports configuration - use centralized storage
* ihub/report: Report to generate after sending transactions to DanskeBank
* Report-ETL-Service Subscription Nov

### 1.0.1-rc.3 (DEV) / 2016-11-29
* Change in the ETL to make multi threaded per topic
* refactoring to avoid hardcoded topic name check in code

### 1.0.1-rc.2 (DEV) / 2016-11-21
* US4759: ETL Test Issues and Fixes Completed

### 1.0.1-rc.1 (DEV) / 2016-11-16
* US4496: Analyse and Remove GamePlayHistory table and update game stats reports
* US4495: Update LimitArchive on limit add/update actions
* US4494: Add fee in transactions in transaction reports
* US4591: ETL Changes for voided and reconcile wager transactions

### 1.0.0-rc.13 (DEV) / 2016-11-09
* US4478: Report-etl-service: Etl for Teams and Leagues

### 1.0.0-rc.12 (DEV) / 2016-11-08
* US4474: Report-etl-service: Update Deposit transaction implementation

### 1.0.0-rc.11 (DEV) / 2016-11-07
* US4474: Report-etl-service: Update Deposit transaction implementation

### 1.0.0-rc.10 (DEV) / 2016-11-04
* 372: Transaction report does not show win/wager unless they are sent in specific format

### 1.0.0-rc.9 (DEV) / 2016-11-02
* Sync call to wallet to update player or operator limit.

### 1.0.0-rc.8 (DEV) / 2016-10-28
* Defect Fixes in release 1.0.1-rc.23

### 1.0.0-rc.7 (DEV) / 2016-10-26
* Add deposit/withdrawel transactions
* Limit issue fix

### 1.0.0-rc.6 / 2016-10-26
* US4422 - Agent Login History Report-ETL-service implementation
* US4425  - AgentOperator SnapShot and Audit tables ETL implementation

### 1.0.0-rc.5 (DEV) / 2016-10-14
* Updated commons jar to 3.2.1 to include new fields from real-money topic messages

### 1.0.0-rc.4 (DEV) / 2016-10-13
* Negative Balance Report ETL
* Agent ETL
* Exclusion ETL
* Defect Fixes

### 1.0.0-rc.3 (DEV) / 2016-09-20
* Log enhancement
* Enabled ELK logging
* Error table insertion for invalid messages

### 1.0.0-rc.2 (DEV) / 2016-09-19
* All game Ids will be read from Wallet Kafka and all transactions will be in the transaction report
* If game id is unknown then the game name, game vertical, etc. will be [gameId]-Unknown
* Need to calculate and display the player before and after balance in the report

### 1.0.0-rc.1 (DEV) / 2016-09-16
* report etl service hibernate entities definition
* report etl service hibernate entities definition
* Etl processing for Wallet transactions
* Avro msg processing and entity mappings for all wallet transactions
