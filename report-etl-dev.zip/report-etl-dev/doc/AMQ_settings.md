AMQ Settings needed for report-etl-service
==========================================

#### Topic to queue re-direction
 
To achieve the multiple thread processing of certain topic messages , we have identified the JMSGroupId based topic to queue re-direction
The ETL Service will consume the re-directed queue messages with multiple threads
As agreed with other SCS owners, they will be publishing the messages to the identified topic name with the JMSGroupId in the message header.
The list of topics needs to be re-directed in AMQ are below:
            
1) wallet.transactions.committed.group topic 
2) exclusion-events-json.topic
3) purchase-send.group
        
    ```xml
    <destinationInterceptors>
              <virtualDestinationInterceptor>
                <virtualDestinations>
                <compositeTopic name="transaction-composite-dli">
                    <forwardTo>
                      <queue physicalName="transaction-dli-report" />
                      <topic physicalName="transaction-dli" />
                    </forwardTo>
                  </compositeTopic>
                  <compositeTopic name="transaction-composite-dlo">
                    <forwardTo>
                      <queue physicalName="transaction-dlo-report" />
                      <topic physicalName="transaction-dlo" />
                    </forwardTo>
                  </compositeTopic>
                  <compositeTopic name="gvi-composite-dli">
                    <forwardTo>
                      <queue physicalName="gvi-dli-report" />
                      <topic physicalName="gvi-dli" />
                    </forwardTo>
                  </compositeTopic>
                  <compositeTopic name="gvi-composite-dlo">
                    <forwardTo>
                      <queue physicalName="gvi-dlo-report" />
                      <topic physicalName="gvi-dlo" />
                    </forwardTo>
                  </compositeTopic>
                  <compositeTopic name="purchase-send.group">
                    <forwardTo>
                      <queue physicalName="purchase-send.queue" />
                    </forwardTo>
                  </compositeTopic>
                </virtualDestinations>
              </virtualDestinationInterceptor>
            </destinationInterceptors>
    ```
       
#### timeBeforeDispatchStarts settings

To make sure the queue message is evenly distributed based on the JMSGroupId , we need to have the timeBeforeDispatchStarts settings .
This will pause the message allocation to the (queue) consumers connected, till the defined time interval.
So that all the consumers are equally distributed based on the groupId value, otherwise all the messages will get allocate to single consumer as soon as one consumer is connected for the enqueued messages.
Since this settings pause the allocation for the n seconds defined, so in the gap , all other consumers will get connect and the messages will be correctly distributed based on the groupId to all the consumers.

```xml
<policyEntry queue="wallet.transactions.committed.queue" timeBeforeDispatchStarts="30000"/>
<policyEntry queue="exclusion-events-json.queue" timeBeforeDispatchStarts="30000"/>
<policyEntry queue="purchase-send.queue" timeBeforeDispatchStarts="30000"/>
```


Reference : http://activemq.apache.org/message-groups.html

    
#### schedulerSupport setting # depricated # no more we are using
This setting will make sure the scheduled delay delivery of messages , if mentioned in the headers.
This will help in the case of delayed reprocessing of the failure messages, this is needed for notification-broker service.

```xml
<broker xmlns="http://activemq.apache.org/schema/core" brokerName="localhost" dataDirectory="${activemq.data}" schedulerSupport="true">
```

 Reference : http://activemq.apache.org/delay-and-schedule-message-delivery.html
 
        
