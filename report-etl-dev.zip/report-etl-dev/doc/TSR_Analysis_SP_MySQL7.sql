-- ----------------------------------------------------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS `SP_PT_ERROR`;
DELIMITER $$
CREATE PROCEDURE `SP_PT_ERROR`(
  IN $Website CHAR(3),
  IN $PlayerId BIGINT(20),
  IN $MoneyType VARCHAR(250),
  IN $DateFrom DATETIME,
  IN $DateTo DATETIME,
  IN $TranId BIGINT(20)
)
BEGIN
	SELECT * FROM PlayerTransaction
	WHERE OperatorId=$Website
	AND TranId >= $TranId
	AND MoneyType= $MoneyType
	AND PlayerId=$PlayerId
	AND UpdatedDate >=$DateFrom
	AND UpdatedDate <=$DateTo
	AND TransactionStatus NOT IN ('completed')
	ORDER BY UpdatedDate DESC, TranId DESC;

END$$
DELIMITER ;
-- ----------------------------------------------------------------------------------------------------------------------

DROP PROCEDURE IF EXISTS `SP_FIND_MISSING_DATA_SYNC`;
DELIMITER $$
CREATE PROCEDURE `SP_FIND_MISSING_DATA_SYNC`(
  IN $fromRange BIGINT(20),
  IN $toRange BIGINT(20)
)
BEGIN

	SET SESSION GROUP_CONCAT_MAX_LEN = 10000000000000;
	SET @expected = -1;
	Select group_concat(missed) FROM (
	Select *,
	IF (@expected = -1, 'ok', IF(@expected+1 = eventId, 'ok', 'error')) AS rankCol, @expected+1 as missed,
	@expected AS expected,
	@expected := eventId
	FROM (
	Select Distinct EventId FROM JmsMessageDetails Where Topic iN ('transaction-dli-report','wallet.ledgers.created', 'transaction-dlo-report')
	AND EventId Between $fromRange AND $toRange
	Order By EventId ASC)y)t Where rankCol = 'error';

END$$
DELIMITER ;
-- ----------------------------------------------------------------------------------------------------------------------

DROP PROCEDURE IF EXISTS `SP_Rank_PT`;
DELIMITER $$
CREATE PROCEDURE `SP_Rank_PT`(
  IN $Website CHAR(3),
  IN $PlayerId BIGINT(20),
  IN $MoneyType VARCHAR(250),
  IN $DateFrom DATETIME,
  IN $DateTo DATETIME
)
BEGIN

			SET @cat = '';
            SET @prevTranId = 0;
            SET @rankStatus = 'ok';
            SET @expected = 0;
            SET @prevTranType = '';
	SELECT PlayerId, OperatorId, MoneyType, UpdatedDate, expected AS expectedBalanceBefore,
	expected+Amount AS expectedBalanceAfter, BalanceBefore,BalanceAfter,
	Amount, TransactionStatus, TransactionType, prevTranType, TranId, prevTranId FROM (
	SELECT *, @prevTranId AS prevTranId, @prevTranType AS prevTranType, @rankStatus := IF( @cat=CONCAT_WS('', PlayerId, OperatorId),
	IF(@expected= BalanceBefore, 'ok', 'error'), 'ok' ) AS rankCol,
	@expected AS expected,
	@expected := BalanceAfter, @cat := CONCAT_WS('', PlayerId, OperatorId),
	@prevTranId := TranId , @prevTranType := TransactionType
	FROM PlayerTransaction
	WHERE MoneyType=$MoneyType
	AND PlayerId=$PlayerId
	AND OperatorId = $Website
	AND UpdatedDate >= $DateFrom
	AND UpdatedDate <=$DateTo
	AND TransactionStatus NOT IN ('completed')
	ORDER BY PlayerId, OperatorId, MoneyType,UpdatedDate ASC,TranId ASC
	)t
	WHERE rankCol = 'error';
END$$
DELIMITER ;

-- ----------------------------------------------------------------------------------------------------------------------



DROP PROCEDURE IF EXISTS `SP_Rank_ST`;
DELIMITER $$
CREATE PROCEDURE `SP_Rank_ST`(
  IN $Website CHAR(3),
  IN $PlayerId BIGINT(20),
  IN $DateFrom DATETIME,
  IN $DateTo DATETIME
)
BEGIN

			SET @cat = '';
            SET @prevTransactionId = 0;
            SET @rankStatus = 'ok';
            SET @expected = 0;
            SET @prevTranType = '';
	SELECT PlayerId, OperatorId, SubscriptionId, UpdatedDate, expected AS expectedBalanceBefore,
	expected+Amount AS expectedBalanceAfter, BalanceBefore,BalanceAfter,
	Amount, STATUS, TransactionType, prevTranType, TransactionId, prevTransactionId FROM (
	SELECT *, @prevTransactionId AS prevTransactionId, @prevTranType AS prevTranType, @rankStatus := IF( @cat=CONCAT_WS('', PlayerId, OperatorId),
	IF(@expected= BalanceBefore, 'ok', 'error'), 'ok' ) AS rankCol,
	@expected AS expected,
	@expected := BalanceAfter, @cat := CONCAT_WS('', PlayerId, OperatorId),
	@prevTransactionId := TransactionId , @prevTranType := TransactionType
	FROM SubscriptionTransactions
	WHERE PlayerId=$PlayerId
	AND OperatorId = $Website
	AND UpdatedDate >= $DateFrom
	AND UpdatedDate <=$DateTo
	AND STATUS NOT IN ('completed')
	ORDER BY PlayerId, OperatorId, SubscriptionId,UpdatedDate ASC,TransactionId ASC
	)t
	WHERE rankCol = 'error';
END$$
DELIMITER ;
-- ----------------------------------------------------------------------------------------------------------------------
