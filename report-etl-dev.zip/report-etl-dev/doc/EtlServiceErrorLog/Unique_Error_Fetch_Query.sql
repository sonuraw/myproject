-- Fetch Unique Errors By Topic,Type,ErrorMessage

select Topic,Type,ErrorMessage,count(*),Any_value(ErrorStackTrace),Any_Value(ErrorSourceData) from EtlServiceErrorLog where CreatedDate > '2017-11-16' 
 group by Topic,Type,ErrorMessage  order by count(*) desc  
 
-- Fetch Unique Errors By Topic,Type
 
select ANY_VALUE(CorrelationId),Type,ANY_VALUE(ErrorMessage),count(*),Any_value(ErrorStackTrace),Any_Value(ErrorSourceData) from EtlServiceErrorLog where CreatedDate > '2017-11-16' 
 group by Topic,Type  order by count(*) desc   