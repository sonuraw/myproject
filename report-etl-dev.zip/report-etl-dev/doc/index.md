# Report ETL Service

## Description

The Report ETL Service consumes kafka messages and processes them to store in the report db.

## Documentation

* [Docker Build Guide](DockerBuild.md) - Instructions to build docker

## Release Notes: ##

* [Changelog](changes.md) - release notes


## Support Links ##

- [Events Data Sync](data_sync_process.md) - Events Data Sync
- [Report ETL Errors Monitoring](report-etl-errors-check.md) - Report ETL Errors Monitoring
- [Report ETL Service Errors Health API](report-etl-service-errors-health-api.md) - Report ETL Service Errors Health API
- [Manual Partition](ManualPartitionDocumentation.md) - Manual Partition
- [AMQ Settings](AMQ_settings.md) - AMQ Settings
- [Transaction Status Changes Flow](wallet_transaction_status_changes.pdf) - Transaction Status Changes Flow
- [Mysql Lock Detection](DC2-Switch-Lock.md) - Mysql Lock Detection
- [Report-Gvi Wager Count Check](Report_Gvi_WagerSync.md) - Report-Gvi Wager Count Check
- [Report-Profile Count Check](Report_Profile_DataSync.md) - Report-Profile Count Sync Check
- [Batch-Execution event details](events/batch-execution.md) - Batch-Execution event details

