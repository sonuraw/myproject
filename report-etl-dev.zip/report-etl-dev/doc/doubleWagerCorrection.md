## Steps to correcting double wager issue in Report DB

 - Get the corrupted wager Id lists by running below query
    ```sh
    SET SESSION GROUP_CONCAT_MAX_LEN=330000009999;
    select group_concat(Id) from Wager where CreationDate >= "2018-09-01 00:00:00" group by Id having count(Id) > 1;
    ```


 - Once got the wagerId list select the rows `from GVI wager` table and imnport the same `into Report DB "tmp_gvi_wager"` table.
    ```sh
    select * from wager where id IN (MissingWagerIdList);
    ```


 - After data import into report DB from GVI, `manuplate the data` that should suited for `report DB Wager table` by running the below query.
    ```sh
    INSERT INTO tmp_report_Wager(`Id`, `EventType`,`PlayerId`,`WagerSetId`,`ExternalWagerId`,`Brand`,`GameId`,`ExternalURL`,`Channel`,`State`,`CreationDate`,`UpdatedDate`,`ExternalCreationDate`,`Value`,`NotifyWin`,`RoundId`,`ExpectedEndDate`,
    `Currency`,`OperatorId`,`PreviousStatus`)
    select W.id, "Wager-Created", W.player_id, W.wager_set_id, W.external_id, W.brand, W.game, W.sub_url, W.channel, W.state, W.created_at, 
    W.updated_at, W.external_created_time, -(W.amount*1000), W.notify_win, W.round_id, W.expected_end_date, "DKK", W.operator_id, W.state
    from tmp_gvi_wager W where id IN (MissingWagerIdList);
    ```


 - Delete the corrupted data from report.Wager table.
    ```sh
    delete from Wager where Id IN (MissingWagerIdList);
    ```
    
    
 - Select and insert `into report.Wager` table `from report.tmp_report_Wager`.
    ```sh
    INSERT INTO report.Wager(`Id`, `EventType`,`PlayerId`,`WagerSetId`,`ExternalWagerId`,`Brand`,`GameId`,`ExternalURL`,`Channel`,`State`,`UpdatedDate`,`CreationDate`,`ExternalCreationDate`,`Value`,`NotifyWin`,`RoundId`,`ExpectedEndDate`,
    `Currency`,`OperatorId`,`PreviousStatus`)
    select `Id`, `EventType`,`PlayerId`,`WagerSetId`,`ExternalWagerId`,`Brand`,`GameId`,`ExternalURL`,`Channel`,`State`,`CreationDate`,`UpdatedDate`,`ExternalCreationDate`,`Value`,`NotifyWin`,`RoundId`,`ExpectedEndDate`,
    `Currency`,`OperatorId`,`PreviousStatus` from tmp_report_Wager W where id IN (MissingWagerIdList);
    ```


 - Insert manually updated details into Archive table.
    ```sh
    INSERT INTO report.`WagerArchive`(`RevisionDate`, `RevisionState`, `Id`, `EventType`, `PlayerId`, `WagerSetId`, `ExternalWagerId`, `Brand`, `GameId`, `ExternalURL`, `Channel`, `State`, `UpdatedDate`, `CreationDate`, `ExternalCreationDate`, `Value`, `NotifyWin`, `RoundId`, `ExpectedEndDate`, `Currency`, `OperatorId`, `IpAddress`, `SubscriptionId`, `SessionId`, `PreviousStatus`, `IsReprocessed`, `ReprocessedDate`, `IsReConciled`, `WagerType`) SELECT NOW(), "wager-Created", id, "wager-Created", PlayerId, WagerSetId, ExternalWagerId, Brand, GameId, ExternalURL, Channel, State, UpdatedDate, CreationDate, ExternalCreationDate, Value, NotifyWin, RoundId, ExpectedEndDate, Currency, OperatorId, IpAddress, SubscriptionId, SessionId, PreviousStatus, IsReprocessed, ReprocessedDate, IsReConciled, WagerType FROM report.Wager WHERE Id IN (MissingWagerIdList);
     ```
