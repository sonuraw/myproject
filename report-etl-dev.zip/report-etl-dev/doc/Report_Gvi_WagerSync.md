## Steps to check the gvi wager count wise in report DB 

* Sync checking can be done by comparing the wager ids range only , date wise also we could check , but gvi.wager doest n't have expected index to quick check.
* So we need to use the id based count check only like taking the first wager id from the given start date and last wager in the given end date and these two wager id's will be used in the between range query.

# Steps
- to get the min and max  wager id to compare 
```sql 
Select * FROM gvi.wager Where created_at >= '2018-11-22' Order By Id ASC LIMIT 1;
Select * FROM gvi.wager Where created_at <= '2018-11-25' Order By Id DESC LIMIT 1;
```

- check the state wise count check in both the DB

```sql
use report;
Select State, Count(Id) FROM Wager Where ID Between 153458669218 AND 153461560126 Group By State;

use gvi;
Select state, Count(Id) FROM gvi.wager Where Id Between  153458669218 AND 153461560126 group BY state;

```

- look for differences, if started in report has more values than gvi , take gvi started wagerids and check what are all the started wager ids in report db other than in GVI db.

```sql

use gvi;
SET SESSION GROUP_CONCAT_MAX_LEN=330000009999;
Select GROUP_CONCAT(Id) From gvi.wager Where id Between 153461560126 AND 153462836663 And State = 'STARTED';

use report;
SET SESSION GROUP_CONCAT_MAX_LEN=330000009999;
Select GROUP_CONCAT(Id) From Wager Where ID Between 153461560126 AND 153462836663 And State = 'STARTED' AND Id NOT In (
-- replace with ids
);

-- for reverse case, take the ids from report DB and check the extra records in gvi DB by using the below query
use gvi;
SET SESSION GROUP_CONCAT_MAX_LEN=330000009999;
Select GROUP_CONCAT(Id) FROM gvi.wager Where ID between 153461560126 AND 153462836663 AND State = 'STARTED' AND Id NOT In (
-- replace with ids
);

```

- take the extra ids and insert into one temp table in report db for analysis

```sql 

INSERT INTO tmp_wager_ids
Select Id FROM Wager Where Id In (
-- replace with ids
);

```

- checking the latest state is not updated correctly in report.Wager but its there in report.WagerArchive can be checked by this - this case wont occur hereafter 

```sql

SET @rank := 0;
SET @tranId := 0;

SET SESSION GROUP_CONCAT_MAX_LEN=330000009999;

Select
-- CONCAT_WS('', "Update Wager Set State = '", t.State, "', UpdatedDate = '", t.UpdatedDate , "' ,PreviousStatus = '", t.PreviousStatus,"' Where Id = ", t.Id, ";")  AS query 
-- GROUP_CONCAT(t.Id)
t.*
FROM Wager left join (Select Id, State,UpdatedDate, PreviousStatus FROM (
Select Id, State, PreviousStatus, UpdatedDate, @rank := IF(@tranId <> Id, 1, @rank+1) AS rank,
 @tranId := Id FROM  
 ( Select *  FROM WagerArchive_old Where ID IN (Select Id From tmp_wager_ids)
  UNION 
 Select *  FROM WagerArchive Where ID In (Select Id From tmp_wager_ids)
 )mt
 Order By Id DESC, UpdatedDate DESC, RevisionNumber DESC)u where rank =1)t on Wager.id = t.Id
 Where Wager.State <> t.State

 ```

 - check the state in gvi.wager table is getting matched with the above result (state, updatedDate), if its matching , get the update statement from the above query itself and run the update in report.Wager along with its archive entry by using the below query 
 
 - Make sure you are updating after confirming with gvi.wager 


 ```sql

 INSERT INTO report.`WagerArchive`(`RevisionDate`, `RevisionState`, `Id`, `EventType`, `PlayerId`, `WagerSetId`, `ExternalWagerId`, `Brand`, `GameId`, 
`ExternalURL`, `Channel`, `State`, `UpdatedDate`, `CreationDate`, `ExternalCreationDate`, `Value`, `NotifyWin`, `RoundId`, `ExpectedEndDate`, `Currency`, 
`OperatorId`, `IpAddress`, `SubscriptionId`, `SessionId`, `PreviousStatus`, `IsReprocessed`, `ReprocessedDate`, `IsReConciled`, `WagerType`) 
SELECT UpdatedDate, "wager-updated", id, "wager-updated", PlayerId, WagerSetId, ExternalWagerId, Brand, GameId, ExternalURL, Channel, State, UpdatedDate,
 CreationDate, ExternalCreationDate, Value, NotifyWin, RoundId, ExpectedEndDate, Currency, OperatorId, IpAddress, SubscriptionId, SessionId,
 PreviousStatus, IsReprocessed, ReprocessedDate, IsReConciled, WagerType 

FROM report.Wager WHERE Id IN (

);

 ```

## Steps to check the gvi wager amount wise in report DB 

- run the below queries to get the amount in both the SCS

```sql

use report;
Select State, Sum(ABS(Value)) / 1000 FROM Wager Where ID Between 153458669218 AND 153461560126 Group By State;

use gvi;
Select state, SUM(amount) FROM gvi.wager Where Id Between  153458669218 AND 153461560126 group BY state;

```

- if any difference is identified, get the players based wager sum for the particular state

```sql

use gvi;
Select player_id AS PlayerId, operator_id AS OperatorId, Sum(amount) As Amount  FROM gvi.wager Where 
Id Between 153458669218 AND 153461560126 
AND State = 'CANCELLED'
AND amount <> 0
Group BY player_id, operator_id;


use report;
Select PlayerId, OperatorId,Sum(ABS(Value)) / 1000 As Amount From Wager Where 
Id Between 153458669218 AND 153461560126 
anD State = 'Cancelled'
AND Value <>0
Group BY PlayerId, OperatorId;

```

- get the result set exported from above queries and dump into any local / test environments for analysis - use table creation scripts mentioned below - here I used analysis DB , which was created for this purpose

```sql

use analysis;
CREATE TABLE `gvisum` (
  `PlayerId` bigint(20) NOT NULL,
  `OperatorId` char(3) NOT NULL,
  `Amount` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`PlayerId`,`OperatorId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


use analysis;
CREATE TABLE `reportsum` (
  `PlayerId` bigint(20) NOT NULL,
  `OperatorId` char(3) NOT NULL,
  `Amount` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`PlayerId`,`OperatorId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

use analysis;
CREATE TABLE `reportwager` (
  `Id` bigint(20) DEFAULT NULL,
  `Amount` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

use analysis;
CREATE TABLE `gviwager` (
  `Id` bigint(20) NOT NULL,
  `Amount` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


```

- now check which players is having amount mismatch 

```sql

use analysis;
SELECT * FROM gviSum G LEFT JOIN reportSum R ON R.PlayerId = G.PlayerId AND G.OperatorId = R.OperatorId 
WHERE R.Amount <> G.Amount
AND G.OperatorId = 'DLI'; -- repeat the process for DLO 

```

- use the playerid's list from the above query to get the wager ids exactly which is having amount mismatch 

```sql

use gvi;
Select id, amount AS Amount FROM gvi.wager Where player_id IN (
-- replace with player ids
)
AND amount <> 0
AND operator_id = 'DLI' AND State = 'PLAYED' 
AND Id Between 153458669218 AND 153461560126;

use report;
Select Id, ABS(Value) / 1000 As Amount FROM Wager Where PlayerId IN (
-- replace with player ids
)
AND OperatorId = 'DLI' 
AND Value <>0 AND State = 'PLAYED' 
AND Id Between 153458669218 AND 153461560126;

```

- export the result to local DB or somewhere and run the below query to get the exact wager Ids

```sql

use analysis;
Select * FROM gviWager G LEFT JOIN reportWager R On G.id = R.Id
Where G.Amount <> R.Amount
LIMIT 100000;

```

- After identifying the problem making wagerId from the above query results, if a single wager id is having multiple transactions, do a sum of all transaction amount and check the amount is matching with our wager and with GVI wager table,problem could be on gvi side too, if so, check with gvi team ( this is a known issue, gvi not accounting all the transactions, if a single wager is having multiple transactions)

```sql

use report;
Select * FROM Wager Where Id = 153460376441;

Select Sum(Amount) FROM PlayerTransaction Where WagerId = 153460376441 AND TransactionType NOT in ('win', 'debit');

```

## Already verified Id's range and obervations

- Count wise check 

```sh

153430115459 AND 153430335725

153430335725 AND 153433638619  - 8 records missing in gvi (153431045807,153431045808,153433309668,153433312365,153433313824,153433317251,153433318390,153433325105,153433329726,153433329727)

153433638619 AND 153434000000 - okay 

153434000000 AND 153440125268 - 153436862883,153437530586,153437536018,153437537007 - records missing in gvi

153440125268 AND 153449269488 - 5 only (seems data correction to STARTED in gvi without sending that to report , still PLAYED in report) - 153440802685,153441695072,153441750924,153443426562,153445525539

153449269488 AND 153454960345 - okay

153454960345 AND 153458669218 - (153455668342,153456147138,153457787930,153457789687,153457791105) - wager status was played / cancelled in gvi , but wallet latest amq message says started

153458669218 AND 153461560126 - okay

153461560126 AND 153462836663 - 1 issue   - except 153462342740 , network issue

153462836663 AND 153470455855

153470455855 AND 153482496857  - 4 records with played and cancelled

153482496857 AND 153495559992 - 4 records with played and cancelled

153495559992 AND 153505973422 -- 


Select * FROM JmsMessageDetails Where eventId In (80336254,80336246) AND Topic = 'gvi-dli-report';
Select * FROM JmsMessageDetails Where EventId In (920412333,920412406) ANd Topic = 'transaction-dli-report';

```

- Amount Wise 

```sh

153458669218 AND 153461560126 - cancelled still have amount in gvi table , should be zero 153459642530 - 24 records like that - details shared to Bastien 

```
