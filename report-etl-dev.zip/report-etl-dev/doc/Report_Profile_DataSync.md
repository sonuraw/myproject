# Profile and Report database data sync verification

Major report tables for data sync periodic verification (May be every week once) based on profile SCS events is listed below.
Result output of profile, report database queries should be manually verified for sync, if there are differences to alert and analyze/take corrective action to the developent team.

## PlayerProfile:

### By total record count

#### profile database query:
```sql
SELECT count(1) count FROM profile.user where website_origin_id = 67; #DLI
SELECT count(1) count FROM profile.user where website_origin_id = 68; #DLO
```

#### report database query:
```sql
SELECT count(1) count  from report.PlayerProfile where OperatorId = 'DLI';
SELECT count(1) count  from report.PlayerProfile where OperatorId = 'DLO';
```

### By Status level count:

#### profile database query:
```sql
select case state when  1 then 'active'
when 2 then 'pending'
when 3 then 'locked'
when 4 then 'closed' end status, count(1) count  from profile.user where website_origin_id = 67 #DLI
group by state;

select case state when  1 then 'active'
when 2 then 'pending'
when 3 then 'locked'
when 4 then 'closed' end status, count(1) count  from profile.user where website_origin_id = 68 #DLO
group by state;
```

#### report database query:
```sql
SELECT status, count(1) count  from report.PlayerProfile where OperatorId = 'DLI' group by status;
SELECT status, count(1) count from report.PlayerProfile where OperatorId = 'DLO' group by status;
```

## PlayerPaymentMethod:

### By total record count

#### profile database query:
```sql
SELECT count(1) count FROM profile.user_payment_method;
```

### report database query:
```sql
SELECT count(1) count  from report.PlayerPaymentMethod;
```

### By IsPreferred, IsValidated count:

#### profile database query:
```sql
SELECT count(1) FROM profile.user_payment_method where is_preferred = 1;
SELECT count(1) FROM profile.user_payment_method where is_validated = 1;
```

### report database query:
```sql
SELECT count(1) count from report.PlayerPaymentMethod where IsPreferred = 1;
SELECT count(1) count from report.PlayerPaymentMethod where IsValid = 1;
```