Error Check in report-etl
==========================================

#### Error check 
DC2 Kibana URL : http://10.75.101.116:5601/app/kibana

### to check the generic error 
```text
container: "report-etl" AND "Error"
```

### to check the error related to one particular AMQ event
here use the JmsMessageId in the search and can seen the logs printed related to that message processing
```text
container: "report-etl" AND "Error" AND "ID:dspdwr24.danskespil.scigames.at-23194-1554786426504-1:1:20601432:1:1"
```

### to check the messages are consumed by report-etl via Kibana
```text
container: "report-etl" AND "delay" AND "ETL Metrics"
```

### to check the messages are consumed by report-etl containers via report DB table
use the additional topic name filter if required
```roomsql
Select * FROM JmsMessageDetails Order BY ID DESC LIMIT 10;
```


#### To check the errors in EtlServiceErrorLog 
here the warning is if the retry count is above 10 , then it could be an issue, less than 10, may get success in the next tries, 
as it might be waiting for other data from other scs to be processed by another thread
so look for retryCount > 10

use the additional topic name filter if required
```roomsql
Select * FROM EtlServiceErrorLog Where ProcessedStatus = 'Error' AND RetryCount > 10 ANd CreatedDate >= '2019-03-01' Order BY ID DESC;
```

#### check the message processing in AMQ
### in topic subscibers
1) all the topic subscribers related to report will start with the client id, report-etl
2) there should n't be any offline subscribers 
3) look for the pending messages count for the above identified subscribers- should n't be in alarming state
4) and in the queues too , pending messages should not be in alarming state.
5) Also, see the enqueue dequeue rate in terms of increasing . if the enqueue is increasing , but dequeue is stagnant , some lock happened in report db related to that event processing   


#### Disabling Reprocess errors cron 
if the load is higher in terms of AMQ, (more pending messages to be processed, if you feel it's slow down because of Etl errors reprocess)

### Identify which instance is doing the cron activity 
1) Check the kibana which container is receiving the messages from topic (not queues), example with access-log or session 
```text
container: "report-etl" AND "delay" AND "ETL Metrics" AND "session"
```

2) note the container_image in the above kibana result
3) log-in to the putty and go inside the above container

### Change steps
1) check crontab -e


![report-etl-crons](./assets/report-etl-crons.PNG "Report-ETL-crons")

2) there will be three crons running - data sync , reprocess error , reprocess concurrence message
3) disable the reprocess cron alone
4) don't forget to revert it once you feel, the load is at okay level .
5) don't leave the cron in disabled state for more time, customer team may create any other issues in jira, as timely updates are not happening (in case of gvi status changes) 
