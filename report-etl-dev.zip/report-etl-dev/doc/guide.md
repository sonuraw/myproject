How to Deploy, Use & Manage the Report ETL Service
=======================================
The service is packed as a [Docker][1] container, and is executed by starting up an instance of this container. Before start using the service we first need to provide and configure
few configuration properties file. The details about these conf files is given in the Configuration Files section below, 

Steps to start the service
--------------------------
The below 2 steps are required to start the Report ETL Service,

* Prepare the app.yml as shown in Configuration Files section and then copy it to some host folder.
* Prepare the docker-compose.yml file as shown in Start the Service section and run the docker-compose command.

The details about the steps are given below in respective sections below.

Configuration Files
-------------------
The service currently has configuration files which are listed below,

* report-etl.yml  : It is an application level settings file and have settings for cache, log and etc.

All these files should be created if not present and put inside the same folder on the host where you are going to run the service and later that folder need to be mount 
inside docker which we will see in Docker section.

The sample structure and content of properties files is shown below. You can copy and use the same for configuration, make sure to properly name the files.


sample **report-etl.yml** file

This is an application level configuration file. contains settings for zookeeper, logger and etc.

```
# Report Path info
hibernateConfigPath : /u01/report-etl-service/config/

topics:
  - real-money
  - player-adjustment
  
#Kafka consumer properties
consumer:
  zookeeper.connect: log.sg-platform-vpc.wms.com:49186
  group.id: report-etl-service-dev
  zookeeper.session.timeout.ms: 3000
  zookeeper.sync.time.ms: 250
  auto.offset.reset: largest
  auto.commit.enable: false
  rebalance.backoff.ms: 3000

```


----------



Start the Service
-----------------

Mentioned below the steps to start the service,

* Docker compose : It will start all the dependent containers along with the Report ETL Service container and is the preferred option.


### Docker Compose (Preferred option)

Docker compose is a tool for defining and running complex applications with
Docker. To spin the application using compose, you need to specify its
structure using YAML configuration file named *docker-compose.yml*. Service
configuration template is shown below.

```
report-etl-service-dev:
  image: docker.sg-platform-vpc.wms.com/platform/report-etl-service:dev
  log_driver: syslog
  log_opt:
    syslog-address: "udp://log.sg-platform-vpc.wms.com:25826"
  restart: always
  volumes:
    - ./conf:/opt/conf

report-etl-service-mysql:
  image: mysql:5.7.10
  container_name: mysql
  restart: always
  log_driver: syslog
  log_opt:
    syslog-address: "udp://log.sg-platform-vpc.wms.com:25826"
    syslog-tag: "report-etl-service-mysql"
  environment:
    - MYSQL_ROOT_PASSWORD=password
    - MYSQL_DATABASE=test
    - MYSQL_USER=test
    - MYSQL_PASSWORD=password
  ports:
    - "3306:3306"
  volumes:
    - ./mysql/database:/var/lib/mysql

```


sample **hibernate.cfg.xml**

```
<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE hibernate-configuration PUBLIC
        "-//Hibernate/Hibernate Configuration DTD 3.0//EN"
        "http://hibernate.sourceforge.net/hibernate-configuration-3.0.dtd">

<hibernate-configuration>
    <session-factory>
        <!-- Database connection settings -->
        <property name="connection.driver_class">com.mysql.jdbc.Driver</property>
        <property name="connection.url">jdbc:mysql://app2.sg-platform-vpc.wms.com:3306/upam_dev</property>
        <property name="connection.username">root</property>
        <property name="connection.password">abc@123</property>
        <property name="connection.pool_size">1</property>
        <property name="dialect">org.hibernate.dialect.MySQLDialect</property>
        <property name="current_session_context_class">thread</property>
        <property name="cache.provider_class">org.hibernate.cache.NoCacheProvider</property>
        <property name="show_sql">true</property>
        <property name="hbm2ddl.auto">validate</property>

        <property name="hibernate.connection.provider_class">org.hibernate.connection.C3P0ConnectionProvider</property>
        <property name="hibernate.c3p0.validate">true</property>
        <property name="hibernate.c3p0.min_size">5</property>
        <property name="hibernate.c3p0.max_size">20</property>
        <property name="hibernate.c3p0.timeout">300</property>
        <property name="hibernate.c3p0.max_statements">50</property>
        <property name="hibernate.c3p0.idle_test_period">120</property>
        
       <mapping class="com.sciplay.report.etl.Entities.WagerEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.WinningEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.PlayerEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.GameDetailsEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.CountryEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.PlayerTranEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.GamePlayHistoryEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.PlayerBalanceEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.ErrorsLogEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.GameCategoriesEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.GameCategoriesArchiveEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.Exclusion.SelfExclusionArchiveEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.Exclusion.SelfExclusionEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.PlayerAddressEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.PlayerInfoEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.PlayerSessionEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.Exclusion.PlayerSelfExclusionEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.Exclusion.GameRestrictionArchiveEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.Exclusion.GameRestrictionEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.Exclusion.PlayerGameExclusionEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.GameProvidersEntity"/>
       <mapping class="com.sciplay.report.etl.Entities.GameSubCategoriesEntity"/>
        <mapping class="com.sciplay.report.etl.Entities.GameSubCategoriesArchiveEntity"/>
        <mapping class="com.sciplay.report.etl.Entities.PlayerAppliedLimitEntity"/>
        <mapping class="com.sciplay.report.etl.Entities.GameTypesEntity"/>
        <mapping class="com.sciplay.report.etl.Entities.GameTypesArchiveEntity"/>
        <mapping class="com.sciplay.report.etl.Entities.LimitCategoryEntity"/>
        <mapping class="com.sciplay.report.etl.Entities.GameProvidersArchiveEntity"/>
        <mapping class="com.sciplay.report.etl.Entities.GamesEntity"/>
         <mapping class="com.sciplay.report.etl.Entities.GamesArchiveEntity"/>
        <mapping class="com.sciplay.report.etl.Entities.AgentProfileEntity"/>
        <mapping class="com.sciplay.report.etl.Entities.AgentProfileArchiveEntity"/>
        <mapping class="com.sciplay.report.etl.Entities.AgentChangeNotificationEntity"/>
        <mapping class="com.sciplay.report.etl.Entities.AgentAccessListEntity"/>
        <mapping class="com.sciplay.report.etl.Entities.AgentPermissionArchiveEntity"/>
        <mapping class="com.sciplay.report.etl.Entities.AgentAccessChangeNotificationEntity"/>
        <mapping class="com.sciplay.report.etl.Entities.AgentOperatorListEntity"/>
        <mapping class="com.sciplay.report.etl.Entities.AgentOperatorArchiveEntity"/>
        <mapping class="com.sciplay.report.etl.Entities.NegativeBalanceEntity"/>

    </session-factory>
</hibernate-configuration>
```


The port number used on the target host may be chosen independently of what the
service internally uses. This port number is used for forwarding request from
the host toward the service. Finally, the version number is optional, and may
specify a concrete version or refer to latest[-dev] (for example, latest-dev
means give me the latest development version of the product). Otherwise, by
omitting the version number (or choosing latest) the latest stable release will
be pulled from the registry.

Necessary directories need to be created that needs to be mounted for data as well as config files. 

Container configured in this manner can be started and created using the
following command:

```
docker-compose up -d
```

To check whether the service has been properly started up, the following 
command should be summoned: 

```
docker ps
```

To list both started and stopped instances, next command should be issued:

```
docker ps -a
```

To stop the service, the following command should be issued:

```
docker-compose stop
```

To remove the *stopped* service instance use:

```
docker-compose rm
```

Removing an instance is useful to save space, as well as to allow the 
usage of the same name (see the --name option) for the new instance. 
Docker will complain if the name is already "occupied", though.


----------



Updating the Docker Container
-----------------------------
In order to switch to a different version of the PW service the user should first stop the currently running instance. Afterward a new version should
be specified in the 'run' command (see above).

It is important to note that by using the 'latest-dev' tag the latest version of the software (located inside the Docker registry) will only be
downloaded if there is no image with that tag on the local machine. In other words, using 'latest-dev' will not always trigger a download of the 
new image. To assure that you will download the latest revision the current image tagged with 'latest-dev' should be deleted first.
To list all the images present on the local machine issue:

```
docker images
```

The desired image should be referenced by its image number. To remove an image issue:

```
docker rmi <image number>
```

Docker will only let you to remove images, which do not have running instances associated with them.


The meaning of the fields are explained in the model descriptions (see the REST API description).

  [1]: http://www.docker.com
  [2]: http://kafka.apache.org/
  [3]: http://zookeeper.apache.org/

[AMQ related settings](./AMQ_settings.md)
