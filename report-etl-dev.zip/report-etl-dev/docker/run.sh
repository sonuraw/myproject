#!/bin/sh

# cron hardlink counter workaround
# touch /etc/cron.d/CronJob
# chmod 644 /etc/cron.d/CronJob

cd /u01/report-etl-service

# copy the default config files to the main config directory which can be mounted
cp -u --backup=simple config/default/* config/

sleep $REPORT_ETL_START_DELAY

java $REPORT_ETL_SERVICE_JAVA_OPTS -jar report-etl-service.jar server /opt/conf/report-etl.yml
